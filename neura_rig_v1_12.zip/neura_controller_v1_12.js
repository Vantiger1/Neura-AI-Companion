
(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("neuraRig not found"); return; }
  const clamp01=x=>Math.max(0,Math.min(1,x));
  // ensure highlights
  function ensureHighlights(){
    ["L","R"].forEach(side=>{
      const eye = document.querySelector(`#eye_${side}`);
      if(!eye) return;
      if(!document.querySelector(`#hl_${side}`)){
        const hl = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
        hl.setAttribute("id", `hl_${side}`);
        hl.setAttribute("rx","6"); hl.setAttribute("ry","4");
        hl.setAttribute("fill","#ffffff"); hl.setAttribute("opacity","0.85");
        eye.appendChild(hl);
      }
    });
  } ensureHighlights();
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };
  function _applyGaze(dx,dy){
    [["L",460],["R",540]].forEach(([s,cx])=>{
      const i=$(`#iris_${s}`), p=$(`#pupil_${s}`), h=$(`#hl_${s}`);
      const x=cx+dx, y=780+dy;
      if(i){ i.setAttribute("cx",x); i.setAttribute("cy",y); }
      if(p){ p.setAttribute("cx",x); p.setAttribute("cy",y); }
      if(h){ h.setAttribute("cx", x-6); h.setAttribute("cy", y-6); }
    });
  }
  function setGaze(dx,dy){ _applyGaze(dx,dy); }
  function setEyeOpen(side, open){
    const span=22, u=$(`#lidU_${side}`), l=$(`#lidL_${side}`);
    if(!u||!l) return;
    const upperH=(1-open)*span, lowerH=(1-open)*span;
    u.setAttribute("y",780-22); u.setAttribute("height",upperH);
    l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
  }
  function setLids(open=1){
    const L = Array.isArray(open)? open[0]: open;
    const R = Array.isArray(open)? (open[1]??open[0]): open;
    setEyeOpen("L", clamp01(L)); setEyeOpen("R", clamp01(R));
  }
  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }
  // Blink with glint on reopen
  let blinking=false, blinkSkew=0;
  function setBlinkAsymmetry(skew=0){ blinkSkew=Math.max(-1, Math.min(1, skew)); }
  function glintFlash(){
    ["L","R"].forEach(s=>{ const h=$(`#hl_${s}`); if(!h) return;
      h.setAttribute("opacity","1"); h.setAttribute("rx","8"); h.setAttribute("ry","5");
      setTimeout(()=>{ h.setAttribute("opacity","0.85"); h.setAttribute("rx","6"); h.setAttribute("ry","4"); }, 90);
    });
  }
  function blinkOnce(duration=120){
    const skewMs = 40 * blinkSkew;
    setTimeout(()=> setLids([0,1]), Math.max(0, -skewMs));
    setTimeout(()=> setLids([1,0]), Math.max(0,  skewMs));
    setTimeout(()=> { setLids(1); glintFlash(); }, duration + Math.abs(skewMs));
  }
  function autoBlink(on=true, min=2200, max=5200){
    blinking=on;
    const loop=()=>{ if(!blinking) return; blinkOnce(120); setTimeout(loop, Math.random()*(max-min)+min); };
    if(on) loop();
  }
  
  function showViseme(n){
 $$(".viseme").forEach(v=>v.classList.add("hidden")); (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden"); }
  function setAffect(){} // placeholder
  function setPose(p={}){ [["#head","head"]].forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); }); }
  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=clamp01(i); }
  function setAmbientLuminance(l){ l=clamp01(l); setPupil(10 - 7*l); }
  
  function saccadeBurst(intensity=1){
    const step=(dx,dy,delay)=> setTimeout(()=>{ 
      setGaze(dx,dy);
    }, delay);
    const dx1=(Math.random()-.5)*4*intensity, dy1=(Math.random()-.5)*3*intensity;
    const dx2=(Math.random()-.5)*2*intensity, dy2=(Math.random()-.5)*2*intensity;
    step(dx1,dy1, 0);
    step(dx1+dx2, dy1+dy2, 60);
    step(0,0, 160);
  }
  
  const EASE = {
    calm: t=>t*t*(3-2*t),                // smoothstep
    focused: t=>t<.3? (t/.3) : 1-(1-t)/(1-.3), // fast-in
    amused: t=>1- Math.pow(1-t, 2.2),    // ease-out
    sad: t=>Math.pow(t,1.8),             // ease-in
    surprised: t=>t<.5? (2*t*t) : 1- Math.pow(-2*t+2,2)/2
  };
  function transitionAffect(target, ms=220, mode='calm'){
    const ease = EASE[mode]||EASE.calm;
    const bl0=0, sm0=0;
    const t0=performance.now();
    function frame(){
      const u=Math.min(1, (performance.now()-t0)/ms);
      const e=ease(u);
      const browLift = (target.browLift||0)*e + bl0*(1-e);
      const smile    = (target.smile||0)*e + sm0*(1-e);
      setAffect({browLift, smile});
      if(u<1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }
  
  let attentionOn=false, attTimer=null, hotspots=[[6,-2],[-6,-2],[0,3]];
  function setHotspots(list){ if(Array.isArray(list)&&list.length) hotspots=list; }
  function idleAttention(on=true, interval=[2600, 5200]){
    attentionOn=on;
    if(attTimer) { clearTimeout(attTimer); attTimer=null; }
    const loop=()=>{
      if(!attentionOn) return;
      const [dx,dy] = hotspots[Math.floor(Math.random()*hotspots.length)];
      saccadeBurst(.9);
      setTimeout(()=> setGaze(dx,dy), 70);
      attTimer = setTimeout(loop, Math.random()*(interval[1]-interval[0])+interval[0]);
    };
    if(on) loop();
  }
  const API={setGaze,setLids,setPupil,blinkOnce,autoBlink,setBlinkAsymmetry,showViseme,setPose,setGlow, setAmbientLuminance, saccadeBurst, transitionAffect, idleAttention, setHotspots};
  global.NeuraRig=API;
})(window);