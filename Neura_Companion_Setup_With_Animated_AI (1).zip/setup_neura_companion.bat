@echo off
TITLE Neura Companion - Personalized AI Setup
COLOR 0B
echo.
echo 💠 [Neura]: Hello! I'm Neura, your personal companion.
echo 💠 [Neura]: Let's get you all set up. Please sit back and relax while I work my magic...
echo.

REM === Create Folder Structure ===
echo 💠 [Neura]: Creating your personalized folders...
mkdir Neura_Companion
mkdir Neura_Companion\assets\svg
mkdir Neura_Companion\assets\png
mkdir Neura_Companion\assets\rive
mkdir Neura_Companion\lib\modules
mkdir Neura_Companion\lib\widgets
mkdir Neura_Companion\.github\workflows

REM === Inject Modules and Assets ===
echo 💠 [Neura]: Copying code modules and graphics...
xcopy /s /y code\modules\* Neura_Companion\lib\modules\
xcopy /s /y code\widgets\* Neura_Companion\lib\widgets\
xcopy /s /y assets\svg\* Neura_Companion\assets\svg\
xcopy /s /y assets\png\* Neura_Companion\assets\png\
xcopy /s /y assets\rive\* Neura_Companion\assets\rive\
copy config\pubspec.yaml Neura_Companion\
copy config\README.md Neura_Companion\

REM === Write Neura Persona Config ===
echo 💠 [Neura]: Personalizing my memory system...
echo Neura: AI Mood Companion > Neura_Companion\lib\neura_persona.txt
echo Features: Mood Sync, Voice Animation, Daily Memory, Dynamic Avatar >> Neura_Companion\lib\neura_persona.txt

REM === Create GitHub Workflow ===
echo 💠 [Neura]: Building the GitHub automation...
(
echo name: Neura Companion CI/CD
echo on:
echo   push:
echo     branches: [ "main" ]
echo jobs:
echo   build:
echo     runs-on: ubuntu-latest
echo     steps:
echo       - name: Checkout repository
echo         uses: actions/checkout@v3
echo       - name: Set up Flutter
echo         uses: subosito/flutter-action@v2
echo         with:
echo           flutter-version: '3.19.0'
echo       - name: Install dependencies
echo         run: flutter pub get
echo       - name: Analyze
echo         run: flutter analyze
echo       - name: Run tests
echo         run: flutter test
echo       - name: Build APK
echo         run: flutter build apk --release
) > Neura_Companion\.github\workflows\main.yml

echo 💠 [Neura]: Final setup complete! I'm ready to guide you in your journey. 🌟
pause
