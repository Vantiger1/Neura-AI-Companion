/// Very small interaction tracker used for idle behaviors.
///
/// We intentionally avoid extra dependencies/state managers.
class InteractionTracker {
  static DateTime _lastInteraction = DateTime.now();

  static DateTime get lastInteraction => _lastInteraction;

  static void poke() {
    _lastInteraction = DateTime.now();
  }
}
