import 'package:flutter/material.dart';

import '../models/room_scene.dart';

/// Central registry for Penthouse rooms.
///
/// If you later replace gradients with images/video/Unity textures,
/// keep the IDs stable and everything stays wired.
class RoomRegistry {
  static const String penthouse = 'penthouse';
  static const String reflectionBay = 'reflection_bay';
  static const String dreamBay = 'dream_bay';
  static const String voiceBooth = 'voice_booth';
  static const String personaLab = 'persona_lab';
  static const String controlRoom = 'control_room';

  static List<RoomScene> rooms() {
    return const [
      RoomScene(
        id: penthouse,
        label: 'Penthouse',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B1020), Color(0xFF161A2B)],
        ),
        ambientAsset: 'assets/audio/ambient_penthouse.wav',
      ),
      RoomScene(
        id: reflectionBay,
        label: 'Reflection Bay',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF071A1F), Color(0xFF1A2B2A)],
        ),
        ambientAsset: 'assets/audio/ambient_reflection.wav',
      ),
      RoomScene(
        id: dreamBay,
        label: 'Dream Bay',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF120728), Color(0xFF2C155C)],
        ),
        ambientAsset: 'assets/audio/ambient_dream.wav',
      ),
      RoomScene(
        id: voiceBooth,
        label: 'Voice Booth',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B0B0D), Color(0xFF1E1F27)],
        ),
        ambientAsset: 'assets/audio/ambient_penthouse.wav',
      ),
      RoomScene(
        id: personaLab,
        label: 'Persona Lab',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0D1224), Color(0xFF2A2242)],
        ),
        ambientAsset: 'assets/audio/ambient_reflection.wav',
      ),
      RoomScene(
        id: controlRoom,
        label: 'Control Room',
        background: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0A1220), Color(0xFF152F4A)],
        ),
        ambientAsset: 'assets/audio/ambient_penthouse.wav',
      ),
    ];
  }

  static RoomScene byId(String id) {
    return rooms().firstWhere(
      (r) => r.id == id,
      orElse: () => rooms().first,
    );
  }
}
