import 'dart:async';

import 'package:audioplayers/audioplayers.dart';

/// Ambient audio loop that follows Neura's current room.
///
/// - Best-effort: if assets/platform audio are unavailable, we fail silently.
/// - Looping: uses ReleaseMode.loop.
class AmbientAudioService {
  AmbientAudioService._();

  static final AmbientAudioService instance = AmbientAudioService._();

  final AudioPlayer _player = AudioPlayer();
  String? _currentAsset;
  bool _enabled = true;

  bool get enabled => _enabled;

  Future<void> setEnabled(bool enabled) async {
    _enabled = enabled;
    if (!_enabled) {
      await stop();
    }
  }

  Future<void> playRoomAmbient(String? assetPath) async {
    if (!_enabled) return;
    if (assetPath == null || assetPath.trim().isEmpty) return;
    if (_currentAsset == assetPath) return;

    _currentAsset = assetPath;
    try {
      await _player.stop();
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.setVolume(0.35);
      await _player.play(AssetSource(assetPath.replaceFirst('assets/', '')));
    } catch (_) {
      // Silent fail: audio should never break the app.
    }
  }

  Future<void> stop() async {
    try {
      await _player.stop();
    } catch (_) {}
    _currentAsset = null;
  }

  Future<void> dispose() async {
    try {
      await _player.dispose();
    } catch (_) {}
  }
}
