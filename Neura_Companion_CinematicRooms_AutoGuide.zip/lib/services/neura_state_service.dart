import 'package:hive/hive.dart';

import 'neura_event_bus.dart';

/// Local-first, encrypted state spine for Neura.
///
/// This stores *continuity* data (room, mood, last interaction), not user content.
class NeuraStateService {
  static late Box _box;

  static Future<void> init(List<int> encryptionKey) async {
    _box = await Hive.openBox(
      'neura_state',
      encryptionCipher: HiveAesCipher(encryptionKey),
    );
    // Seed defaults once.
    _box.putIfAbsent('room', () => 'penthouse');
    _box.putIfAbsent('mood', () => 'calm');
    _box.putIfAbsent('last_object', () => null);
    _box.putIfAbsent('updated_at', () => DateTime.now().toIso8601String());
  }

  static String get room => (_box.get('room') as String?) ?? 'penthouse';
  static String get mood => (_box.get('mood') as String?) ?? 'calm';
  static String? get lastObject => _box.get('last_object') as String?;

  static Future<void> setRoom(String roomId) async {
    await _box.put('room', roomId);
    NeuraEventBus.roomChanged.value = roomId;
    await _touch();
  }

  static DateTime? get updatedAt {
    final raw = _box.get('updated_at') as String?;
    if (raw == null) return null;
    return DateTime.tryParse(raw);
  }

  static Future<void> setMood(String moodId) async {
    await _box.put('mood', moodId);
    await _touch();
  }

  static Future<void> setLastObject(String? objectId) async {
    await _box.put('last_object', objectId);
    await _touch();
  }

  static Future<void> _touch() async {
    await _box.put('updated_at', DateTime.now().toIso8601String());
  }
}
