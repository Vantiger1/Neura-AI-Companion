import 'package:flutter/foundation.dart';

/// Tiny in-app event bus for cross-widget navigation/animation triggers.
///
/// We keep this intentionally simple (ValueNotifiers) so it works
/// without extra dependencies or complex state management.
class PenthouseNavRequest {
  final String objectId;
  final bool open;
  final String? reason;

  const PenthouseNavRequest({
    required this.objectId,
    this.open = true,
    this.reason,
  });
}

class NeuraEventBus {
  /// When set, the Penthouse should animate Neura to the object.
  ///
  /// If [open] is true, the module screen opens after arrival.
  static final ValueNotifier<PenthouseNavRequest?> goToObject =
      ValueNotifier<PenthouseNavRequest?>(null);

  /// When set, the UI can display a brief status line.
  static final ValueNotifier<String?> statusLine = ValueNotifier<String?>(null);

  /// Emits room changes so optional systems (like ambient audio)
  /// can react without coupling to navigation.
  static final ValueNotifier<String?> roomChanged = ValueNotifier<String?>(null);

  static void announce(String message) {
    statusLine.value = message;
  }

  static void requestObject(String objectId) {
    goToObject.value = PenthouseNavRequest(objectId: objectId, open: true);
  }

  static void suggestObject(String objectId, {String? reason}) {
    goToObject.value = PenthouseNavRequest(objectId: objectId, open: false, reason: reason);
  }
}
