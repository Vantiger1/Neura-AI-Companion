import '../services/neura_state_service.dart';
import '../services/penthouse_registry.dart';

/// Simple, deterministic "where should we go" suggestion engine.
///
/// This is intentionally conservative (helpful, not controlling):
/// - Picks a likely object based on time-of-day + current mood.
/// - Returns an object id from [PenthouseRegistry].
class NeuraGuideService {
  static String suggestObjectId() {
    final mood = NeuraStateService.mood.toLowerCase();
    final hour = DateTime.now().hour;

    // Night: dreams/reflection.
    if (hour >= 21 || hour <= 5) {
      return mood.contains('anx') || mood.contains('stress')
          ? 'journal_desk'
          : 'dream_bed';
    }

    // Morning: intention setting.
    if (hour >= 5 && hour <= 11) {
      return mood.contains('tired') ? 'voice_booth' : 'journal_desk';
    }

    // Midday: quick check-ins / voice journaling.
    if (hour >= 12 && hour <= 16) {
      return mood.contains('calm') ? 'avatar_mirror' : 'voice_booth';
    }

    // Evening: wind down.
    if (mood.contains('sad') || mood.contains('heavy')) {
      return 'journal_desk';
    }
    return 'dream_theater';
  }
}
