import 'dart:async';

import 'package:flutter/material.dart';

import '../models/penthouse_object.dart';
import '../services/ambient_audio_service.dart';
import '../services/interaction_tracker.dart';
import '../services/neura_guide_service.dart';
import '../services/neura_event_bus.dart';
import '../services/neura_state_service.dart';
import '../services/penthouse_registry.dart';
import '../services/room_registry.dart';
import '../widgets/mascot_widget.dart';
import '../widgets/particle_burst.dart';

/// The "module world" home screen.
///
/// Modules are physical objects. Neura "moves" to an object, then the module opens.
class PenthouseScreen extends StatefulWidget {
  @override
  State<PenthouseScreen> createState() => _PenthouseScreenState();
}

class _PenthouseScreenState extends State<PenthouseScreen> {
  late final List<PenthouseObject> _objects;
  StreamSubscription? _sub;
  Timer? _idleTimer;

  final ParticleBurstController _burst = ParticleBurstController();
  String? _highlightObjectId;
  String? _hoveredObjectId;
  bool _interacting = false;

  String _roomId = NeuraStateService.room;

  // Normalized Neura position.
  double _nx = 0.50;
  double _ny = 0.30;

  @override
  void initState() {
    super.initState();
    _objects = PenthouseRegistry.objects();
    _roomId = NeuraStateService.room;
    // Restore a sensible position.
    final last = NeuraStateService.lastObject;
    if (last != null) {
      final o = PenthouseRegistry.byId(last);
      if (o != null) {
        _nx = o.x;
        _ny = o.y;
      }
    }

    NeuraStateService.setRoom(RoomRegistry.penthouse);
    _applyRoom(RoomRegistry.penthouse, cinematic: false);

    // Listen for voice-driven routing.
    NeuraEventBus.goToObject.addListener(_onExternalObjectRequest);

    // Gentle autopilot: if the user is idle, Neura moves (without opening) to a suggested object.
    _idleTimer = Timer.periodic(const Duration(seconds: 22), (_) {
      final idle = DateTime.now().difference(InteractionTracker.lastInteraction);
      if (idle.inSeconds < 16) return;
      final suggested = NeuraGuideService.suggestObjectId();
      // Don't spam the same suggestion.
      if (suggested == _hoveredObjectId || suggested == _highlightObjectId) return;
      final obj = PenthouseRegistry.byId(suggested);
      if (obj == null) return;
      NeuraEventBus.announce(_suggestLine(obj.label));
      NeuraEventBus.suggestObject(obj.id, reason: 'idle_autopilot');
    });

    // On entry, offer a single, non-invasive suggestion if we don't have a recent object.
    Future.delayed(const Duration(milliseconds: 1400), () {
      if (!mounted) return;
      final updatedAt = NeuraStateService.updatedAt;
      final stale = updatedAt == null || DateTime.now().difference(updatedAt).inHours >= 10;
      if (!stale) return;
      final suggested = NeuraGuideService.suggestObjectId();
      final obj = PenthouseRegistry.byId(suggested);
      if (obj == null) return;
      NeuraEventBus.announce(_suggestLine(obj.label));
      NeuraEventBus.suggestObject(obj.id, reason: 'startup_suggest');
    });
  }

  @override
  void dispose() {
    NeuraEventBus.goToObject.removeListener(_onExternalObjectRequest);
    _sub?.cancel();
    _idleTimer?.cancel();
    super.dispose();
  }

  void _onExternalObjectRequest() {
    final req = NeuraEventBus.goToObject.value;
    if (req == null) return;
    // Clear it to avoid re-triggering.
    NeuraEventBus.goToObject.value = null;
    final obj = PenthouseRegistry.byId(req.objectId);
    if (obj != null) {
      _goToObject(obj, openAfterArrive: req.open);
    }
  }

  String _suggestLine(String label) {
    final mood = NeuraStateService.mood.toLowerCase();
    final hour = DateTime.now().hour;
    if (hour >= 21 || hour <= 5) {
      return mood.contains('stress') || mood.contains('anx')
          ? 'Let\'s soften the night. Want the $label?'
          : 'Dream energy detected. Want the $label?';
    }
    if (hour <= 11) {
      return 'Morning momentum. Want the $label?';
    }
    if (mood.contains('tired')) return 'Low battery vibes. $label could help.';
    return 'Quick idea: $label.';
  }

  Future<void> _goToObject(PenthouseObject obj, {required bool openAfterArrive}) async {
    InteractionTracker.poke();

    // Cinematic room transition first.
    await _applyRoom(obj.roomId, cinematic: true);

    setState(() {
      _nx = obj.x;
      _ny = obj.y;
      _highlightObjectId = obj.id;
      _hoveredObjectId = openAfterArrive ? null : obj.id;
    });

    await NeuraStateService.setLastObject(obj.id);
    await NeuraStateService.setRoom(obj.roomId);
    NeuraEventBus.announce(openAfterArrive ? 'Heading to ${obj.label}…' : 'Floating over to ${obj.label}…');

    // Give the movement time to complete, then open.
    await Future.delayed(const Duration(milliseconds: 680));
    if (!mounted) return;

    // Interaction moment.
    setState(() => _interacting = true);
    _burst.burst();
    await Future.delayed(const Duration(milliseconds: 720));
    if (!mounted) return;
    setState(() => _interacting = false);

    if (openAfterArrive) {
      Navigator.of(context).push(
        PageRouteBuilder(
          pageBuilder: (_, __, ___) => obj.builder(_),
          transitionsBuilder: (_, a, __, child) {
            return FadeTransition(
              opacity: CurvedAnimation(parent: a, curve: Curves.easeOutCubic),
              child: ScaleTransition(
                scale: Tween<double>(begin: 0.985, end: 1.0).animate(
                  CurvedAnimation(parent: a, curve: Curves.easeOutCubic),
                ),
                child: child,
              ),
            );
          },
        ),
      );
    } else {
      NeuraEventBus.announce('I\'m here. Tap ${obj.label} again to enter.');
    }
  }

  Future<void> _applyRoom(String roomId, {required bool cinematic}) async {
    if (_roomId == roomId) return;
    setState(() => _roomId = roomId);
    // Ambient audio follows rooms.
    final scene = RoomRegistry.byId(roomId);
    unawaited(AmbientAudioService.instance.playRoomAmbient(scene.ambientAsset));
    // Optional cinematic pause so the crossfade is felt.
    if (cinematic) {
      await Future.delayed(const Duration(milliseconds: 420));
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: GestureDetector(
        behavior: HitTestBehavior.translucent,
        onTap: InteractionTracker.poke,
        onPanDown: (_) => InteractionTracker.poke(),
        child: LayoutBuilder(
          builder: (context, constraints) {
          final w = constraints.maxWidth;
          final h = constraints.maxHeight;

          // Neura on-screen position.
          final neuraX = (w * _nx).clamp(0.0, w - 120);
          final neuraY = (h * _ny).clamp(0.0, h - 160);

          return Stack(
            children: [
              // Cinematic room background (crossfades by room id).
              AnimatedSwitcher(
                duration: const Duration(milliseconds: 520),
                switchInCurve: Curves.easeOutCubic,
                switchOutCurve: Curves.easeInCubic,
                child: Container(
                  key: ValueKey<String>(_roomId),
                  decoration: BoxDecoration(
                    gradient: RoomRegistry.byId(_roomId).background,
                  ),
                ),
              ),

              // Objects.
              for (final obj in _objects) _buildObject(obj, w, h),

              // Neura avatar "moves" between objects.
              AnimatedPositioned(
                duration: const Duration(milliseconds: 620),
                curve: Curves.easeInOutCubic,
                left: neuraX,
                top: neuraY,
                child: Column(
                  children: [
                    MascotWidget(),
                    if (_interacting)
                      Padding(
                        padding: const EdgeInsets.only(top: 2),
                        child: _handsHover(),
                      ),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.45),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        '${RoomRegistry.byId(_roomId).label} • ${NeuraStateService.mood}',
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),

              // Particle burst lives above objects (centered on the highlighted one).
              if (_highlightObjectId != null)
                _buildBurstLayer(_highlightObjectId!, w, h),

              // Title.
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    RoomRegistry.byId(_roomId).label,
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: Colors.white),
                  ),
                ),
              ),
            ],
          );
          },
        ),
      ),
    );
  }

  Widget _handsHover() {
    return TweenAnimationBuilder<double>(
      tween: Tween(begin: 0, end: 1),
      duration: const Duration(milliseconds: 520),
      builder: (_, t, __) {
        return Opacity(
          opacity: (0.35 + 0.65 * t).clamp(0.0, 1.0),
          child: Container(
            width: 56,
            height: 18,
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(999),
              color: Colors.white.withOpacity(0.10),
              border: Border.all(color: Colors.white.withOpacity(0.12)),
            ),
            child: Center(
              child: Text(
                '…',
                style: TextStyle(color: Colors.white.withOpacity(0.75), fontSize: 16, height: 1),
              ),
            ),
          ),
        );
      },
    );
  }

  Widget _buildBurstLayer(String objectId, double w, double h) {
    final obj = PenthouseRegistry.byId(objectId);
    if (obj == null) return const SizedBox.shrink();
    final left = (w * obj.x).clamp(0.0, w - 120) + 55 - 45;
    final top = (h * obj.y).clamp(0.0, h - 120) + 25;
    return Positioned(
      left: left,
      top: top,
      child: ParticleBurst(controller: _burst),
    );
  }

  Widget _buildObject(PenthouseObject obj, double w, double h) {
    final left = (w * obj.x).clamp(0.0, w - 120);
    final top = (h * obj.y).clamp(0.0, h - 120);
    final isHighlighted = obj.id == _highlightObjectId;
    final isHovered = obj.id == _hoveredObjectId;
    return Positioned(
      left: left,
      top: top,
      child: GestureDetector(
        onTap: () {
          InteractionTracker.poke();
          // If Neura already hovered here, second tap enters.
          final shouldOpen = _hoveredObjectId == obj.id;
          _goToObject(obj, openAfterArrive: shouldOpen);
        },
        child: Container(
          width: 110,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: (isHighlighted ? Colors.white.withOpacity(0.14) : Colors.white.withOpacity(0.08)),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: (isHighlighted ? Colors.white.withOpacity(0.26) : Colors.white.withOpacity(0.10))),
            boxShadow: isHighlighted
                ? [
                    BoxShadow(
                      color: Colors.white.withOpacity(0.10),
                      blurRadius: 18,
                      spreadRadius: 1,
                    ),
                  ]
                : const [],
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(obj.icon, color: Colors.white, size: 28),
              const SizedBox(height: 6),
              Text(
                obj.label,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
              if (isHovered)
                Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                    decoration: BoxDecoration(
                      color: Colors.black.withOpacity(0.35),
                      borderRadius: BorderRadius.circular(999),
                      border: Border.all(color: Colors.white.withOpacity(0.10)),
                    ),
                    child: const Text(
                      'Tap to enter',
                      style: TextStyle(color: Colors.white, fontSize: 11),
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
