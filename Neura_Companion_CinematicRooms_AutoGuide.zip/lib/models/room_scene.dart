import 'package:flutter/material.dart';

/// Visual + audio identity for a "room" inside the Penthouse world.
///
/// We keep this lightweight so you can later swap the gradients for
/// image/3D backgrounds without changing the routing logic.
class RoomScene {
  final String id;
  final String label;
  final Gradient background;
  final String? ambientAsset;

  const RoomScene({
    required this.id,
    required this.label,
    required this.background,
    this.ambientAsset,
  });
}
