import 'dart:math';

import 'package:flutter/material.dart';

/// Lightweight particle burst (no deps) used for "object interaction" moments.
///
/// Trigger with [ParticleBurstController.burst].
class ParticleBurstController {
  final ValueNotifier<int> _tick = ValueNotifier<int>(0);

  ValueListenable<int> get tick => _tick;

  void burst() {
    _tick.value = _tick.value + 1;
  }
}

class ParticleBurst extends StatefulWidget {
  final ParticleBurstController controller;
  final double size;

  const ParticleBurst({
    super.key,
    required this.controller,
    this.size = 90,
  });

  @override
  State<ParticleBurst> createState() => _ParticleBurstState();
}

class _ParticleBurstState extends State<ParticleBurst>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c;
  late final List<_P> _particles;

  @override
  void initState() {
    super.initState();
    _c = AnimationController(vsync: this, duration: const Duration(milliseconds: 720));
    _particles = _makeParticles();
    widget.controller.tick.addListener(_onBurst);
  }

  @override
  void didUpdateWidget(covariant ParticleBurst oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.controller != widget.controller) {
      oldWidget.controller.tick.removeListener(_onBurst);
      widget.controller.tick.addListener(_onBurst);
    }
  }

  @override
  void dispose() {
    widget.controller.tick.removeListener(_onBurst);
    _c.dispose();
    super.dispose();
  }

  void _onBurst() {
    if (!mounted) return;
    setState(() {
      _particles
        ..clear()
        ..addAll(_makeParticles());
    });
    _c.forward(from: 0);
  }

  List<_P> _makeParticles() {
    final r = Random();
    return List.generate(18, (_) {
      final angle = r.nextDouble() * pi * 2;
      final speed = 0.35 + r.nextDouble() * 0.85;
      final radius = 0.35 + r.nextDouble() * 0.65;
      final size = 1.8 + r.nextDouble() * 2.7;
      return _P(angle: angle, speed: speed, radius: radius, size: size);
    });
  }

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: SizedBox(
        width: widget.size,
        height: widget.size,
        child: AnimatedBuilder(
          animation: _c,
          builder: (_, __) {
            final t = Curves.easeOutCubic.transform(_c.value);
            final opacity = (1.0 - t).clamp(0.0, 1.0);
            return CustomPaint(
              painter: _ParticlePainter(particles: _particles, t: t, opacity: opacity),
            );
          },
        ),
      ),
    );
  }
}

class _P {
  final double angle;
  final double speed;
  final double radius;
  final double size;
  const _P({required this.angle, required this.speed, required this.radius, required this.size});
}

class _ParticlePainter extends CustomPainter {
  final List<_P> particles;
  final double t;
  final double opacity;

  const _ParticlePainter({required this.particles, required this.t, required this.opacity});

  @override
  void paint(Canvas canvas, Size size) {
    final c = Offset(size.width / 2, size.height / 2);
    final base = min(size.width, size.height) / 2;
    final paint = Paint()..style = PaintingStyle.fill;

    // Inner bloom.
    paint.color = Colors.white.withOpacity(0.08 * opacity);
    canvas.drawCircle(c, base * (0.28 + 0.18 * (1 - t)), paint);

    for (final p in particles) {
      final dist = base * p.radius * (t * p.speed).clamp(0.0, 1.0);
      final x = c.dx + cos(p.angle) * dist;
      final y = c.dy + sin(p.angle) * dist;
      paint.color = Colors.white.withOpacity(0.55 * opacity);
      canvas.drawCircle(Offset(x, y), p.size, paint);
    }
  }

  @override
  bool shouldRepaint(covariant _ParticlePainter oldDelegate) {
    return oldDelegate.t != t || oldDelegate.opacity != opacity || oldDelegate.particles != particles;
  }
}
