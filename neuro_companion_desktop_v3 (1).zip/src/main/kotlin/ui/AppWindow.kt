package ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import ui.screens.DashboardScreen
import ui.screens.RitualScreen
import ui.screens.GoalTrackerScreen
import ui.screens.MoodAnalyticsScreen
import ui.screens.MeditationCoachScreen
import ui.screens.TherapistModeScreen
import ui.screens.PayItForwardScreen
import ui.screens.DreamVisualizerScreen
import ui.screens.FeedbackScreen

@Composable
fun AppWindow() {
    var currentScreen by remember { mutableStateOf("dashboard") }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when(currentScreen) {
            "dashboard"       -> DashboardScreen { currentScreen = it }
            "ritual"          -> RitualScreen { currentScreen = it }
            "goals"           -> GoalTrackerScreen { currentScreen = it }
            "mood"            -> MoodAnalyticsScreen { currentScreen = it }
            "meditation"      -> MeditationCoachScreen { currentScreen = it }
            "therapist"       -> TherapistModeScreen { currentScreen = it }
            "payitforward"    -> PayItForwardScreen { currentScreen = it }
            "dream"           -> DreamVisualizerScreen { currentScreen = it }
            "feedback"        -> FeedbackScreen { currentScreen = it }
            else              -> Text("Coming Soon")
        }
    }
}
