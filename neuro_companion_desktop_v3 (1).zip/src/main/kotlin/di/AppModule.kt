package di

import org.koin.dsl.module
import services.AuthService
import services.AIService
import services.StorageService
import services.ExportService
import services.VoiceService
import viewmodel.*

val appModule = module {
    single { AuthService() }
    single { AIService() }
    single { StorageService() }
    single { ExportService() }
    single { VoiceService() }

    // ViewModels
    single { DashboardViewModel(get()) }
    single { RitualViewModel(get()) }
    single { GoalTrackerViewModel(get()) }
    single { MoodAnalyticsViewModel(get()) }
    single { MeditationCoachViewModel(get()) }
    single { TherapistModeViewModel(get()) }
    single { PayItForwardViewModel(get()) }
    single { DreamVisualizerViewModel(get()) }
    single { FeedbackViewModel(get()) }
}
