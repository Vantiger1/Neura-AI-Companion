package services

import com.azure.storage.blob.BlobServiceClientBuilder

class StorageService(conn: String = System.getenv("AZURE_CONN")) {
    private val client = BlobServiceClientBuilder()
        .connectionString(conn)
        .buildClient()

    fun listContainers(): List<String> =
        client.listBlobContainers().map { it.name }
}
