package services

import com.theokanning.openai.OpenAiService
import com.theokanning.openai.completion.CompletionRequest

class AIService(apiKey: String = System.getenv("OPENAI_API_KEY")) {
    private val service = OpenAiService(apiKey)

    suspend fun generateText(prompt: String): String {
        val req = CompletionRequest.builder()
            .prompt(prompt)
            .model("gpt-4o-mini")
            .maxTokens(150)
            .build()
        return service.createCompletion(req).choices.first().text.trim()
    }
}
