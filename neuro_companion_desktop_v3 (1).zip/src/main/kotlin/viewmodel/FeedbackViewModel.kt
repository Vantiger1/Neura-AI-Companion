package viewmodel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import services.AIService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.Exception
import android.util.Log

class FeedbackViewModel(private val ai: AIService) {
    var result by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun submitFeedback() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            result = try {
                ai.generateText("Submit the following feedback:")
            } catch (e: Exception) {
                Log.e("FeedbackVM", "Error in submitFeedback", e)
                "Operation failed."
            } finally {
                isBusy = false
            }
        }
    }
}
