package viewmodel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import services.AIService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.Exception
import android.util.Log

class DreamVisualizerViewModel(private val ai: AIService) {
    var result by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun interpretDream() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            result = try {
                ai.generateText("Interpret this dream:")
            } catch (e: Exception) {
                Log.e("DreamVisualizerVM", "Error in interpretDream", e)
                "Operation failed."
            } finally {
                isBusy = false
            }
        }
    }
}
