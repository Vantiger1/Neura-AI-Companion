package viewmodel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import services.AIService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.lang.Exception
import android.util.Log

class MeditationCoachViewModel(private val ai: AIService) {
    var result by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun getSession() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            result = try {
                ai.generateText("Provide a short guided meditation session:")
            } catch (e: Exception) {
                Log.e("MeditationCoachVM", "Error in getSession", e)
                "Operation failed."
            } finally {
                isBusy = false
            }
        }
    }
}
