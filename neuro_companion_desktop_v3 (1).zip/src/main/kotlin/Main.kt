import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import org.koin.core.context.startKoin
import di.appModule

fun main() = application {
    startKoin { modules(appModule) }
    Window(onCloseRequest = ::exitApplication, title = "Neuro Companion") {
        ui.AppWindow()
    }
}
