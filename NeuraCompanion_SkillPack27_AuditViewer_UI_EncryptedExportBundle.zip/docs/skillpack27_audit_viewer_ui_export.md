# Skill Pack 27 — Audit Viewer UI + Encrypted Export Bundle + Checksum

## What this adds
1) A simple in-app **Audit Log Viewer** screen (Android + Windows)
2) An **Encrypted Export Bundle**:
   - neura_approvals.encdb (encrypted)
   - neura_audit.encdb (encrypted)
   - manifest.json (sha256 + metadata)
   Exported as a ZIP to Downloads (desktop) or Documents/Support fallback.

## Dependencies
Add if missing:
- archive
- crypto
- path_provider

(Plus the Step 26 deps: cryptography, flutter_secure_storage)

## New action
- `audit_export_bundle` (medium risk, file system)

## Wiring
1) Register the export action at boot:
```dart
final exportSvc = NeuraAuditExportService();
NeuraAuditExportAction.register(NeuraKernel.I.registry, exportSvc);
```

2) Ensure Step 26 actions exist:
- `audit_log_list` (from Step 26 persisted actions)

3) Add navigation route:
- `AuditLogScreen()` (lib/ui/audit/audit_log_screen.dart)

4) Replace the shim:
In `AuditLogScreen`, replace `NeuraActions.exec(...)` with your real ActionBus call.

## Security note
This export is encrypted at rest, but still sensitive (it’s a ledger of user approvals/actions).
Treat exports as private files.

## Next
Step 28: Signed Action Plans (plan hash + approval binding) so execution can’t drift from what was approved.
