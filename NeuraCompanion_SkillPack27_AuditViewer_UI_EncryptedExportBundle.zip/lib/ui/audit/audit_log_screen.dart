\
import 'package:flutter/material.dart';

/// Minimal UI to view audit events + export bundle.
/// Wiring assumptions:
/// - ActionBus: `audit_log_list` returns { events: [ ... ] }
/// - Export action: `audit_export_bundle` returns { zipPath, manifestPath, bytes }
///
/// Replace `NeuraActions` with your existing executor/facade.
class AuditLogScreen extends StatefulWidget {
  const AuditLogScreen({super.key});

  @override
  State<AuditLogScreen> createState() => _AuditLogScreenState();
}

class _AuditLogScreenState extends State<AuditLogScreen> {
  bool _loading = true;
  String _error = '';
  List<Map<String, dynamic>> _events = [];

  String _query = '';
  String _typeFilter = 'all';

  @override
  void initState() {
    super.initState();
    _refresh();
  }

  Future<void> _refresh() async {
    setState(() {
      _loading = true;
      _error = '';
    });

    try {
      // TODO: swap to your executor:
      final res = await NeuraActions.exec('audit_log_list', args: {'limit': 300});
      final events = (res['events'] as List?)?.cast<Map<String, dynamic>>() ?? <Map<String, dynamic>>[];
      setState(() => _events = events);
    } catch (e) {
      setState(() => _error = '$e');
    } finally {
      setState(() => _loading = false);
    }
  }

  Future<void> _export() async {
    setState(() => _error = '');
    try {
      final res = await NeuraActions.exec('audit_export_bundle', args: {
        'prefix': 'neura_audit_export',
        'meta': {'requestedFrom': 'AuditLogScreen'},
      });

      final zipPath = res['zipPath']?.toString() ?? '';
      final manifestPath = res['manifestPath']?.toString() ?? '';

      if (!mounted) return;
      await showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Export Created'),
          content: SelectableText(
            'ZIP:\n$zipPath\n\nManifest:\n$manifestPath\n\nKeep this file secure. It is encrypted, but still sensitive.',
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
          ],
        ),
      );
    } catch (e) {
      setState(() => _error = '$e');
    }
  }

  List<Map<String, dynamic>> get _filtered {
    final q = _query.trim().toLowerCase();
    return _events.where((e) {
      if (_typeFilter != 'all') {
        final t = (e['type'] ?? '').toString();
        if (t != _typeFilter) return false;
      }
      if (q.isEmpty) return true;
      final s = e.toString().toLowerCase();
      return s.contains(q);
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    final items = _filtered;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Audit Log'),
        actions: [
          IconButton(onPressed: _loading ? null : _refresh, icon: const Icon(Icons.refresh)),
          IconButton(onPressed: _export, icon: const Icon(Icons.archive)),
        ],
      ),
      body: Column(
        children: [
          _Toolbar(
            query: _query,
            typeFilter: _typeFilter,
            onQuery: (v) => setState(() => _query = v),
            onType: (v) => setState(() => _typeFilter = v),
          ),
          if (_error.isNotEmpty)
            MaterialBanner(
              content: Text(_error),
              actions: [TextButton(onPressed: () => setState(() => _error = ''), child: const Text('Dismiss'))],
            ),
          Expanded(
            child: _loading
                ? const Center(child: CircularProgressIndicator())
                : items.isEmpty
                    ? const Center(child: Text('No audit events yet.'))
                    : ListView.separated(
                        itemCount: items.length,
                        separatorBuilder: (_, __) => const Divider(height: 1),
                        itemBuilder: (_, i) => _AuditTile(items[i]),
                      ),
          ),
        ],
      ),
    );
  }
}

class _Toolbar extends StatelessWidget {
  final String query;
  final String typeFilter;
  final ValueChanged<String> onQuery;
  final ValueChanged<String> onType;

  const _Toolbar({
    required this.query,
    required this.typeFilter,
    required this.onQuery,
    required this.onType,
  });

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.all(12),
      child: Row(
        children: [
          Expanded(
            child: TextField(
              decoration: const InputDecoration(
                labelText: 'Search',
                prefixIcon: Icon(Icons.search),
                border: OutlineInputBorder(),
              ),
              onChanged: onQuery,
            ),
          ),
          const SizedBox(width: 12),
          DropdownButton<String>(
            value: typeFilter,
            items: const [
              DropdownMenuItem(value: 'all', child: Text('All')),
              DropdownMenuItem(value: 'approval_requested', child: Text('approval_requested')),
              DropdownMenuItem(value: 'approval_decided', child: Text('approval_decided')),
              DropdownMenuItem(value: 'guarded_executed', child: Text('guarded_executed')),
              DropdownMenuItem(value: 'system_note', child: Text('system_note')),
            ],
            onChanged: (v) => onType(v ?? 'all'),
          ),
        ],
      ),
    );
  }
}

class _AuditTile extends StatelessWidget {
  final Map<String, dynamic> e;
  const _AuditTile(this.e);

  @override
  Widget build(BuildContext context) {
    final type = (e['type'] ?? '').toString();
    final at = (e['at'] ?? '').toString();
    final actionId = (e['actionId'] ?? '').toString();
    final outcome = (e['outcome'] ?? '').toString();
    final note = (e['note'] ?? '').toString();

    return ListTile(
      title: Text('$type • $outcome'),
      subtitle: Text('$at\n$actionId\n$note'),
      isThreeLine: true,
    );
  }
}

/// TEMP shim. Replace with your real ActionBus executor.
/// Expected:
/// - exec(actionId, args) -> Map result data (not wrapped).
class NeuraActions {
  static Future<Map<String, dynamic>> exec(String actionId, {Map<String, dynamic>? args}) async {
    // TODO: integrate with NeuraKernel.I.executor / action bus.
    throw UnimplementedError('Wire NeuraActions.exec to your action bus / kernel executor.');
  }
}
