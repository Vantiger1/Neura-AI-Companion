\
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';

import 'neura_audit_export_service.dart';

class NeuraAuditExportAction {
  static void register(NeuraActionRegistry reg, NeuraAuditExportService svc) {
    reg.register(
      NeuraAction(
        id: 'audit_export_bundle',
        title: 'Export Audit Bundle (Encrypted)',
        description: 'Exports encrypted audit + approvals stores into a ZIP with a manifest + sha256.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileSystem,
        handler: (req) async {
          try {
            final prefix = (req.args['prefix'] as String?)?.trim();
            final meta = (req.args['meta'] as Map?)?.cast<String, dynamic>();

            final res = await svc.exportEncryptedBundle(
              bundleNamePrefix: (prefix != null && prefix.isNotEmpty) ? prefix : 'neura_audit_export',
              extraMetadata: meta,
            );
            return NeuraActionResult.success('Exported', data: res.toJson());
          } catch (e) {
            return NeuraActionResult.error('Export failed: $e');
          }
        },
      ),
    );
  }
}
