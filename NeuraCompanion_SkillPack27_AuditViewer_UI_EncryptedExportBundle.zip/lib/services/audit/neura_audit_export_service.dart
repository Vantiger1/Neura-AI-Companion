\
import 'dart:convert';
import 'dart:io';

import 'package:archive/archive.dart';
import 'package:archive/archive_io.dart';
import 'package:crypto/crypto.dart';
import 'package:path_provider/path_provider.dart';

class NeuraAuditExportResult {
  final String zipPath;
  final String manifestPath;
  final int bytes;

  NeuraAuditExportResult({
    required this.zipPath,
    required this.manifestPath,
    required this.bytes,
  });

  Map<String, dynamic> toJson() => {
        'zipPath': zipPath,
        'manifestPath': manifestPath,
        'bytes': bytes,
      };
}

class NeuraAuditExportService {
  static const String approvalsFile = 'neura_approvals.encdb';
  static const String auditFile = 'neura_audit.encdb';

  /// Creates an encrypted export bundle (ZIP) containing:
  /// - neura_approvals.encdb
  /// - neura_audit.encdb
  /// - manifest.json (sha256 + metadata)
  ///
  /// NOTE: This does NOT decrypt anything. It exports encrypted files only.
  Future<NeuraAuditExportResult> exportEncryptedBundle({
    String bundleNamePrefix = 'neura_audit_export',
    Map<String, dynamic>? extraMetadata,
  }) async {
    final supportDir = await getApplicationSupportDirectory();
    final srcApprovals = File('${supportDir.path}/$approvalsFile');
    final srcAudit = File('${supportDir.path}/$auditFile');

    if (!await srcApprovals.exists() || !await srcAudit.exists()) {
      throw StateError('Missing encrypted stores. Run Step 26 bootstrap first.');
    }

    final outDir = await _bestExportDir();
    final ts = DateTime.now().toIso8601String().replaceAll(':', '-');
    final zipPath = '${outDir.path}/$bundleNamePrefix-$ts.zip';
    final manifestPath = '${outDir.path}/$bundleNamePrefix-$ts.manifest.json';

    final approvalsHash = await _sha256File(srcApprovals);
    final auditHash = await _sha256File(srcAudit);

    final manifest = <String, dynamic>{
      'schema': 'neura.audit.export.v1',
      'createdAt': DateTime.now().toIso8601String(),
      'files': [
        {
          'name': approvalsFile,
          'bytes': await srcApprovals.length(),
          'sha256': approvalsHash,
        },
        {
          'name': auditFile,
          'bytes': await srcAudit.length(),
          'sha256': auditHash,
        },
      ],
      'notes': 'Encrypted export bundle. Contents are encrypted at rest. Keep it safe.',
      if (extraMetadata != null) 'meta': extraMetadata,
    };

    final manifestFile = File(manifestPath);
    await manifestFile.writeAsString(const JsonEncoder.withIndent('  ').convert(manifest), flush: true);

    final archive = Archive();
    archive.addFile(ArchiveFile(approvalsFile, await srcApprovals.length(), await srcApprovals.readAsBytes()));
    archive.addFile(ArchiveFile(auditFile, await srcAudit.length(), await srcAudit.readAsBytes()));
    archive.addFile(ArchiveFile('manifest.json', await manifestFile.length(), await manifestFile.readAsBytes()));

    final zipData = ZipEncoder().encode(archive);
    if (zipData == null) throw StateError('Failed to encode zip');

    final outZip = File(zipPath);
    await outZip.writeAsBytes(zipData, flush: true);

    return NeuraAuditExportResult(
      zipPath: zipPath,
      manifestPath: manifestPath,
      bytes: await outZip.length(),
    );
  }

  Future<Directory> _bestExportDir() async {
    // Desktop-friendly: Downloads if available, else Documents, else Support.
    try {
      final d = await getDownloadsDirectory();
      if (d != null) return d;
    } catch (_) {}
    try {
      final d = await getApplicationDocumentsDirectory();
      return d;
    } catch (_) {}
    return getApplicationSupportDirectory();
  }

  Future<String> _sha256File(File f) async {
    final bytes = await f.readAsBytes();
    return sha256.convert(bytes).toString();
  }
}
