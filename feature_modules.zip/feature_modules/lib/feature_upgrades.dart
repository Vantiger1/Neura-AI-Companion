import 'package:dynamic_theme/dynamic_theme.dart';
import 'package:accessibility/accessibility.dart';
import 'package:voice_personas/voice_personas.dart';
import 'package:dream_interpreter/dream_interpreter.dart';
import 'package:health_sync/health_sync.dart';
import 'package:calendar_notifications/calendar_notifications.dart';
import 'package:smart_home/smart_home.dart';
import 'package:state_di/state_di.dart';
import 'package:analytics_dashboard/analytics_dashboard.dart';
import 'package:secure_storage/secure_storage.dart';
import 'package:consent_manager/consent_manager.dart';
import 'package:ci_cd_helpers/ci_cd_helpers.dart';

class FeatureUpgrades {
  /// Call this to initialize all Neura Companion upgrades
  static Future<void> initAll() async {
    await DynamicTheme.init();
    await Accessibility.init();
    await VoicePersonas.init();
    await DreamInterpreter.init();
    await HealthSync.init();
    await CalendarNotifications.init();
    await SmartHome.init();
    await StateDi.init();
    await AnalyticsDashboard.init();
    await SecureStorage.init();
    await ConsentManager.init();
    await CiCdHelpers.init();
  }
}