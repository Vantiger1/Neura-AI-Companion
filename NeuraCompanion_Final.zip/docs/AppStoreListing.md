# App Store Listing Copy

**Title:** Neura Companion: AI-driven Wellness & Productivity

**Subtitle:** Your AI-powered guide to better habits, mood tracking & more

**Description:**
Neura Companion uses advanced AI to help you:
- Track daily rituals & see visual analytics
- Journal via text or voice with mood insights
- Connect with community feeds & challenges
- Dream journal with AI interpretation
- Interactive AI mascot, Neura & Neuro
- Offline mode with automatic sync

**Keywords:** AI wellness, habit tracker, dream journal, mood analysis

**Support URL:** https://neura.com/support  
**Privacy Policy URL:** https://neura.com/privacy
