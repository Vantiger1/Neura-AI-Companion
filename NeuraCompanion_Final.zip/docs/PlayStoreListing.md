# Google Play Store Listing Copy

**App Name:** Neura Companion – AI Wellness

**Short Description:** AI companion for wellness, mood tracking & habits.

**Full Description:**
Welcome to Neura Companion—the AI-powered wellness app that:
* Guides you through daily rituals
* Analyzes mood & emotions
* Journals dreams with AI summaries
* Connects you to community challenges

**Promotional Text:**
Unlock your best self with personalized AI insights.

**Graphic Assets:**
- Feature Graphic: marketing/feature_graphic.png
- Screenshots: screenshots/android/, screenshots/ios/

**Privacy Policy:**
https://neura.com/privacy
