import '../models/dream_entry.dart';

class DreamInterpretationService {
  /// Uses AI to interpret [transcript] and return interpretation and mood.
  Future<Map<String, String>> interpret(String transcript) async {
    // TODO: call AI model
    return {
      'interpretation': '',
      'moodSummary': '',
    };
  }
}
