import 'package:flutter/material.dart';
import '../models/ritual_portal_model.dart';

class RitualPortalScreen extends StatelessWidget {
  final List<RitualPortal> portals = [
    RitualPortal(
      id: 'moonlight',
      name: 'Moonlight Garden',
      backgroundAsset: 'assets/scenes/moonlight_garden.jpg',
      description: 'Meditate in a peaceful garden under the stars.',
    ),
    RitualPortal(
      id: 'studyroom',
      name: 'Zen Study Room',
      backgroundAsset: 'assets/scenes/zen_study.jpg',
      description: 'Focus your mind in silence with gentle inspiration.',
    ),
    RitualPortal(
      id: 'hearth',
      name: 'Warm Hearth',
      backgroundAsset: 'assets/scenes/warm_hearth.jpg',
      description: 'Unwind and reflect beside a cozy fire.',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Ritual Worlds')),
      body: ListView(
        children: portals.map((p) => GestureDetector(
          onTap: () => Navigator.push(context,
            MaterialPageRoute(builder: (_) => PortalExperienceView(portal: p))),
          child: Card(
            margin: EdgeInsets.all(12),
            child: Stack(
              alignment: Alignment.bottomLeft,
              children: [
                Image.asset(p.backgroundAsset, fit: BoxFit.cover, height: 180, width: double.infinity),
                Container(
                  color: Colors.black45,
                  width: double.infinity,
                  padding: EdgeInsets.all(12),
                  child: Text('${p.name} — ${p.description}', style: TextStyle(color: Colors.white)),
                ),
              ],
            ),
          ),
        )).toList(),
      ),
    );
  }
}

class PortalExperienceView extends StatelessWidget {
  final RitualPortal portal;

  const PortalExperienceView({required this.portal});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(portal.name)),
      body: Stack(
        children: [
          Image.asset(portal.backgroundAsset, fit: BoxFit.cover, height: double.infinity, width: double.infinity),
          Center(child: Text(portal.description, style: TextStyle(fontSize: 24, color: Colors.white))),
        ],
      ),
    );
  }
}
