import 'package:flutter/foundation.dart';

@immutable
class RitualPortal {
  final String id;
  final String name;
  final String backgroundAsset;
  final String description;

  const RitualPortal({
    required this.id,
    required this.name,
    required this.backgroundAsset,
    required this.description,
  });
}
