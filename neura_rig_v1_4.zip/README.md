
# Neura Rig v1.4 — Cheek-Corner Tug + Lower-Lid Assist
- Smiles now **lift mouth corners** and subtly **raise the lower eyelids** for that cohesive, lifelike expression.
- Works via both `setAffect({smile})` and `setAffectPlus({cheek})`.

## Examples
```js
// Simple smile path with corner tug + lower-lid assist
NeuraRig.setAffect({ smile: 0.8 });

// Granular control with cheeks (and optional squint)
NeuraRig.setAffectPlus({ cheek: 0.8, squintL: 0.4, squintR: 0.4 });

// Reset
NeuraRig.setAffectPlus({}); NeuraRig.setAffect({browLift:0, smile:0}); NeuraRig.setLids(1);
```

Everything else (blink, gaze, visemes, phoneme sync, pose) remains compatible.
