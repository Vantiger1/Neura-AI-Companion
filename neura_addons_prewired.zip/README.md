# Neura Add-Ons Pre-Wired Package

This folder includes all modules and enhancements pre-integrated into `lib/neura/`.

## Integration Instructions

1. Drop the entire `lib/neura/` folder into your existing Flutter project.
2. Add relevant imports like:

```dart
import 'package:your_app/neura/neura_manager.dart';
import 'package:your_app/neura/neura_voice_engine.dart';
// and so on...
```

3. Initialize Neura in your `main.dart`:

```dart
await NeuraManager.init();
```

## Modules Included

- Emotion Engine
- Voice & Joke System
- Dream Journal & Player
- Memory & Growth Tracking
- Calendar Navigator
- Sleep Listener & Dream Interpreter
