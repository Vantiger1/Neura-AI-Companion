# Skill Pack 30 — Release Hardening (Safe Boot + Crash Recovery + Ship Mode)

## What this adds
1) Crash capture (local + encrypted)
   - FlutterError.onError
   - PlatformDispatcher.instance.onError
   - Zone capture via runZonedGuarded
2) Safe Mode auto-enable after repeated crashes
   - Persistent crash-streak tracking
   - User-visible recovery screen
3) Ship Mode
   - Tightens UI/diagnostics
   - Disables dev-only actions in production
   - Reduces max crash events stored

## Integration (main.dart)
Pseudocode wiring (adjust to your kernel naming):

```dart
Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  final safetyStore = await NeuraSafetyConfigStore.create();
  final shipMode = await safetyStore.getShipMode();

  final crashStore = await NeuraCrashStore.create(maxEvents: shipMode.maxCrashEvents);
  final crashRecovery = NeuraCrashRecovery(
    crashStore: crashStore,
    audit: auditLogStoreInstance,
    policy: policyEngineInstance,
    safetyStore: safetyStore,
  );

  crashRecovery.installGlobalHandlers(
    platformLabel: Platform.isWindows ? 'windows' : 'android',
    contextProvider: () => {'shipMode': shipMode.enabled},
  );

  final prevCrashed = await crashRecovery.wasPreviousSessionCrashed();

  final safeModeManager = NeuraSafeModeManager(
    store: safetyStore,
    audit: auditLogStoreInstance,
    policy: policyEngineInstance,
    registry: NeuraKernel.I.registry,
  );
  await safeModeManager.registerActions();

  final safeState = await safeModeManager.onBoot(previousSessionCrashed: prevCrashed);

  crashRecovery.runGuarded(() {
    runApp(MyApp(safeState: safeState, crashStore: crashStore, safeMode: safeModeManager));
  }, platformLabel: Platform.isWindows ? 'windows' : 'android');

  // Mark clean once the first frame is drawn (recommended)
  // WidgetsBinding.instance.addPostFrameCallback((_) => crashRecovery.markSessionClean());
}
```

## Recommended Safe Mode behavior
When Safe Mode is ON:
- Force model profile to Tiny/Base (Step 29)
- Disable "systemAutomation" (Policy engine)
- Require approvals for export/import/execute (already built)
- Show a Safe Mode banner & route to NeuraSafeModeScreen

## Next
Step 31: Consent-aware, offline-first “Skill Store” (signed module install/uninstall).
