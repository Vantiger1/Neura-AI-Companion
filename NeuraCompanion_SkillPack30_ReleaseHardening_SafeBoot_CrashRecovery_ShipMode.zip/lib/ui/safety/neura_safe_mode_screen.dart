import 'package:flutter/material.dart';

import '../../services/safety/neura_safe_mode.dart';
import '../../services/safety/neura_safe_mode_manager.dart';
import '../../services/crash/neura_crash_store.dart';

class NeuraSafeModeScreen extends StatefulWidget {
  final NeuraSafeModeManager safeMode;
  final NeuraCrashStore crashStore;

  const NeuraSafeModeScreen({
    super.key,
    required this.safeMode,
    required this.crashStore,
  });

  @override
  State<NeuraSafeModeScreen> createState() => _NeuraSafeModeScreenState();
}

class _NeuraSafeModeScreenState extends State<NeuraSafeModeScreen> {
  bool _busy = false;
  String _status = '';
  List<Map<String, dynamic>> _events = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final list = await widget.crashStore.list();
    setState(() {
      _events = list.map((e) => e.toJson()).toList();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Safe Mode')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            FutureBuilder<NeuraSafeModeState>(
              future: widget.safeMode.current(),
              builder: (context, snap) {
                final state = snap.data ?? NeuraSafeModeState.off();
                return _card(
                  title: state.enabled ? 'Safe Mode is ON' : 'Safe Mode is OFF',
                  subtitle: state.enabled
                      ? (state.reason.isEmpty ? 'Enabled for stability.' : state.reason)
                      : 'Normal operating mode.',
                );
              },
            ),
            const SizedBox(height: 12),
            _rowButtons(context),
            const SizedBox(height: 12),
            if (_status.isNotEmpty) Text(_status),
            const SizedBox(height: 12),
            Expanded(
              child: _events.isEmpty
                  ? const Center(child: Text('No crash events recorded.'))
                  : ListView.builder(
                      itemCount: _events.length,
                      itemBuilder: (context, i) {
                        final e = _events[i];
                        return ListTile(
                          title: Text(e['summary'] ?? 'Crash'),
                          subtitle: Text('${e['at']} • ${e['platform']}'),
                          onTap: () => _showDetails(context, e),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _rowButtons(BuildContext context) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        ElevatedButton.icon(
          onPressed: _busy ? null : () async => _export(context),
          icon: const Icon(Icons.download),
          label: const Text('Export Crash Bundle'),
        ),
        OutlinedButton.icon(
          onPressed: _busy ? null : () async => _clear(),
          icon: const Icon(Icons.delete_outline),
          label: const Text('Clear Logs'),
        ),
        FilledButton.icon(
          onPressed: _busy ? null : () async => _disableSafeMode(),
          icon: const Icon(Icons.lock_open),
          label: const Text('Disable Safe Mode'),
        ),
      ],
    );
  }

  Future<void> _export(BuildContext context) async {
    setState(() {
      _busy = true;
      _status = 'Preparing export...';
    });
    final bundle = await widget.crashStore.exportBundle();

    final preview = (bundle['events'] as List).take(3).toList();
    if (mounted) {
      showDialog(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Crash Bundle Preview'),
          content: SingleChildScrollView(child: Text(preview.toString())),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
          ],
        ),
      );
    }
    setState(() {
      _busy = false;
      _status = 'Export ready (wire to Step 18 export for real file output).';
    });
  }

  Future<void> _clear() async {
    setState(() {
      _busy = true;
      _status = 'Clearing...';
    });
    await widget.crashStore.clear();
    await _load();
    setState(() {
      _busy = false;
      _status = 'Cleared.';
    });
  }

  Future<void> _disableSafeMode() async {
    setState(() {
      _busy = true;
      _status = 'Requesting...';
    });

    // Your action registry may expose invoke differently; adapt as needed.
    final res = await widget.safeMode.registry.invoke('safe_mode_disable', const {});

    setState(() {
      _busy = false;
      _status = res.ok ? 'Safe Mode disabled.' : 'Blocked: ${res.message}';
    });
  }

  void _showDetails(BuildContext context, Map<String, dynamic> e) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: const Text('Crash Details'),
        content: SingleChildScrollView(
          child: Text((e['details'] as String?) ?? ''),
        ),
        actions: [
          TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close')),
        ],
      ),
    );
  }

  Widget _card({required String title, required String subtitle}) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
            const SizedBox(height: 8),
            Text(subtitle),
          ],
        ),
      ),
    );
  }
}
