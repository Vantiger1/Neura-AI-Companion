class NeuraCrashEvent {
  final String id;
  final DateTime at;
  final String platform; // android/windows/web/ios/macos/linux
  final String summary;
  final String details; // stack trace or error string
  final Map<String, dynamic> context;

  const NeuraCrashEvent({
    required this.id,
    required this.at,
    required this.platform,
    required this.summary,
    required this.details,
    required this.context,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'at': at.toIso8601String(),
        'platform': platform,
        'summary': summary,
        'details': details,
        'context': context,
      };

  static NeuraCrashEvent fromJson(Map<String, dynamic> j) => NeuraCrashEvent(
        id: j['id'] as String,
        at: DateTime.parse(j['at'] as String),
        platform: (j['platform'] as String?) ?? 'unknown',
        summary: (j['summary'] as String?) ?? 'Unknown crash',
        details: (j['details'] as String?) ?? '',
        context: (j['context'] as Map?)?.cast<String, dynamic>() ?? const {},
      );
}
