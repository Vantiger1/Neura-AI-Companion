import '../audit/neura_key_provider.dart';
import '../audit/neura_encrypted_json_store.dart';
import 'neura_crash_event.dart';

/// Stores crashes locally and encrypted.
class NeuraCrashStore {
  final NeuraEncryptedJsonStore _store;
  final int maxEvents;

  NeuraCrashStore._(this._store, {required this.maxEvents});

  static Future<NeuraCrashStore> create({required int maxEvents}) async {
    final keyProvider = NeuraKeyProvider();
    final enc = NeuraEncryptedJsonStore(
      fileName: 'neura_crash_log.encdb',
      keyProvider: keyProvider,
    );
    return NeuraCrashStore._(enc, maxEvents: maxEvents);
  }

  Future<Map<String, dynamic>> _load() => _store.readJson(fallback: {'events': <dynamic>[]});

  Future<void> _save(Map<String, dynamic> obj) => _store.writeJson(obj);

  Future<List<NeuraCrashEvent>> list() async {
    final obj = await _load();
    final raw = (obj['events'] as List?) ?? const [];
    return raw
        .whereType<Map>()
        .map((m) => NeuraCrashEvent.fromJson(m.cast<String, dynamic>()))
        .toList()
        .reversed
        .toList();
  }

  Future<void> append(NeuraCrashEvent e) async {
    final obj = await _load();
    final raw = (obj['events'] as List?) ?? <dynamic>[];
    raw.add(e.toJson());
    while (raw.length > maxEvents) {
      raw.removeAt(0);
    }
    obj['events'] = raw;
    await _save(obj);
  }

  Future<void> clear() async => _save({'events': <dynamic>[]});

  Future<Map<String, dynamic>> exportBundle() async {
    final events = await list();
    return {
      'exportedAt': DateTime.now().toIso8601String(),
      'events': events.map((e) => e.toJson()).toList(),
    };
  }
}
