import 'dart:async';
import 'dart:ui';

import 'package:flutter/foundation.dart';

import '../audit/neura_audit_log_store.dart';
import '../audit/neura_audit_models.dart';
import '../policy/neura_policy_engine.dart';
import '../safety/neura_safe_mode_store.dart';

import 'neura_crash_event.dart';
import 'neura_crash_store.dart';

/// Step 30 — Crash capture + safe-mode triggering.
class NeuraCrashRecovery {
  final NeuraCrashStore crashStore;
  final NeuraAuditLogStore audit;
  final NeuraPolicyEngine policy;
  final NeuraSafetyConfigStore safetyStore;

  NeuraCrashRecovery({
    required this.crashStore,
    required this.audit,
    required this.policy,
    required this.safetyStore,
  });

  Future<void> markSessionClean() async => safetyStore.markPreviousSessionCrashed(false);
  Future<void> markSessionCrashed() async => safetyStore.markPreviousSessionCrashed(true);
  Future<bool> wasPreviousSessionCrashed() async => safetyStore.wasPreviousSessionCrashed();

  /// Install global crash handlers. Call early in main().
  void installGlobalHandlers({
    required String platformLabel,
    Map<String, dynamic> Function()? contextProvider,
  }) {
    FlutterError.onError = (FlutterErrorDetails details) async {
      await _handle(
        platformLabel: platformLabel,
        summary: details.exceptionAsString(),
        details: details.stack?.toString() ?? '',
        contextProvider: contextProvider,
      );
      FlutterError.dumpErrorToConsole(details);
    };

    PlatformDispatcher.instance.onError = (error, stack) {
      _handle(
        platformLabel: platformLabel,
        summary: error.toString(),
        details: stack.toString(),
        contextProvider: contextProvider,
      );
      return true;
    };
  }

  /// Wrap runApp with this to capture zone-level async exceptions.
  void runGuarded(
    void Function() body, {
    required String platformLabel,
    Map<String, dynamic> Function()? contextProvider,
  }) {
    runZonedGuarded(
      body,
      (error, stack) async {
        await _handle(
          platformLabel: platformLabel,
          summary: error.toString(),
          details: stack.toString(),
          contextProvider: contextProvider,
        );
      },
    );
  }

  Future<void> _handle({
    required String platformLabel,
    required String summary,
    required String details,
    Map<String, dynamic> Function()? contextProvider,
  }) async {
    await markSessionCrashed();

    final now = DateTime.now();
    final ev = NeuraCrashEvent(
      id: 'CRASH-${now.microsecondsSinceEpoch}',
      at: now,
      platform: platformLabel,
      summary: summary,
      details: details,
      context: contextProvider?.call() ?? const {},
    );
    await crashStore.append(ev);

    await audit.append(
      NeuraAuditEvent(
        id: 'AUD-${now.microsecondsSinceEpoch}',
        type: 'app_crash_captured',
        at: now,
        actionId: 'crash_recovery',
        args: {'platform': platformLabel, 'summary': summary},
        outcome: 'info',
        disclaimerVersion: 'v1',
        checklistAccepted: true,
        argsHash: NeuraAuditLogStore.hashArgs({'platform': platformLabel, 'summary': summary}),
        note: 'Step 30 crash capture',
      ),
    );
  }
}
