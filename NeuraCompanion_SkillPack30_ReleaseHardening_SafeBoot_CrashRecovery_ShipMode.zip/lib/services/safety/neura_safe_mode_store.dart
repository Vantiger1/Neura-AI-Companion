import '../audit/neura_key_provider.dart';
import '../audit/neura_encrypted_json_store.dart';
import 'neura_safe_mode.dart';
import 'neura_ship_mode.dart';

/// Persists Safe Mode and Ship Mode locally (encrypted).
class NeuraSafetyConfigStore {
  final NeuraEncryptedJsonStore _store;

  NeuraSafetyConfigStore._(this._store);

  static Future<NeuraSafetyConfigStore> create() async {
    final keyProvider = NeuraKeyProvider();
    final enc = NeuraEncryptedJsonStore(
      fileName: 'neura_safety_config.encdb',
      keyProvider: keyProvider,
    );
    return NeuraSafetyConfigStore._(enc);
  }

  Future<Map<String, dynamic>> readRaw() => _store.readJson(fallback: {
        'safeMode': NeuraSafeModeState.off().toJson(),
        'shipMode': NeuraShipMode.dev().toJson(),
        'previousSessionCrashed': false,
      });

  Future<void> writeRaw(Map<String, dynamic> obj) => _store.writeJson(obj);

  Future<NeuraSafeModeState> getSafeMode() async {
    final obj = await readRaw();
    return NeuraSafeModeState.fromJson((obj['safeMode'] as Map).cast<String, dynamic>());
  }

  Future<void> setSafeMode(NeuraSafeModeState state) async {
    final obj = await readRaw();
    obj['safeMode'] = state.toJson();
    await writeRaw(obj);
  }

  Future<NeuraShipMode> getShipMode() async {
    final obj = await readRaw();
    return NeuraShipMode.fromJson((obj['shipMode'] as Map).cast<String, dynamic>());
  }

  Future<void> setShipMode(NeuraShipMode mode) async {
    final obj = await readRaw();
    obj['shipMode'] = mode.toJson();
    await writeRaw(obj);
  }

  Future<bool> wasPreviousSessionCrashed() async {
    final obj = await readRaw();
    return (obj['previousSessionCrashed'] as bool?) ?? false;
  }

  Future<void> markPreviousSessionCrashed(bool crashed) async {
    final obj = await readRaw();
    obj['previousSessionCrashed'] = crashed;
    await writeRaw(obj);
  }
}
