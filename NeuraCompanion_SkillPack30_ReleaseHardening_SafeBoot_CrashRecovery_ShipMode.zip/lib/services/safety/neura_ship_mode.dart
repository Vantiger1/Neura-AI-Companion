/// Step 30 — Ship Mode toggles & feature flags.
///
/// ShipMode is a runtime configuration that tightens behavior for public builds:
/// - reduces debug surfaces
/// - defaults to safer model profile (Tiny/Base depending on your preference)
/// - restricts risky actions behind approvals (handled in earlier steps)
class NeuraShipMode {
  final bool enabled;

  /// When true, hide internal debug UI and diagnostics that aren't needed by end users.
  final bool hideDebugPanels;

  /// When true, prevent "dev-only" actions from registering.
  final bool disableDevActions;

  /// Max number of crash events stored locally.
  final int maxCrashEvents;

  const NeuraShipMode({
    required this.enabled,
    required this.hideDebugPanels,
    required this.disableDevActions,
    required this.maxCrashEvents,
  });

  factory NeuraShipMode.dev() => const NeuraShipMode(
        enabled: false,
        hideDebugPanels: false,
        disableDevActions: false,
        maxCrashEvents: 250,
      );

  factory NeuraShipMode.ship() => const NeuraShipMode(
        enabled: true,
        hideDebugPanels: true,
        disableDevActions: true,
        maxCrashEvents: 50,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'hideDebugPanels': hideDebugPanels,
        'disableDevActions': disableDevActions,
        'maxCrashEvents': maxCrashEvents,
      };

  static NeuraShipMode fromJson(Map<String, dynamic> j) => NeuraShipMode(
        enabled: (j['enabled'] as bool?) ?? false,
        hideDebugPanels: (j['hideDebugPanels'] as bool?) ?? false,
        disableDevActions: (j['disableDevActions'] as bool?) ?? false,
        maxCrashEvents: (j['maxCrashEvents'] as num?)?.toInt() ?? 250,
      );
}
