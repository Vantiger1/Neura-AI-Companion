class NeuraSafeModeState {
  final bool enabled;

  /// Reason is user-visible text explaining why safe mode is on.
  final String reason;

  /// Tracks consecutive crash count to trigger safe mode automatically.
  final int crashStreak;

  const NeuraSafeModeState({
    required this.enabled,
    required this.reason,
    required this.crashStreak,
  });

  factory NeuraSafeModeState.off() => const NeuraSafeModeState(
        enabled: false,
        reason: '',
        crashStreak: 0,
      );

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'reason': reason,
        'crashStreak': crashStreak,
      };

  static NeuraSafeModeState fromJson(Map<String, dynamic> j) => NeuraSafeModeState(
        enabled: (j['enabled'] as bool?) ?? false,
        reason: (j['reason'] as String?) ?? '',
        crashStreak: (j['crashStreak'] as num?)?.toInt() ?? 0,
      );

  NeuraSafeModeState copyWith({
    bool? enabled,
    String? reason,
    int? crashStreak,
  }) =>
      NeuraSafeModeState(
        enabled: enabled ?? this.enabled,
        reason: reason ?? this.reason,
        crashStreak: crashStreak ?? this.crashStreak,
      );
}
