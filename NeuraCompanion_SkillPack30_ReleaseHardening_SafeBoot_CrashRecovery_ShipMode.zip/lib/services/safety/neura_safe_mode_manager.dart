import '../audit/neura_audit_log_store.dart';
import '../audit/neura_audit_models.dart';
import '../policy/neura_policy_engine.dart';
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';

import 'neura_safe_mode.dart';
import 'neura_safe_mode_store.dart';
import 'neura_ship_mode.dart';

/// Step 30 — Safe Mode boot guard.
///
/// Purpose:
/// - If app crashes repeatedly, auto-enter Safe Mode.
/// - Safe Mode limits risky capabilities and makes recovery UX explicit.
class NeuraSafeModeManager {
  final NeuraSafetyConfigStore store;
  final NeuraAuditLogStore audit;
  final NeuraPolicyEngine policy;
  final NeuraActionRegistry registry;

  NeuraSafeModeManager({
    required this.store,
    required this.audit,
    required this.policy,
    required this.registry,
  });

  /// Crash streak threshold before entering safe mode automatically.
  final int crashThreshold = 2;

  Future<NeuraSafeModeState> current() => store.getSafeMode();

  Future<void> registerActions() async {
    registry.register(
      NeuraAction(
        id: 'safe_mode_enable',
        title: 'Enable Safe Mode',
        description: 'Enables Safe Mode (limits risky operations until disabled).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.settings,
        handler: (req) async {
          await setEnabled(true, reason: 'Enabled by user.');
          return NeuraActionResult.success('Safe Mode enabled');
        },
      ),
    );

    registry.register(
      NeuraAction(
        id: 'safe_mode_disable',
        title: 'Disable Safe Mode',
        description: 'Disables Safe Mode after user confirmation.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.settings,
        handler: (req) async {
          final decision = policy.decide('policy_safe_mode_disable');
          if (!decision.allowed) {
            return NeuraActionResult.error('Blocked: ${decision.reason}');
          }
          await setEnabled(false, reason: 'Disabled by user.');
          return NeuraActionResult.success('Safe Mode disabled');
        },
      ),
    );

    registry.register(
      NeuraAction(
        id: 'ship_mode_set',
        title: 'Set Ship Mode',
        description: 'Toggles Ship Mode for public builds (tightens UI + disables dev actions).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.settings,
        handler: (req) async {
          final enabled = (req.args['enabled'] as bool?) ?? false;
          final mode = enabled ? NeuraShipMode.ship() : NeuraShipMode.dev();
          await store.setShipMode(mode);
          await _audit('ship_mode_set', {'enabled': enabled});
          return NeuraActionResult.success('OK', data: {'shipMode': mode.toJson()});
        },
      ),
    );
  }

  Future<NeuraSafeModeState> onBoot({required bool previousSessionCrashed}) async {
    final state = await store.getSafeMode();
    if (!previousSessionCrashed) {
      if (state.crashStreak != 0) {
        await store.setSafeMode(state.copyWith(crashStreak: 0));
      }
      return await store.getSafeMode();
    }

    final nextStreak = state.crashStreak + 1;
    var next = state.copyWith(crashStreak: nextStreak);

    if (nextStreak >= crashThreshold && !state.enabled) {
      next = next.copyWith(
        enabled: true,
        reason: 'Neura detected repeated crashes and entered Safe Mode to protect your device and data.',
      );
      await _audit('safe_mode_auto_enabled', {'crashStreak': nextStreak});
    } else {
      await _audit('boot_crash_streak', {'crashStreak': nextStreak});
    }

    await store.setSafeMode(next);
    return next;
  }

  Future<void> setEnabled(bool enabled, {required String reason}) async {
    final current = await store.getSafeMode();
    final next = current.copyWith(
      enabled: enabled,
      reason: enabled ? reason : '',
      crashStreak: enabled ? current.crashStreak : 0,
    );
    await store.setSafeMode(next);
    await _audit(enabled ? 'safe_mode_enabled' : 'safe_mode_disabled', {'reason': reason});
  }

  Future<void> _audit(String type, Map<String, dynamic> args) async {
    final now = DateTime.now();
    await audit.append(
      NeuraAuditEvent(
        id: 'AUD-${now.microsecondsSinceEpoch}',
        type: type,
        at: now,
        actionId: 'safety_config',
        args: args,
        outcome: 'info',
        disclaimerVersion: 'v1',
        checklistAccepted: true,
        argsHash: NeuraAuditLogStore.hashArgs(args),
        note: 'Step 30 safety hardening',
      ),
    );
  }
}
