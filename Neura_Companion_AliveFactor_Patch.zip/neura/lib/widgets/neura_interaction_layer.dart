import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../src/modules/core/neura_core.dart';

/// Wraps the app and updates Neura's interaction tracker on user activity.
///
/// This is how the IdleLifeSystem knows when to do ambient actions.
class NeuraInteractionLayer extends StatefulWidget {
  const NeuraInteractionLayer({super.key, required this.child});
  final Widget child;

  @override
  State<NeuraInteractionLayer> createState() => _NeuraInteractionLayerState();
}

class _NeuraInteractionLayerState extends State<NeuraInteractionLayer> {
  final FocusNode _focus = FocusNode(debugLabel: 'neura_interaction_focus');

  void _touch() {
    // Idempotent safe-start.
    NeuraCore.ensureStarted();
    NeuraCore.interaction.touch();
  }

  @override
  void dispose() {
    _focus.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Listener(
      onPointerDown: (_) => _touch(),
      onPointerMove: (_) => _touch(),
      onPointerSignal: (_) => _touch(),
      child: RawKeyboardListener(
        focusNode: _focus,
        autofocus: true,
        onKey: (RawKeyEvent _) => _touch(),
        child: widget.child,
      ),
    );
  }
}
