import 'package:flutter/material.dart';

import '../src/modules/core/neura_core.dart';

class NeuraOverlay extends StatefulWidget {
  const NeuraOverlay({super.key});

  @override
  State<NeuraOverlay> createState() => _NeuraOverlayState();
}

class _NeuraOverlayState extends State<NeuraOverlay> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final voice = NeuraCore.voice;
    final idle = NeuraCore.idleLife;

    return AnimatedBuilder(
      animation: Listenable.merge([voice, idle]),
      builder: (context, _) {
        final mouth = voice.mouth.clamp(0.0, 1.0);
        final viseme = voice.viseme;
        final isListening = voice.state.name == 'listening';
        final idleLevel = idle.idleLevel;
        final idleAction = idle.idleAction;
        final lastNudge = NeuraCore.memory.getJson<String>('idle.last_nudge') ?? '';

        return Material(
          color: Colors.transparent,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (_expanded)
                _Bubble(
                  heard: voice.lastHeard,
                  spoken: voice.lastSpoken,
                  stateLabel: voice.state.name,
                  room: NeuraCore.continuity.currentRoom ?? 'penthouse',
                  mood: NeuraCore.continuity.currentMood ?? 'calm',
                  idleAction: idleLevel == 0 ? '' : idleAction,
                  nudge: lastNudge,
                ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _expanded = !_expanded),
                    child: _AvatarGlow(mouth: mouth, viseme: viseme, idleLevel: idleLevel, idleAction: idleAction),
                  ),
                  const SizedBox(width: 10),
                  FloatingActionButton.small(
                    heroTag: 'neura_mic',
                    onPressed: () => voice.toggleListening(),
                    backgroundColor: isListening ? Colors.redAccent : null,
                    child: Icon(isListening ? Icons.mic : Icons.mic_none),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AvatarGlow extends StatelessWidget {
  const _AvatarGlow({
    required this.mouth,
    required this.viseme,
    required this.idleLevel,
    required this.idleAction,
  });

  final double mouth;
  final int viseme;
  final int idleLevel;
  final String idleAction;

  @override
  Widget build(BuildContext context) {
    final s = 1.0 + (mouth * 0.08);
    final bob = idleLevel == 0
        ? 0.0
        : (idleAction == 'walk'
            ? 0.04
            : (idleAction == 'breathe' ? 0.02 : 0.012));
    final turns = idleLevel == 0
        ? 0.0
        : (idleAction == 'look'
            ? -0.01
            : (idleAction == 'scan' ? 0.01 : 0.0));

    return AnimatedSlide(
      offset: Offset(0, -bob),
      duration: const Duration(milliseconds: 450),
      curve: Curves.easeInOut,
      child: AnimatedRotation(
        turns: turns,
        duration: const Duration(milliseconds: 450),
        curve: Curves.easeInOut,
        child: AnimatedScale(
          scale: s,
          duration: const Duration(milliseconds: 120),
          child: Container(
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              boxShadow: [
                BoxShadow(
                  blurRadius: 18 + mouth * 10,
                  spreadRadius: 2 + mouth * 2,
                  color: Colors.cyanAccent.withOpacity(0.25 + mouth * 0.15),
                ),
              ],
            ),
            child: ClipOval(
              child: Stack(
                fit: StackFit.expand,
                children: [
                  Image.asset('assets/images/ai_avatar.png', fit: BoxFit.cover),
                  Align(
                    alignment: const Alignment(0.0, 0.62),
                    child: _MouthIndicator(mouth: mouth, viseme: viseme),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _MouthIndicator extends StatelessWidget {
  const _MouthIndicator({required this.mouth, required this.viseme});
  final double mouth;
  final int viseme;

  @override
  Widget build(BuildContext context) {
    final baseW = 20.0;
    final baseH = 6.0;

    final w = switch (viseme) {
      3 => baseW * 0.9,
      2 => baseW * 1.15,
      5 => baseW * 1.0,
      4 => baseW * 0.95,
      _ => baseW,
    };
    final h = switch (viseme) {
      3 => baseH * (1.2 + mouth * 1.4),
      2 => baseH * (0.7 + mouth * 0.8),
      5 => baseH * (0.55 + mouth * 0.5),
      _ => baseH * (0.9 + mouth * 1.0),
    };

    final radius = viseme == 3 ? 999.0 : 8.0;
    final opacity = 0.18 + (mouth * 0.22);

    return AnimatedContainer(
      duration: const Duration(milliseconds: 90),
      width: w,
      height: h,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        border: Border.all(color: Colors.white.withOpacity(opacity), width: 1.2),
        color: Colors.black.withOpacity(0.10 + mouth * 0.08),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({
    required this.heard,
    required this.spoken,
    required this.stateLabel,
    required this.room,
    required this.mood,
    required this.idleAction,
    required this.nudge,
  });

  final String heard;
  final String spoken;
  final String stateLabel;
  final String room;
  final String mood;
  final String idleAction;
  final String nudge;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      width: 290,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withOpacity(0.9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.onSurface.withOpacity(0.08)),
      ),
      child: DefaultTextStyle(
        style: theme.textTheme.bodySmall ?? const TextStyle(fontSize: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Neura: $stateLabel  •  $room  •  $mood', style: theme.textTheme.labelMedium),
            if (idleAction.trim().isNotEmpty) ...[
              const SizedBox(height: 4),
              Text('Idle: $idleAction', style: theme.textTheme.labelSmall),
            ],
            const SizedBox(height: 8),
            if (heard.trim().isNotEmpty) ...[
              Text('Heard: $heard'),
              const SizedBox(height: 6),
            ],
            if (spoken.trim().isNotEmpty) Text('Said: $spoken'),
            if (nudge.trim().isNotEmpty) ...[
              const SizedBox(height: 8),
              Text('Nudge: $nudge'),
            ],
            if (heard.trim().isEmpty && spoken.trim().isEmpty)
              const Text('Tap the avatar to expand. Use the mic to speak commands.'),
          ],
        ),
      ),
    );
  }
}
