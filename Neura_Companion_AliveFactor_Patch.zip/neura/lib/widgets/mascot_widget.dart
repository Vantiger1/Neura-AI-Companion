import 'package:flutter/material.dart';
import 'package:flutter/services.dart' show rootBundle;
import 'package:lottie/lottie.dart';

import '../models/ai_avatar.dart';
import '../services/avatar_service.dart';

/// A safe mascot widget:
/// - Tries to render the selected Lottie animation
/// - Falls back to the static avatar image if assets are missing
class MascotWidget extends StatefulWidget {
  const MascotWidget({super.key, this.size = 100});

  final double size;

  @override
  State<MascotWidget> createState() => _MascotWidgetState();
}

class _MascotWidgetState extends State<MascotWidget> {
  final _avatarService = AvatarService();
  AIAvatar? _avatar;

  @override
  void initState() {
    super.initState();
    _avatarService.getSelectedAvatar().then((a) {
      if (mounted) setState(() => _avatar = a);
    });
  }

  @override
  Widget build(BuildContext context) {
    final avatar = _avatar;
    if (avatar == null) return const SizedBox.shrink();

    return FutureBuilder<ByteData>(
      future: rootBundle.load(avatar.assetPath),
      builder: (ctx, snap) {
        if (snap.connectionState == ConnectionState.done && snap.hasData) {
          return Lottie.asset(avatar.assetPath, width: widget.size, height: widget.size, fit: BoxFit.contain);
        }
        // Fallback
        return Image.asset('assets/images/ai_avatar.png', width: widget.size, height: widget.size, fit: BoxFit.cover);
      },
    );
  }
}
