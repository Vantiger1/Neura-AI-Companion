import 'package:shared_preferences/shared_preferences.dart';

import '../models/ai_avatar.dart';

class AvatarService {
  static const _kSelected = 'avatar.selected';

  /// Returns available AI Avatars.
  List<AIAvatar> getAvailableAvatars() {
    // If you add Lottie/Rive assets later, set assetPath accordingly.
    return const [
      AIAvatar(id: 'neura', name: 'Neura', assetPath: 'assets/animations/neura_idle.json'),
      AIAvatar(id: 'neuro', name: 'Neuro', assetPath: 'assets/animations/neuro_idle.json'),
    ];
  }

  Future<void> selectAvatar(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kSelected, id);
  }

  Future<AIAvatar> getSelectedAvatar() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString(_kSelected);

    final available = getAvailableAvatars();
    return available.firstWhere(
      (a) => a.id == id,
      orElse: () => available.first,
    );
  }
}
