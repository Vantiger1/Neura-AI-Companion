import '../src/modules/core/voice/simple_emotion_analyzer.dart';

class EmotionAnalysisService {
  final SimpleEmotionAnalyzer _analyzer = SimpleEmotionAnalyzer();

  /// Analyzes text and returns a mood tag.
  ///
  /// Values: anxious, sad, angry, happy, calm, neutral
  Future<String> analyzeEmotion(String text) async {
    return _analyzer.analyze(text);
  }
}
