import 'package:flutter/material.dart';
import 'src/app.dart';
import 'src/modules/core/neura_core.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await NeuraCore.start();
  runApp(const NeuroCompanionApp());
}
