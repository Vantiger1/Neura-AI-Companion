import 'package:flutter/material.dart';

import '../services/auth_service.dart';

class ResetPasswordScreen extends StatefulWidget {
  const ResetPasswordScreen({super.key});

  @override
  State<ResetPasswordScreen> createState() => _ResetPasswordScreenState();
}

class _ResetPasswordScreenState extends State<ResetPasswordScreen> {
  final _email = TextEditingController();
  bool _loading = false;
  String? _msg;
  String? _err;

  Future<void> _send() async {
    setState(() {
      _loading = true;
      _err = null;
      _msg = null;
    });
    try {
      await AuthService().sendPasswordReset(_email.text.trim());
      setState(() => _msg = 'Password reset email sent.');
    } catch (e) {
      setState(() => _err = e.toString());
    } finally {
      if (mounted) setState(() => _loading = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Reset Password')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            if (_err != null) Text(_err!, style: const TextStyle(color: Colors.red)),
            if (_msg != null) Text(_msg!),
            TextField(
              controller: _email,
              decoration: const InputDecoration(labelText: 'Email'),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _loading ? null : _send,
              child: _loading ? const CircularProgressIndicator() : const Text('Send reset link'),
            ),
          ],
        ),
      ),
    );
  }
}
