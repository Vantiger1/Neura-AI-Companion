import 'package:flutter/material.dart';

import '../core/neura_core.dart';

/// The Penthouse "Module World".
///
/// Modules are *objects* — not buttons.
/// This is intentionally asset-light so it runs out-of-the-box.
/// Replace the simple shapes/icons with your real room background + props
/// (SVG/Lottie/Rive/Unity overlays) when ready.
class PenthouseWorldScreen extends StatelessWidget {
  const PenthouseWorldScreen({super.key});

  static const _objects = <_PenthouseObject>[
    _PenthouseObject(
      id: 'journal_desk',
      label: 'Journal Desk',
      icon: Icons.edit_note,
      tabKey: 'journal',
      roomKey: 'journal_room',
      // x/y as fractional positions within the room.
      x: 0.18,
      y: 0.62,
    ),
    _PenthouseObject(
      id: 'mood_den',
      label: 'Mood Den',
      icon: Icons.mood,
      tabKey: 'mood',
      roomKey: 'mood_den',
      x: 0.56,
      y: 0.60,
    ),
    _PenthouseObject(
      id: 'goals_wall',
      label: 'Goals Wall',
      icon: Icons.flag,
      tabKey: 'goals',
      roomKey: 'goals_lab',
      x: 0.77,
      y: 0.38,
    ),
    _PenthouseObject(
      id: 'meditation_corner',
      label: 'Meditation Corner',
      icon: Icons.spa,
      tabKey: 'meditation',
      roomKey: 'meditation_sanctuary',
      x: 0.74,
      y: 0.78,
    ),
    _PenthouseObject(
      id: 'settings_console',
      label: 'Settings Console',
      icon: Icons.settings,
      tabKey: 'settings',
      roomKey: 'settings_console',
      x: 0.10,
      y: 0.30,
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Penthouse'),
        actions: [
          IconButton(
            tooltip: 'Neura status',
            icon: const Icon(Icons.info_outline),
            onPressed: () {
              final room = NeuraCore.continuity.currentRoom ?? 'penthouse';
              final mood = NeuraCore.continuity.currentMood ?? 'calm';
              final last = NeuraCore.continuity.lastInteraction;
              final lastLine = last == null
                  ? 'No recent interaction.'
                  : 'Last: ${last['kind'] ?? 'voice'} • ${last['mood'] ?? ''}';
              showDialog(
                context: context,
                builder: (_) => AlertDialog(
                  title: const Text('Neura Continuity'),
                  content: Text('Room: $room\nMood: $mood\n$lastLine'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK')),
                  ],
                ),
              );
            },
          ),
        ],
      ),
      body: LayoutBuilder(
        builder: (context, c) {
          final w = c.maxWidth;
          final h = c.maxHeight;

          return Stack(
            children: [
              // Background (placeholder). Swap with your penthouse art.
              Container(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [
                      theme.colorScheme.surface,
                      theme.colorScheme.surface.withOpacity(0.6),
                    ],
                  ),
                ),
              ),

              // Subtle "window glow" layer.
              Positioned.fill(
                child: IgnorePointer(
                  child: Opacity(
                    opacity: 0.15,
                    child: Container(
                      decoration: BoxDecoration(
                        gradient: RadialGradient(
                          center: const Alignment(0.55, -0.3),
                          radius: 1.2,
                          colors: [
                            Colors.cyanAccent.withOpacity(0.6),
                            Colors.transparent,
                          ],
                        ),
                      ),
                    ),
                  ),
                ),
              ),

              // Objects (modules).
              for (final obj in _objects)
                Positioned(
                  left: (w * obj.x) - 46,
                  top: (h * obj.y) - 46,
                  child: _ModuleObjectButton(obj: obj),
                ),

              // Room hint
              Positioned(
                left: 16,
                bottom: 16,
                child: _RoomHint(theme: theme),
              )
            ],
          );
        },
      ),
    );
  }
}

class _RoomHint extends StatelessWidget {
  const _RoomHint({required this.theme});

  final ThemeData theme;

  @override
  Widget build(BuildContext context) {
    final room = NeuraCore.continuity.currentRoom ?? 'penthouse';
    final mood = NeuraCore.continuity.currentMood ?? 'calm';

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withOpacity(0.75),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.onSurface.withOpacity(0.08)),
      ),
      child: DefaultTextStyle(
        style: theme.textTheme.bodySmall ?? const TextStyle(fontSize: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Room: $room', style: theme.textTheme.labelMedium),
            const SizedBox(height: 4),
            Text('Mood: $mood'),
            const SizedBox(height: 6),
            const Text('Tip: Say “open journal”, “check in”, “open goals”…'),
          ],
        ),
      ),
    );
  }
}

class _ModuleObjectButton extends StatelessWidget {
  const _ModuleObjectButton({required this.obj});

  final _PenthouseObject obj;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return InkWell(
      borderRadius: BorderRadius.circular(18),
      onTap: () async {
        // Persist the choice so EnhancedNavigation switches without extra routing.
        await NeuraCore.memory.putJson('ui.selected_tab', obj.tabKey);
        await NeuraCore.continuity.setRoom(obj.roomKey, reason: 'tap:${obj.id}');
        // Neura gives a quick acknowledgement.
        await NeuraCore.voice.speak('On it. Taking you to the ${obj.label}.');
      },
      child: Container(
        width: 92,
        height: 92,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: theme.colorScheme.surface.withOpacity(0.65),
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: theme.colorScheme.onSurface.withOpacity(0.10)),
          boxShadow: [
            BoxShadow(
              blurRadius: 14,
              spreadRadius: 1,
              color: Colors.cyanAccent.withOpacity(0.10),
            ),
          ],
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(obj.icon, size: 30),
            const SizedBox(height: 8),
            Text(
              obj.label,
              textAlign: TextAlign.center,
              style: (theme.textTheme.labelSmall ?? const TextStyle(fontSize: 11)).copyWith(
                height: 1.1,
              ),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

class _PenthouseObject {
  const _PenthouseObject({
    required this.id,
    required this.label,
    required this.icon,
    required this.tabKey,
    required this.roomKey,
    required this.x,
    required this.y,
  });

  final String id;
  final String label;
  final IconData icon;
  final String tabKey;
  final String roomKey;
  final double x;
  final double y;
}
