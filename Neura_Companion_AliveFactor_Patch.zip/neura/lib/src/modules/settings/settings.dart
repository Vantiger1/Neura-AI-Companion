import 'package:flutter/material.dart';
import 'package:share_plus/share_plus.dart';

import '../core/neura_core.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  Future<void> _export(BuildContext context) async {
    final json = NeuraCore.memory.exportDecryptedJson();
    await Share.share(json, subject: 'Neura Companion – My Data Export');
  }

  Future<void> _deleteAll(BuildContext context) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete local data?'),
        content: const Text('This wipes Neura\'s local memory on this device. This cannot be undone.'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Delete')),
        ],
      ),
    );
    if (ok == true) {
      await NeuraCore.memory.nukeAll();
      // Reset tab to home to avoid weirdness.
      await NeuraCore.memory.putJson('ui.selected_tab', 'home');
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Local data deleted.')));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final nudgesEnabled = NeuraCore.memory.getJson<bool>('idle.nudges_enabled') ?? true;
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Presence', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          _IdleNudgesTile(initialValue: nudgesEnabled),
          const Divider(height: 32),
          const Text('Privacy & Data', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.lock),
            title: const Text('Encrypted local memory'),
            subtitle: const Text('Your core personalization stays on-device by default.'),
          ),
          ListTile(
            leading: const Icon(Icons.upload_file),
            title: const Text('Export my data'),
            subtitle: const Text('Export a decrypted JSON snapshot (share it to your email/drive).'),
            onTap: () => _export(context),
          ),
          ListTile(
            leading: const Icon(Icons.delete_forever),
            title: const Text('Delete my local data'),
            subtitle: const Text('Wipes Neura\'s local memory vault.'),
            onTap: () => _deleteAll(context),
          ),
          const Divider(height: 32),
          const Text('Voice', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          ListTile(
            leading: const Icon(Icons.mic),
            title: const Text('Voice loop'),
            subtitle: const Text('Use the mic button (bottom-right) to speak commands and get replies.'),
          ),
          const Divider(height: 32),
          const Text('About', style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          const ListTile(
            leading: Icon(Icons.info_outline),
            title: Text('Neura Companion'),
            subtitle: Text('Local-first, privacy-forward companion OS.'),
          ),
        ],
      ),
    );
  }
}

class _IdleNudgesTile extends StatefulWidget {
  const _IdleNudgesTile({required this.initialValue});
  final bool initialValue;

  @override
  State<_IdleNudgesTile> createState() => _IdleNudgesTileState();
}

class _IdleNudgesTileState extends State<_IdleNudgesTile> {
  late bool _enabled = widget.initialValue;

  @override
  Widget build(BuildContext context) {
    return SwitchListTile(
      secondary: const Icon(Icons.auto_awesome),
      title: const Text('Idle nudges'),
      subtitle: const Text('Neura can occasionally suggest a helpful next step when you go quiet.'),
      value: _enabled,
      onChanged: (v) async {
        setState(() => _enabled = v);
        await NeuraCore.memory.putJson('idle.nudges_enabled', v);
      },
    );
  }
}
