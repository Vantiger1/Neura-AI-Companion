import 'dart:async';

import 'package:flutter/material.dart';

import '../core/neura_core.dart';
import '../penthouse/penthouse_world.dart';
import '../journal/journal.dart';
import '../mood/mood_checkin.dart';
import '../goals/goal_tracker.dart';
import '../meditation/meditation.dart';
import '../settings/settings.dart';
import '../../widgets/neura_overlay.dart';

class EnhancedNavigation extends StatefulWidget {
  const EnhancedNavigation({super.key});

  @override
  State<EnhancedNavigation> createState() => _EnhancedNavigationState();
}

class _EnhancedNavigationState extends State<EnhancedNavigation> {
  int _selectedIndex = 0;
  StreamSubscription? _tabSub;

  final List<Widget> _pages = const [
    PenthouseWorldScreen(),
    JournalScreen(),
    MoodCheckinScreen(),
    GoalTrackerScreen(),
    MeditationScreen(),
    SettingsScreen(),
  ];

  static const _tabKeys = ['home', 'journal', 'mood', 'goals', 'meditation', 'settings'];

  @override
  void initState() {
    super.initState();

    // Default tab.
    NeuraCore.ensureStarted();

    // Restore last tab immediately (continuity = no "reset" feel on launch).
    final saved = NeuraCore.memory.getJson<String>('ui.selected_tab');
    if (saved != null) {
      final idx = _tabKeys.indexOf(saved);
      if (idx >= 0) {
        _selectedIndex = idx;
      }
    }

    // Listen for tool-driven tab switches.
    // (Hive emits changes instantly; no polling, no tears.)
    _tabSub = NeuraCore.memory.watchKey('ui.selected_tab').listen((value) {
      final key = (value is String ? value : (value is Map ? value.toString() : '$value')).toString();
      final idx = _tabKeys.indexOf(key);
      if (idx >= 0 && idx != _selectedIndex && mounted) {
        setState(() => _selectedIndex = idx);
      }
    });
  }

  @override
  void dispose() {
    _tabSub?.cancel();
    super.dispose();
  }

  void _onItemTapped(int index) {
    setState(() => _selectedIndex = index);
    // Persist current tab so actions and future sessions can align.
    NeuraCore.memory.putJson('ui.selected_tab', _tabKeys[index]);
    // Continuity room mapping.
    final room = switch (_tabKeys[index]) {
      'home' => 'penthouse',
      'journal' => 'journal_room',
      'mood' => 'mood_den',
      'goals' => 'goals_lab',
      'meditation' => 'meditation_sanctuary',
      'settings' => 'settings_console',
      _ => 'penthouse',
    };
    NeuraCore.continuity.setRoom(room, reason: 'tap:${_tabKeys[index]}');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _pages[_selectedIndex],
          // Neura lives here: always present, always reachable.
          const Align(
            alignment: Alignment.bottomRight,
            child: Padding(
              padding: EdgeInsets.only(right: 12, bottom: 86),
              child: NeuraOverlay(),
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedIndex,
        onTap: _onItemTapped,
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.dashboard), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.book), label: 'Journal'),
          BottomNavigationBarItem(icon: Icon(Icons.mood), label: 'Check-In'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Goals'),
          BottomNavigationBarItem(icon: Icon(Icons.spa), label: 'Meditation'),
          BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
        ],
      ),
    );
  }
}
