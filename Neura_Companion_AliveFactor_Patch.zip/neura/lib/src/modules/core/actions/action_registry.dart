import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import '../continuity/neura_continuity.dart';
import '../intent/intent_engine.dart';
import '../memory/memory_vault.dart';
import 'neura_action.dart';

typedef ActionHandler = Future<ActionResult> Function(String rawText);

/// Registry for Neura's "tool" actions.
///
/// This is intentionally simple:
/// - Actions declare trigger phrases.
/// - We do cheap text matching.
///
/// Later you can upgrade matching with embedding or an LLM ōrchestrator.
class ActionRegistry {
  ActionRegistry({required this.navigatorKey, required this.memory, required this.continuity});

  final GlobalKey<NavigatorState> navigatorKey;
  final MemoryVault memory;
  final NeuraContinuity continuity;

  final List<NeuraAction> _actions = [];

  // Intent matching (v1).
  final IntentEngine _intent = IntentEngine();

  List<NeuraAction> get actions => List.unmodifiable(_actions);

  void register(NeuraAction action) {
    _actions.removeWhere((a) => a.id == action.id);
    _actions.add(action);
  }

  void registerDefaults() {
    register(_OpenHome());
    register(_OpenJournal());
    register(_OpenMood());
    register(_OpenGoals());
    register(_OpenMeditation());
    register(_OpenSettings());
  }

  /// Attempts to match and run an action from raw text.
  Future<ActionResult?> tryHandle(String rawText, {required Future<void> Function(String) speak}) async {
    final text = rawText.toLowerCase().trim();
    if (text.isEmpty) return null;

    // v1 intent matching: pick the best action by score.
    final match = _intent.match(text, _actions);
    if (match != null) {
      final ctx = ActionContext(
        navigateTo: _navigateTo,
        speak: speak,
      );
      final res = await match.action.run(ctx, rawText);
      if (kDebugMode) {
        debugPrint('Intent matched: ${match.action.id} score=${match.score.toStringAsFixed(2)} ok=${res.ok}');
      }
      return res;
    }

    // Fallback: legacy contains() matching.
    for (final action in _actions) {
      for (final trig in action.triggers) {
        if (text.contains(trig.toLowerCase())) {
          final ctx = ActionContext(
            navigateTo: _navigateTo,
            speak: speak,
          );
          final res = await action.run(ctx, rawText);
          if (kDebugMode) {
            debugPrint('Action matched: ${action.id} -> ${res.ok}');
          }
          return res;
        }
      }
    }
    return null;
  }

  void _navigateTo(String routeOrTab) {
    // We use a single route (EnhancedNavigation) and communicate via memory.
    // routeOrTab is one of: home, journal, mood, goals, meditation, settings.
    memory.putJson('ui.selected_tab', routeOrTab);

    // Continuity: map tabs to "rooms".
    final room = switch (routeOrTab) {
      'home' => 'penthouse',
      'journal' => 'journal_room',
      'mood' => 'mood_den',
      'goals' => 'goals_lab',
      'meditation' => 'meditation_sanctuary',
      'settings' => 'settings_console',
      _ => 'penthouse',
    };
    continuity.setRoom(room, reason: 'action:$routeOrTab');

    // Pop to root so the tab switch is visible.
    final nav = navigatorKey.currentState;
    nav?.popUntil((r) => r.isFirst);
  }
}

// ----------------- Default Actions -----------------

abstract class _TabActionBase implements NeuraAction {
  @override
  Future<ActionResult> run(ActionContext ctx, String rawText) async {
    ctx.navigateTo(tabKey);
    await ctx.speak(spokenConfirmation);
    return ActionResult.success(spokenConfirmation);
  }

  String get tabKey;
  String get spokenConfirmation;
}

class _OpenHome extends _TabActionBase {
  @override
  String get id => 'open.home';
  @override
  String get title => 'Open Home';
  @override
  String get description => 'Jump back to the dashboard.';
  @override
  List<String> get triggers => const ['open home', 'go home', 'dashboard', 'home screen'];
  @override
  String get tabKey => 'home';
  @override
  String get spokenConfirmation => 'Heading back to the dashboard.';
}

class _OpenJournal extends _TabActionBase {
  @override
  String get id => 'open.journal';
  @override
  String get title => 'Open Journal';
  @override
  String get description => 'Open the journal room.';
  @override
  List<String> get triggers => const ['open journal', 'journal room', 'write journal', 'write'];
  @override
  String get tabKey => 'journal';
  @override
  String get spokenConfirmation => 'Opening the journal.';
}

class _OpenMood extends _TabActionBase {
  @override
  String get id => 'open.mood';
  @override
  String get title => 'Open Mood Check-In';
  @override
  String get description => 'Open the mood check-in.';
  @override
  List<String> get triggers => const ['check in', 'mood', 'how i feel', 'open mood'];
  @override
  String get tabKey => 'mood';
  @override
  String get spokenConfirmation => 'Let’s do a quick check-in.';
}

class _OpenGoals extends _TabActionBase {
  @override
  String get id => 'open.goals';
  @override
  String get title => 'Open Goals';
  @override
  String get description => 'Open the goals tracker.';
  @override
  List<String> get triggers => const ['open goals', 'goals', 'quests', 'progress'];
  @override
  String get tabKey => 'goals';
  @override
  String get spokenConfirmation => 'Opening your goals.';
}

class _OpenMeditation extends _TabActionBase {
  @override
  String get id => 'open.meditation';
  @override
  String get title => 'Open Meditation';
  @override
  String get description => 'Open the meditation room.';
  @override
  List<String> get triggers => const ['meditate', 'meditation', 'breath', 'calm'];
  @override
  String get tabKey => 'meditation';
  @override
  String get spokenConfirmation => 'Let’s slow things down.';
}

class _OpenSettings extends _TabActionBase {
  @override
  String get id => 'open.settings';
  @override
  String get title => 'Open Settings';
  @override
  String get description => 'Open settings.';
  @override
  List<String> get triggers => const ['settings', 'open settings', 'preferences'];
  @override
  String get tabKey => 'settings';
  @override
  String get spokenConfirmation => 'Opening settings.';
}
