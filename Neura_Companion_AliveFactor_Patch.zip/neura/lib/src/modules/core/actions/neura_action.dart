
/// A Neura "tool" that can be invoked from voice or chat.
abstract class NeuraAction {
  String get id;
  String get title;
  String get description;

  /// One or more phrases Neura can match from raw text.
  /// Example: ["open journal", "journal room"]
  List<String> get triggers;

  Future<ActionResult> run(ActionContext ctx, String rawText);
}

class ActionContext {
  final void Function(String routeName) navigateTo;
  final Future<void> Function(String message) speak;

  ActionContext({
    required this.navigateTo,
    required this.speak,
  });
}

class ActionResult {
  final bool ok;
  final String? message;

  const ActionResult({required this.ok, this.message});

  factory ActionResult.success([String? message]) => ActionResult(ok: true, message: message);
  factory ActionResult.fail(String message) => ActionResult(ok: false, message: message);
}
