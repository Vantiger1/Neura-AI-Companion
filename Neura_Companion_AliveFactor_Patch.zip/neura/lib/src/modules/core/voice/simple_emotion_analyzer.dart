class SimpleEmotionAnalyzer {
  // Tiny lexicon-based mood tagger. Not "therapy", just a hint for tone.
  // Replace with a real model later.

  String analyze(String text) {
    final t = text.toLowerCase();

    int scoreAnxious = _countAny(t, const ['anxious', 'panic', 'worried', 'nervous', 'stress', 'stressed', 'overwhelmed', 'scared']);
    int scoreSad = _countAny(t, const ['sad', 'down', 'depressed', 'cry', 'lonely', 'grief', 'hopeless']);
    int scoreAngry = _countAny(t, const ['angry', 'mad', 'furious', 'pissed', 'rage', 'hate']);
    int scoreHappy = _countAny(t, const ['happy', 'excited', 'great', 'amazing', 'love', 'grateful', 'win', 'proud']);
    int scoreCalm = _countAny(t, const ['calm', 'peaceful', 'okay', 'fine', 'steady', 'relaxed']);

    final map = {
      'anxious': scoreAnxious,
      'sad': scoreSad,
      'angry': scoreAngry,
      'happy': scoreHappy,
      'calm': scoreCalm,
    };

    String best = 'neutral';
    int bestScore = 0;
    map.forEach((k, v) {
      if (v > bestScore) {
        best = k;
        bestScore = v;
      }
    });

    return best;
  }

  int _countAny(String text, List<String> needles) {
    var c = 0;
    for (final n in needles) {
      if (text.contains(n)) c++;
    }
    return c;
  }
}
