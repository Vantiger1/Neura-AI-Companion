import 'dart:math';

import '../actions/neura_action.dart';

/// IntentEngine v1
///
/// Goal: stop relying on brittle `text.contains(trigger)` matching.
///
/// This engine scores each action against the user's utterance using:
/// - token overlap
/// - phrase similarity (cheap normalized edit distance)
/// - lightweight "verb" + "target" heuristics
///
/// No ML. No embeddings. Runs instantly on-device.
class IntentEngine {
  IntentEngine({this.minimumScore = 0.56});

  /// 0..1 threshold required to execute an action.
  final double minimumScore;

  IntentMatch? match(String rawText, List<NeuraAction> actions) {
    final text = _normalize(rawText);
    if (text.isEmpty) return null;

    IntentMatch? best;
    for (final a in actions) {
      final s = score(text, a.triggers);
      if (best == null || s > best.score) {
        best = IntentMatch(action: a, score: s);
      }
    }
    if (best == null || best.score < minimumScore) return null;
    return best;
  }

  double score(String normalizedText, List<String> triggers) {
    if (triggers.isEmpty) return 0;

    final textTokens = _tokens(normalizedText);
    if (textTokens.isEmpty) return 0;

    double best = 0;
    for (final trig in triggers) {
      final t = _normalize(trig);
      if (t.isEmpty) continue;

      // (1) token overlap
      final trigTokens = _tokens(t);
      final overlap = _jaccard(textTokens, trigTokens);

      // (2) phrase similarity (edit-distance-ish)
      final sim = _phraseSimilarity(normalizedText, t);

      // (3) command heuristic: does text include an "open/go/start" verb?
      final verbBoost = _hasVerb(normalizedText) ? 0.08 : 0.0;

      // (4) exact contains is still a strong signal
      final containsBoost = normalizedText.contains(t) ? 0.18 : 0.0;

      // Weighted blend
      final s = (overlap * 0.45) + (sim * 0.45) + verbBoost + containsBoost;
      if (s > best) best = s;
    }

    return best.clamp(0, 1);
  }

  // ----------------- Helpers -----------------

  String _normalize(String s) {
    return s
        .toLowerCase()
        .replaceAll(RegExp(r"[^a-z0-9\s]"), ' ')
        .replaceAll(RegExp(r"\s+"), ' ')
        .trim();
  }

  Set<String> _tokens(String s) {
    final toks = s.split(' ').where((t) => t.isNotEmpty).toList();
    // drop ultra-common filler tokens
    const stop = {
      'a',
      'an',
      'the',
      'to',
      'please',
      'me',
      'my',
      'i',
      'we',
      'you',
      'us',
      'in',
      'on',
      'at',
      'of',
      'for',
      'and',
      'then',
      'now',
    };
    return toks.where((t) => !stop.contains(t)).toSet();
  }

  double _jaccard(Set<String> a, Set<String> b) {
    if (a.isEmpty || b.isEmpty) return 0;
    final inter = a.intersection(b).length;
    final uni = a.union(b).length;
    if (uni == 0) return 0;
    return inter / uni;
  }

  bool _hasVerb(String s) {
    // keep simple: common command verbs
    const verbs = {
      'open',
      'go',
      'take',
      'start',
      'launch',
      'show',
      'bring',
      'enter',
      'switch',
    };
    final toks = s.split(' ');
    return toks.any(verbs.contains);
  }

  double _phraseSimilarity(String a, String b) {
    if (a == b) return 1.0;
    if (a.isEmpty || b.isEmpty) return 0.0;

    // normalized edit distance (Levenshtein) but capped for speed.
    final dist = _levenshteinCapped(a, b, cap: 24);
    final maxLen = max(a.length, b.length);
    if (maxLen == 0) return 0.0;
    final sim = 1.0 - (dist / maxLen);
    return sim.clamp(0.0, 1.0);
  }

  int _levenshteinCapped(String s, String t, {required int cap}) {
    // If strings are far apart in length, bail early.
    if ((s.length - t.length).abs() > cap) return cap;

    final m = s.length;
    final n = t.length;
    if (m == 0) return min(n, cap);
    if (n == 0) return min(m, cap);

    var prev = List<int>.generate(n + 1, (j) => j);
    var cur = List<int>.filled(n + 1, 0);

    for (var i = 1; i <= m; i++) {
      cur[0] = i;
      var rowBest = cur[0];
      final sc = s.codeUnitAt(i - 1);
      for (var j = 1; j <= n; j++) {
        final cost = (sc == t.codeUnitAt(j - 1)) ? 0 : 1;
        final ins = cur[j - 1] + 1;
        final del = prev[j] + 1;
        final sub = prev[j - 1] + cost;
        final v = min(ins, min(del, sub));
        cur[j] = v;
        if (v < rowBest) rowBest = v;
      }
      if (rowBest > cap) return cap;
      final tmp = prev;
      prev = cur;
      cur = tmp;
    }
    return min(prev[n], cap);
  }
}

class IntentMatch {
  IntentMatch({required this.action, required this.score});
  final NeuraAction action;
  final double score;
}
