import '../memory/memory_vault.dart';

/// Neura Continuity Spine
///
/// A tiny persistent state layer that makes Neura feel *continuous*:
/// - where she "is" (room)
/// - how she "feels" (mood)
/// - what just happened (last interaction)
///
/// Local-first. Encrypted at rest via [MemoryVault].
class NeuraContinuity {
  NeuraContinuity(this._memory);

  final MemoryVault _memory;

  static const _kRoom = 'neura.continuity.room';
  static const _kMood = 'neura.continuity.mood';
  static const _kLast = 'neura.continuity.last';

  Future<void> init() async {
    // Seed defaults once.
    final room = currentRoom;
    if (room == null || room.trim().isEmpty) {
      await setRoom('penthouse');
    }
    final mood = currentMood;
    if (mood == null || mood.trim().isEmpty) {
      await setMood('calm');
    }
  }

  String? get currentRoom => _memory.getJson<String>(_kRoom);
  String? get currentMood => _memory.getJson<String>(_kMood);

  Map<String, dynamic>? get lastInteraction =>
      _memory.getJson<Map<String, dynamic>>(_kLast);

  Future<void> setRoom(String roomKey, {String? reason}) async {
    await _memory.putJson(_kRoom, roomKey);
    await _memory.putJson('ui.selected_room', {
      'room': roomKey,
      'reason': reason,
      'ts': DateTime.now().toIso8601String(),
    });
  }

  Future<void> setMood(String moodKey) async {
    await _memory.putJson(_kMood, moodKey);
  }

  Future<void> recordInteraction({
    required String heard,
    required String reply,
    required String mood,
    String? room,
    String? kind,
  }) async {
    final payload = <String, dynamic>{
      'heard': heard,
      'reply': reply,
      'mood': mood,
      'room': room ?? currentRoom ?? 'penthouse',
      'kind': kind ?? 'voice',
      'ts': DateTime.now().toIso8601String(),
    };
    await _memory.putJson(_kLast, payload);
    await _memory.putJson('conversation.last', payload);
  }
}
