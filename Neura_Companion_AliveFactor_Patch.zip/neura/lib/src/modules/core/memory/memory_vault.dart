import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';

/// Local-first encrypted memory vault.
///
/// Under the hood:
/// - Encryption key stored in OS keychain/keystore via flutter_secure_storage
/// - Hive box encrypted with that key
///
/// This keeps user data on-device by default. If you later add cloud sync,
/// you can sync *encrypted blobs*.
class MemoryVault {
  static const _secureKeyName = 'neura_memory_key_v1';
  static const _boxName = 'neura_memory_v1';

  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage();
  late Box _box;

  bool get isOpen => _box.isOpen;

  Future<void> init() async {
    final key = await _getOrCreateKey();
    _box = await Hive.openBox(
      _boxName,
      encryptionCipher: HiveAesCipher(key),
    );
  }

  /// Stores a value (JSON-serializable) under a key.
  Future<void> putJson(String key, Object? value) async {
    _requireOpen();
    await _box.put(key, jsonEncode(value));
  }

  /// Returns decoded JSON or null.
  T? getJson<T>(String key) {
    _requireOpen();
    final raw = _box.get(key);
    if (raw is! String) return null;
    try {
      return jsonDecode(raw) as T;
    } catch (_) {
      return null;
    }
  }

  Future<void> delete(String key) async {
    _requireOpen();
    await _box.delete(key);
  }

  /// Wipes all local memory.
  Future<void> nukeAll() async {
    _requireOpen();
    await _box.clear();
  }

  /// Exports all memory as a JSON string (still decrypted in-app).
  /// If you want export to be safer: export encrypted dump instead.
  String exportDecryptedJson() {
    _requireOpen();
    final out = <String, dynamic>{};
    for (final key in _box.keys) {
      final v = _box.get(key);
      if (key is String && v is String) {
        try {
          out[key] = jsonDecode(v);
        } catch (_) {
          out[key] = v;
        }
      }
    }
    return const JsonEncoder.withIndent('  ').convert(out);
  }



  /// Watches a key for changes (decoded JSON when possible).
  Stream<dynamic> watchKey(String key) {
    _requireOpen();
    return _box.watch(key: key).map((e) {
      final v = e.value;
      if (v is String) {
        try {
          return jsonDecode(v);
        } catch (_) {
          return v;
        }
      }
      return v;
    });
  }

  Future<void> close() async {
    if (_box.isOpen) {
      await _box.close();
    }
  }

  void _requireOpen() {
    if (!isOpen) {
      throw StateError('MemoryVault not initialized. Call init() first.');
    }
  }

  Future<List<int>> _getOrCreateKey() async {
    final existing = await _secureStorage.read(key: _secureKeyName);
    if (existing != null && existing.isNotEmpty) {
      try {
        return base64Url.decode(existing);
      } catch (_) {
        // Fall through to regenerate.
      }
    }

    final rnd = Random.secure();
    final key = List<int>.generate(32, (_) => rnd.nextInt(256));
    final encoded = base64Url.encode(key);
    await _secureStorage.write(key: _secureKeyName, value: encoded);

    if (kDebugMode) {
      debugPrint('Generated new encrypted memory key.');
    }

    return key;
  }
}
