import 'dart:async';
import 'dart:math';

import 'package:flutter/foundation.dart';

import '../continuity/neura_continuity.dart';
import '../memory/memory_vault.dart';
import '../voice/neura_voice_loop.dart';
import 'interaction_tracker.dart';

/// IdleLifeSystem
///
/// Makes Neura feel "present" when the user isn't actively interacting.
///
/// It does **not** spam notifications. It triggers subtle ambient actions
/// and (optionally) extremely infrequent gentle nudges.
class IdleLifeSystem extends ChangeNotifier {
  IdleLifeSystem({
    required this.interaction,
    required this.memory,
    required this.voice,
    required this.continuity,
  });

  final InteractionTracker interaction;
  final MemoryVault memory;
  final NeuraVoiceLoop voice;
  final NeuraContinuity continuity;

  Timer? _timer;
  final Random _rand = Random();

  /// Current ambient action label (e.g. "blink", "look", "breathe").
  String _idleAction = 'none';
  String get idleAction => _idleAction;

  /// 0 = active, 1 = idle, 2 = deep idle
  int _idleLevel = 0;
  int get idleLevel => _idleLevel;

  DateTime _lastActionAt = DateTime.fromMillisecondsSinceEpoch(0);
  DateTime _lastNudgeAt = DateTime.fromMillisecondsSinceEpoch(0);

  Future<void> start() async {
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(milliseconds: 700), (_) => _tick());
  }

  void stop() {
    _timer?.cancel();
    _timer = null;
  }

  void _tick() {
    // Never idle-act while listening/thinking/speaking.
    if (voice.state != NeuraVoiceState.idle) {
      _setIdle(level: 0, action: 'none');
      return;
    }

    final idleFor = interaction.sinceLastInteraction();
    final newLevel = idleFor.inSeconds >= 120
        ? 2
        : (idleFor.inSeconds >= 20 ? 1 : 0);

    if (newLevel != _idleLevel) {
      _idleLevel = newLevel;
      notifyListeners();
    }

    if (newLevel == 0) {
      _setIdle(level: 0, action: 'none');
      return;
    }

    // Don't fire actions too frequently.
    final sinceAction = DateTime.now().difference(_lastActionAt);
    if (sinceAction.inSeconds < (newLevel == 2 ? 6 : 4)) return;

    final mood = (continuity.currentMood ?? 'calm').toLowerCase();
    final action = _pickAction(mood, deep: newLevel == 2);
    _lastActionAt = DateTime.now();
    _setIdle(level: newLevel, action: action);

    // Optional gentle nudges (rare; local setting).
    _maybeNudge(mood: mood, deep: newLevel == 2, idleFor: idleFor);
  }

  String _pickAction(String mood, {required bool deep}) {
    // Weighted choices by mood.
    final base = <String>[
      'blink',
      'look',
      'scan',
      'breathe',
      'glow',
    ];

    if (deep) {
      base.addAll(['stretch', 'walk']);
    }
    if (mood == 'anxious' || mood == 'angry') {
      // More grounding behaviors.
      base.addAll(['breathe', 'breathe', 'glow']);
    }
    if (mood == 'sad') {
      base.addAll(['breathe', 'look']);
    }

    return base[_rand.nextInt(base.length)];
  }

  Future<void> _maybeNudge({required String mood, required bool deep, required Duration idleFor}) async {
    final enabled = memory.getJson<bool>('idle.nudges_enabled') ?? true;
    if (!enabled) return;
    if (!deep) return; // nudges only in deep idle
    if (idleFor.inMinutes < 4) return; // wait a bit

    final sinceNudge = DateTime.now().difference(_lastNudgeAt);
    if (sinceNudge.inMinutes < 12) return; // no spam

    _lastNudgeAt = DateTime.now();

    final line = switch (mood) {
      'anxious' => 'No pressure. Want a 60-second breathing reset?',
      'sad' => 'I’m here. If you want, we can write one honest sentence together.',
      'angry' => 'I’m still here. When you’re ready, we’ll pick the next right move.',
      'happy' => 'Quick win idea: want to log what made you smile so we can repeat it?',
      _ => 'Want me to open something—journal, goals, or a short meditation?',
    };

    // Keep it subtle: store as "last nudge" and let the overlay show it.
    await memory.putJson('idle.last_nudge', line);
    notifyListeners();
  }

  void _setIdle({required int level, required String action}) {
    if (_idleLevel != level || _idleAction != action) {
      _idleLevel = level;
      _idleAction = action;
      notifyListeners();
    }
  }
}
