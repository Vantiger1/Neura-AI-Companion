import 'package:flutter/foundation.dart';

/// Tracks last user activity (taps, pointer moves, keys, etc.).
///
/// Used by IdleLifeSystem to decide when Neura should switch into
/// ambient idle behavior.
class InteractionTracker extends ChangeNotifier {
  DateTime _last = DateTime.now();

  DateTime get lastInteraction => _last;

  Duration sinceLastInteraction() => DateTime.now().difference(_last);

  void touch() {
    _last = DateTime.now();
    notifyListeners();
  }
}
