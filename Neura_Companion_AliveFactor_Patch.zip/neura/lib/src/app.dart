import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import 'modules/core/neura_core.dart';
import 'modules/navigation/enhanced_navigation.dart';
import '../widgets/neura_interaction_layer.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    // Ensure the core is initialized early (idempotent).
    NeuraCore.ensureStarted();

    return ProviderScope(
      child: MaterialApp(
        navigatorKey: NeuraCore.navigatorKey,
        title: 'Neura Companion',
        theme: ThemeData.dark(useMaterial3: true),
        builder: (context, child) => NeuraInteractionLayer(child: child ?? const SizedBox.shrink()),
        home: const EnhancedNavigation(),
      ),
    );
  }
}
