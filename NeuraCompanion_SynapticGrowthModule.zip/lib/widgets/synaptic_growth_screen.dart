import 'package:flutter/material.dart';
import '../services/synaptic_growth_service.dart';

class SynapticGrowthScreen extends StatelessWidget {
  final SynapticGrowthService service;

  const SynapticGrowthScreen({required this.service});

  @override
  Widget build(BuildContext context) {
    final scores = service.calculateMoodLiftByRitual();
    return Scaffold(
      appBar: AppBar(title: Text('Synaptic Growth Insights')),
      body: ListView(
        children: scores.entries.map((e) => ListTile(
          title: Text(e.key),
          trailing: Text('${(e.value * 100).toStringAsFixed(1)}% lift'),
        )).toList(),
      ),
    );
  }
}
