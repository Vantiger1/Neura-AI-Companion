import '../models/world_post_model.dart';
import 'package:uuid/uuid.dart';

class WorldFeedService {
  final List<WorldPost> _posts = [];

  List<WorldPost> getPosts() {
    return List.of(_posts)..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  void addPost(String userId, String mood, String message) {
    _posts.add(WorldPost(
      id: const Uuid().v4(),
      userId: userId,
      mood: mood,
      message: message,
      timestamp: DateTime.now(),
      reactions: [],
    ));
  }

  void addReaction(String postId, String emoji) {
    final index = _posts.indexWhere((p) => p.id == postId);
    if (index != -1) {
      _posts[index].reactions.add(emoji);
    }
  }
}
