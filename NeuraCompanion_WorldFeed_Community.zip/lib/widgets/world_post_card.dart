import 'package:flutter/material.dart';
import '../models/world_post_model.dart';

class WorldPostCard extends StatelessWidget {
  final WorldPost post;
  final void Function(String emoji) onReact;

  const WorldPostCard({required this.post, required this.onReact});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: ListTile(
        title: Text(post.message),
        subtitle: Text('Mood: ${post.mood} • by ${post.userId}'),
        trailing: PopupMenuButton<String>(
          icon: Icon(Icons.emoji_emotions_outlined),
          onSelected: onReact,
          itemBuilder: (_) => ['😊', '👏', '❤️', '🔥'].map((e) =>
              PopupMenuItem(value: e, child: Text(e))).toList(),
        ),
      ),
    );
  }
}
