import 'package:flutter/material.dart';
import '../services/world_feed_service.dart';
import '../widgets/world_post_card.dart';
import '../models/world_post_model.dart';

class WorldFeedScreen extends StatefulWidget {
  final WorldFeedService service;
  const WorldFeedScreen({required this.service});

  @override
  _WorldFeedScreenState createState() => _WorldFeedScreenState();
}

class _WorldFeedScreenState extends State<WorldFeedScreen> {
  final _controller = TextEditingController();
  final _userId = 'you';
  final _mood = 'happy';

  void _postMessage() {
    if (_controller.text.trim().isEmpty) return;
    widget.service.addPost(_userId, _mood, _controller.text.trim());
    _controller.clear();
    setState(() {});
  }

  void _reactToPost(WorldPost post, String emoji) {
    widget.service.addReaction(post.id, emoji);
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final posts = widget.service.getPosts();
    return Scaffold(
      appBar: AppBar(title: Text('Neura World Feed')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(child: TextField(controller: _controller, decoration: InputDecoration(hintText: 'Share your mood...'))),
                IconButton(icon: Icon(Icons.send), onPressed: _postMessage),
              ],
            ),
          ),
          Expanded(
            child: ListView(
              children: posts.map((p) => WorldPostCard(post: p, onReact: (emoji) => _reactToPost(p, emoji))).toList(),
            ),
          )
        ],
      ),
    );
  }
}
