import 'package:flutter/foundation.dart';

@immutable
class WorldPost {
  final String id;
  final String userId;
  final String mood;
  final String message;
  final DateTime timestamp;
  final List<String> reactions;

  const WorldPost({
    required this.id,
    required this.userId,
    required this.mood,
    required this.message,
    required this.timestamp,
    this.reactions = const [],
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'userId': userId,
        'mood': mood,
        'message': message,
        'timestamp': timestamp.toIso8601String(),
        'reactions': reactions,
      };

  factory WorldPost.fromMap(Map<String, dynamic> map) => WorldPost(
        id: map['id'],
        userId: map['userId'],
        mood: map['mood'],
        message: map['message'],
        timestamp: DateTime.parse(map['timestamp']),
        reactions: List<String>.from(map['reactions']),
      );
}
