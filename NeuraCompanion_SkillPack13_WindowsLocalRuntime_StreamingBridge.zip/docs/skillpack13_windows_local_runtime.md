# Skill Pack 13 — Windows Local Runtime + Streaming Bridge

## What this enables
- Neura can talk using a LOCAL OpenAI-compatible server (llama.cpp `llama-server`) with **token streaming**.
- Neura boots normally even if the server/model are missing.

## Windows setup (offline-friendly)
1. Build or download `llama-server.exe` from llama.cpp.
2. Place it in one of these locations:
   - `<project>/bin/llama-server.exe` (recommended)
   - Or set an absolute path in **Settings → Local Models**
3. Start the server from Neura (via later packs) or run it manually:
   ```
   llama-server.exe --host 127.0.0.1 --port 8080 --model C:\path\to\model.gguf --no-webui
   ```

## Neura config
- Base URL: `http://127.0.0.1:8080/v1`
- Model: `local-model` (name can be anything depending on server)

## Health check
- `http://127.0.0.1:8080/health`

## Notes
- This patch updates `DualChatService` to use the local model router.
- Streaming parsing supports standard SSE (`data: {...}` + `[DONE]`).
