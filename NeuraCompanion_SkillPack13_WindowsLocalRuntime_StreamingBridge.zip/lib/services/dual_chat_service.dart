import '../models/ai_avatar.dart';
import 'local_models/neura_model_router.dart';

class DualChatService {
  /// Sends user message to the AI and returns response from specified avatar.
  ///
  /// Offline-first: uses local model routing (desktop llama.cpp server, etc.)
  Future<String> sendMessage(String message, AIAvatar avatar) async {
    final system = 'You are ${avatar.name}. Be helpful, calm, and practical. Keep responses concise.';
    try {
      final text = await NeuraModelRouter.I.replyOnce(userMessage: message, system: system);
      return '${avatar.name}: $text';
    } catch (e) {
      return '${avatar.name}: (offline model error) $e';
    }
  }

  /// Stream a reply for realtime typing UX.
  Stream<String> streamMessage(String message, AIAvatar avatar) {
    final system = 'You are ${avatar.name}. Be helpful, calm, and practical. Keep responses concise.';
    return NeuraModelRouter.I.streamReply(userMessage: message, system: system);
  }
}
