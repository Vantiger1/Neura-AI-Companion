import 'dart:io';

import 'neura_openai_compat_client.dart';

/// One front door for "get an answer" regardless of platform.
///
/// Today:
/// - Desktop/Android use a local OpenAI-compatible endpoint (llama.cpp server, etc.)
/// Next (already staged in earlier packs):
/// - Android on-device JNI runtime can be swapped in here.
class NeuraModelRouter {
  static final NeuraModelRouter I = NeuraModelRouter._();
  NeuraModelRouter._();

  Stream<String> streamReply({
    required String userMessage,
    String? system,
  }) {
    // If later you add Android JNI streaming, route here by Platform.isAndroid.
    if (Platform.isAndroid) {
      return NeuraOpenAICompatClient.I.streamChat(prompt: userMessage, system: system);
    }
    return NeuraOpenAICompatClient.I.streamChat(prompt: userMessage, system: system);
  }

  Future<String> replyOnce({
    required String userMessage,
    String? system,
  }) {
    return NeuraOpenAICompatClient.I.completeOnce(prompt: userMessage, system: system);
  }
}
