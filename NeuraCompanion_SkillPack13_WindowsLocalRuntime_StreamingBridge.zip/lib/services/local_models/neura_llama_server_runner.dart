import 'dart:async';
import 'dart:io';

import 'neura_local_model_settings.dart';

/// Desktop local runner for llama.cpp's `llama-server` (OpenAI-compatible API).
///
/// This patch focuses on Windows reliability:
/// - autodetect common executable locations when not explicitly set
/// - wait briefly for server to become ready
/// - always bind to 127.0.0.1 (offline-first)
class NeuraLlamaServerRunner {
  static final NeuraLlamaServerRunner I = NeuraLlamaServerRunner._();
  NeuraLlamaServerRunner._();

  Process? _proc;

  bool get isRunning => _proc != null;

  int get port => NeuraLocalModelSettings.I.runnerPort;

  Future<Map<String, dynamic>> start({
    required String modelPath,
    int? ctx,
    int? threads,
  }) async {
    await NeuraLocalModelSettings.I.init();

    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return {'ok': false, 'error': 'Local runner is desktop-only.'};
    }
    if (_proc != null) {
      return {'ok': true, 'message': 'Already running', 'port': port};
    }

    final exe = await _resolveExe();
    if (exe == null) {
      return {
        'ok': false,
        'error': 'llama-server executable not found. Set it in Settings → Local Models, or place it in ./bin/',
      };
    }

    if (modelPath.isEmpty || !File(modelPath).existsSync()) {
      return {'ok': false, 'error': 'Model not found: $modelPath'};
    }

    final args = <String>[
      '--host', '127.0.0.1',
      '--port', port.toString(),
      '--model', modelPath,
      // OpenAI-style endpoint is available at /v1 on newer llama.cpp
      '--no-webui',
    ];

    if (ctx != null && ctx > 0) {
      args.addAll(['--ctx-size', ctx.toString()]);
    }
    if (threads != null && threads > 0) {
      args.addAll(['--threads', threads.toString()]);
    }

    try {
      _proc = await Process.start(exe, args, runInShell: true);
      // Drain output to avoid blocking.
      _proc!.stdout.listen((_) {});
      _proc!.stderr.listen((_) {});

      // Give the server a moment to bind.
      final ready = await _waitReady(timeout: const Duration(seconds: 4));
      if (!ready) {
        // Keep process running but signal not ready; UI can still retry.
        return {
          'ok': true,
          'message': 'Started (warmup)',
          'port': port,
          'model': File(modelPath).uri.pathSegments.last,
          'ready': false,
        };
      }

      return {
        'ok': true,
        'message': 'Started',
        'port': port,
        'model': File(modelPath).uri.pathSegments.last,
        'ready': true,
      };
    } catch (e) {
      _proc = null;
      return {'ok': false, 'error': e.toString()};
    }
  }

  Future<Map<String, dynamic>> stop() async {
    final p = _proc;
    _proc = null;
    if (p == null) return {'ok': true, 'message': 'Not running'};
    try {
      p.kill(ProcessSignal.sigterm);
      return {'ok': true, 'message': 'Stopped'};
    } catch (e) {
      return {'ok': false, 'error': e.toString()};
    }
  }

  Future<String?> _resolveExe() async {
    final fromSettings = NeuraLocalModelSettings.I.runnerExecutablePath;
    if (fromSettings.isNotEmpty && File(fromSettings).existsSync()) return fromSettings;

    final candidates = <String>[
      // Project-local conventions
      '${Directory.current.path}${Platform.pathSeparator}bin${Platform.pathSeparator}${Platform.isWindows ? 'llama-server.exe' : 'llama-server'}',
      '${Directory.current.path}${Platform.pathSeparator}${Platform.isWindows ? 'llama-server.exe' : 'llama-server'}',
      // Common user locations
      if (Platform.isWindows) r'C:\llama.cpp\llama-server.exe',
      if (Platform.isWindows) r'C:\Program Files\llama.cpp\llama-server.exe',
      if (Platform.isWindows) r'C:\Program Files (x86)\llama.cpp\llama-server.exe',
      if (Platform.isLinux) '/usr/local/bin/llama-server',
      if (Platform.isMacOS) '/usr/local/bin/llama-server',
    ];

    for (final c in candidates) {
      if (File(c).existsSync()) return c;
    }

    // Best-effort PATH lookup.
    try {
      final which = Platform.isWindows ? 'where' : 'which';
      final res = await Process.run(which, [Platform.isWindows ? 'llama-server.exe' : 'llama-server'], runInShell: true);
      final out = (res.stdout ?? '').toString().trim();
      if (out.isNotEmpty) {
        final first = out.split(RegExp(r'\r?\n')).first.trim();
        if (first.isNotEmpty && File(first).existsSync()) return first;
      }
    } catch (_) {}

    return null;
  }

  Future<bool> _waitReady({required Duration timeout}) async {
    final client = HttpClient();
    final deadline = DateTime.now().add(timeout);
    while (DateTime.now().isBefore(deadline)) {
      try {
        final req = await client.getUrl(Uri.parse('http://127.0.0.1:$port/health'));
        final res = await req.close();
        if (res.statusCode >= 200 && res.statusCode < 500) {
          return true;
        }
      } catch (_) {}
      await Future<void>.delayed(const Duration(milliseconds: 200));
    }
    return false;
  }
}
