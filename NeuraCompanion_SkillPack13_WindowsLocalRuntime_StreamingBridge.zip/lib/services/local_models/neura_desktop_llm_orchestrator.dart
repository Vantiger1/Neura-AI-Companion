import 'dart:io';

import '../../modules/core/app_log.dart';
import 'neura_local_model_settings.dart';
import 'neura_llama_server_runner.dart';

/// Boots desktop local LLM infrastructure.
/// - If autostart is enabled, attempts to start llama-server.
/// - Keeps Neura offline-first by binding to localhost.
/// - Never blocks app startup.
class NeuraDesktopLlmOrchestrator {
  static final NeuraDesktopLlmOrchestrator I = NeuraDesktopLlmOrchestrator._();
  NeuraDesktopLlmOrchestrator._();

  bool _inited = false;

  Future<void> init() async {
    if (_inited) return;
    _inited = true;

    await NeuraLocalModelSettings.I.init();

    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) return;

    if (!NeuraLocalModelSettings.I.runnerAutostart) return;

    // If the user set a base URL that isn't the runner, don't override.
    final desiredBase = 'http://127.0.0.1:${NeuraLocalModelSettings.I.runnerPort}/v1';
    final currentBase = NeuraLocalModelSettings.I.llmBaseUrl;

    if (currentBase.startsWith('http://127.0.0.1') && !currentBase.contains('/v1')) {
      // Normalize older setting values.
      await NeuraLocalModelSettings.I.setLlmBaseUrl(desiredBase);
    }

    // We can't assume a model path here; the model pack manager owns it in later packs.
    // So autostart is a best-effort and will no-op unless the user points at a model.
    // We keep this lightweight and safe.
    AppLog.instance.i('NeuraDesktopLlmOrchestrator: autostart enabled (runner port ${NeuraLocalModelSettings.I.runnerPort})');
  }

  /// Optional helper to start a runner when you have a model path.
  Future<Map<String, dynamic>> startRunnerWithModel(String ggufPath, {int ctx = 4096, int threads = 0}) async {
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return {'ok': false, 'error': 'Runner is desktop-only.'};
    }
    await NeuraLocalModelSettings.I.init();
    await NeuraLocalModelSettings.I.setLlmBaseUrl('http://127.0.0.1:${NeuraLocalModelSettings.I.runnerPort}/v1');

    try {
      final r = await NeuraLlamaServerRunner.I.start(
        modelPath: ggufPath,
        ctx: ctx > 0 ? ctx : null,
        threads: threads > 0 ? threads : null,
      );
      return r;
    } catch (e) {
      return {'ok': false, 'error': e.toString()};
    }
  }
}
