import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'neura_local_model_settings.dart';

class NeuraOpenAICompatClient {
  static final NeuraOpenAICompatClient I = NeuraOpenAICompatClient._();
  NeuraOpenAICompatClient._();

  Uri _endpoint(String path) {
    final base = NeuraLocalModelSettings.I.llmBaseUrl.trim();
    // If user configured without /v1, normalize.
    final normalized = base.endsWith('/v1') ? base : (base.endsWith('/') ? '${base}v1' : '$base/v1');
    return Uri.parse('$normalized$path');
  }

  Future<String> completeOnce({
    required String prompt,
    String? system,
  }) async {
    final out = StringBuffer();
    await for (final tok in streamChat(prompt: prompt, system: system)) {
      out.write(tok);
    }
    return out.toString();
  }

  /// Stream tokens from a local OpenAI-compatible server (e.g., llama.cpp).
  Stream<String> streamChat({
    required String prompt,
    String? system,
    int maxTokens = 512,
  }) async* {
    await NeuraLocalModelSettings.I.init();

    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: NeuraLocalModelSettings.I.llmTimeoutMs);

    final body = <String, dynamic>{
      'model': NeuraLocalModelSettings.I.llmModel,
      'stream': true,
      'temperature': NeuraLocalModelSettings.I.llmTemperature,
      'max_tokens': maxTokens,
      'messages': [
        if ((system ?? '').trim().isNotEmpty) {'role': 'system', 'content': system},
        {'role': 'user', 'content': prompt},
      ],
    };

    final uri = _endpoint('/chat/completions');
    HttpClientRequest req;
    try {
      req = await client.postUrl(uri);
    } catch (e) {
      yield* Stream.error('Local model endpoint not reachable: $e');
      return;
    }
    req.headers.contentType = ContentType.json;
    req.write(jsonEncode(body));

    final res = await req.close();
    if (res.statusCode < 200 || res.statusCode >= 300) {
      final txt = await utf8.decoder.bind(res).join();
      yield* Stream.error('Local model error ${res.statusCode}: $txt');
      return;
    }

    // Parse SSE-style stream: lines beginning with "data:".
    final transformer = const Utf8Decoder();
    final stream = transformer.bind(res);

    var buffer = '';
    await for (final chunk in stream) {
      buffer += chunk;
      while (true) {
        final idx = buffer.indexOf('\n');
        if (idx == -1) break;
        final line = buffer.substring(0, idx).trimRight();
        buffer = buffer.substring(idx + 1);

        final t = line.trim();
        if (t.isEmpty) continue;
        if (!t.startsWith('data:')) continue;

        final data = t.substring(5).trim();
        if (data == '[DONE]') return;

        try {
          final j = jsonDecode(data);
          final choices = (j['choices'] as List?) ?? const [];
          if (choices.isEmpty) continue;
          final c0 = choices.first as Map<String, dynamic>;
          // OpenAI-style
          final delta = c0['delta'];
          if (delta is Map && delta['content'] is String) {
            final s = delta['content'] as String;
            if (s.isNotEmpty) yield s;
            continue;
          }
          // Some servers use "text"
          if (c0['text'] is String) {
            final s = c0['text'] as String;
            if (s.isNotEmpty) yield s;
            continue;
          }
        } catch (_) {
          // Ignore malformed SSE lines
        }
      }
    }
  }
}
