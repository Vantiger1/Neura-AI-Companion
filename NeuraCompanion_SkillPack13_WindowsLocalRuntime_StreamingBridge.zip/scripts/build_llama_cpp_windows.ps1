# Build llama.cpp on Windows (Developer PowerShell)
# This script is optional and can be run by power users who want a local offline build.

param(
  [string]$RepoDir = "$PSScriptRoot\..\third_party\llama.cpp",
  [string]$OutDir = "$PSScriptRoot\..\bin"
)

Write-Host "RepoDir: $RepoDir"
Write-Host "OutDir:  $OutDir"

if (!(Test-Path $RepoDir)) {
  Write-Host "Missing llama.cpp repo at $RepoDir"
  Write-Host "Clone it (when internet allowed) or copy it offline into that folder."
  exit 1
}

New-Item -ItemType Directory -Force -Path $OutDir | Out-Null

Push-Location $RepoDir
try {
  cmake -S . -B build -DLLAMA_BUILD_SERVER=ON -DCMAKE_BUILD_TYPE=Release
  cmake --build build --config Release
  $exe = Get-ChildItem -Recurse -Path build -Filter "llama-server.exe" | Select-Object -First 1
  if ($null -eq $exe) {
    Write-Host "Could not find llama-server.exe in build output."
    exit 2
  }
  Copy-Item $exe.FullName (Join-Path $OutDir "llama-server.exe") -Force
  Write-Host "Copied llama-server.exe to $OutDir"
} finally {
  Pop-Location
}
