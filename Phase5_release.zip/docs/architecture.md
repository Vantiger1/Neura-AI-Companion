# Architecture Overview
```mermaid
graph TD;
  App-->Core;
  App-->Features;
  Features-->Ritual;
  Features-->Dream;
  App-->Extensions;
```