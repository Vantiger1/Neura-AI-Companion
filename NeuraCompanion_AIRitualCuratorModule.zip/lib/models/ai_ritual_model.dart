import 'package:flutter/foundation.dart';

@immutable
class AIRitual {
  final String id;
  final String title;
  final String purpose;
  final bool completed;

  const AIRitual({
    required this.id,
    required this.title,
    required this.purpose,
    this.completed = false,
  });

  AIRitual complete() => AIRitual(
    id: id,
    title: title,
    purpose: purpose,
    completed: true,
  );
}
