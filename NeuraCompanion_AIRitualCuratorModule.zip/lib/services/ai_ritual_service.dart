import '../models/ai_ritual_model.dart';

class AIRitualService {
  final List<AIRitual> _rituals = [
    AIRitual(id: 'r1', title: 'Sunrise Journaling', purpose: 'Reflect and release overnight tension.'),
    AIRitual(id: 'r2', title: 'Focus Ritual', purpose: 'Set intention and reduce distractions.'),
    AIRitual(id: 'r3', title: 'Dream Sketch', purpose: 'Draw or write your dream upon waking.'),
    AIRitual(id: 'r4', title: 'Gratitude Gong', purpose: 'List 3 things you are thankful for.'),
  ];

  List<AIRitual> get rituals => List.unmodifiable(_rituals);

  void complete(String id) {
    final i = _rituals.indexWhere((r) => r.id == id);
    if (i != -1) {
      _rituals[i] = _rituals[i].complete();
    }
  }
}
