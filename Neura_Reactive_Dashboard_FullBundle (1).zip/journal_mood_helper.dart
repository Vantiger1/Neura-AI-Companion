import 'package:flutter/material.dart';
import 'mood_notifier.dart';

String getPromptForMood(MoodType mood) {
  switch (mood) {
    case MoodType.calm:
      return "What helped you feel calm today?";
    case MoodType.focus:
      return "What helped you stay focused today?";
    case MoodType.energy:
      return "Where did your energy come from today?";
    case MoodType.reflective:
      return "What thoughts have been on your mind lately?";
  }
}

class JournalMoodTagger {
  final MoodNotifier moodNotifier;

  JournalMoodTagger(this.moodNotifier);

  String get currentTag => moodNotifier.value.name;

  String get suggestedPrompt => getPromptForMood(moodNotifier.value);
}