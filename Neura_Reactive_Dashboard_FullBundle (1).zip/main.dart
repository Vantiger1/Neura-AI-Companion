
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'mood_notifier.dart';
import 'mood_history_tracker.dart';
import 'dashboard_screen.dart';

void main() {
  runApp(const NeuraApp());
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MoodNotifier()),
        ChangeNotifierProvider(create: (_) => MoodHistoryTracker()),
      ],
      child: MaterialApp(
        title: 'Neura Companion',
        theme: ThemeData.dark(useMaterial3: true),
        home: DashboardScreen(),
      ),
    );
  }
}
