
import 'dart:async';
import 'package:flutter/material.dart';
import 'mood_notifier.dart';

class RitualAutoSuggestor extends StatefulWidget {
  final MoodNotifier moodNotifier;
  final void Function(String moodName)? onTrigger;

  const RitualAutoSuggestor({super.key, required this.moodNotifier, this.onTrigger});

  @override
  State<RitualAutoSuggestor> createState() => _RitualAutoSuggestorState();
}

class _RitualAutoSuggestorState extends State<RitualAutoSuggestor> {
  Timer? _moodTimer;
  MoodType? _lastMood;

  @override
  void initState() {
    super.initState();
    widget.moodNotifier.addListener(_onMoodChange);
  }

  void _onMoodChange() {
    final mood = widget.moodNotifier.value;
    if (_lastMood != mood) {
      _lastMood = mood;
      _moodTimer?.cancel();
      _moodTimer = Timer(Duration(seconds: 10), () {
        if (widget.onTrigger != null) {
          widget.onTrigger!(mood.name);
        }
      });
    }
  }

  @override
  void dispose() {
    _moodTimer?.cancel();
    widget.moodNotifier.removeListener(_onMoodChange);
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SizedBox.shrink(); // Invisible hook widget
  }
}
