import 'package:flutter/material.dart';
import 'mood_notifier.dart';
import 'package:provider/provider.dart';

mixin MoodMusicMixin<T extends StatefulWidget> on State<T> {
  late MoodNotifier moodNotifier;

  void setupMoodListener(Function(String) onMoodPlaylistChange) {
    moodNotifier = Provider.of<MoodNotifier>(context, listen: false);
    moodNotifier.addListener(() {
      switch (moodNotifier.value) {
        case MoodType.energy:
          onMoodPlaylistChange('Energy');
          break;
        case MoodType.calm:
          onMoodPlaylistChange('Calm');
          break;
        case MoodType.focus:
          onMoodPlaylistChange('Focus');
          break;
        case MoodType.reflective:
          onMoodPlaylistChange('Reflective');
          break;
      }
    });
  }
}