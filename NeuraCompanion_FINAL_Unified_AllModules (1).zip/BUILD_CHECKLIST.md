# Neura Companion — Final Unified Build (Preflight Checklist)

This bundle is designed to be runnable out-of-the-box once Flutter is installed.

## 0) Prereqs
- Flutter (recommended stable) and Dart installed and on PATH
- Android Studio (for Android builds) / Visual Studio Build Tools (for Windows builds)

## 1) Quick start
```bash
flutter pub get
flutter run
```

## 2) Android release
```bash
flutter build apk --release
# output: build/app/outputs/flutter-apk/app-release.apk
```

## 3) Windows release
```bash
flutter config --enable-windows-desktop
flutter build windows --release
# output: build/windows/x64/runner/Release/
```

## 4) Tests (optional)
```bash
flutter test
```

## 5) Configuration notes
- Firebase / Google Sign-In / Apple Sign-In are optional. If you enable them, add keys and platform config files.
- Azure hooks are optional and can be ignored unless you wire credentials.

## 6) Integrity
- `SHA256SUMS.txt` and `MANIFEST.json` describe every included file and hash.
