@echo off
setlocal enabledelayedexpansion

REM Neura Companion - One-shot build helper (Windows)
REM Requirements: Flutter on PATH. For Windows builds, enable desktop + install VS Build Tools.

set ROOT=%~dp0..
set DIST=%ROOT%\dist
if not exist "%DIST%" mkdir "%DIST%"

echo === Neura Companion Preflight ===
where flutter >nul 2>&1
if errorlevel 1 (
  echo ERROR: Flutter not found on PATH.
  echo Install Flutter and ensure flutter.exe is available, then rerun.
  exit /b 1
)

cd /d "%ROOT%"

echo === flutter pub get ===
flutter pub get || exit /b 1

echo === Running analyzer (non-fatal) ===
flutter analyze

echo === Building Android APK (release) ===
flutter build apk --release || echo (Android build failed - verify Android toolchain)

if exist "build\app\outputs\flutter-apk\app-release.apk" (
  copy /y "build\app\outputs\flutter-apk\app-release.apk" "%DIST%\NeuraCompanion-Android-release.apk" >nul
  echo Copied Android APK to dist\
)

echo === Building Windows (release) ===
flutter config --enable-windows-desktop >nul 2>&1
flutter build windows --release || echo (Windows build failed - verify Windows toolchain)

if exist "build\windows\x64\runner\Release" (
  echo Copying Windows Release folder to dist\NeuraCompanion-Windows-Release\
  if exist "%DIST%\NeuraCompanion-Windows-Release" rmdir /s /q "%DIST%\NeuraCompanion-Windows-Release"
  xcopy /e /i /y "build\windows\x64\runner\Release" "%DIST%\NeuraCompanion-Windows-Release" >nul
)

echo === Done ===
echo Outputs (if build succeeded):
echo   %DIST%
pause
