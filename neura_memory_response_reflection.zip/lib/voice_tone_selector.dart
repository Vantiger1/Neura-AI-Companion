import 'package:flutter/material.dart';

class VoiceToneSelector extends StatelessWidget {
  final Function(String tone) onSelected;

  const VoiceToneSelector({Key? key, required this.onSelected}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final tones = ['zen', 'motivational', 'goofy'];

    return Column(
      children: [
        Text("Choose Neura's Tone:"),
        ...tones.map((tone) => ListTile(
              title: Text(tone.toUpperCase()),
              leading: Radio<String>(
                value: tone,
                groupValue: null,
                onChanged: (value) {
                  if (value != null) onSelected(value);
                },
              ),
            )),
      ],
    );
  }
}