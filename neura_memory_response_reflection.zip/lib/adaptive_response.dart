class NeuraStyle {
  final String personality;

  NeuraStyle(this.personality);

  String respondTo(String message) {
    switch (personality) {
      case 'motivational':
        return "You got this! 💪 $message";
      case 'zen':
        return "Let’s breathe and reflect... 🌿 $message";
      case 'goofy':
        return "Haha, let’s roll with it! 😂 $message";
      default:
        return message;
    }
  }
}