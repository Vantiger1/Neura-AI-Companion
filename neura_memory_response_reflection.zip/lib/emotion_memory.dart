import 'package:shared_preferences/shared_preferences.dart';

class EmotionMemory {
  static Future<void> logEmotion(String mood, String date) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('mood_$date', mood);
  }

  static Future<Map<String, String>> getWeeklyEmotions(List<String> last7Dates) async {
    final prefs = await SharedPreferences.getInstance();
    final Map<String, String> logs = {};
    for (final date in last7Dates) {
      logs[date] = prefs.getString('mood_$date') ?? 'unknown';
    }
    return logs;
  }

  static String generateReflection(Map<String, String> weekLog) {
    final moodCount = <String, int>{};
    weekLog.values.forEach((mood) {
      moodCount[mood] = (moodCount[mood] ?? 0) + 1;
    });

    final topMood = moodCount.entries.reduce((a, b) => a.value > b.value ? a : b).key;
    return "You've felt mostly $topMood this week. Let’s keep track and see how we can support you better.";
  }
}