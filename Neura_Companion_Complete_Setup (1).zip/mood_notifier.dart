import 'package:flutter/material.dart';
import 'neura_voice_engine.dart';

enum MoodType { calm, focus, energy, reflective }

class MoodNotifier extends ValueNotifier<MoodType> {
  final NeuraVoiceEngine _voiceEngine = NeuraVoiceEngine();

  MoodNotifier() : super(MoodType.calm);

  void update(MoodType newMood) {
    if (value != newMood) {
      value = newMood;
      _voiceEngine.speakMood(newMood);
    }
  }
}
