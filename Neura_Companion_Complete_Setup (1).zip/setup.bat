@echo off
echo Initializing Neura Companion Setup...

:: Check if Flutter is installed
flutter --version >nul 2>&1
IF ERRORLEVEL 1 (
    echo Flutter is not installed or not in PATH. Please install Flutter and try again.
    pause
    exit /b
)

:: Run pub get
echo Running flutter pub get...
flutter pub get

:: Create build directory structure if needed
if not exist build mkdir build

echo Setup complete. You can now run: flutter run
pause
