# Neura SVG Rig v1.1 (Enhanced)
New: lids openness, pupil dilation, micro-saccades, emotion presets, extra visemes.
API: NeuraRig.setLids(), setPupil(), microIdle(), setEmotion(), plus all v1.0 methods and NeuraRig.act(json).
