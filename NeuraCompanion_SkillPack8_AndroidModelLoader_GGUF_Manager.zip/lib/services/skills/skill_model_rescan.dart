import '../local_models/neura_model_pack_manager.dart';
import 'neura_skill.dart';

class SkillModelRescan extends NeuraSkill {
  @override
  String get type => 'model_rescan';

  @override
  String get capability => 'localModels';

  @override
  String get risk => 'low';

  @override
  String summarize(NeuraActionRequest req) => 'Rescan model folder for GGUF files';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final res = await NeuraModelPackManager.I.rescanFromDisk();
    return NeuraActionResult.ok(data: res);
  }
}
