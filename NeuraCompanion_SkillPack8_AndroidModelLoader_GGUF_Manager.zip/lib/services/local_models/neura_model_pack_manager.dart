import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'neura_local_model_settings.dart';

class NeuraModelPack {
  final String id;
  final String fileName;
  final String path;
  final int bytes;
  final String addedAt;
  final String description;

  const NeuraModelPack({
    required this.id,
    required this.fileName,
    required this.path,
    required this.bytes,
    required this.addedAt,
    required this.description,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'fileName': fileName,
        'path': path,
        'bytes': bytes,
        'addedAt': addedAt,
        'description': description,
      };

  factory NeuraModelPack.fromJson(Map<String, dynamic> j) => NeuraModelPack(
        id: (j['id'] ?? '').toString(),
        fileName: (j['fileName'] ?? '').toString(),
        path: (j['path'] ?? '').toString(),
        bytes: (j['bytes'] ?? 0) is int ? (j['bytes'] as int) : int.tryParse('${j['bytes']}') ?? 0,
        addedAt: (j['addedAt'] ?? '').toString(),
        description: (j['description'] ?? '').toString(),
      );
}

/// Offline model pack manager.
///
/// Key upgrade (Skill Pack 8):
/// - Android stores model packs in app **external** files dir when available, so users can
///   copy GGUF files in via USB/file managers without broad storage permissions.
/// - Adds `rescanFromDisk()` to sync the registry with the folder contents.
class NeuraModelPackManager {
  static final NeuraModelPackManager I = NeuraModelPackManager._();
  NeuraModelPackManager._();

  Directory? _root;
  File? _registry;
  final List<NeuraModelPack> _packs = <NeuraModelPack>[];

  Future<void> init() async {
    if (_root != null) return;
    _root = await _resolveRootDir();
    if (!_root!.existsSync()) _root!.createSync(recursive: true);

    _registry = File('${_root!.path}${Platform.pathSeparator}registry.json');
    await NeuraLocalModelSettings.I.init();
    await _load();

    // Sync registry with disk (important for Android manual copy).
    await rescanFromDisk();
  }

  /// Best-effort location:
  /// - Android: external app dir (Android/data/<package>/files/...) if present.
  /// - Else: application support directory.
  Future<Directory> _resolveRootDir() async {
    Directory? base;

    if (Platform.isAndroid) {
      try {
        base = await getExternalStorageDirectory();
      } catch (_) {
        base = null;
      }
    }

    base ??= await getApplicationSupportDirectory();
    return Directory('${base.path}${Platform.pathSeparator}neura_models');
  }

  String? get rootPath => _root?.path;

  List<NeuraModelPack> list() => List.unmodifiable(_packs);

  NeuraModelPack? byId(String id) {
    for (final p in _packs) {
      if (p.id == id) return p;
    }
    return null;
  }

  NeuraModelPack? get selected {
    final id = NeuraLocalModelSettings.I.selectedModelId;
    if (id.isEmpty) return null;
    return byId(id);
  }

  Future<void> select(String id) async {
    await NeuraLocalModelSettings.I.setSelectedModelId(id);
  }

  /// Import by file path.
  /// Desktop-friendly. Android may work if the file is already in an accessible sandbox path.
  Future<NeuraModelPack> importFromPath({
    required String sourcePath,
    String description = '',
  }) async {
    await init();
    final src = File(sourcePath);
    if (!src.existsSync()) {
      throw Exception('Model file not found: $sourcePath');
    }
    final name = src.uri.pathSegments.isNotEmpty ? src.uri.pathSegments.last : 'model.gguf';
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final dstPath = '${_root!.path}${Platform.pathSeparator}$id-$name';
    final dst = await src.copy(dstPath);
    final bytes = await dst.length();

    final pack = NeuraModelPack(
      id: id,
      fileName: name,
      path: dst.path,
      bytes: bytes,
      addedAt: DateTime.now().toIso8601String(),
      description: description,
    );
    _packs.insert(0, pack);
    await _save();

    // Auto-select first import.
    if (NeuraLocalModelSettings.I.selectedModelId.isEmpty) {
      await NeuraLocalModelSettings.I.setSelectedModelId(id);
    }
    return pack;
  }

  /// Rescan the model folder for `*.gguf` and sync registry.
  ///
  /// This is the Android path:
  /// - User copies `*.gguf` into the folder.
  /// - Neura runs rescan.
  /// - Packs appear in `model_list`.
  Future<Map<String, dynamic>> rescanFromDisk() async {
    await init();

    final dir = _root!;
    if (!dir.existsSync()) {
      dir.createSync(recursive: true);
    }

    final files = dir
        .listSync()
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.gguf'))
        .toList();

    final existingByPath = {for (final p in _packs) p.path: p};
    final seenPaths = <String>{};

    int added = 0;
    int removed = 0;

    // Add missing from disk
    for (final f in files) {
      seenPaths.add(f.path);
      if (existingByPath.containsKey(f.path)) continue;

      final name = f.uri.pathSegments.isNotEmpty ? f.uri.pathSegments.last : 'model.gguf';
      final id = _stableIdForPath(f.path);
      final bytes = await f.length();

      _packs.insert(
        0,
        NeuraModelPack(
          id: id,
          fileName: name,
          path: f.path,
          bytes: bytes,
          addedAt: DateTime.now().toIso8601String(),
          description: 'Discovered on disk',
        ),
      );
      added++;
    }

    // Remove registry entries whose files no longer exist
    final before = _packs.length;
    _packs.removeWhere((p) {
      if (p.path.toLowerCase().endsWith('.json')) return false;
      final exists = File(p.path).existsSync();
      if (!exists) removed++;
      return !exists;
    });
    final after = _packs.length;

    // Keep selection sane
    final sel = NeuraLocalModelSettings.I.selectedModelId;
    if (sel.isNotEmpty && byId(sel) == null) {
      await NeuraLocalModelSettings.I.setSelectedModelId(_packs.isNotEmpty ? _packs.first.id : '');
    }

    await _save();

    return {
      'ok': true,
      'root': dir.path,
      'found': files.length,
      'added': added,
      'removed': removed,
      'packs': _packs.map((e) => e.toJson()).toList(),
      'before': before,
      'after': after,
    };
  }

  String _stableIdForPath(String p) {
    // Stable-ish identifier so rescans don't create duplicates.
    // Not cryptographic; just enough to stay consistent.
    var hash = 2166136261; // FNV-1a 32-bit offset basis
    final bytes = utf8.encode(p);
    for (final b in bytes) {
      hash ^= b;
      hash = (hash * 16777619) & 0xffffffff;
    }
    return hash.toUnsigned(32).toString();
  }

  Future<bool> remove(String id) async {
    await init();
    final p = byId(id);
    if (p == null) return false;
    try {
      final f = File(p.path);
      if (f.existsSync()) {
        await f.delete();
      }
    } catch (_) {
      // ignore
    }
    _packs.removeWhere((e) => e.id == id);
    if (NeuraLocalModelSettings.I.selectedModelId == id) {
      await NeuraLocalModelSettings.I.setSelectedModelId(_packs.isNotEmpty ? _packs.first.id : '');
    }
    await _save();
    return true;
  }

  Future<void> _load() async {
    if (_registry == null) return;
    if (!_registry!.existsSync()) {
      _packs.clear();
      return;
    }
    try {
      final raw = await _registry!.readAsString();
      final j = jsonDecode(raw);
      final items = (j['packs'] as List?) ?? const [];
      _packs
        ..clear()
        ..addAll(items.map((e) => NeuraModelPack.fromJson((e as Map).cast<String, dynamic>())));
    } catch (_) {
      _packs.clear();
    }
  }

  Future<void> _save() async {
    if (_registry == null) return;
    final j = {
      'version': 1,
      'savedAt': DateTime.now().toIso8601String(),
      'root': _root?.path,
      'packs': _packs.map((e) => e.toJson()).toList(),
    };
    await _registry!.writeAsString(const JsonEncoder.withIndent('  ').convert(j));
  }
}
