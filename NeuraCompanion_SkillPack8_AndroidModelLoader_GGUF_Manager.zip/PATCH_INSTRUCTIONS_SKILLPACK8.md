# Patch Instructions — Skill Pack 8

1) Copy files into your project root, preserving paths:
- `lib/services/local_models/neura_model_pack_manager.dart`
- `lib/services/skills/skill_model_rescan.dart`
- `NEURA_SKILLPACK8_README.md`

2) Register the new skill in your daemon init (where other model skills are registered):

In `lib/services/neura_local_core_daemon.dart`:
- Add import:
  `import 'skills/skill_model_rescan.dart';`
- Register after other model skills:
  `reg.register(SkillModelRescan());`

3) Rebuild.

4) Android usage:
- Copy `*.gguf` into your external app folder (see README)
- Run `model_rescan`
- Then `model_list` / `model_select`
