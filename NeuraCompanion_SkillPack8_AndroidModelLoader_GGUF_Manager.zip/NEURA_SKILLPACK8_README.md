# Neura Companion — Skill Pack 8
## Android Model Loader + GGUF File Manager (Offline)

This patch strengthens **true offline model pack handling on Android** without adding new Flutter plugins.

### What’s new
- **Android-friendly model storage**: model packs are stored in the app’s *external app directory* when available:
  - `Android/data/<your.package.id>/files/neura_models/`
  - This directory can be accessed via USB/file managers on many devices.
- **Disk rescan**: Neura can discover GGUF files you copied into the folder (Android) and sync the local registry.
- **New Core skill**: `model_rescan`
  - Safely updates the registry by scanning the model folder for `*.gguf`.

### How to use (Android)
1. Build/install the app on Android.
2. Using a file manager or USB connection, copy your `*.gguf` file(s) into:
   - `Android/data/<your.package.id>/files/neura_models/`
3. In Neura:
   - Run the action `model_rescan` (via your command console / core execute endpoint)
   - Then run `model_list` and `model_select`.

### Notes
- This patch intentionally avoids broad storage permissions and does **not** read from Downloads on Android (Scoped Storage).
- Desktop behavior stays the same (Application Support directory), but also benefits from the rescan.

### Files
- `lib/services/local_models/neura_model_pack_manager.dart` (updated)
- `lib/services/skills/skill_model_rescan.dart` (new)

