
import 'package:flutter/material.dart';
import 'widgets/emotion_memory_graph.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final moodData = [
      MoodEntry(now.subtract(Duration(days: 0)), 'joy', 0.8),
      MoodEntry(now.subtract(Duration(days: 1)), 'sad', 0.5),
      MoodEntry(now.subtract(Duration(days: 2)), 'calm', 0.6),
      MoodEntry(now.subtract(Duration(days: 3)), 'anger', 0.3),
      MoodEntry(now.subtract(Duration(days: 4)), 'joy', 0.9),
      MoodEntry(now.subtract(Duration(days: 5)), 'calm', 0.7),
      MoodEntry(now.subtract(Duration(days: 6)), 'sad', 0.4),
    ];

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Emotion Memory Graph')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: EmotionMemoryGraph(moodData: moodData),
        ),
      ),
    );
  }
}
