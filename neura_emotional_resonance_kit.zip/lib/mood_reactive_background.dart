import 'package:flutter/material.dart';

class MoodReactiveBackground extends StatelessWidget {
  final String mood;
  final Widget child;

  const MoodReactiveBackground({Key? key, required this.mood, required this.child}) : super(key: key);

  Color getGradientStart() {
    switch (mood) {
      case "happy":
        return Colors.yellow.shade200;
      case "sad":
        return Colors.indigo.shade400;
      case "calm":
        return Colors.lightBlue.shade100;
      case "excited":
        return Colors.deepOrangeAccent.shade100;
      default:
        return Colors.grey.shade300;
    }
  }

  Color getGradientEnd() {
    switch (mood) {
      case "happy":
        return Colors.orangeAccent.shade100;
      case "sad":
        return Colors.deepPurple.shade200;
      case "calm":
        return Colors.cyan.shade100;
      case "excited":
        return Colors.orange.shade200;
      default:
        return Colors.grey.shade100;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [getGradientStart(), getGradientEnd()],
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
        ),
      ),
      child: child,
    );
  }
}