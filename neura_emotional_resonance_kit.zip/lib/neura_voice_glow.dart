import 'package:flutter/material.dart';

class NeuraVoiceGlow extends StatefulWidget {
  final bool isSpeaking;

  const NeuraVoiceGlow({Key? key, required this.isSpeaking}) : super(key: key);

  @override
  _NeuraVoiceGlowState createState() => _NeuraVoiceGlowState();
}

class _NeuraVoiceGlowState extends State<NeuraVoiceGlow>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _glow;

  @override
  void initState() {
    _controller = AnimationController(
      duration: Duration(milliseconds: 800),
      vsync: this,
    );

    _glow = Tween<double>(begin: 0.0, end: 30.0).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );

    if (widget.isSpeaking) _controller.repeat(reverse: true);
    super.initState();
  }

  @override
  void didUpdateWidget(NeuraVoiceGlow oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSpeaking && !_controller.isAnimating) {
      _controller.repeat(reverse: true);
    } else if (!widget.isSpeaking && _controller.isAnimating) {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (_, __) {
        return Container(
          width: 120,
          height: 120,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.purpleAccent,
            boxShadow: [
              BoxShadow(
                color: Colors.purpleAccent.withOpacity(0.7),
                blurRadius: _glow.value,
                spreadRadius: _glow.value / 2,
              ),
            ],
          ),
          child: Icon(Icons.mic, color: Colors.white, size: 50),
        );
      },
    );
  }
}