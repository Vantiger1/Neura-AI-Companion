import 'package:flutter/material.dart';

class NeuraChatBubble extends StatelessWidget {
  final String message;
  final String mood;

  const NeuraChatBubble({Key? key, required this.message, required this.mood}) : super(key: key);

  Color getMoodColor() {
    switch (mood) {
      case "happy":
        return Colors.yellow;
      case "sad":
        return Colors.indigo;
      case "calm":
        return Colors.teal;
      case "excited":
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      padding: EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: getMoodColor().withOpacity(0.2),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: getMoodColor()),
      ),
      child: Row(
        children: [
          CircleAvatar(
            backgroundImage: AssetImage('assets/images/neura_$mood.png'),
            radius: 20,
          ),
          SizedBox(width: 12),
          Expanded(
            child: Text(
              message,
              style: TextStyle(fontSize: 16, color: getMoodColor().shade700),
            ),
          ),
        ],
      ),
    );
  }
}