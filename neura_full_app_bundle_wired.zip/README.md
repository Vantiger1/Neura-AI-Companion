# Neura Companion Full App Integration

This build includes:
✅ Full Neura AI Add-On Modules  
✅ Wired integration into `lib/neura/`  
✅ Ready to launch in your existing Flutter project

## How to Use

1. Drop the included `lib/neura/` folder into your Flutter app.
2. Update your `pubspec.yaml` to include dependencies such as:
   ```yaml
   dependencies:
     flutter:
       sdk: flutter
     shared_preferences: ^2.0.0
     flutter_tts: ^3.5.0
     connectivity_plus: ^2.0.2
     hive: ^2.0.0
     path_provider: ^2.0.0
   ```
3. In your `main.dart`:
   ```dart
   import 'package:your_app/neura/neura_manager.dart';

   void main() async {
     WidgetsFlutterBinding.ensureInitialized();
     await NeuraManager.init();
     runApp(MyApp());
   }
   ```

## Included Modules

- 🎭 Emotion Animator
- 🗣️ Voice + Jokes Engine
- 🛌 Dream Capture, Replay & Calendar
- 🧠 Memory Model + Preferences
- 💤 Sleep Listener & Interpreter
- 📆 Monthly Dream Show Launcher

Each module is pre-scaffolded and can be customized further inside `lib/neura/`.
