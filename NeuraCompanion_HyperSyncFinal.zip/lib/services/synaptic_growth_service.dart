import '../models/user_memory.dart';

class SynapticGrowthService {
  final List<UserMemory> history;

  SynapticGrowthService({required this.history});

  Map<String, double> calculateMoodLiftByRitual() {
    final Map<String, List<String>> ritualToMoods = {};
    final Map<String, double> ritualLift = {};

    for (final m in history) {
      if (!ritualToMoods.containsKey(m.source)) {
        ritualToMoods[m.source] = [];
      }
      ritualToMoods[m.source]?.add(m.moodTag);
    }

    ritualToMoods.forEach((ritual, moods) {
      final score = moods.map((m) => _moodScore(m)).reduce((a, b) => a + b) / moods.length;
      ritualLift[ritual] = score;
    });

    return ritualLift;
  }

  double _moodScore(String mood) {
    final scale = {
      'sad': -1.0,
      'anxious': -0.5,
      'tired': 0.0,
      'calm': 0.5,
      'happy': 1.0,
    };
    return scale[mood.toLowerCase()] ?? 0.0;
  }
}
