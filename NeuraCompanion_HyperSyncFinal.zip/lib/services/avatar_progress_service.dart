import 'package:hive/hive.dart';
import '../models/evolving_avatar_model.dart';

class AvatarProgressService {
  static const _boxName = 'avatar_progress';
  late Box box;

  Future<void> init() async {
    box = await Hive.openBox(_boxName);
  }

  Future<void> saveAvatar(EvolvingAvatar avatar) async {
    await box.put(avatar.id, avatar.toMap());
  }

  EvolvingAvatar? getAvatar(String id) {
    final data = box.get(id);
    if (data == null) return null;
    return EvolvingAvatar.fromMap(Map<String, dynamic>.from(data));
  }

  Future<EvolvingAvatar> evolveAvatar(String id) async {
    final avatar = getAvatar(id);
    if (avatar == null) throw Exception('Avatar not found');
    final evolved = avatar.evolve();
    await saveAvatar(evolved);
    return evolved;
  }
}
