import 'package:intl/intl.dart';
import '../models/user_memory.dart';
import 'memory_service.dart';

class ReflectiveMirrorService {
  final MemoryService memoryService;

  ReflectiveMirrorService(this.memoryService);

  String generateWeeklyReflection() {
    final memories = memoryService.getAllMemories();
    if (memories.isEmpty) return "You haven't recorded much this week.";

    final summary = <String, int>{};
    for (final m in memories) {
      summary[m.moodTag] = (summary[m.moodTag] ?? 0) + 1;
    }

    final sorted = summary.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topMood = sorted.first.key;
    final total = summary.values.reduce((a, b) => a + b);

    return "This week, your most dominant emotion was "$topMood". "
        "You experienced $total logged moods and showed emotional awareness. "
        "You're progressing steadily. Keep reflecting!";
  }
}
