import '../models/user_memory.dart';
import 'memory_service.dart';
import 'package:uuid/uuid.dart';

class ChatMemoryWrapper {
  final MemoryService memoryService;

  ChatMemoryWrapper(this.memoryService);

  Future<void> recordMemory(String mood, String content, {String source = 'chat'}) async {
    final keywords = _extractKeywords(content);
    final memory = UserMemory(
      id: Uuid().v4(),
      timestamp: DateTime.now(),
      moodTag: mood,
      keywords: keywords,
      source: source,
    );
    await memoryService.saveMemory(memory);
  }

  List<String> _extractKeywords(String text) {
    final words = text.split(RegExp(r'\W+'));
    final filtered = words.where((w) => w.length > 4).toSet().toList();
    return filtered.take(10).toList();
  }
}
