import 'package:flutter/foundation.dart';

@immutable
class Quest {
  final String id;
  final String title;
  final String description;
  final bool completed;
  final int xp;

  const Quest({
    required this.id,
    required this.title,
    required this.description,
    this.completed = false,
    this.xp = 10,
  });

  Quest markCompleted() => Quest(
    id: id,
    title: title,
    description: description,
    completed: true,
    xp: xp,
  );
}
