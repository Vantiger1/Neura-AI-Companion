import 'package:flutter/material.dart';
import '../models/user_memory.dart';

class NeuraTimelineScreen extends StatelessWidget {
  final List<UserMemory> history;

  const NeuraTimelineScreen({required this.history});

  @override
  Widget build(BuildContext context) {
    final sorted = history..sort((a, b) => a.timestamp.compareTo(b.timestamp));

    return Scaffold(
      appBar: AppBar(title: Text('Neura Emotional Timeline')),
      body: ListView.separated(
        padding: EdgeInsets.all(12),
        itemCount: sorted.length,
        separatorBuilder: (_, __) => Divider(),
        itemBuilder: (context, index) {
          final mem = sorted[index];
          return ListTile(
            leading: Icon(Icons.circle, color: _colorForMood(mem.moodTag)),
            title: Text('${mem.moodTag.toUpperCase()} - ${mem.source}'),
            subtitle: Text('${mem.timestamp.year}/${mem.timestamp.month}/${mem.timestamp.day}'),
            trailing: Text(mem.keywords.join(', ')),
          );
        },
      ),
    );
  }

  Color _colorForMood(String mood) {
    switch (mood.toLowerCase()) {
      case 'happy': return Colors.yellow;
      case 'calm': return Colors.blueAccent;
      case 'anxious': return Colors.orange;
      case 'sad': return Colors.indigo;
      case 'tired': return Colors.grey;
      default: return Colors.teal;
    }
  }
}
