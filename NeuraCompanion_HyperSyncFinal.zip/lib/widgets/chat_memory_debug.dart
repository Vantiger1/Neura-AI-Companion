import 'package:flutter/material.dart';
import '../services/memory_service.dart';

class ChatMemoryDebugScreen extends StatefulWidget {
  final MemoryService service;
  const ChatMemoryDebugScreen({required this.service});

  @override
  _ChatMemoryDebugScreenState createState() => _ChatMemoryDebugScreenState();
}

class _ChatMemoryDebugScreenState extends State<ChatMemoryDebugScreen> {
  @override
  Widget build(BuildContext context) {
    final memories = widget.service.getAllMemories();
    return Scaffold(
      appBar: AppBar(title: Text('Memory Graph')),
      body: ListView.builder(
        itemCount: memories.length,
        itemBuilder: (ctx, i) {
          final m = memories[i];
          return ListTile(
            title: Text(m.moodTag),
            subtitle: Text(m.keywords.join(', ')),
            trailing: Text('${m.timestamp.hour}:${m.timestamp.minute}'),
          );
        },
      ),
    );
  }
}
