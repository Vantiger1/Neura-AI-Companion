class OnboardingTutorialService {
  final List<TutorialStep> steps = [
    TutorialStep(
      title: 'Welcome to Neura',
      description: 'Your AI companion to help you grow emotionally, mentally, and socially.',
    ),
    TutorialStep(
      title: 'Mood Check-In',
      description: 'Log how you’re feeling daily to build emotional awareness and get tailored guidance.',
    ),
    TutorialStep(
      title: 'Neura & Neuro',
      description: 'Chat with your evolving AI companion for reflection, feedback, humor, or advice.',
    ),
    TutorialStep(
      title: 'Daily Rituals',
      description: 'Track powerful habits like journaling, water intake, gratitude, and meditation.',
    ),
    TutorialStep(
      title: 'Dream Journal',
      description: 'Record dreams, get AI interpretations, and visualize recurring themes.',
    ),
    TutorialStep(
      title: 'Evolve Neura',
      description: 'The more you engage, the more Neura evolves and reflects your journey.',
    ),
  ];
}

class TutorialStep {
  final String title;
  final String description;

  const TutorialStep({
    required this.title,
    required this.description,
  });
}
