import 'package:flutter/material.dart';
import '../services/therapy_service.dart';
import '../widgets/therapy_prompt_card.dart';
import '../models/therapy_path_model.dart';

class TherapyPathScreen extends StatefulWidget {
  final TherapyService service;
  const TherapyPathScreen({required this.service});

  @override
  _TherapyPathScreenState createState() => _TherapyPathScreenState();
}

class _TherapyPathScreenState extends State<TherapyPathScreen> {
  String selectedMethod = 'CBT';
  List<TherapyPrompt> prompts = [];

  @override
  void initState() {
    super.initState();
    prompts = widget.service.getAll(selectedMethod);
  }

  void _selectMethod(String method) {
    setState(() {
      selectedMethod = method;
      prompts = widget.service.getAll(method);
    });
  }

  @override
  Widget build(BuildContext context) {
    final methods = widget.service.getMethods();
    return Scaffold(
      appBar: AppBar(title: Text('Therapy Journal')),
      body: Column(
        children: [
          DropdownButton<String>(
            value: selectedMethod,
            onChanged: (v) => _selectMethod(v!),
            items: methods.map((m) => DropdownMenuItem(value: m, child: Text(m))).toList(),
          ),
          Expanded(
            child: ListView(
              children: prompts.map((p) => TherapyPromptCard(prompt: p, onTap: () {})).toList(),
            ),
          )
        ],
      ),
    );
  }
}
