import 'package:flutter/material.dart';
import '../services/ai_ritual_service.dart';

class AIRitualCuratorScreen extends StatefulWidget {
  final AIRitualService service;
  const AIRitualCuratorScreen({required this.service});

  @override
  State<AIRitualCuratorScreen> createState() => _AIRitualCuratorScreenState();
}

class _AIRitualCuratorScreenState extends State<AIRitualCuratorScreen> {
  @override
  Widget build(BuildContext context) {
    final rituals = widget.service.rituals;
    return Scaffold(
      appBar: AppBar(title: Text('Neura Ritual Curator')),
      body: ListView(
        children: rituals.map((r) => Card(
          child: ListTile(
            title: Text(r.title),
            subtitle: Text(r.purpose),
            trailing: r.completed
              ? Icon(Icons.check_circle, color: Colors.green)
              : ElevatedButton(
                  child: Text('Do Ritual'),
                  onPressed: () {
                    setState(() {
                      widget.service.complete(r.id);
                    });
                  },
                ),
          ),
        )).toList(),
      ),
    );
  }
}
