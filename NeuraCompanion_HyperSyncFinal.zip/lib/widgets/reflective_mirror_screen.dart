import 'package:flutter/material.dart';
import '../services/reflective_summary_service.dart';

class ReflectiveMirrorScreen extends StatelessWidget {
  final ReflectiveMirrorService mirror;

  const ReflectiveMirrorScreen({required this.mirror});

  @override
  Widget build(BuildContext context) {
    final text = mirror.generateWeeklyReflection();
    return Scaffold(
      appBar: AppBar(title: Text('Neura Reflective Mirror')),
      body: Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(text, style: TextStyle(fontSize: 18)),
        ),
      ),
    );
  }
}
