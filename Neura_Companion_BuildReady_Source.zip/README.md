# Neura Companion App

Neura Companion is an AI-driven wellness app that provides:
- **Joke Panel**: Animated jokes with user ratings and favorites.
- **Dream Journal**: Record, interpret, and visualize your dreams.
- **Dream Calendar**: Browse your dream entries by date.
- **Settings**: Toggle voice, quiet mode, and joke preferences.

## Prerequisites

- Flutter SDK (≥ 3.7.0)
- Android Studio or Xcode (for respective platforms)
- A connected device or emulator (Android 8.0 / iOS 14+)

## Installation

1. Clone or extract this repository.
2. Navigate to the project folder:
   ```bash
   cd NeuraCompanion_FullSource
   ```
3. Fetch dependencies:
   ```bash
   flutter pub get
   ```
4. Run the app on a connected device:
   ```bash
   flutter run
   ```
5. Build a release APK:
   ```bash
   flutter build apk
   ```
6. (On macOS) Build for iOS:
   ```bash
   flutter build ios
   ```

## Project Structure

```
NeuraCompanion_FullSource/
├── android/                # Android platform build files
├── ios/                    # iOS platform build files
├── lib/                    # Dart source files
│   ├── main.dart           # App entry point
│   ├── neura_manager.dart
│   ├── ...
├── assets/
│   ├── images/             # Placeholder for images
│   ├── audio/              # Placeholder for audio
│   └── sample/             # Sample dream entries (dreams.json)
├── test/                   # Test suites
│   └── neura_memory_model_test.dart
├── pubspec.yaml            # Project manifest
├── .gitignore              # Ignore rules
├── README.md               # This documentation
├── build.sh                # UNIX build script
├── build.bat               # Windows build script
└── ...
```

## Sample Data

A sample dreams JSON is provided in `assets/sample/dreams.json` for testing the Dream Journal.

## Tests

Run the test suite with:

```bash
flutter test
```