
🧠 NEURA COMPANION — BUILD INSTRUCTIONS

📱 Android:
1. Open terminal in project root
2. Run: flutter pub get
3. Build: flutter build apk --release
→ APK output: build/app/outputs/flutter-apk/app-release.apk

🍎 iOS:
1. Open project in Xcode (macOS)
2. Setup signing: add provisioning profile
3. Archive and Export to IPA
→ Output: .ipa for TestFlight or App Store

🌐 Web:
1. Run: flutter build web
→ Output: build/web folder (upload to Firebase or GitHub Pages)

🪟 Windows:
1. Run: flutter build windows
2. (Optional) Use Inno Setup or NSIS to package EXE installer

✨ Batch Setup:
Run `setup_neura_companion.bat` to create project folders and initiate build.
