
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js').then(function(reg) {
    reg.onupdatefound = function() {
      const installingWorker = reg.installing;
      installingWorker.onstatechange = function() {
        if (installingWorker.state === 'installed') {
          if (navigator.serviceWorker.controller) {
            alert("A fresh glow is ready. Please refresh Neura Companion ✨");
          }
        }
      };
    };
  });
}
