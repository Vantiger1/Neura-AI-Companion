
(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("neuraRig not found"); return; }
  const clamp01=x=>Math.max(0,Math.min(1,x));

  // ---------- Create eye highlights if missing ----------
  function ensureHighlights(){
    ["L","R"].forEach(side=>{
      const eye = document.querySelector(`#eye_${side}`);
      if(!eye) return;
      if(!document.querySelector(`#hl_${side}`)){
        const hl = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
        hl.setAttribute("id", `hl_${side}`);
        hl.setAttribute("rx","6"); hl.setAttribute("ry","4");
        hl.setAttribute("fill","#ffffff"); hl.setAttribute("opacity","0.85");
        hl.style.filter = "drop-shadow(0 0 2px rgba(255,255,255,.5))";
        eye.appendChild(hl);
      }
    });
  }
  ensureHighlights();

  // ---------- Core helpers ----------
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };

  function showViseme(n){ $$(".viseme").forEach(v=>v.classList.add("hidden")); (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden"); }

  // Gaze (immediate) + keep iris/pupil & highlights aligned
  function _applyGaze(dx,dy){
    [["L",460],["R",540]].forEach(([s,cx])=>{
      const i=$(`#iris_${s}`), p=$(`#pupil_${s}`), h=$(`#hl_${s}`);
      const x=cx+dx, y=780+dy;
      if(i){ i.setAttribute("cx",x); i.setAttribute("cy",y); }
      if(p){ p.setAttribute("cx",x); p.setAttribute("cy",y); }
      if(h){ h.setAttribute("cx", x-6); h.setAttribute("cy", y-6); }
    });
  }
  function setGaze(dx,dy){ _applyGaze(dx,dy); }

  // Smooth lookAt using simple critically damped approach
  let gazeTarget={x:0,y:0}, gazeState={x:0,y:0}, gvx=0, gvy=0, gazeRAF=null;
  function lookAt(x,y, stiffness=32, damping=6){
    gazeTarget={x,y};
    if(gazeRAF) return;
    const step=(t)=>{
      const ax = stiffness*(gazeTarget.x - gazeState.x) - damping*gvx;
      const ay = stiffness*(gazeTarget.y - gazeState.y) - damping*gvy;
      // discrete integration
      const dt=1/60;
      gvx += ax*dt; gvy += ay*dt;
      gazeState.x += gvx*dt; gazeState.y += gvy*dt;
      _applyGaze(gazeState.x, gazeState.y);
      const head=$("#head"); if(head) setRotation(head, Math.max(-6, Math.min(6, gazeState.x*0.6)));
      if(Math.hypot(gazeTarget.x-gazeState.x, gazeTarget.y-gazeState.y) > 0.01 || Math.hypot(gvx,gvy) > 0.01){
        gazeRAF=requestAnimationFrame(step);
      } else { gazeRAF=null; gvx=gvy=0; }
    };
    gazeRAF=requestAnimationFrame(step);
  }

  // ---------- Eyelid inertia (springy openness) ----------
  let lidTargetL=1, lidTargetR=1, lidOpenL=1, lidOpenR=1, lvL=0, lvR=0, lidRAF=null;
  function setLids(open=1){
    if(Array.isArray(open)){ lidTargetL=clamp01(open[0]); lidTargetR=clamp01(open[1]??open[0]); }
    else { lidTargetL=lidTargetR=clamp01(open); }
    if(!lidRAF){ lidRAF=requestAnimationFrame(lidStep); }
  }
  function setEyeOpennessRaw(side, open){
    const span=22;
    const u=$(`#lidU_${side}`), l=$(`#lidL_${side}`);
    if(!u||!l) return;
    const upperH=(1-open)*span, lowerH=(1-open)*span;
    u.setAttribute("y",780-22); u.setAttribute("height",upperH);
    l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
  }
  function lidStep(){
    // spring params (stiffer when opening to allow overshoot)
    const kOpen=42, cOpen=6, kClose=26, cClose=5, dt=1/60;
    // Left
    const kL = (lidTargetL > lidOpenL) ? kOpen : kClose;
    const cL = (lidTargetL > lidOpenL) ? cOpen : cClose;
    const aL = kL*(lidTargetL - lidOpenL) - cL*lvL;
    lvL += aL*dt; lidOpenL = clamp01(lidOpenL + lvL*dt);
    // Right
    const kR = (lidTargetR > lidOpenR) ? kOpen : kClose;
    const cR = (lidTargetR > lidOpenR) ? cOpen : cClose;
    const aR = kR*(lidTargetR - lidOpenR) - cR*lvR;
    lvR += aR*dt; lidOpenR = clamp01(lidOpenR + lvR*dt);

    setEyeOpennessRaw("L", lidOpenL);
    setEyeOpennessRaw("R", lidOpenR);

    // highlight flicker on near-closed
    ["L","R"].forEach(s=>{
      const h=$(`#hl_${s}`);
      const open = (s==="L"? lidOpenL: lidOpenR);
      if(h){ h.setAttribute("opacity", (0.5 + 0.5*open).toFixed(2)); }
    });

    if(Math.abs(lidTargetL-lidOpenL)>0.002 || Math.abs(lidTargetR-lidOpenR)>0.002 || Math.abs(lvL)>0.002 || Math.abs(lvR)>0.002){
      lidRAF=requestAnimationFrame(lidStep);
    } else { lidRAF=null; }
  }

  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }

  // Blink (uses inertia targets with optional asymmetry)
  let blinking=false, blinkSkew=0;
  function setBlinkAsymmetry(skew=0){ blinkSkew=Math.max(-1, Math.min(1, skew)); }
  function blinkOnce(duration=120){
    const skewMs = 40 * blinkSkew;
    // close
    setTimeout(()=> setLids([0, lidOpenR]), Math.max(0, -skewMs));
    setTimeout(()=> setLids([lidOpenL, 0]), Math.max(0,  skewMs));
    // open to 1; inertia will cause soft overshoot
    setTimeout(()=> setLids(1), duration + Math.abs(skewMs));
  }
  function autoBlink(on=true, min=2200, max=5200){
    blinking=on;
    const loop=()=>{
      if(!blinking) return;
      blinkOnce(120);
      setTimeout(loop, Math.random()*(max-min)+min);
    };
    if(on) loop();
  }

  // Affect & AffectPlus (same as v1.5 corner/lid coupling)
  function setAffect({browLift=0, smile=0}={}){
    const bl=$("#brow_left"), br=$("#brow_right"), neutral=$("#viseme_X");
    if(bl&&br){
      bl.setAttribute("d", `M440,${740-browLift} C455,${730-browLift} 470,${730-browLift} 485,${740-browLift}`);
      br.setAttribute("d", `M515,${740-browLift} C530,${730-browLift} 545,${730-browLift} 560,${740-browLift}`);
    }
    if(neutral){
      const mid = 860 + 10*smile;
      const corner = 845 - 12*Math.max(0,smile);
      neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
      applyCheekLowerLid(Math.max(0,smile));
    }
  }
  function setAffectPlus({squintL=0, squintR=0, cheek=0, nose=0, browTilt=0}={}){
    const openL = clamp01(1 - 0.6*squintL);
    const openR = clamp01(1 - 0.6*squintR);
    setLids([openL, openR]);
    const neutral=$("#viseme_X");
    if(neutral){
      const cornerLift = 12*cheek;
      const mid = 860 + 6*cheek;
      const cornerY = 845 - cornerLift;
      neutral.setAttribute("d", `M455,${cornerY} Q500,${mid} 545,${cornerY}`);
      applyCheekLowerLid(cheek);
    }
    const bl=$("#brow_left"), br=$("#brow_right");
    if(bl&&br){
      const shift = 6*nose, tilt = browTilt||0;
      bl.setAttribute("d", `M440,${740-shift+tilt*0.2} C455,${730-shift+tilt*0.2} 470,${730-shift} 485,${740-shift}`);
      br.setAttribute("d", `M515,${740-shift-tilt*0.2} C530,${730-shift-tilt*0.2} 545,${730-shift} 560,${740-shift}`);
    }
  }
  function applyCheekLowerLid(cheek){
    cheek=clamp01(cheek);
    const maxRaise=6, raise=maxRaise*cheek;
    ["L","R"].forEach(side=>{
      const l=$(`#lidL_${side}`);
      if(l){
        const h=parseFloat(l.getAttribute("height")||"0");
        const nh=h + raise/2;
        l.setAttribute("height", nh);
        l.setAttribute("y", 780+22-nh);
      }
    });
  }

  // Breath with head-pitch coupling
  let breatheId=null, breathPeriod=3000, breathAmp=1.5, breatheVar=0.08;
  function breathe(on=true, amp=1.5, period=3000, variability=0.08){
    breathAmp=amp; breathPeriod=period; breatheVar=variability;
    if(breatheId) cancelAnimationFrame(breatheId), breatheId=null;
    if(!on) return;
    const torso=$("#torso"), head=$("#head"); let start=null;
    function step(ts){
      if(!start) start=ts;
      const phase=(ts-start)/breathPeriod;
      const s=1+Math.sin(phase*2*Math.PI)*breathAmp/100;
      if(torso) torso.style.transform=`scale(${s})`;
      if(head)  setRotation(head, Math.sin(phase*2*Math.PI)*0.3); // ±0.3° pitch
      if(Math.floor(phase)%2===0 && Math.random()<0.005){
        breathPeriod = period*(1 + (Math.random()*2-1)*breatheVar);
      }
      breatheId=requestAnimationFrame(step);
    }
    breatheId=requestAnimationFrame(step);
  }

  // Audio-reactive hook
  function audioReact(level){
    level=clamp01(level);
    setPupil(6 + 3*level);
    const head=$("#head"); if(head) setRotation(head, (level-0.5)*2);
  }

  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }

  function setPose(p={}){
    [["#head","head"],["#neck","neck"],["#torso","torso"],
     ["#arm_L","armL"],["#forearm_L","forearmL"],
     ["#arm_R","armR"],["#forearm_R","forearmR"],
     ["#leg_L","legL"],["#shin_L","shinL"],
     ["#leg_R","legR"],["#shin_R","shinR"]]
    .forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); });
  }

  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=clamp01(i); }
  let microId=null;
  function microIdle(on=true){
    if(microId){ clearInterval(microId); microId=null; }
    if(!on) return;
    microId=setInterval(()=>{
      const dx=(Math.random()-.5)*4, dy=(Math.random()-.5)*3; setGaze(dx,dy);
      const head=$("#head"); if(head) setRotation(head,(Math.random()-.5)*4);
    }, 450+Math.random()*400);
  }

  // phoneme→viseme and scheduler
  const MAP={ A:["AA","AH","AO"], EE:["IY","IH","EH","EY","AE"], WQ:["UW","W"], O:["OW","OH","UH","UW"], FV:["F","V"], L:["L"], TH:["TH","DH"], MBP:["M","B","P"], X:["SIL","REST"] };
  function phonemeToViseme(ph){ ph=(ph||"").toUpperCase(); for(const [v,arr] of Object.entries(MAP)) if(arr.includes(ph)) return v; return "X"; }
  function scheduleVisemes(audio,timeline,lead=0){ if(!timeline||!timeline.length) return; const start=performance.now()+50; audio.currentTime=0; audio.play().catch(()=>{});
    timeline.forEach(({t,ph})=>{ const when=start+t-lead; setTimeout(()=>showViseme(phonemeToViseme(ph)), Math.max(0, when-performance.now())); }); }

  // Public API
  const API = {
    showViseme, setGaze, lookAt, blinkOnce, autoBlink, setBlinkAsymmetry,
    setAffect, setAffectPlus,
    setPose, breathe, setGlow, microIdle, setLids, setPupil,
    phonemeToViseme, scheduleVisemes, audioReact
  };
  global.NeuraRig=API;
})(window);
