
# Neura Rig v1.6 — Realism Pack
**New**
- **Eye highlights** (catchlights) that track gaze and dim with lid closure.
- **Eyelid inertia**: lids spring open/close with soft overshoot when reopening.
- **Breath–head coupling**: head pitch ±0.3° synced to breathing.

## Quick API
```js
NeuraRig.setLids(0); setTimeout(()=>NeuraRig.setLids(1), 300); // feel the spring
NeuraRig.lookAt(6,-2);                                        // smooth gaze + highlights track
NeuraRig.breathe(true, 1.6, 3200, 0.1);                        // slight variability + head pitch
```

Compatible with v1.5 features (SmileSpring, blink asymmetry, audioReact, affectPlus).
