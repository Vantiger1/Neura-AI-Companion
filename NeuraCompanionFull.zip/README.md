# Neura Companion OnTheGoLogging Integration

This project integrates the OnTheGoLogging modules into the Neura Companion Flutter app, providing:
- Clinical module with FHIR API calls and subscription flow
- Biometric feedback and HRV computation
- Activity posture monitoring
- Voice logging and TTS playback
- Micro-workouts with timed exercises
- Haptic and visual cues
- Health trend insights with charting
- Upgrade management for clinical upgrades
- Neura avatar widget integration

## Getting Started

1. Install Flutter SDK (>=2.18.0)
2. Run `flutter pub get`
3. To run on mobile: `flutter run`
4. To run tests: `flutter test`

## CI

A GitHub Actions workflow (`.github/workflows/ci.yaml`) runs analysis and tests on each PR.

## Directory Structure

```
lib/
  services/
  models/
  widgets/
  modules/
scripts/
.github/workflows/
analysis_options.yaml
```
