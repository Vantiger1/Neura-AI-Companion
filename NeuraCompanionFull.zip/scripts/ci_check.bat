@echo off
flutter pub get
flutter analyze
flutter test
