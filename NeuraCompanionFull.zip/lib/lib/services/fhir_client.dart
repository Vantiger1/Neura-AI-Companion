import 'package:http/http.dart' as http;
import 'dart:convert';

class FhirClient {
  final String baseUrl;

  FhirClient(this.baseUrl);

  Future<Map<String, dynamic>> getResource(String path) async {
    final response = await http.get(Uri.parse('\$baseUrl\$path'));
    if (response.statusCode == 200) {
      return json.decode(response.body) as Map<String, dynamic>;
    } else {
      throw Exception('FHIR request failed: \${response.statusCode}');
    }
  }
}
