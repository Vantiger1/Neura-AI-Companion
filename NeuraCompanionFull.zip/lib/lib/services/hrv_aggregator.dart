import 'package:health/health.dart';

class HRVAggregator {
  double computeAverageHRV(List<HealthDataPoint> samples) {
    if (samples.isEmpty) return 0;
    final values = samples.map((e) => e.value?.toDouble() ?? 0).toList();
    return values.reduce((a, b) => a + b) / values.length;
  }
}
