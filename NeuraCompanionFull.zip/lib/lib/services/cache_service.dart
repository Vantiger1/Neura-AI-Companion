import 'package:hive/hive.dart';

class CacheService {
  final Box _box;

  CacheService(this._box);

  T? get<T>(String key) {
    return _box.get(key) as T?;
  }

  Future<void> set<T>(String key, T value) async {
    await _box.put(key, value);
  }

  Future<void> invalidate(String key) async {
    await _box.delete(key);
  }
}
