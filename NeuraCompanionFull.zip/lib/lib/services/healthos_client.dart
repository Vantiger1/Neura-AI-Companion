import 'package:health/health.dart';

class HealthOSClient {
  final HealthFactory _health = HealthFactory();

  Future<List<HealthDataPoint>> getHeartRateSamples(Duration interval) async {
    final now = DateTime.now();
    final past = now.subtract(interval);
    bool requested = await _health.requestAuthorization([HealthDataType.HEART_RATE]);
    if (!requested) throw Exception('Authorization not granted');
    return _health.getHealthDataFromTypes(past, now, [HealthDataType.HEART_RATE]);
  }
}
