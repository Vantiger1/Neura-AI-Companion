import 'package:firebase_auth/firebase_auth.dart';

class AuthService {
  final FirebaseAuth _auth = FirebaseAuth.instance;

  Future<bool> checkEntitlement() async {
    final user = _auth.currentUser;
    if (user == null) return false;
    // entitlement logic
    return true;
  }

  Future<String> renewToken() async {
    return _auth.currentUser?.getIdToken(refresh: true) ?? '';
  }
}
