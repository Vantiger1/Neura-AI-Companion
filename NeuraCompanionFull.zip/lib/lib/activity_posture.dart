import 'package:sensors_plus/sensors_plus.dart';
import 'services/logger_service.dart';

class AccelEvent {
  final double x, y, z;
  final DateTime timestamp;

  AccelEvent(this.x, this.y, this.z) : timestamp = DateTime.now();
}

class SlouchDetector {
  bool detectSlouch(AccelEvent event) {
    // simple threshold
    return event.y.abs() > 1.2;
  }
}

class ActivityPosture {
  final SlouchDetector detector;

  ActivityPosture({required this.detector});

  void startMonitoring() {
    gyroscopeEvents.listen((e) {
      final event = AccelEvent(e.x, e.y, e.z);
      if (detector.detectSlouch(event)) {
        LoggerService.logInfo('Slouch detected');
        // send UI alert via provider or callback
      }
    });
  }

  void stopMonitoring() {
    // cancel subscription
  }
}
