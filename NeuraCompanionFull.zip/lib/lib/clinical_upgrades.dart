import 'services/logger_service.dart';

class Upgrade {
  final String id;
  final String description;
  bool applied;
  Upgrade(this.id, this.description, this.applied);
}

class ClinicalUpgrades {
  final List<Upgrade> available;

  ClinicalUpgrades(this.available);

  bool applyUpgrade(String id) {
    try {
      final up = available.firstWhere((u) => u.id == id);
      up.applied = true;
      LoggerService.logInfo('Applied upgrade: \$id');
      return true;
    } catch (e, st) {
      LoggerService.logError('Upgrade failed', e, st);
      return false;
    }
  }
}
