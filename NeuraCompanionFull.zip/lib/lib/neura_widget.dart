import 'package:flutter/widgets.dart';
import 'services/logger_service.dart';

class PersonaData {
  final String mood;
  final Map<String, dynamic> attributes;
  PersonaData(this.mood, this.attributes);
}

class NeuraWidget extends StatefulWidget {
  final PersonaData initialPersona;
  NeuraWidget({required this.initialPersona});

  @override
  _NeuraWidgetState createState() => _NeuraWidgetState();
}

class _NeuraWidgetState extends State<NeuraWidget> {
  late PersonaData _persona;

  @override
  void initState() {
    super.initState();
    _persona = widget.initialPersona;
  }

  void updatePersona(PersonaData data) {
    setState(() {
      _persona = data;
    });
    LoggerService.logInfo('Persona updated: \${data.mood}');
  }

  @override
  Widget build(BuildContext context) {
    return Text('Neura: \${_persona.mood}');
  }
}
