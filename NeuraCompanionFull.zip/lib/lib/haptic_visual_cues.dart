import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'services/logger_service.dart';

enum CueType { SLIDE, TAP, SHAKE }

class HapticVisualCues {
  Future<void> triggerPattern(CueType type) async {
    try {
      HapticFeedback.mediumImpact();
      LoggerService.logInfo('Haptic pattern: \$type');
      // visual overlay trigger via provider
    } catch (e, st) {
      LoggerService.logError('Haptic failed', e, st);
    }
  }
}
