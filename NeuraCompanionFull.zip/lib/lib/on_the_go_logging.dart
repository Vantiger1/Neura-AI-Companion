import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'services/logger_service.dart';

class OnTheGoLogging {
  final SpeechToText _recorder = SpeechToText();
  final FlutterTts _tts = FlutterTts();

  Future<void> startVoiceLog() async {
    try {
      if (await _recorder.initialize()) {
        await _recorder.listen(onResult: (r) => LoggerService.logInfo(r.recognizedWords));
      }
    } catch (e, st) {
      LoggerService.logError('Recording failed', e, st);
      rethrow;
    }
  }

  Future<String> stopVoiceLog() async {
    try {
      await _recorder.stop();
      // get last result
      return _recorder.lastRecognizedWords;
    } catch (e, st) {
      LoggerService.logError('Stop recording failed', e, st);
      rethrow;
    }
  }

  Future<void> playback(String text) async {
    try {
      await _tts.speak(text);
    } catch (e, st) {
      LoggerService.logError('TTS failed', e, st);
    }
  }
}
