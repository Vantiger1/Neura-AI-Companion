class Patient {
  final String id;
  final String name;
  final DateTime birthDate;
  final List<Observation> observations;

  Patient({
    required this.id,
    required this.name,
    required this.birthDate,
    required this.observations,
  });

  factory Patient.fromJson(Map<String, dynamic> json) {
    return Patient(
      id: json['id'] as String,
      name: json['name'] as String,
      birthDate: DateTime.parse(json['birthDate'] as String),
      observations: [], // TODO parse observations
    );
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'name': name,
        'birthDate': birthDate.toIso8601String(),
      };
}

class Observation {
  final String code;
  final double value;
  final DateTime timestamp;

  Observation({
    required this.code,
    required this.value,
    required this.timestamp,
  });
}
