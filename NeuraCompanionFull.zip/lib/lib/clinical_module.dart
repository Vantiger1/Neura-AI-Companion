import 'services/fhir_client.dart';
import 'services/auth_service.dart';
import 'services/cache_service.dart';
import 'services/logger_service.dart';
import 'models/patient.dart';

class ClinicalModule {
  final FhirClient fhirClient;
  final AuthService authService;
  final CacheService cache;

  ClinicalModule({
    required this.fhirClient,
    required this.authService,
    required this.cache,
  });

  Future<bool> purchaseSubscription() async {
    try {
      // implement in-app purchase
      LoggerService.logInfo('Subscription purchased');
      return true;
    } catch (e, st) {
      LoggerService.logError('Purchase failed', e, st);
      return false;
    }
  }

  Future<Patient> fetchPatient(String id) async {
    final cached = cache.get<Patient>(id);
    if (cached != null) return cached;
    try {
      final json = await fhirClient.getResource('/Patient/\$id');
      final patient = Patient.fromJson(json);
      await cache.set(id, patient);
      return patient;
    } catch (e, st) {
      LoggerService.logError('FetchPatient failed', e, st);
      rethrow;
    }
  }

  Future<void> initialize() async {
    if (!await authService.checkEntitlement()) {
      LoggerService.logError('Entitlement denied');
      throw Exception('User not entitled');
    }
    LoggerService.logInfo('ClinicalModule initialized');
  }
}
