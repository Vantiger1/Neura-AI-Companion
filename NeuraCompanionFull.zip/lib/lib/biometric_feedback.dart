import 'services/permissions_service.dart';
import 'services/healthos_client.dart';
import 'services/hrv_aggregator.dart';
import 'services/logger_service.dart';

class BiometricFeedback {
  final PermissionsService permService;
  final HealthOSClient osClient;
  final HRVAggregator aggregator;

  BiometricFeedback({
    required this.permService,
    required this.osClient,
    required this.aggregator,
  });

  Future<double> fetchHRV(Duration interval) async {
    if (!await permService.requestPermission(Permission.health)) {
      LoggerService.logError('Health permission denied');
      throw Exception('Permission denied');
    }
    try {
      final samples = await osClient.getHeartRateSamples(interval);
      final avg = aggregator.computeAverageHRV(samples);
      LoggerService.logInfo('HRV computed: \$avg');
      return avg;
    } catch (e, st) {
      LoggerService.logError('HRV fetch error', e, st);
      rethrow;
    }
  }
}
