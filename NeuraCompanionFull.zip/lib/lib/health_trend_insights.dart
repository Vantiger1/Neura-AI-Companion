import 'package:charts_flutter/flutter.dart' as charts;
import 'services/logger_service.dart';

class HealthData {
  final DateTime date;
  final double value;
  HealthData(this.date, this.value);
}

enum ChartType { LINE, BAR, HEATMAP }

class HealthTrendInsights {
  final List<HealthData> dataPoints;
  HealthTrendInsights(this.dataPoints);

  charts.Series<HealthData, DateTime> _createSeries() {
    return charts.Series<HealthData, DateTime>(
      id: 'Health',
      data: dataPoints,
      domainFn: (d, _) => d.date,
      measureFn: (d, _) => d.value,
    );
  }

  Widget buildChart(ChartType type) {
    try {
      LoggerService.logInfo('Building chart: \$type');
      return charts.TimeSeriesChart([_createSeries()]);
    } catch (e, st) {
      LoggerService.logError('Chart build failed', e, st);
      rethrow;
    }
  }
}
