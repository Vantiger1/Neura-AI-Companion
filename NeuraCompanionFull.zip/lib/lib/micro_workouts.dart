import 'dart:async';
import 'services/logger_service.dart';

class Exercise {
  final String name;
  final Duration duration;
  Exercise(this.name, this.duration);
}

class MicroWorkouts {
  final List<Exercise> exercises;
  late final StreamController<Exercise> _controller;
  Timer? _timer;
  int _index = 0;

  MicroWorkouts({required this.exercises}) {
    _controller = StreamController<Exercise>();
  }

  Stream<Exercise> get onExercise => _controller.stream;

  void startWorkout() {
    _index = 0;
    _startNext();
  }

  void _startNext() {
    if (_index >= exercises.length) {
      _controller.close();
      return;
    }
    final ex = exercises[_index++];
    LoggerService.logInfo('Starting exercise: \${ex.name}');
    _controller.add(ex);
    _timer = Timer(ex.duration, _startNext);
  }

  void pauseWorkout() {
    _timer?.cancel();
    LoggerService.logInfo('Workout paused');
  }
}
