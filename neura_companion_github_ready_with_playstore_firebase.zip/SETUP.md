# Neura Companion GitHub Setup

## Instructions to Push to GitHub

1. Unzip this folder
2. Navigate to the directory in terminal:
   ```bash
   cd neura_companion_github_ready
   ```
3. Initialize Git:
   ```bash
   git init
   git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO.git
   git add .
   git commit -m "Initial commit - Neura Companion Full App"
   git push -u origin main
   ```

Replace `YOUR_USERNAME` and `YOUR_REPO` with your GitHub info.

---

If you need help setting up GitHub secrets, CI, or deploy workflows, I can scaffold those next.
