# Neura Companion - Final Full App Package

## Overview

This package includes **every implemented module, AI system, and enhancement** completed so far:

### ✅ AI Core Enhancements
- AIQuantized local model runner (TFLite)
- Pinecone + OpenAI-based RAG system
- Caching for embeddings and responses
- Streaming OpenAI integration
- Online/offline detection fallback logic

### 😴 Dream & Sleep Modules
- Sleep listener
- Dream interpreter
- Dream journal entry model
- Journal screen UI
- Dream calendar navigator
- Dreamscape generator
- Monthly dream show replay & player

### 😂 Voice, Jokes & Expression
- Voice engine with mood tone modulation
- Joke panel with animated reactions
- Age-gated preferences and toggle logic
- Face animator with mood expression
- Expression evolution (weekly growth)

### 🧠 Memory & Behavior
- Neura manager with init routine
- Persistent memory model
- Settings manager with toggle/scheduler

### 🏥 Clinical API Integration (Pro)
- FHIR Observation + Patient sync
- Caching, queueing, flush, secure fallback
- Gated by in-app subscription

### 📦 Install Scripts
- `install_ai_optimizations.sh`
- `install_clinical_v4.sh`

---

## Integration Steps

1. Extract this archive into your Flutter project root.
2. Update `pubspec.yaml`:
   ```yaml
   dependencies:
     flutter:
       sdk: flutter
     hive: ^2.0.0
     flutter_secure_storage: ^8.0.0
     flutter_tts: ^3.5.0
     in_app_purchase: ^3.0.0
     connectivity_plus: ^2.0.2
     openai: ^1.0.0
     pinecone: ^0.1.0
     shared_preferences: ^2.0.0
   ```

3. Initialize in `main.dart`:
   ```dart
   void main() async {
     WidgetsFlutterBinding.ensureInitialized();
     await NeuraManager.init();
     runApp(MyApp());
   }
   ```

Let me know if you want Firebase, billing, analytics, or push notifications included next.
