# Firebase Setup for Neura Companion

1. Go to https://console.firebase.google.com and create a new project.
2. Add an Android app and use your package name (e.g., com.neuracomp.app).
3. Download `google-services.json` and place it in `android/app/`.
4. Add to your `android/build.gradle`:
   ```
   classpath 'com.google.gms:google-services:4.3.10'
   ```
5. In `android/app/build.gradle` add:
   ```
   apply plugin: 'com.google.gms.google-services'
   ```

## Enable these services:
- Firestore (for mood/journal sync)
- Firebase Auth (if login enabled)
- Firebase Storage (optional for media uploads)
