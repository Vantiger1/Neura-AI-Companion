# Flutter Project Placeholder

Place your existing Flutter project here. Then run the batch script to build the web assets and Android shell.
