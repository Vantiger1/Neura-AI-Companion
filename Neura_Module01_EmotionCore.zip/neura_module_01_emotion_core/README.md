# Neura Companion — Module 1: Emotion & Personality Core + Safety Guard

See integration steps inside.