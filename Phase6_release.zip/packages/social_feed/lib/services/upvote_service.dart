import 'package:hive/hive.dart';

class UpvoteService {
  final Box _box = Hive.box('upvotes');
  Future<void> upvote(String featureId) async {
    final count = (_box.get(featureId) ?? 0) + 1;
    await _box.put(featureId, count);
  }
}
