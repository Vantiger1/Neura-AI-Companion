import 'package:hive/hive.dart';

class FeedbackService {
  final Box _box = Hive.box('feedback');
  Future<void> submit(String comment, int rating) async {
    await _box.add({
      'comment': comment,
      'rating': rating,
      'time': DateTime.now().toIso8601String()
    });
  }
}
