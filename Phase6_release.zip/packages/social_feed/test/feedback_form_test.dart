// feedback form test stub
import 'package:flutter_test/flutter_test.dart';

void main() {
  test('FeedbackForm loads', () {
    expect(1, 1);
  });
}
