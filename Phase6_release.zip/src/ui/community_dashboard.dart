import 'package:flutter/material.dart';
import '../../packages/social_feed/lib/services/feedback_service.dart';
import '../../packages/social_feed/lib/services/upvote_service.dart';

class CommunityDashboard extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final feedbackList = []; // Fetch from service
    return ListView(
      children: feedbackList.map((f) => ListTile(
        title: Text(f['comment']),
        subtitle: Text('Rating: ${f['rating']}'),
        trailing: IconButton(icon: Icon(Icons.thumb_up),
          onPressed: () => UpvoteService().upvote(f['id'])),
      )).toList(),
    );
  }
}
