# Skill Pack 28 — Signed Action Plans (No Scope Drift)

## Problem solved
Even with approvals, a system can "drift" by changing arguments after the user consented.
This patch binds approval to an immutable, signed plan hash.

## What you get
- Signed plans (HMAC-SHA256 over planHash)
- Encrypted plan store: `neura_plans.encdb`
- One-call flow: `plan_create_and_request_approval`
- Drift-proof execution: `plan_execute_from_request` executes plan.args ONLY

## New actions
- `plan_create_signed`
- `plan_list`
- `plan_create_and_request_approval`
- `plan_execute_from_request`

## Storage
- Encrypted at rest using Step 26 `NeuraEncryptedJsonStore`
- Signing key stored in secure storage (Android Keystore / Windows DPAPI)

## Integration
1) Ensure Step 26 is wired (persisted approvals + audit log).
2) Register this bootstrap after Step 26 bootstraps:

```dart
await NeuraActionPlanBootstrap.register(
  registry: NeuraKernel.I.registry,
  executor: NeuraKernel.I.executor,
  approvals: approvalsStoreInstance, // the same approvals store used by Step 26
  audit: auditLogStoreInstance,      // the same audit store used by Step 26
);
```

## Execution flow
1) Create plan + request approval (includes checklist + typed phrase):
   - `plan_create_and_request_approval`
2) User approves: `policy_decide_persisted`
3) Execute exactly what was approved: `plan_execute_from_request`
   - If hashes mismatch -> blocked

## Next
Step 29: Local model safety rails (capability gating by model class + strict temp caps).
