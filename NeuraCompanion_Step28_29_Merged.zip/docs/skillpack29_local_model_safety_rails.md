# Skill Pack 29 — Local Model Safety Rails (Offline)

## What this adds
- Model profiles (Tiny/Base/Pro) with capability flags
- Hard caps on temperature and max tokens
- Extra tightening for medical/legal/financial outputs
- Offline enforcement (web search disabled)
- Audit events for sanitized/blocked requests (Step 26 audit log)

## Integration
1) Init at boot (after Step 26 audit + policy exist):
```dart
final guard = await NeuraModelSafetyBootstrap.initAndRegister(
  registry: NeuraKernel.I.registry,
  audit: auditLogStoreInstance,
  policy: NeuraPolicyEngine(registry: NeuraKernel.I.registry),
);
```

2) Wrap local model runtime:
```dart
final runtime = NeuraModelRuntimeGuarded(
  guard: guard,
  runner: MyLocalRunner(),
);
final res = await runtime.runGuarded(
  NeuraModelRunRequest(
    prompt: '...',
    temperature: 0.9,
    maxTokens: 1024,
    tags: ['codegen'],
  ),
);
```

## Optional actions
- model_profiles_list
- model_profile_set_active
