import '../audit/neura_encrypted_json_store.dart';
import 'neura_model_profiles.dart';
import 'neura_model_profile.dart';

class NeuraModelSafetyStore {
  final NeuraEncryptedJsonStore store;

  NeuraModelSafetyStore(this.store);

  Future<Map<String, dynamic>> _load() => store.readJson(fallback: {
        'activeProfileId': NeuraModelProfiles.tiny.id,
        'profiles': NeuraModelProfiles.all.map((p) => p.toJson()).toList(),
      });

  Future<void> _save(Map<String, dynamic> obj) => store.writeJson(obj);

  Future<String> getActiveProfileId() async {
    final obj = await _load();
    return (obj['activeProfileId'] as String?) ?? NeuraModelProfiles.tiny.id;
  }

  Future<void> setActiveProfileId(String id) async {
    final obj = await _load();
    obj['activeProfileId'] = id;
    await _save(obj);
  }

  Future<List<NeuraModelProfile>> listProfiles() async {
    final obj = await _load();
    final raw = (obj['profiles'] as List?) ?? const [];
    return raw
        .whereType<Map>()
        .map((m) => NeuraModelProfile.fromJson(m.cast<String, dynamic>()))
        .toList();
  }

  Future<NeuraModelProfile> getActiveProfile() async {
    final id = await getActiveProfileId();
    final profiles = await listProfiles();
    return profiles.firstWhere((p) => p.id == id, orElse: () => NeuraModelProfiles.tiny);
  }
}
