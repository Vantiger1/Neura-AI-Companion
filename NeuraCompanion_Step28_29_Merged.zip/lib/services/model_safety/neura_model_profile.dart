enum NeuraModelClass {
  tiny,
  base,
  pro,
}

class NeuraModelProfile {
  final String id;
  final String displayName;
  final NeuraModelClass modelClass;
  final double maxTemperature;
  final int maxTokens;
  final bool allowSystemAutomation;
  final bool allowPersonalData;
  final bool allowWebSearch;
  final bool allowCodeGenHighRisk;

  const NeuraModelProfile({
    required this.id,
    required this.displayName,
    required this.modelClass,
    required this.maxTemperature,
    required this.maxTokens,
    required this.allowSystemAutomation,
    required this.allowPersonalData,
    required this.allowWebSearch,
    required this.allowCodeGenHighRisk,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'displayName': displayName,
        'modelClass': modelClass.name,
        'maxTemperature': maxTemperature,
        'maxTokens': maxTokens,
        'allowSystemAutomation': allowSystemAutomation,
        'allowPersonalData': allowPersonalData,
        'allowWebSearch': allowWebSearch,
        'allowCodeGenHighRisk': allowCodeGenHighRisk,
      };

  static NeuraModelProfile fromJson(Map<String, dynamic> j) => NeuraModelProfile(
        id: j['id'] as String,
        displayName: j['displayName'] as String,
        modelClass: NeuraModelClass.values.firstWhere((e) => e.name == j['modelClass']),
        maxTemperature: (j['maxTemperature'] as num).toDouble(),
        maxTokens: (j['maxTokens'] as num).toInt(),
        allowSystemAutomation: (j['allowSystemAutomation'] as bool?) ?? false,
        allowPersonalData: (j['allowPersonalData'] as bool?) ?? false,
        allowWebSearch: (j['allowWebSearch'] as bool?) ?? false,
        allowCodeGenHighRisk: (j['allowCodeGenHighRisk'] as bool?) ?? false,
      );
}
