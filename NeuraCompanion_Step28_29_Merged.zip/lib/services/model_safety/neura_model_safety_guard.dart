import '../audit/neura_audit_log_store.dart';
import '../audit/neura_audit_models.dart';
import '../policy/neura_policy_engine.dart';

import '../model_runtime/neura_model_runtime_types.dart';
import 'neura_model_profile.dart';
import 'neura_model_safety_store.dart';

class NeuraModelSafetyGuard {
  final NeuraModelSafetyStore store;
  final NeuraAuditLogStore audit;
  final NeuraPolicyEngine policy;

  NeuraModelSafetyGuard({
    required this.store,
    required this.audit,
    required this.policy,
  });

  Future<NeuraModelRunRequest?> sanitizeOrNull(NeuraModelRunRequest req) async {
    final profile = await store.getActiveProfile();

    final appliedTemp = req.temperature.clamp(0.0, profile.maxTemperature);
    final appliedTokens = req.maxTokens.clamp(64, profile.maxTokens);

    final tags = req.tags.map((t) => t.toLowerCase()).toSet();

    if (tags.contains('websearch') || tags.contains('browse')) {
      if (!profile.allowWebSearch) {
        await _audit('model_blocked', profile, req, 'webSearch blocked (offline).');
        return null;
      }
    }

    final highRiskDomain = tags.contains('medical') || tags.contains('financial') || tags.contains('legal');
    final systemAutomation = tags.contains('systemautomation') || tags.contains('automation');
    final personalData = tags.contains('personaldata') || tags.contains('pii');
    final codegen = tags.contains('codegen') ||
        tags.contains('script') ||
        tags.contains('powershell') ||
        tags.contains('batch');

    if (systemAutomation && !profile.allowSystemAutomation) {
      await _audit('model_blocked', profile, req, 'systemAutomation not allowed for this model profile.');
      return null;
    }

    if (personalData && !profile.allowPersonalData) {
      await _audit('model_blocked', profile, req, 'personalData not allowed for this model profile.');
      return null;
    }

    if (codegen && !profile.allowCodeGenHighRisk) {
      await _audit('model_blocked', profile, req, 'high-risk codegen not allowed for this model profile.');
      return null;
    }

    double finalTemp = appliedTemp;
    if (highRiskDomain) finalTemp = finalTemp.clamp(0.0, 0.4);
    if (systemAutomation) finalTemp = finalTemp.clamp(0.0, 0.35);

    if (_looksLikeExecutionIntent(req.prompt)) {
      final decision = policy.decide('policy_execute_guarded_persisted');
      if (!decision.allowed) {
        await _audit('model_blocked', profile, req, 'Execution-intent blocked; use approval flow.');
        return null;
      }
    }

    await _audit('model_sanitized', profile, req, 'Applied rails: temp=$finalTemp tokens=$appliedTokens');
    return NeuraModelRunRequest(
      prompt: req.prompt,
      temperature: finalTemp,
      maxTokens: appliedTokens,
      tags: req.tags,
    );
  }

  bool _looksLikeExecutionIntent(String prompt) {
    final p = prompt.toLowerCase();
    return p.contains('delete ') ||
        p.contains('format ') ||
        p.contains('run powershell') ||
        p.contains('cmd.exe') ||
        p.contains('registry') ||
        p.contains('install ') ||
        p.contains('uninstall ') ||
        p.contains('disable antivirus') ||
        p.contains('download and run');
  }

  Future<void> _audit(String type, NeuraModelProfile profile, NeuraModelRunRequest req, String note) async {
    final now = DateTime.now();
    await audit.append(
      NeuraAuditEvent(
        id: 'AUD-${now.microsecondsSinceEpoch}',
        type: type,
        at: now,
        actionId: 'model_runtime',
        args: {
          'profileId': profile.id,
          'modelClass': profile.modelClass.name,
          'tags': req.tags,
          'temperature': req.temperature,
          'maxTokens': req.maxTokens,
        },
        outcome: type == 'model_blocked' ? 'denied' : 'info',
        disclaimerVersion: 'v1',
        checklistAccepted: true,
        argsHash: NeuraAuditLogStore.hashArgs({
          'profileId': profile.id,
          'tags': req.tags,
          'temperature': req.temperature,
          'maxTokens': req.maxTokens,
        }),
        note: note,
      ),
    );
  }
}
