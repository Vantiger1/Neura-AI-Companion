import 'neura_model_profile.dart';

class NeuraModelProfiles {
  static const NeuraModelProfile tiny = NeuraModelProfile(
    id: 'tiny_safe',
    displayName: 'Tiny (Safe)',
    modelClass: NeuraModelClass.tiny,
    maxTemperature: 0.6,
    maxTokens: 512,
    allowSystemAutomation: false,
    allowPersonalData: false,
    allowWebSearch: false,
    allowCodeGenHighRisk: false,
  );

  static const NeuraModelProfile base = NeuraModelProfile(
    id: 'base_balanced',
    displayName: 'Base (Balanced)',
    modelClass: NeuraModelClass.base,
    maxTemperature: 0.8,
    maxTokens: 1024,
    allowSystemAutomation: false,
    allowPersonalData: true,
    allowWebSearch: false,
    allowCodeGenHighRisk: false,
  );

  static const NeuraModelProfile pro = NeuraModelProfile(
    id: 'pro_power',
    displayName: 'Pro (Power)',
    modelClass: NeuraModelClass.pro,
    maxTemperature: 0.9,
    maxTokens: 2048,
    allowSystemAutomation: true,
    allowPersonalData: true,
    allowWebSearch: false,
    allowCodeGenHighRisk: true,
  );

  static const List<NeuraModelProfile> all = [tiny, base, pro];
}
