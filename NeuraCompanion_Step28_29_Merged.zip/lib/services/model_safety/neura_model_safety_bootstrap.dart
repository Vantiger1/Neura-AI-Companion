import '../audit/neura_key_provider.dart';
import '../audit/neura_encrypted_json_store.dart';
import '../audit/neura_audit_log_store.dart';
import '../policy/neura_policy_engine.dart';
import '../neura_action_bus/action_registry.dart';

import 'neura_model_safety_actions.dart';
import 'neura_model_safety_guard.dart';
import 'neura_model_safety_store.dart';

class NeuraModelSafetyBootstrap {
  static Future<NeuraModelSafetyGuard> initAndRegister({
    required NeuraActionRegistry registry,
    required NeuraAuditLogStore audit,
    required NeuraPolicyEngine policy,
  }) async {
    final keyProvider = NeuraKeyProvider();
    final encStore = NeuraEncryptedJsonStore(
      fileName: 'neura_model_profiles.encdb',
      keyProvider: keyProvider,
    );

    final store = NeuraModelSafetyStore(encStore);
    NeuraModelSafetyActions(store).registerAll(registry);

    return NeuraModelSafetyGuard(store: store, audit: audit, policy: policy);
  }
}
