import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import 'neura_model_safety_store.dart';

class NeuraModelSafetyActions {
  final NeuraModelSafetyStore store;
  NeuraModelSafetyActions(this.store);

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'model_profiles_list',
        title: 'List Model Profiles',
        description: 'Lists available local model safety profiles.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final profiles = (await store.listProfiles()).map((p) => p.toJson()).toList();
          final active = await store.getActiveProfileId();
          return NeuraActionResult.success('OK', data: {'activeProfileId': active, 'profiles': profiles});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'model_profile_set_active',
        title: 'Set Active Model Profile',
        description: 'Switch active model safety profile (tiny/base/pro).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.settings,
        handler: (req) async {
          final id = (req.args['profileId'] as String?)?.trim() ?? '';
          if (id.isEmpty) return NeuraActionResult.error('Missing profileId');
          await store.setActiveProfileId(id);
          return NeuraActionResult.success('OK', data: {'activeProfileId': id});
        },
      ),
    );
  }
}
