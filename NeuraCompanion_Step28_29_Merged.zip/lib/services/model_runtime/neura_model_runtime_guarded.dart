import '../model_safety/neura_model_safety_guard.dart';
import 'neura_model_runtime_types.dart';

abstract class NeuraLocalModelRunner {
  Future<NeuraModelRunResult> run(NeuraModelRunRequest req);
}

class NeuraModelRuntimeGuarded {
  final NeuraModelSafetyGuard guard;
  final NeuraLocalModelRunner runner;

  NeuraModelRuntimeGuarded({
    required this.guard,
    required this.runner,
  });

  Future<NeuraModelRunResult> runGuarded(NeuraModelRunRequest req) async {
    final sanitized = await guard.sanitizeOrNull(req);
    if (sanitized == null) {
      return const NeuraModelRunResult(
        ok: false,
        text: '',
        message: 'Blocked by model safety rails. Route risky operations through approvals/actions.',
        appliedTemperature: 0,
        appliedMaxTokens: 0,
      );
    }
    final res = await runner.run(sanitized);
    return NeuraModelRunResult(
      ok: res.ok,
      text: res.text,
      message: res.message,
      appliedTemperature: sanitized.temperature,
      appliedMaxTokens: sanitized.maxTokens,
    );
  }
}
