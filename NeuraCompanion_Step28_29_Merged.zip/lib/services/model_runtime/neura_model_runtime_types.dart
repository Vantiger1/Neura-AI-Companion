class NeuraModelRunRequest {
  final String prompt;
  final double temperature;
  final int maxTokens;
  final List<String> tags;

  const NeuraModelRunRequest({
    required this.prompt,
    required this.temperature,
    required this.maxTokens,
    this.tags = const [],
  });

  Map<String, dynamic> toJson() => {
        'prompt': prompt,
        'temperature': temperature,
        'maxTokens': maxTokens,
        'tags': tags,
      };
}

class NeuraModelRunResult {
  final bool ok;
  final String text;
  final String message;
  final double appliedTemperature;
  final int appliedMaxTokens;

  const NeuraModelRunResult({
    required this.ok,
    required this.text,
    required this.message,
    required this.appliedTemperature,
    required this.appliedMaxTokens,
  });

  Map<String, dynamic> toJson() => {
        'ok': ok,
        'text': text,
        'message': message,
        'appliedTemperature': appliedTemperature,
        'appliedMaxTokens': appliedMaxTokens,
      };
}
