\
import 'dart:convert';
import 'dart:typed_data';

import 'package:crypto/crypto.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// Lightweight offline plan signing using HMAC-SHA256.
/// This prevents "scope drift": if args change, planHash changes, signature fails.
class NeuraActionPlanSigner {
  static const _storage = FlutterSecureStorage();
  static const _keyName = 'neura_plan_signing_key_b64';

  Future<Uint8List> _getOrCreateKey() async {
    final existing = await _storage.read(key: _keyName);
    if (existing != null && existing.isNotEmpty) {
      return base64Decode(existing);
    }

    // 32-byte HMAC key stored in secure storage.
    final bytes = Uint8List.fromList(
      List<int>.generate(32, (i) => (DateTime.now().microsecondsSinceEpoch >> (i % 8)) & 0xFF),
    );
    for (int i = 0; i < bytes.length; i++) {
      bytes[i] = (bytes[i] ^ (i * 17) ^ (DateTime.now().millisecondsSinceEpoch & 0xFF)) & 0xFF;
    }

    await _storage.write(key: _keyName, value: base64Encode(bytes));
    return bytes;
  }

  Future<String> signHash(String planHash) async {
    final key = await _getOrCreateKey();
    final h = Hmac(sha256, key);
    final sig = h.convert(utf8.encode(planHash)).bytes;
    return base64Encode(sig);
  }

  Future<bool> verify(String planHash, String signatureB64) async {
    final expected = await signHash(planHash);
    // constant-time compare
    final a = base64Decode(expected);
    final b = base64Decode(signatureB64);
    if (a.length != b.length) return false;
    int diff = 0;
    for (int i = 0; i < a.length; i++) {
      diff |= (a[i] ^ b[i]);
    }
    return diff == 0;
  }
}
