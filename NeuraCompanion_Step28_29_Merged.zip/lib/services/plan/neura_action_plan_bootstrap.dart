\
import '../neura_action_bus/action_executor.dart';
import '../neura_action_bus/action_registry.dart';

import '../audit/neura_key_provider.dart';
import '../audit/neura_encrypted_json_store.dart';
import '../audit/neura_audit_log_store.dart';

import '../policy/neura_policy_engine.dart';
import '../policy/neura_persistent_approval_store.dart';

import 'neura_action_plan_actions.dart';
import 'neura_action_plan_signer.dart';
import 'neura_action_plan_store.dart';

class NeuraActionPlanBootstrap {
  static Future<void> register({
    required NeuraActionRegistry registry,
    required NeuraActionExecutor executor,
    required NeuraPersistentApprovalStore approvals,
    required NeuraAuditLogStore audit,
  }) async {
    // Reuse the same key provider class for encrypted stores (Step 26).
    final keyProvider = NeuraKeyProvider();

    final plansEnc = NeuraEncryptedJsonStore(
      fileName: 'neura_plans.encdb',
      keyProvider: keyProvider,
    );

    final plans = NeuraActionPlanStore(plansEnc);
    final signer = NeuraActionPlanSigner();
    final policy = NeuraPolicyEngine(registry: registry);

    NeuraActionPlanActions(
      plans: plans,
      signer: signer,
      policy: policy,
      approvals: approvals,
      audit: audit,
      executor: executor,
    ).registerAll(registry);
  }
}
