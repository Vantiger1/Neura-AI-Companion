\
import '../neura_action_bus/action_executor.dart';
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';

import '../audit/neura_audit_log_store.dart';
import '../audit/neura_audit_models.dart';

import '../policy/neura_persistent_approval_store.dart';
import '../policy/neura_policy_engine.dart';

import 'neura_action_plan_hash.dart';
import 'neura_action_plan_models.dart';
import 'neura_action_plan_signer.dart';
import 'neura_action_plan_store.dart';

class NeuraActionPlanActions {
  final NeuraActionPlanStore plans;
  final NeuraActionPlanSigner signer;
  final NeuraPolicyEngine policy;
  final NeuraPersistentApprovalStore approvals;
  final NeuraAuditLogStore audit;
  final NeuraActionExecutor executor;

  NeuraActionPlanActions({
    required this.plans,
    required this.signer,
    required this.policy,
    required this.approvals,
    required this.audit,
    required this.executor,
  });

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'plan_create_signed',
        title: 'Create Signed Action Plan',
        description: 'Creates a signed plan hash (no scope drift).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final actionId = (req.args['actionId'] as String?)?.trim() ?? '';
          final args = (req.args['args'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
          final intent = (req.args['intent'] as String?)?.trim() ?? '';

          final ttlSeconds = (req.args['ttlSeconds'] as int?) ?? 600;
          final now = DateTime.now();
          final expiresAt = now.add(Duration(seconds: ttlSeconds.clamp(60, 3600)));

          if (actionId.isEmpty) return NeuraActionResult.error('Missing actionId');

          final d = policy.decide(actionId);
          if (!d.allowed) return NeuraActionResult.error('Unknown actionId');

          final payload = <String, dynamic>{
            'actionId': actionId,
            'args': args,
            'intent': intent,
            'createdAt': now.toIso8601String(),
            'expiresAt': expiresAt.toIso8601String(),
          };
          final planHash = NeuraActionPlanHash.hashPlanPayload(payload);
          final sig = await signer.signHash(planHash);

          final id = 'PLAN-${now.microsecondsSinceEpoch}';
          final plan = NeuraActionPlan(
            id: id,
            actionId: actionId,
            args: args,
            intent: intent,
            planHash: planHash,
            signatureB64: sig,
            createdAt: now,
            expiresAt: expiresAt,
          );

          await plans.upsert(plan);

          await audit.append(NeuraAuditEvent(
            id: 'AUD-${now.microsecondsSinceEpoch}',
            type: 'plan_created',
            at: now,
            actionId: actionId,
            args: {'planId': id, 'planHash': planHash},
            outcome: 'info',
            disclaimerVersion: 'v1',
            checklistAccepted: true,
            argsHash: NeuraAuditLogStore.hashArgs({'planId': id, 'planHash': planHash}),
            note: 'Signed plan created (HMAC)',
          ));

          return NeuraActionResult.success('Plan created', data: plan.toJson());
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'plan_create_and_request_approval',
        title: 'Create Plan + Request Approval',
        description: 'Creates signed plan then requests persisted approval bound to planHash.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final actionId = (req.args['actionId'] as String?)?.trim() ?? '';
          final args = (req.args['args'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
          final intent = (req.args['intent'] as String?)?.trim() ?? '';
          final reason = (req.args['reason'] as String?)?.trim() ?? 'User approval required';

          final ttlSeconds = (req.args['ttlSeconds'] as int?) ?? 300;

          final checklistAccepted = (req.args['checklistAccepted'] as bool?) ?? false;
          final disclaimerVersion = (req.args['disclaimerVersion'] as String?)?.trim() ?? 'v1';
          final userTypedPhrase = (req.args['userTypedPhrase'] as String?)?.trim() ?? '';

          final undoActionId = (req.args['undoActionId'] as String?)?.trim();
          final undoArgs = (req.args['undoArgs'] as Map?)?.cast<String, dynamic>();

          // Create plan
          final now = DateTime.now();
          final expiresAt = now.add(Duration(seconds: ttlSeconds.clamp(60, 1800)));

          if (actionId.isEmpty) return NeuraActionResult.error('Missing actionId');
          final d = policy.decide(actionId);
          if (!d.allowed) return NeuraActionResult.error('Unknown actionId');

          final payload = <String, dynamic>{
            'actionId': actionId,
            'args': args,
            'intent': intent,
            'createdAt': now.toIso8601String(),
            'expiresAt': expiresAt.toIso8601String(),
          };
          final planHash = NeuraActionPlanHash.hashPlanPayload(payload);
          final sig = await signer.signHash(planHash);
          final planId = 'PLAN-${now.microsecondsSinceEpoch}';

          final plan = NeuraActionPlan(
            id: planId,
            actionId: actionId,
            args: args,
            intent: intent,
            planHash: planHash,
            signatureB64: sig,
            createdAt: now,
            expiresAt: expiresAt,
          );
          await plans.upsert(plan);

          // Request persisted approval, embedding plan binding in args meta.
          final approvalRes = await executor.execute('policy_request_approval_persisted', args: {
            'actionId': actionId,
            'args': {
              ...args,
              '__plan': {'planId': planId, 'planHash': planHash, 'sigB64': sig},
            },
            'reason': reason,
            'ttlSeconds': ttlSeconds,
            'checklistAccepted': checklistAccepted,
            'disclaimerVersion': disclaimerVersion,
            'userTypedPhrase': userTypedPhrase,
            if (undoActionId != null) 'undoActionId': undoActionId,
            if (undoArgs != null) 'undoArgs': undoArgs,
          });

          if (!approvalRes.ok) {
            return NeuraActionResult.error('Approval request failed: ${approvalRes.message}');
          }

          final reqJson = (approvalRes.data as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
          final requestId = (reqJson['id'] ?? '').toString();

          final boundPlan = NeuraActionPlan(
            id: plan.id,
            actionId: plan.actionId,
            args: plan.args,
            intent: plan.intent,
            planHash: plan.planHash,
            signatureB64: plan.signatureB64,
            createdAt: plan.createdAt,
            expiresAt: plan.expiresAt,
            boundRequestId: requestId.isEmpty ? null : requestId,
          );
          await plans.upsert(boundPlan);

          await audit.append(NeuraAuditEvent(
            id: 'AUD-${DateTime.now().microsecondsSinceEpoch}',
            type: 'plan_bound',
            at: DateTime.now(),
            actionId: actionId,
            args: {'planId': planId, 'requestId': requestId, 'planHash': planHash},
            outcome: 'info',
            disclaimerVersion: disclaimerVersion,
            checklistAccepted: checklistAccepted,
            argsHash: NeuraAuditLogStore.hashArgs({'planId': planId, 'requestId': requestId, 'planHash': planHash}),
            note: 'Plan bound to approval request',
          ));

          return NeuraActionResult.success('Plan + approval requested', data: {
            'plan': boundPlan.toJson(),
            'approvalRequest': reqJson,
          });
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'plan_execute_from_request',
        title: 'Execute Approved Plan (No Drift)',
        description:
            'Executes the exact plan args that were approved; rejects drift; logs audit outcome.',
        risk: NeuraRisk.high,
        capability: NeuraCapability.systemAutomation,
        handler: (req) async {
          final requestId = (req.args['requestId'] as String?)?.trim() ?? '';
          if (requestId.isEmpty) return NeuraActionResult.error('Missing requestId');

          // Ensure decision exists and approved (persisted approvals).
          final decision = await approvals.getDecision(requestId);
          if (decision == null || !decision.approved) {
            return NeuraActionResult.error('Not approved or expired.');
          }

          // Find matching plan by scanning store (MVP).
          final list = await plans.list(limit: 10000);
          NeuraActionPlan? plan;
          for (final p in list) {
            if (p.boundRequestId == requestId) {
              plan = p;
              break;
            }
          }
          if (plan == null) return NeuraActionResult.error('No plan bound to this requestId.');
          if (plan.expired) return NeuraActionResult.error('Plan expired.');

          // Verify signature (tamper detection)
          final okSig = await signer.verify(plan.planHash, plan.signatureB64);
          if (!okSig) return NeuraActionResult.error('Plan signature invalid. Possible tamper.');

          // Load original request to validate stored plan binding matches args.
          final pending = await approvals.getPending(requestId);
          if (pending == null) {
            // Might be moved out of pending; still, args integrity should come from stored __plan meta.
          } else {
            final reqArgs = pending.args;
            final meta = (reqArgs['__plan'] as Map?)?.cast<String, dynamic>();
            final reqPlanHash = meta?['planHash']?.toString() ?? '';
            if (reqPlanHash.isNotEmpty && reqPlanHash != plan.planHash) {
              return NeuraActionResult.error('Plan hash mismatch vs approval request (drift).');
            }
          }

          // Execute the action using plan.args ONLY (no drift).
          final d = policy.decide(plan.actionId);
          if (!d.allowed) return NeuraActionResult.error('Unknown action in plan.');

          final res = await executor.execute(plan.actionId, args: plan.args);

          final now = DateTime.now();
          await audit.append(NeuraAuditEvent(
            id: 'AUD-${now.microsecondsSinceEpoch}',
            type: 'plan_executed',
            at: now,
            actionId: plan.actionId,
            args: {'planId': plan.id, 'requestId': requestId, 'planHash': plan.planHash},
            outcome: res.ok ? 'ok' : 'failed',
            disclaimerVersion: 'v1',
            checklistAccepted: true,
            argsHash: NeuraAuditLogStore.hashArgs({'planId': plan.id, 'requestId': requestId, 'planHash': plan.planHash}),
            note: res.ok ? 'Executed (no drift)' : 'Failed: ${res.message}',
          ));

          if (!res.ok) return NeuraActionResult.error('Execution failed: ${res.message}');
          return NeuraActionResult.success('Executed', data: {'result': res.data, 'plan': plan.toJson()});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'plan_list',
        title: 'List Action Plans',
        description: 'Lists recent signed plans (encrypted local store).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final limit = (req.args['limit'] as int?) ?? 200;
          final list = (await plans.list(limit: limit)).map((p) => p.toJson()).toList();
          return NeuraActionResult.success('OK', data: {'plans': list});
        },
      ),
    );
  }
}
