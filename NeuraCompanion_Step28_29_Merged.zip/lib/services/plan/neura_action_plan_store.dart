\
import '../audit/neura_encrypted_json_store.dart';
import 'neura_action_plan_models.dart';

class NeuraActionPlanStore {
  final NeuraEncryptedJsonStore store;

  NeuraActionPlanStore(this.store);

  Future<Map<String, dynamic>> _load() => store.readJson(fallback: {'plans': []});

  Future<void> _save(Map<String, dynamic> obj) => store.writeJson(obj);

  Future<List<NeuraActionPlan>> list({int limit = 200}) async {
    final obj = await _load();
    final raw = (obj['plans'] as List?) ?? const [];
    final plans = raw
        .whereType<Map>()
        .map((e) => NeuraActionPlan.fromJson(e.cast<String, dynamic>()))
        .toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
    return plans.take(limit).toList();
  }

  Future<NeuraActionPlan?> getById(String id) async {
    final plans = await list(limit: 10000);
    for (final p in plans) {
      if (p.id == id) return p;
    }
    return null;
  }

  Future<void> upsert(NeuraActionPlan plan) async {
    final obj = await _load();
    final list = (obj['plans'] as List?)?.cast<Map<String, dynamic>>() ?? <Map<String, dynamic>>[];
    final idx = list.indexWhere((e) => e['id'] == plan.id);
    if (idx >= 0) {
      list[idx] = plan.toJson();
    } else {
      list.add(plan.toJson());
    }
    obj['plans'] = list;
    await _save(obj);
  }
}
