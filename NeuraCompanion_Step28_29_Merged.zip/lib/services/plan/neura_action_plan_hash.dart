\
import 'dart:convert';
import 'package:crypto/crypto.dart';

class NeuraActionPlanHash {
  /// Canonical hash (sha256) of a plan payload.
  static String hashPlanPayload(Map<String, dynamic> payload) {
    final canonical = jsonEncode(_sortJson(payload));
    return sha256.convert(utf8.encode(canonical)).toString();
  }

  static Object _sortJson(Object v) {
    if (v is Map) {
      final keys = v.keys.map((k) => k.toString()).toList()..sort();
      final out = <String, dynamic>{};
      for (final k in keys) {
        out[k] = _sortJson(v[k]);
      }
      return out;
    }
    if (v is List) return v.map(_sortJson).toList();
    return v;
  }
}
