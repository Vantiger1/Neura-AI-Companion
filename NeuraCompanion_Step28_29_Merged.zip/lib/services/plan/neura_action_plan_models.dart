\
class NeuraActionPlan {
  final String id;
  final String actionId;
  final Map<String, dynamic> args;

  /// Human-facing intent (optional)
  final String intent;

  /// sha256 canonical hash of {actionId,args,intent,createdAt,expiresAt}
  final String planHash;

  /// HMAC signature over planHash
  final String signatureB64;

  final DateTime createdAt;
  final DateTime expiresAt;

  /// Optional: approval request id bound to this plan
  final String? boundRequestId;

  NeuraActionPlan({
    required this.id,
    required this.actionId,
    required this.args,
    required this.intent,
    required this.planHash,
    required this.signatureB64,
    required this.createdAt,
    required this.expiresAt,
    this.boundRequestId,
  });

  bool get expired => DateTime.now().isAfter(expiresAt);

  Map<String, dynamic> toJson() => {
        'id': id,
        'actionId': actionId,
        'args': args,
        'intent': intent,
        'planHash': planHash,
        'signatureB64': signatureB64,
        'createdAt': createdAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
        if (boundRequestId != null) 'boundRequestId': boundRequestId,
      };

  static NeuraActionPlan fromJson(Map<String, dynamic> j) => NeuraActionPlan(
        id: j['id'] as String,
        actionId: j['actionId'] as String,
        args: (j['args'] as Map).cast<String, dynamic>(),
        intent: (j['intent'] as String?) ?? '',
        planHash: (j['planHash'] as String?) ?? '',
        signatureB64: (j['signatureB64'] as String?) ?? '',
        createdAt: DateTime.parse(j['createdAt'] as String),
        expiresAt: DateTime.parse(j['expiresAt'] as String),
        boundRequestId: j['boundRequestId'] as String?,
      );
}
