import '../models/emotion_node.dart';
import '../models/emotion_edge.dart';

class MemoryGraphService {
  final List<EmotionNode> nodes = [];
  final List<EmotionEdge> edges = [];

  void addNode(EmotionNode node) {
    nodes.add(node);
  }

  void addEdge(String fromId, String toId, String reason) {
    edges.add(EmotionEdge(fromId: fromId, toId: toId, reason: reason));
  }

  List<EmotionNode> getConnections(String nodeId) {
    final connectedIds = edges
        .where((e) => e.fromId == nodeId || e.toId == nodeId)
        .map((e) => e.fromId == nodeId ? e.toId : e.fromId)
        .toSet();
    return nodes.where((n) => connectedIds.contains(n.id)).toList();
  }
}
