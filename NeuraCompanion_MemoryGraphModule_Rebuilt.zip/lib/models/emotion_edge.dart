import 'package:flutter/foundation.dart';

@immutable
class EmotionEdge {
  final String fromId;
  final String toId;
  final String reason; // why connected: "same mood", "same day", etc.

  const EmotionEdge({
    required this.fromId,
    required this.toId,
    required this.reason,
  });
}
