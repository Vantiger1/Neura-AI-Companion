import 'package:flutter/foundation.dart';

@immutable
class EmotionNode {
  final String id;
  final String label;
  final String category; // mood, dream, journal
  final DateTime timestamp;

  const EmotionNode({
    required this.id,
    required this.label,
    required this.category,
    required this.timestamp,
  });
}
