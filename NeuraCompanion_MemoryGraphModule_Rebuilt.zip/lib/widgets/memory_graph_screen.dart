import 'package:flutter/material.dart';
import '../services/memory_graph_service.dart';

class MemoryGraphScreen extends StatelessWidget {
  final MemoryGraphService graph;

  const MemoryGraphScreen({required this.graph});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Neura Memory Graph')),
      body: ListView(
        padding: EdgeInsets.all(12),
        children: graph.nodes.map((node) {
          final links = graph.getConnections(node.id);
          return Card(
            child: ListTile(
              title: Text(node.label),
              subtitle: Text('${node.category} • Connected to: ${links.map((e) => e.label).join(", ")}'),
            ),
          );
        }).toList(),
      ),
    );
  }
}
