#!/bin/bash
flutter test --coverage
