# Neura Lottie Animation Bundle

Includes:
- wave_smile_hello.json
- idle_breathing_glow.json
- peace_sign_cheer.json
- celebrate_raise_arms.json
- listening_mode_ear_glow.json
- sad_reflective_look.json
- hug_open_arms.json
- sleep_curl_mode.json
- surprised_blink.json
- smirk_sideways.json
- hopeful_eyes.json
- skeptical_look.json
- confident_gaze.json
- annoyed_puff.json
- innocent_halo.json
- mind_blown.json
- yawn_sleepy.json
- cheeky_wink.json