# Neura Companion

**Neura Companion** is an AI-driven wellness and productivity app offering:

- Ritual & Usage Analytics  
- Social & Community Feed  
- Dream Journal & Sleep Analysis  
- Voice & Text Journaling  
- Offline Mode & Sync  
- AI Companion Mascots (Neura & Neuro)  
- In-App Monetization & Billing  
- Full CI/CD & Deployment Pipeline  

## Getting Started

1. **Clone the repository**  
   ```bash
   git clone <repo_url>
   cd NeuraCompanionProject
   ```
2. **Install dependencies**  
   ```bash
   flutter pub get
   ```
3. **Run on device/emulator**  
   ```bash
   flutter run
   ```
4. **Run tests**  
   ```bash
   flutter test
   ```

## Folder Structure

- `lib/models/` – Data models  
- `lib/services/` – Business logic & API wrappers  
- `lib/screens/` – UI screens  
- `lib/widgets/` – Reusable widgets  
- `docs/` – Policies, guides, architecture docs  
- `.github/workflows/` – CI/CD configs  
- `scripts/` – Deployment scripts  

## Contributing

Please follow coding standards and update tests accordingly.
