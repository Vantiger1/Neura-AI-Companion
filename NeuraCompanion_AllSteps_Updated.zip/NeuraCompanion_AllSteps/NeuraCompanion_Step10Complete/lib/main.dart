import 'package:flutter/material.dart';

import 'package:sentry_flutter/sentry_flutter.dart';
import 'dart:convert';
import 'dart:math';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:hive/hive.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'widgets/auth_guard.dart';

import 'package:firebase_core/firebase_core.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'screens/sign_in_screen.dart';
import 'screens/privacy_agreement_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/feed_screen.dart';
import 'screens/challenge_list_screen.dart';
import 'screens/leaderboard_screen.dart';
import 'screens/profile_screen.dart';
import 'services/auth_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  await Hive.initFlutter();

  // Hive encryption key setup
  final secureStorage = FlutterSecureStorage();
  String? key = await secureStorage.read(key: 'hive_key');
  if (key == null) {
    key = base64UrlEncode(List<int>.generate(32, (_) => Random.secure().nextInt(256)));
    await secureStorage.write(key: 'hive_key', value: key);
  }
  final encryptionKey = base64Url.decode(key);
  Hive.openBox('usage_entries', encryptionCipher: HiveAesCipher(encryptionKey));


      // Hive encryption key setup
      final secureStorage = FlutterSecureStorage();
      String? key = await secureStorage.read(key: 'hive_key');
      if (key == null) {
        final bytes = List<int>.generate(32, (_) => Random.secure().nextInt(256));
        key = base64UrlEncode(bytes);
        await secureStorage.write(key: 'hive_key', value: key);
      }
      final encryptionKey = base64Url.decode(key);
      await Hive.initFlutter();
      Hive.registerAdapter(/* your adapters */);
      await Hive.openBox('usage_entries', encryptionCipher: HiveAesCipher(encryptionKey));
      await Firebase.initializeApp();

  await SentryFlutter.init(
    (options) {
      options.dsn = 'YOUR_SENTRY_DSN';
    },
    appRunner: () async {
      runApp(MyApp());
    );
}

class MyApp extends StatelessWidget {
  final _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      home: AuthWidget(),
    );
  }
}

class AuthWidget extends StatefulWidget {
  @override
  _AuthWidgetState createState() => _AuthWidgetState();
}

class _AuthWidgetState extends State<AuthWidget> {
  @override
  void initState() {
    super.initState();
    AuthService.onAuthStateChanged.listen((user) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.currentUser;
    if (user == null) return SignInScreen();
    return FutureBuilder<bool>(
      future: PrivacyAgreementScreen.isAccepted(),
      builder: (_, snap) {
        if (!snap.hasData) return SizedBox.shrink();
        return snap.data! ? MainNav() : PrivacyAgreementScreen();
      },
    );
  }
}

class MainNav extends StatefulWidget {
  @override
  _MainNavState createState() => _MainNavState();
}

class _MainNavState extends State<MainNav> {
  int _idx = 0;
  final _tabs = [
    AnalyticsScreen(),
    FeedScreen(),
    ChallengeListScreen(),
    LeaderboardScreen(),
    ProfileScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: AuthGuard(child: _tabs[_idx]),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Analytics'),
          BottomNavigationBarItem(icon: Icon(Icons.feed), label: 'Feed'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Challenges'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'Leaderboard'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
