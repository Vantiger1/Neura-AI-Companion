# Skill Pack 19 — Offline Document Index + Search (FTS5)

This patch gives Neura true offline “OS memory” over files in the **NeuraSandbox**:
- Index text content locally
- Search instantly without web or cloud

## What you get
- `NeuraDocIndex` (SQLite FTS5)
  - `rebuild()` full index
  - `updateIncremental()` fast updates
  - `search(query)` returns ranked hits + snippets
- `NeuraOfflineSearchActions`
  - `offline_index_rebuild`
  - `offline_index_update`
  - `offline_search`
- Optional UI: `NeuraOfflineSearchPanel`

## Dependencies (pubspec.yaml)
```yaml
dependencies:
  sqlite3: any
  sqlite3_flutter_libs: any
  crypto: any
```

Then:
- `flutter pub get`

## Register actions at boot
In your kernel boot (after sandbox actions):
```dart
NeuraOfflineSearchActions().registerAll(registry);
```

## Notes
- This version indexes: `.txt .md .log .json .csv`
- It intentionally ignores PDFs/Office docs for now (Step 20+ can add parsers).
- Index is stored at: `neura_sandbox/.neura_index.sqlite`

## Next
Step 20: PDF/DOCX extractors + “Knowledge Pack → cite sources from local docs” suggestions.
