import 'dart:convert';
import 'dart:io';

import 'package:crypto/crypto.dart';
import 'package:sqlite3/sqlite3.dart';

import '../neura_action_bus/sandbox_paths.dart';

class NeuraIndexedDoc {
  final String id;
  final String relPath;
  final int bytes;
  final int mtimeMs;
  final String sha1;

  NeuraIndexedDoc({
    required this.id,
    required this.relPath,
    required this.bytes,
    required this.mtimeMs,
    required this.sha1,
  });
}

class NeuraSearchHit {
  final String relPath;
  final String snippet;
  final double score;

  NeuraSearchHit({required this.relPath, required this.snippet, required this.score});
}

/// Offline document index + search (FTS5) over NeuraSandbox.
/// - Strictly indexes files inside the sandbox
/// - Extracts text for common formats (txt, md, json, csv)
/// - Stores an FTS index for fast local search
class NeuraDocIndex {
  final NeuraSandbox sandbox;

  Database? _db;

  NeuraDocIndex({NeuraSandbox? sandbox}) : sandbox = sandbox ?? NeuraSandbox();

  Future<void> open() async {
    if (_db != null) return;
    final root = await sandbox.root();
    final dbFile = File('${root.path}${Platform.pathSeparator}.neura_index.sqlite');
    dbFile.parent.createSync(recursive: true);

    _db = sqlite3.open(dbFile.path);

    _db!.execute('PRAGMA journal_mode=WAL;');
    _db!.execute('PRAGMA synchronous=NORMAL;');

    _db!.execute('''
      CREATE TABLE IF NOT EXISTS docs (
        id TEXT PRIMARY KEY,
        rel_path TEXT NOT NULL UNIQUE,
        bytes INTEGER NOT NULL,
        mtime_ms INTEGER NOT NULL,
        sha1 TEXT NOT NULL
      );
    ''');

    // FTS table: content stored in separate table; we only store rel_path + body.
    _db!.execute('''
      CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts USING fts5(
        rel_path,
        body,
        content='',
        tokenize='porter'
      );
    ''');

    _db!.execute('''
      CREATE TABLE IF NOT EXISTS meta (
        k TEXT PRIMARY KEY,
        v TEXT NOT NULL
      );
    ''');

    _setMeta('schema', '1');
  }

  void close() {
    _db?.dispose();
    _db = null;
  }

  Future<int> rebuild({int maxBytesPerFile = 2 * 1024 * 1024}) async {
    await open();
    _db!.execute('DELETE FROM docs;');
    _db!.execute('DELETE FROM docs_fts;');

    final root = await sandbox.root();
    final files = _listSandboxFiles(root);

    int indexed = 0;
    for (final f in files) {
      final rel = f.path.replaceFirst(root.path + Platform.pathSeparator, '');
      if (_isTrash(rel) || _isIndexFile(rel)) continue;

      final stat = f.statSync();
      if (stat.size <= 0) continue;
      if (stat.size > maxBytesPerFile) continue;

      final text = _extractTextBestEffort(f, rel);
      if (text.trim().isEmpty) continue;

      final digest = sha1.convert(utf8.encode(text)).toString();
      final id = _docId(rel);

      _db!.execute(
        'INSERT OR REPLACE INTO docs(id, rel_path, bytes, mtime_ms, sha1) VALUES(?,?,?,?,?)',
        [id, rel, stat.size, stat.modified.millisecondsSinceEpoch, digest],
      );
      _db!.execute(
        'INSERT INTO docs_fts(rel_path, body) VALUES(?,?)',
        [rel, text],
      );
      indexed++;
    }
    return indexed;
  }

  Future<int> updateIncremental({int maxBytesPerFile = 2 * 1024 * 1024}) async {
    await open();

    final root = await sandbox.root();
    final files = _listSandboxFiles(root);

    int updated = 0;

    for (final f in files) {
      final rel = f.path.replaceFirst(root.path + Platform.pathSeparator, '');
      if (_isTrash(rel) || _isIndexFile(rel)) continue;

      final stat = f.statSync();
      if (stat.size <= 0) continue;
      if (stat.size > maxBytesPerFile) continue;

      final mtimeMs = stat.modified.millisecondsSinceEpoch;

      final existing = _db!.select('SELECT mtime_ms, sha1 FROM docs WHERE rel_path=?', [rel]);
      final needs = existing.isEmpty || (existing.first['mtime_ms'] as int) != mtimeMs;

      if (!needs) continue;

      final text = _extractTextBestEffort(f, rel);
      if (text.trim().isEmpty) continue;

      final digest = sha1.convert(utf8.encode(text)).toString();
      final id = _docId(rel);

      _db!.execute('DELETE FROM docs_fts WHERE rel_path=?', [rel]);

      _db!.execute(
        'INSERT OR REPLACE INTO docs(id, rel_path, bytes, mtime_ms, sha1) VALUES(?,?,?,?,?)',
        [id, rel, stat.size, mtimeMs, digest],
      );
      _db!.execute('INSERT INTO docs_fts(rel_path, body) VALUES(?,?)', [rel, text]);

      updated++;
    }

    // Remove deleted files from index
    final indexedPaths = _db!.select('SELECT rel_path FROM docs').map((r) => r['rel_path'] as String).toList();
    final currentSet = files
        .map((f) => f.path.replaceFirst(root.path + Platform.pathSeparator, ''))
        .where((rel) => !_isTrash(rel) && !_isIndexFile(rel))
        .toSet();

    for (final rel in indexedPaths) {
      if (!currentSet.contains(rel)) {
        _db!.execute('DELETE FROM docs WHERE rel_path=?', [rel]);
        _db!.execute('DELETE FROM docs_fts WHERE rel_path=?', [rel]);
      }
    }

    return updated;
  }

  List<NeuraSearchHit> search(String query, {int limit = 12}) {
    if (_db == null) {
      throw StateError('Index is not open. Call open() first.');
    }
    final q = query.trim();
    if (q.isEmpty) return [];

    // bm25 available in FTS5; lower is better. We invert into a positive score.
    final rs = _db!.select('''
      SELECT rel_path,
             snippet(docs_fts, 1, '[', ']', '…', 12) AS snip,
             bm25(docs_fts) AS rank
      FROM docs_fts
      WHERE docs_fts MATCH ?
      ORDER BY rank
      LIMIT ?;
    ''', [q, limit]);

    return rs.map((r) {
      final rank = (r['rank'] as num).toDouble();
      final score = 1.0 / (1.0 + rank.abs());
      return NeuraSearchHit(
        relPath: r['rel_path'] as String,
        snippet: (r['snip'] as String?) ?? '',
        score: score,
      );
    }).toList(growable: false);
  }

  Map<String, dynamic> stats() {
    if (_db == null) return {'open': false};
    final c = _db!.select('SELECT COUNT(*) AS c FROM docs').first['c'] as int;
    return {'open': true, 'docs': c};
  }

  String? _getMeta(String k) {
    final rs = _db!.select('SELECT v FROM meta WHERE k=?', [k]);
    if (rs.isEmpty) return null;
    return rs.first['v'] as String;
  }

  void _setMeta(String k, String v) {
    _db!.execute('INSERT OR REPLACE INTO meta(k,v) VALUES(?,?)', [k, v]);
  }

  List<File> _listSandboxFiles(Directory root) {
    final out = <File>[];
    for (final ent in root.listSync(recursive: true, followLinks: false)) {
      if (ent is File) out.add(ent);
    }
    return out;
  }

  bool _isTrash(String rel) => rel.startsWith('${NeuraSandbox.trashFolderName}${Platform.pathSeparator}') || rel == NeuraSandbox.trashFolderName;

  bool _isIndexFile(String rel) => rel.endsWith('.neura_index.sqlite') || rel.endsWith('.neura_index.sqlite-wal') || rel.endsWith('.neura_index.sqlite-shm');

  String _docId(String relPath) => sha1.convert(utf8.encode(relPath)).toString();

  String _extractTextBestEffort(File f, String rel) {
    final lower = rel.toLowerCase();
    // NOTE: keep extraction deterministic and safe. For binary types, return empty.
    if (lower.endsWith('.txt') || lower.endsWith('.md') || lower.endsWith('.log') || lower.endsWith('.json') || lower.endsWith('.csv')) {
      // For json/csv we still treat as text; caller can add structured extract later.
      try {
        final bytes = f.readAsBytesSync();
        // best-effort utf8 decode (allow malformed)
        return const Utf8Decoder(allowMalformed: true).convert(bytes);
      } catch (_) {
        return '';
      }
    }
    // Keep PDFs/Office out for now (Step 20+ can add pdf_text/docx parsing).
    return '';
  }
}
