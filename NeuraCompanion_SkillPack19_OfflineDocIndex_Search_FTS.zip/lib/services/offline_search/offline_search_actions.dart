import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import 'neura_doc_index.dart';

class NeuraOfflineSearchActions {
  final NeuraDocIndex index;

  NeuraOfflineSearchActions({NeuraDocIndex? index}) : index = index ?? NeuraDocIndex();

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'offline_index_rebuild',
        title: 'Rebuild Offline Index',
        description: 'Rebuilds the sandbox document index for fast offline search.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final maxBytes = (req.args['maxBytesPerFile'] as int?) ?? (2 * 1024 * 1024);
          final n = await index.rebuild(maxBytesPerFile: maxBytes);
          return NeuraActionResult.success('Indexed $n files', data: {'indexed': n, 'stats': index.stats()});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'offline_index_update',
        title: 'Update Offline Index',
        description: 'Incrementally updates the sandbox document index (fast).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final maxBytes = (req.args['maxBytesPerFile'] as int?) ?? (2 * 1024 * 1024);
          final n = await index.updateIncremental(maxBytesPerFile: maxBytes);
          return NeuraActionResult.success('Updated $n files', data: {'updated': n, 'stats': index.stats()});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'offline_search',
        title: 'Offline Search (Sandbox)',
        description: 'Searches indexed sandbox documents (FTS).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final q = (req.args['q'] as String?)?.trim() ?? '';
          if (q.isEmpty) return NeuraActionResult.error('Missing query');
          await index.open();
          final hits = index.search(q, limit: (req.args['limit'] as int?) ?? 12);
          return NeuraActionResult.success('OK', data: {
            'q': q,
            'hits': hits.map((h) => {'path': h.relPath, 'snippet': h.snippet, 'score': h.score}).toList(),
          });
        },
      ),
    );
  }
}
