import 'package:flutter/material.dart';

import '../neura_kernel/neura_kernel.dart';

class NeuraOfflineSearchPanel extends StatefulWidget {
  const NeuraOfflineSearchPanel({super.key});

  @override
  State<NeuraOfflineSearchPanel> createState() => _NeuraOfflineSearchPanelState();
}

class _NeuraOfflineSearchPanelState extends State<NeuraOfflineSearchPanel> {
  final _q = TextEditingController();
  bool _busy = false;
  String _status = 'Type a query and search.';
  List<Map<String, dynamic>> _hits = [];

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  Future<void> _rebuild() async {
    setState(() {
      _busy = true;
      _status = 'Indexing...';
    });
    final r = await NeuraKernel.I.executor.execute('offline_index_rebuild', args: {});
    setState(() {
      _busy = false;
      _status = r.ok ? r.message : 'ERR: ${r.message}';
    });
  }

  Future<void> _search() async {
    final q = _q.text.trim();
    if (q.isEmpty) return;
    setState(() {
      _busy = true;
      _status = 'Searching...';
    });
    final r = await NeuraKernel.I.executor.execute('offline_search', args: {'q': q, 'limit': 12});
    setState(() {
      _busy = false;
      if (r.ok) {
        _hits = (r.data['hits'] as List).cast<Map<String, dynamic>>();
        _status = 'Found ${_hits.length} result(s).';
      } else {
        _hits = [];
        _status = 'ERR: ${r.message}';
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Offline Search')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _q,
                    decoration: const InputDecoration(
                      labelText: 'Search sandbox docs',
                      hintText: 'e.g., “ritual”, “privacy”, “dream”',
                    ),
                    onSubmitted: (_) => _search(),
                  ),
                ),
                const SizedBox(width: 8),
                ElevatedButton(onPressed: _busy ? null : _search, child: const Text('Search')),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                OutlinedButton(onPressed: _busy ? null : _rebuild, child: const Text('Rebuild Index')),
                const SizedBox(width: 12),
                Expanded(child: Text(_status, maxLines: 2, overflow: TextOverflow.ellipsis)),
              ],
            ),
            const SizedBox(height: 12),
            Expanded(
              child: ListView(
                children: _hits
                    .map(
                      (h) => Card(
                        child: ListTile(
                          title: Text(h['path']?.toString() ?? ''),
                          subtitle: Text(h['snippet']?.toString() ?? ''),
                        ),
                      ),
                    )
                    .toList(),
              ),
            )
          ],
        ),
      ),
    );
  }
}
