
Neura Joke Module Integration

Folders:
- flutter_dashboard_app: Embed NeuraJokePanelAnimated into your existing app UI.
- neura_standalone_pc_mobile: Use with floating companion on desktop/mobile standalone.
- neura_joke_components: Contains all Dart components needed to power joke engine, memory, and animated interface.

Usage:
- Ensure flutter_tts and shared_preferences are added to your pubspec.yaml
- Import and display NeuraJokePanelAnimated inside your app or standalone screen.

This build supports full joke reactions, favorites, age settings, and animated facial feedback.
