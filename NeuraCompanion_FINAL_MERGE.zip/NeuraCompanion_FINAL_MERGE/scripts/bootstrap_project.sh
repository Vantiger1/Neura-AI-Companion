#!/usr/bin/env bash
set -euo pipefail

echo "=== Neura Companion Bootstrap ==="
if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter not found in PATH. Install Flutter and retry." >&2
  exit 1
fi

if [ ! -d android ]; then
  echo "Missing platform folders. Running flutter create..."
  flutter create . --platforms=android,ios,web,windows,macos,linux
fi

flutter pub get
flutter analyze
flutter test

echo "Done. Next: flutter run"
