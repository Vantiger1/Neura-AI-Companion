@echo off
setlocal

echo === Neura Companion Bootstrap ===
where flutter >nul 2>&1
if errorlevel 1 (
  echo Flutter not found in PATH.
  echo Install Flutter, then rerun this script.
  exit /b 1
)

if not exist android\ (
  echo Missing platform folders. Running flutter create...
  flutter create . --platforms=android,ios,web,windows,macos,linux
  if errorlevel 1 exit /b 1
)

echo Running pub get...
flutter pub get || exit /b 1

echo Running analyze...
flutter analyze || exit /b 1

echo Running tests...
flutter test || exit /b 1

echo Done. Next: flutter run
