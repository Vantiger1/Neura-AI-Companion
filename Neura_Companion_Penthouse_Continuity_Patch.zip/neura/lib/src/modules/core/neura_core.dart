import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'actions/action_registry.dart';
import 'continuity/neura_continuity.dart';
import 'memory/memory_vault.dart';
import 'voice/neura_voice_loop.dart';

/// The one ring to bind Neura's core systems.
///
/// - Local-first encrypted memory
/// - Voice loop (STT -> Emotion -> TTS + viseme pulses)
/// - Action registry (tool system)
class NeuraCore {
  NeuraCore._();

  static final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

  static bool _started = false;
  static late final MemoryVault memory;
  static late final ActionRegistry actions;
  static late final NeuraVoiceLoop voice;
  static late final NeuraContinuity continuity;

  static Future<void> start() async {
    if (_started) return;
    _started = true;

    // Storage
    await Hive.initFlutter();
    memory = MemoryVault();
    await memory.init();

    // Continuity spine (room/mood/last interaction).
    continuity = NeuraContinuity(memory);
    await continuity.init();

    // Optional Firebase init (safe no-op if not configured yet).
    try {
      await Firebase.initializeApp();
    } catch (e) {
      if (kDebugMode) {
        // Ignore: Firebase not configured in this build.
        debugPrint('Firebase init skipped: $e');
      }
    }

    // Actions
    actions = ActionRegistry(navigatorKey: navigatorKey, memory: memory, continuity: continuity);
    actions.registerDefaults();

    // Voice loop
    voice = NeuraVoiceLoop(memory: memory, actions: actions, continuity: continuity);
    await voice.init();
  }

  /// Fire-and-forget startup for widgets that can't await.
  static void ensureStarted() {
    // Unawaited startup; errors are logged but not fatal.
    unawaited(start().catchError((e, st) {
      debugPrint('NeuraCore.start error: $e');
    }));
  }
}
