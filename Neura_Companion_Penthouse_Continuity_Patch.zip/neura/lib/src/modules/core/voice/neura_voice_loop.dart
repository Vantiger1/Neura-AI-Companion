import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../actions/action_registry.dart';
import '../continuity/neura_continuity.dart';
import '../memory/memory_vault.dart';
import 'simple_emotion_analyzer.dart';

enum NeuraVoiceState { idle, listening, thinking, speaking }

class NeuraVoiceLoop extends ChangeNotifier {
  NeuraVoiceLoop({required this.memory, required this.actions, required this.continuity});

  final MemoryVault memory;
  final ActionRegistry actions;
  final NeuraContinuity continuity;

  final stt.SpeechToText _stt = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  final SimpleEmotionAnalyzer _emotion = SimpleEmotionAnalyzer();

  NeuraVoiceState _state = NeuraVoiceState.idle;
  NeuraVoiceState get state => _state;

  String _lastHeard = '';
  String get lastHeard => _lastHeard;

  String _lastSpoken = '';
  String get lastSpoken => _lastSpoken;

  /// A "mouth openness" pulse value (0..1) used by avatar widgets for viseme-ish motion.
  double _mouth = 0.0;
  double get mouth => _mouth;

  Timer? _mouthTimer;

  Future<void> init() async {
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);

    _tts.setStartHandler(() {
      _setState(NeuraVoiceState.speaking);
      _startMouthPulses();
    });
    _tts.setCompletionHandler(() {
      _stopMouthPulses();
      _setState(NeuraVoiceState.idle);
    });
    _tts.setErrorHandler((msg) {
      _stopMouthPulses();
      _setState(NeuraVoiceState.idle);
      if (kDebugMode) debugPrint('TTS error: $msg');
    });

    try {
      await _stt.initialize(
        onError: (e) {
          if (kDebugMode) debugPrint('STT error: $e');
          _setState(NeuraVoiceState.idle);
        },
        onStatus: (s) {
          if (kDebugMode) debugPrint('STT status: $s');
        },
      );
    } catch (e) {
      if (kDebugMode) debugPrint('STT init failed: $e');
    }
  }

  Future<void> toggleListening() async {
    if (_state == NeuraVoiceState.listening) {
      await stopListening();
      return;
    }
    await startListening();
  }

  Future<void> startListening() async {
    if (!_stt.isAvailable) {
      await speak('Speech recognition is not available on this device yet.');
      return;
    }
    _lastHeard = '';
    _setState(NeuraVoiceState.listening);

    await _stt.listen(
      listenMode: stt.ListenMode.confirmation,
      partialResults: true,
      onResult: (res) {
        _lastHeard = res.recognizedWords;
        notifyListeners();
        if (res.finalResult) {
          unawaited(_handleFinalTranscript(_lastHeard));
        }
      },
    );
  }

  Future<void> stopListening() async {
    await _stt.stop();
    if (_state == NeuraVoiceState.listening) {
      _setState(NeuraVoiceState.idle);
    }
  }

  Future<void> _handleFinalTranscript(String text) async {
    await stopListening();
    final cleaned = text.trim();
    if (cleaned.isEmpty) return;

    _setState(NeuraVoiceState.thinking);

    // 1) Emotion tag
    final mood = _emotion.analyze(cleaned);
    await memory.putJson('voice.last_mood', mood);
    await memory.putJson('voice.last_heard', cleaned);
    await continuity.setMood(mood);

    // 2) Try tool/action first
    final actionRes = await actions.tryHandle(
      cleaned,
      speak: (m) => speak(m),
    );
    if (actionRes != null) {
      await continuity.recordInteraction(
        heard: cleaned,
        reply: actionRes.message ?? 'Done.',
        mood: mood,
        room: continuity.currentRoom ?? 'penthouse',
        kind: 'action',
      );
      _setState(NeuraVoiceState.idle);
      return;
    }

    // 3) Otherwise: simple helpful response (replace with LLM later).
    final reply = _defaultReply(cleaned, mood: mood);
    await speak(reply);

    // Store a tiny memory of the interaction + continuity record.
    await continuity.recordInteraction(
      heard: cleaned,
      reply: reply,
      mood: mood,
      room: continuity.currentRoom ?? 'penthouse',
      kind: 'voice',
    );
  }

  String _defaultReply(String text, {required String mood}) {
    // Keep it safe and grounded.
    switch (mood) {
      case 'anxious':
        return 'I’m hearing some stress. Want to do 60 seconds of breathing, or jump into the journal to unpack it?';
      case 'sad':
        return 'That sounds heavy. I’m here. Do you want a gentle check-in, or should we write one honest paragraph in the journal together?';
      case 'angry':
        return 'Okay. No pretending. Let’s cool the system: 3 slow breaths, then we pick the next right action.';
      case 'happy':
        return 'Nice. Let’s bottle that. Want to log a quick win in your journal or set a small goal while the energy is hot?';
      case 'calm':
        return 'You sound steady. Want to build momentum—journal, goals, or a short meditation?';
      default:
        return 'Got it. I can open modules by voice—say “open journal”, “open goals”, or “check in”.';
    }
  }

  Future<void> speak(String message) async {
    _lastSpoken = message;
    notifyListeners();

    try {
      await _tts.stop();
      await _tts.speak(message);
    } catch (e) {
      if (kDebugMode) debugPrint('Speak failed: $e');
      _setState(NeuraVoiceState.idle);
    }
  }

  void _startMouthPulses() {
    _mouthTimer?.cancel();
    _mouth = 0.4;
    notifyListeners();

    // This is an intentionally simple "viseme-ish" pulse driver.
    // Later: swap for phoneme timepoints or audio-energy analysis.
    var up = true;
    _mouthTimer = Timer.periodic(const Duration(milliseconds: 120), (_) {
      _mouth = up ? 1.0 : 0.2;
      up = !up;
      notifyListeners();
    });
  }

  void _stopMouthPulses() {
    _mouthTimer?.cancel();
    _mouthTimer = null;
    _mouth = 0.0;
    notifyListeners();
  }

  void _setState(NeuraVoiceState s) {
    if (_state == s) return;
    _state = s;
    notifyListeners();
  }
}
