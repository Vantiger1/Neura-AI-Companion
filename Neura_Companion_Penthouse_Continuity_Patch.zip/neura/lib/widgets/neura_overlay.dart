import 'package:flutter/material.dart';

import '../src/modules/core/neura_core.dart';

class NeuraOverlay extends StatefulWidget {
  const NeuraOverlay({super.key});

  @override
  State<NeuraOverlay> createState() => _NeuraOverlayState();
}

class _NeuraOverlayState extends State<NeuraOverlay> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final voice = NeuraCore.voice;

    return AnimatedBuilder(
      animation: voice,
      builder: (context, _) {
        final mouth = voice.mouth.clamp(0.0, 1.0);
        final isListening = voice.state.name == 'listening';

        return Material(
          color: Colors.transparent,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              if (_expanded)
                _Bubble(
                  heard: voice.lastHeard,
                  spoken: voice.lastSpoken,
                  stateLabel: voice.state.name,
                  room: NeuraCore.continuity.currentRoom ?? 'penthouse',
                  mood: NeuraCore.continuity.currentMood ?? 'calm',
                ),
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  GestureDetector(
                    onTap: () => setState(() => _expanded = !_expanded),
                    child: _AvatarGlow(mouth: mouth),
                  ),
                  const SizedBox(width: 10),
                  FloatingActionButton.small(
                    heroTag: 'neura_mic',
                    onPressed: () => voice.toggleListening(),
                    backgroundColor: isListening ? Colors.redAccent : null,
                    child: Icon(isListening ? Icons.mic : Icons.mic_none),
                  ),
                ],
              ),
            ],
          ),
        );
      },
    );
  }
}

class _AvatarGlow extends StatelessWidget {
  const _AvatarGlow({required this.mouth});

  final double mouth;

  @override
  Widget build(BuildContext context) {
    final s = 1.0 + (mouth * 0.08);

    return AnimatedScale(
      scale: s,
      duration: const Duration(milliseconds: 120),
      child: Container(
        width: 72,
        height: 72,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              blurRadius: 18 + mouth * 10,
              spreadRadius: 2 + mouth * 2,
              color: Colors.cyanAccent.withOpacity(0.25 + mouth * 0.15),
            ),
          ],
        ),
        child: ClipOval(
          child: Image.asset(
            'assets/images/ai_avatar.png',
            fit: BoxFit.cover,
          ),
        ),
      ),
    );
  }
}

class _Bubble extends StatelessWidget {
  const _Bubble({required this.heard, required this.spoken, required this.stateLabel, required this.room, required this.mood});

  final String heard;
  final String spoken;
  final String stateLabel;
  final String room;
  final String mood;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Container(
      margin: const EdgeInsets.only(bottom: 8),
      padding: const EdgeInsets.all(12),
      width: 290,
      decoration: BoxDecoration(
        color: theme.colorScheme.surface.withOpacity(0.9),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: theme.colorScheme.onSurface.withOpacity(0.08)),
      ),
      child: DefaultTextStyle(
        style: theme.textTheme.bodySmall ?? const TextStyle(fontSize: 12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('Neura: $stateLabel  •  $room  •  $mood', style: theme.textTheme.labelMedium),
            const SizedBox(height: 8),
            if (heard.trim().isNotEmpty) ...[
              Text('Heard: $heard'),
              const SizedBox(height: 6),
            ],
            if (spoken.trim().isNotEmpty) Text('Said: $spoken'),
            if (heard.trim().isEmpty && spoken.trim().isEmpty)
              const Text('Tap the avatar to expand. Use the mic to speak commands.'),
          ],
        ),
      ),
    );
  }
}
