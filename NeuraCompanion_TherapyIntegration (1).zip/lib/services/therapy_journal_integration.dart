import '../models/therapy_path_model.dart';
import '../models/journal_entry.dart';
import 'therapy_service.dart';
import 'emotion_analysis_service.dart';

class TherapyJournalIntegration {
  final TherapyService therapyService;
  final EmotionAnalysisService emotionService;

  TherapyJournalIntegration(this.therapyService, this.emotionService);

  /// Convert a journal entry into a therapy reflection
  Future<Map<String, String>> reflectWithPrompt(String method, JournalEntry entry) async {
    final prompts = therapyService.getAll(method);
    final mood = await emotionService.analyzeEmotion(entry.content);
    final match = prompts.where((p) => entry.content.contains(p.title)).toList();
    final prompt = match.isNotEmpty ? match.first : prompts.first;

    return {
      'prompt': prompt.instruction,
      'method': method,
      'mood': mood,
      'suggestion': 'You may be experiencing a common challenge in ${method}. Reflect on: ${prompt.instruction}'
    };
  }
}
