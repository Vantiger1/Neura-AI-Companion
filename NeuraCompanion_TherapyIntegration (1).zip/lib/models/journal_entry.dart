import 'package:flutter/foundation.dart';

@immutable
class JournalEntry {
  final String id;
  final DateTime timestamp;
  final String content;
  final String moodTag;

  const JournalEntry({
    required this.id,
    required this.timestamp,
    required this.content,
    required this.moodTag,
  });
}
