import 'package:flutter/foundation.dart';

@immutable
class MoodMusic {
  final String moodTag;
  final String title;
  final String url;

  const MoodMusic({
    required this.moodTag,
    required this.title,
    required this.url,
  });
}
