import '../models/user_memory.dart';
import 'memory_service.dart';

class WeeklyCheckInService {
  final MemoryService memoryService;

  WeeklyCheckInService(this.memoryService);

  String generateSummary() {
    final memories = memoryService.getAllMemories();
    if (memories.isEmpty) return 'No entries found this week.';

    final moodCounts = <String, int>{};
    for (var m in memories) {
      final key = m.moodTag.toLowerCase();
      moodCounts[key] = (moodCounts[key] ?? 0) + 1;
    }

    final mostCommon = (moodCounts.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value))).first.key;

    return 'This week you felt mostly: $mostCommon. Keep an eye on this trend!';
  }
}
