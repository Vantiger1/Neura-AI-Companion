import '../models/mood_music_model.dart';

class MoodMusicService {
  List<MoodMusic> getMusicForMood(String moodTag) {
    final all = <MoodMusic>[
      MoodMusic(moodTag: 'calm', title: 'Gentle Rain', url: 'https://example.com/rain.mp3'),
      MoodMusic(moodTag: 'focus', title: 'Lo-Fi Study', url: 'https://example.com/lofi.mp3'),
      MoodMusic(moodTag: 'happy', title: 'Uplifting Vibes', url: 'https://example.com/happy.mp3'),
    ];
    return all.where((m) => m.moodTag == moodTag).toList();
  }
}
