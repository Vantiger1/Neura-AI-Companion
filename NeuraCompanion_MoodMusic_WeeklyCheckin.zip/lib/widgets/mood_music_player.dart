import 'package:flutter/material.dart';
import '../models/mood_music_model.dart';

class MoodMusicPlayer extends StatelessWidget {
  final List<MoodMusic> tracks;

  const MoodMusicPlayer({required this.tracks});

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: tracks.map((track) {
        return ListTile(
          title: Text(track.title),
          subtitle: Text('Mood: ${track.moodTag}'),
          trailing: Icon(Icons.play_arrow),
          onTap: () {
            // TODO: Add real playback with just_audio or audioplayers
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Play ${track.title}')));
          },
        );
      }).toList(),
    );
  }
}
