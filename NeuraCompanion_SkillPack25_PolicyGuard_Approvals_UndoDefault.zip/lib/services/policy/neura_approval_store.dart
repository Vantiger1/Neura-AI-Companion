\
import 'dart:convert';
import 'package:crypto/crypto.dart';

import 'neura_policy_models.dart';

class NeuraApprovalStore {
  final Map<String, NeuraApprovalRequest> _pending = {};
  final Map<String, NeuraApprovalDecision> _decisions = {};

  List<NeuraApprovalRequest> listPending() {
    _prune();
    return _pending.values.toList()
      ..sort((a, b) => b.createdAt.compareTo(a.createdAt));
  }

  NeuraApprovalRequest? getPending(String id) {
    _prune();
    return _pending[id];
  }

  NeuraApprovalDecision? getDecision(String id) => _decisions[id];

  NeuraApprovalRequest create({
    required String actionId,
    required Map<String, dynamic> args,
    required String reason,
    required String risk,
    required Duration ttl,
    required bool checklistAccepted,
    required String disclaimerVersion,
    required String userTypedPhrase,
    String? undoActionId,
    Map<String, dynamic>? undoArgs,
  }) {
    final now = DateTime.now();
    final expires = now.add(ttl);
    final id = _makeId(actionId, now);

    final req = NeuraApprovalRequest(
      id: id,
      actionId: actionId,
      args: args,
      reason: reason,
      risk: risk,
      createdAt: now,
      expiresAt: expires,
      checklistAccepted: checklistAccepted,
      disclaimerVersion: disclaimerVersion,
      userTypedPhrase: userTypedPhrase,
      undoActionId: undoActionId,
      undoArgs: undoArgs,
    );

    _pending[id] = req;
    return req;
  }

  NeuraApprovalDecision decide(String requestId, bool approve, {String decidedBy = 'user'}) {
    _prune();
    final req = _pending.remove(requestId);
    final now = DateTime.now();
    final d = NeuraApprovalDecision(
      requestId: requestId,
      approved: approve && req != null && !req.expired,
      decidedBy: decidedBy,
      decidedAt: now,
    );
    _decisions[requestId] = d;
    return d;
  }

  void _prune() {
    final now = DateTime.now();
    final expired = _pending.values.where((r) => now.isAfter(r.expiresAt)).map((r) => r.id).toList();
    for (final id in expired) {
      _pending.remove(id);
      _decisions[id] = NeuraApprovalDecision(
        requestId: id,
        approved: false,
        decidedBy: 'system',
        decidedAt: now,
      );
    }
  }

  String _makeId(String actionId, DateTime now) {
    final bytes = utf8.encode('$actionId|${now.microsecondsSinceEpoch}|${DateTime.now().millisecondsSinceEpoch}');
    return sha256.convert(bytes).toString().substring(0, 18);
  }
}
