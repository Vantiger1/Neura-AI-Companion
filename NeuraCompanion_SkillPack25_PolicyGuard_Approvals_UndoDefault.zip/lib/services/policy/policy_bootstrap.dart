\
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/action_executor.dart';

import 'neura_policy_engine.dart';
import 'neura_approval_store.dart';
import 'policy_actions.dart';

class NeuraPolicyBootstrap {
  static void register({
    required NeuraActionRegistry registry,
    required NeuraActionExecutor executor,
  }) {
    final engine = NeuraPolicyEngine(registry: registry);
    final store = NeuraApprovalStore();
    NeuraPolicyActions(policy: engine, store: store, executor: executor).registerAll(registry);
  }
}
