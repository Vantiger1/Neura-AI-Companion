\
class NeuraApprovalRequest {
  final String id;
  final String actionId;
  final Map<String, dynamic> args;
  final String reason;
  final String risk; // low|medium|high
  final DateTime createdAt;
  final DateTime expiresAt;

  // UX/legal fields
  final bool checklistAccepted;
  final String disclaimerVersion;
  final String userTypedPhrase; // must match required phrase

  // For high risk: require undo plan
  final String? undoActionId;
  final Map<String, dynamic>? undoArgs;

  NeuraApprovalRequest({
    required this.id,
    required this.actionId,
    required this.args,
    required this.reason,
    required this.risk,
    required this.createdAt,
    required this.expiresAt,
    required this.checklistAccepted,
    required this.disclaimerVersion,
    required this.userTypedPhrase,
    this.undoActionId,
    this.undoArgs,
  });

  bool get expired => DateTime.now().isAfter(expiresAt);

  Map<String, dynamic> toJson() => {
        'id': id,
        'actionId': actionId,
        'args': args,
        'reason': reason,
        'risk': risk,
        'createdAt': createdAt.toIso8601String(),
        'expiresAt': expiresAt.toIso8601String(),
        'checklistAccepted': checklistAccepted,
        'disclaimerVersion': disclaimerVersion,
        'userTypedPhrase': userTypedPhrase,
        if (undoActionId != null) 'undoActionId': undoActionId,
        if (undoArgs != null) 'undoArgs': undoArgs,
      };
}

class NeuraApprovalDecision {
  final String requestId;
  final bool approved;
  final String decidedBy; // "user" | "system"
  final DateTime decidedAt;

  NeuraApprovalDecision({
    required this.requestId,
    required this.approved,
    required this.decidedBy,
    required this.decidedAt,
  });

  Map<String, dynamic> toJson() => {
        'requestId': requestId,
        'approved': approved,
        'decidedBy': decidedBy,
        'decidedAt': decidedAt.toIso8601String(),
      };
}
