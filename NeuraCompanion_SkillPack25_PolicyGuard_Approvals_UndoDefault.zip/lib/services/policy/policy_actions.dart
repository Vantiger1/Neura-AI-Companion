\
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import '../neura_action_bus/action_executor.dart';

import 'neura_policy_engine.dart';
import 'neura_approval_store.dart';

class NeuraPolicyActions {
  final NeuraPolicyEngine policy;
  final NeuraApprovalStore store;
  final NeuraActionExecutor executor;

  static const String requiredPhrase = 'I understand and approve this action';

  NeuraPolicyActions({
    required this.policy,
    required this.store,
    required this.executor,
  });

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'policy_request_approval',
        title: 'Request Approval',
        description: 'Creates an approval request for a guarded action.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final actionId = (req.args['actionId'] as String?)?.trim() ?? '';
          final args = (req.args['args'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
          final reason = (req.args['reason'] as String?)?.trim() ?? 'User approval required';
          final ttlSeconds = (req.args['ttlSeconds'] as int?) ?? 300;

          final checklistAccepted = (req.args['checklistAccepted'] as bool?) ?? false;
          final disclaimerVersion = (req.args['disclaimerVersion'] as String?)?.trim() ?? 'v1';
          final userTypedPhrase = (req.args['userTypedPhrase'] as String?)?.trim() ?? '';

          final undoActionId = (req.args['undoActionId'] as String?)?.trim();
          final undoArgs = (req.args['undoArgs'] as Map?)?.cast<String, dynamic>();

          if (actionId.isEmpty) return NeuraActionResult.error('Missing actionId');

          final d = policy.decide(actionId);
          if (!d.allowed) return NeuraActionResult.error('Unknown actionId');

          if (!checklistAccepted) return NeuraActionResult.error('Checklist not accepted.');
          if (userTypedPhrase != requiredPhrase) return NeuraActionResult.error('Typed approval phrase mismatch.');

          if (d.needsUndoPlan && (undoActionId == null || undoActionId.isEmpty)) {
            return NeuraActionResult.error('Undo plan required for this action.');
          }

          final reqObj = store.create(
            actionId: actionId,
            args: args,
            reason: reason,
            risk: d.risk,
            ttl: Duration(seconds: ttlSeconds.clamp(60, 1800)),
            checklistAccepted: checklistAccepted,
            disclaimerVersion: disclaimerVersion,
            userTypedPhrase: userTypedPhrase,
            undoActionId: undoActionId,
            undoArgs: undoArgs,
          );

          return NeuraActionResult.success('Approval requested', data: reqObj.toJson());
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'policy_list_pending',
        title: 'List Pending Approvals',
        description: 'Lists all pending approval requests.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final pending = store.listPending().map((r) => r.toJson()).toList();
          return NeuraActionResult.success('OK', data: {'pending': pending});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'policy_decide',
        title: 'Decide Approval',
        description: 'Approves or denies a pending request.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final requestId = (req.args['requestId'] as String?)?.trim() ?? '';
          final approve = (req.args['approve'] as bool?) ?? false;
          if (requestId.isEmpty) return NeuraActionResult.error('Missing requestId');
          final d = store.decide(requestId, approve);
          return NeuraActionResult.success('OK', data: d.toJson());
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'policy_execute_guarded',
        title: 'Execute Guarded Action',
        description: 'Executes an action only if it is approved. Requires actionId/args provided again for MVP.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.systemAutomation,
        handler: (req) async {
          final requestId = (req.args['requestId'] as String?)?.trim() ?? '';
          if (requestId.isEmpty) return NeuraActionResult.error('Missing requestId');

          // If still pending, force decision first
          final pending = store.getPending(requestId);
          if (pending != null) return NeuraActionResult.error('Request still pending. Decide first.');

          final decision = store.getDecision(requestId);
          if (decision == null || !decision.approved) return NeuraActionResult.error('Not approved or expired.');

          final actionId = (req.args['actionId'] as String?)?.trim() ?? '';
          final args = (req.args['args'] as Map?)?.cast<String, dynamic>() ?? <String, dynamic>{};
          final undoActionId = (req.args['undoActionId'] as String?)?.trim();
          final undoArgs = (req.args['undoArgs'] as Map?)?.cast<String, dynamic>();

          if (actionId.isEmpty) return NeuraActionResult.error('Missing actionId for execution');

          final d = policy.decide(actionId);
          if (!d.allowed) return NeuraActionResult.error('Unknown actionId');
          if (d.needsUndoPlan && (undoActionId == null || undoActionId.isEmpty)) {
            return NeuraActionResult.error('Undo plan required for this action.');
          }

          final res = await executor.execute(actionId, args: args);
          if (!res.ok) {
            if (undoActionId != null && undoActionId.isNotEmpty) {
              await executor.execute(undoActionId, args: undoArgs ?? const {});
            }
            return NeuraActionResult.error('Guarded action failed: ${res.message}');
          }

          return NeuraActionResult.success('Executed', data: {'actionId': actionId, 'result': res.data});
        },
      ),
    );
  }
}
