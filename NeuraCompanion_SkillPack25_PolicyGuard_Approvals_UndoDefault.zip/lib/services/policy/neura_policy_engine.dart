\
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';

class NeuraPolicyRule {
  final RegExp actionIdPattern;
  final String minRisk; // low|medium|high
  final bool requireApproval;
  final bool requireUndoPlan;

  const NeuraPolicyRule({
    required this.actionIdPattern,
    required this.minRisk,
    required this.requireApproval,
    required this.requireUndoPlan,
  });

  bool matches(String actionId) => actionIdPattern.hasMatch(actionId);
}

class NeuraPolicyDecision {
  final bool allowed;
  final bool needsApproval;
  final bool needsUndoPlan;
  final String risk;

  NeuraPolicyDecision({
    required this.allowed,
    required this.needsApproval,
    required this.needsUndoPlan,
    required this.risk,
  });
}

class NeuraPolicyEngine {
  final NeuraActionRegistry registry;
  final List<NeuraPolicyRule> rules;

  NeuraPolicyEngine({required this.registry, List<NeuraPolicyRule>? rules})
      : rules = rules ?? _defaultRules();

  NeuraPolicyDecision decide(String actionId) {
    final action = registry.get(actionId);
    if (action == null) {
      return NeuraPolicyDecision(allowed: false, needsApproval: false, needsUndoPlan: false, risk: 'high');
    }

    final risk = _riskToString(action.risk);

    for (final r in rules) {
      if (!r.matches(actionId)) continue;
      final needsApproval = r.requireApproval || _riskRank(risk) >= _riskRank(r.minRisk);
      final needsUndo = r.requireUndoPlan || (risk == 'high');
      return NeuraPolicyDecision(allowed: true, needsApproval: needsApproval, needsUndoPlan: needsUndo, risk: risk);
    }

    final needsApproval = (risk == 'medium' || risk == 'high');
    final needsUndo = (risk == 'high');
    return NeuraPolicyDecision(allowed: true, needsApproval: needsApproval, needsUndoPlan: needsUndo, risk: risk);
  }

  static List<NeuraPolicyRule> _defaultRules() {
    return [
      NeuraPolicyRule(
        actionIdPattern: RegExp(r'(install|uninstall|delete|wipe|format|system|registry|driver|firewall|network)', caseSensitive: false),
        minRisk: 'medium',
        requireApproval: true,
        requireUndoPlan: true,
      ),
      NeuraPolicyRule(
        actionIdPattern: RegExp(r'(unlock_encrypted_session|offline_index_encrypted_session)', caseSensitive: false),
        minRisk: 'high',
        requireApproval: true,
        requireUndoPlan: false,
      ),
      NeuraPolicyRule(
        actionIdPattern: RegExp(r'(export|import|move|copy|rename)', caseSensitive: false),
        minRisk: 'medium',
        requireApproval: true,
        requireUndoPlan: false,
      ),
    ];
  }

  String _riskToString(NeuraRisk r) {
    switch (r) {
      case NeuraRisk.low:
        return 'low';
      case NeuraRisk.medium:
        return 'medium';
      case NeuraRisk.high:
        return 'high';
    }
  }

  int _riskRank(String s) {
    switch (s) {
      case 'low':
        return 1;
      case 'medium':
        return 2;
      case 'high':
        return 3;
      default:
        return 2;
    }
  }
}
