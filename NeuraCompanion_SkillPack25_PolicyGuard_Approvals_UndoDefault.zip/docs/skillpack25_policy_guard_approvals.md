# Skill Pack 25 — Policy Guard + Approvals + Undo-by-Default

This patch enforces explicit consent for sensitive actions.

## What you get
- `NeuraPolicyEngine` (rules-based gating)
- `NeuraApprovalStore` (in-memory pending approvals)
- Actions:
  - `policy_request_approval`
  - `policy_list_pending`
  - `policy_decide`
  - `policy_execute_guarded`

## Required typed phrase
User must type EXACTLY:
I understand and approve this action

## Recommended UX flow
1) Neura proposes an action (with “why”)
2) App shows checklist + disclaimer
3) User types approval phrase
4) `policy_request_approval`
5) Approve/Deny → `policy_decide`
6) Execute → `policy_execute_guarded`

## Undo requirement
For actions matching install/delete/system/network patterns OR risk=high:
Provide:
- `undoActionId`
- `undoArgs` (optional)

If execution fails, Neura attempts undo automatically.

## Integration
Register on boot:
```dart
NeuraPolicyBootstrap.register(
  registry: NeuraKernel.I.registry,
  executor: NeuraKernel.I.executor,
);
```

## Next
Step 26: Persist approvals + audit log to encrypted local store (for proof of consent, offline).
