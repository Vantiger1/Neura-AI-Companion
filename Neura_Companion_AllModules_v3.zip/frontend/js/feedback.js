// frontend/js/feedback.js
const fbQueue = [];
export function showFeedbackPanel(action, context) {
  const panel = document.getElementById('feedback-panel');
  panel.style.display = 'block';
  document.getElementById('fb-yes').onclick = () => recordFeedback(action, context, 1);
  document.getElementById('fb-no').onclick  = () => recordFeedback(action, context, 0);
}

function recordFeedback(action, context, liked) {
  fbQueue.push({ action, context, liked });
  document.getElementById('feedback-panel').style.display = 'none';
}

export function syncFeedback() {
  if (!fbQueue.length) return;
  fetch('/api/neura/feedback', {
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body: JSON.stringify(fbQueue)
  }).then(() => fbQueue.length = 0)
    .catch(e => console.error('Feedback sync failed', e));
}

// Sync hourly
setInterval(syncFeedback, 60*60*1000);
