// frontend/js/moodFusion.js
export const moodHistory = [];

export function recordMood(source, mood, confidence=1.0) {
  moodHistory.push({ source, mood, confidence, timestamp: Date.now() });
  const cutoff = Date.now() - 60_000;
  while (moodHistory[0] && moodHistory[0].timestamp < cutoff) {
    moodHistory.shift();
  }
}

export function inferFusedMood() {
  const scores = {};
  for (const { mood, confidence } of moodHistory) {
    scores[mood] = (scores[mood]||0) + confidence;
  }
  return Object.entries(scores).sort((a,b)=>b[1]-a[1])[0]?.[0] || 'Neutral';
}
