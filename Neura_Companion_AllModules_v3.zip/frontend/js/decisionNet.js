// frontend/js/decisionNet.js
import * as tf from '@tensorflow/tfjs';

let decisionNet, actionMap;
export async function initDecisionNet() {
  decisionNet = await tf.loadGraphModel('/models/decision_net/web_model/model.json');
  actionMap = ['calmMood','upliftMood','suggestNap','startGame','confirmMood'];
}

export function encodeFeatures({mood, stress, fatigue, posture, childLevel}) {
  const moods = ['Happy','Neutral','Sad','Mad','Anxious','Calm'];
  const onehot = moods.map(m => m === mood ? 1 : 0);
  return onehot.concat([stress||0, fatigue||0, posture||0, childLevel||0]);
}

export async function decideNextAction(context) {
  const feats = encodeFeatures(context);
  const input = tf.tensor2d([feats]);
  const out = decisionNet.predict(input);
  const idx = out.argMax(-1).dataSync()[0];
  return actionMap[idx];
}
