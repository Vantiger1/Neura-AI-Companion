# scripts/train_decision_net.py
import numpy as np
import tensorflow as tf
import os

# Load historical feature & label arrays
X = np.load('data/decision/X.npy')
y = np.load('data/decision/y.npy')
num_actions = len(np.unique(y))

model = tf.keras.Sequential([
    tf.keras.layers.Input(shape=(X.shape[1],)),
    tf.keras.layers.Dense(16, activation='relu'),
    tf.keras.layers.Dense(8, activation='relu'),
    tf.keras.layers.Dense(num_actions, activation='softmax')
])
model.compile(optimizer='adam',
              loss='sparse_categorical_crossentropy',
              metrics=['accuracy'])
model.fit(X, y, epochs=30, batch_size=32, validation_split=0.2)

save_dir = 'frontend/models/decision_net/saved_model'
os.makedirs(save_dir, exist_ok=True)
model.save(save_dir)

# Convert for TF.js
# run in shell:
# tensorflowjs_converter --input_format=tf_saved_model --output_format=tfjs_graph_model \
#   frontend/models/decision_net/saved_model frontend/models/decision_net/web_model
