import 'dart:io';
import 'dart:typed_data';

import 'package:file_picker/file_picker.dart';

import 'action_registry.dart';
import 'neura_action.dart';
import 'sandbox_paths.dart';
import 'undo_stack.dart';
import 'crypto_vault.dart';

class NeuraSandboxIOActions {
  final NeuraSandbox sandbox;
  final NeuraUndoStack undo;
  final NeuraCryptoVault vault;

  NeuraSandboxIOActions({
    NeuraSandbox? sandbox,
    NeuraUndoStack? undo,
    NeuraCryptoVault? vault,
  })  : sandbox = sandbox ?? NeuraSandbox(),
        undo = undo ?? NeuraUndoStack(),
        vault = vault ?? NeuraCryptoVault();

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'sandbox_import_file',
        title: 'Import File into Sandbox',
        description: 'Copies a chosen file into Neura’s sandbox (optional encryption).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final encrypt = (req.args['encrypt'] as bool?) ?? false;
          final passphrase = (req.args['passphrase'] as String?) ?? '';

          final picked = await FilePicker.platform.pickFiles(withData: true);
          if (picked == null || picked.files.isEmpty) {
            return NeuraActionResult.error('No file selected.');
          }
          final f = picked.files.first;
          final name = (req.args['destName'] as String?)?.trim().isNotEmpty == true
              ? (req.args['destName'] as String).trim()
              : (f.name.isNotEmpty ? f.name : 'import.bin');

          if (name.contains('..') || name.contains('/') || name.contains('\\')) {
            return NeuraActionResult.error('Invalid destName.');
          }

          final root = await sandbox.root();
          final destRel = encrypt ? '$name.enc' : name;
          final destEnt = await sandbox.resolve(destRel);
          final dest = File(destEnt.path);

          if (!sandbox.isWithinSandbox(dest.path, root.path)) {
            return NeuraActionResult.error('Denied: outside sandbox');
          }

          Uint8List bytes;
          if (f.bytes != null) {
            bytes = f.bytes!;
          } else if (f.path != null) {
            bytes = await File(f.path!).readAsBytes();
          } else {
            return NeuraActionResult.error('Could not read selected file.');
          }

          String? previous;
          if (dest.existsSync()) previous = String.fromCharCodes(dest.readAsBytesSync());

          dest.parent.createSync(recursive: true);
          if (encrypt) {
            if (passphrase.trim().isEmpty) return NeuraActionResult.error('Missing passphrase for encryption.');
            final enc = await vault.encryptBytes(plain: bytes, passphrase: passphrase);
            await dest.writeAsBytes(enc, flush: true);
          } else {
            await dest.writeAsBytes(bytes, flush: true);
          }

          undo.push(
            NeuraUndoEntry(
              title: 'Undo import: $destRel',
              undoActionId: 'sandbox_delete',
              undoArgs: {'path': destRel},
            ),
          );

          return NeuraActionResult.success('Imported', data: {
            'dest': destRel,
            'encrypted': encrypt,
            'size': bytes.length,
          });
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_export_file',
        title: 'Export Sandbox File',
        description: 'Exports a sandbox file to user-chosen location (decrypts if needed).',
        risk: NeuraRisk.high,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final rel = (req.args['path'] as String?)?.trim() ?? '';
          final passphrase = (req.args['passphrase'] as String?) ?? '';

          if (rel.isEmpty) return NeuraActionResult.error('Missing path');

          final root = await sandbox.root();
          final ent = await sandbox.resolve(rel);
          final src = File(ent.path);

          if (!sandbox.isWithinSandbox(src.path, root.path)) return NeuraActionResult.error('Denied: outside sandbox');
          if (!src.existsSync()) return NeuraActionResult.error('Not found: $rel');

          final suggestedName = rel.endsWith('.enc') ? rel.substring(0, rel.length - 4) : rel;
          final savePath = await FilePicker.platform.saveFile(
            dialogTitle: 'Export ${suggestedName}',
            fileName: suggestedName.split(Platform.pathSeparator).last,
          );
          if (savePath == null || savePath.trim().isEmpty) {
            return NeuraActionResult.error('Export cancelled.');
          }

          final raw = await src.readAsBytes();
          Uint8List outBytes = Uint8List.fromList(raw);

          if (_looksEncrypted(outBytes)) {
            if (passphrase.trim().isEmpty) return NeuraActionResult.error('Missing passphrase to decrypt export.');
            outBytes = await vault.decryptBytes(enc: outBytes, passphrase: passphrase);
          }

          final outFile = File(savePath);
          outFile.parent.createSync(recursive: true);
          await outFile.writeAsBytes(outBytes, flush: true);

          return NeuraActionResult.success('Exported', data: {'from': rel, 'to': savePath, 'bytes': outBytes.length});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_read_text',
        title: 'Read Text File (Sandbox)',
        description: 'Reads a sandbox text file (decrypts if .enc).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final rel = (req.args['path'] as String?)?.trim() ?? '';
          final passphrase = (req.args['passphrase'] as String?) ?? '';
          if (rel.isEmpty) return NeuraActionResult.error('Missing path');

          final root = await sandbox.root();
          final ent = await sandbox.resolve(rel);
          final f = File(ent.path);
          if (!sandbox.isWithinSandbox(f.path, root.path)) return NeuraActionResult.error('Denied: outside sandbox');
          if (!f.existsSync()) return NeuraActionResult.error('Not found: $rel');

          final raw = await f.readAsBytes();
          Uint8List bytes = Uint8List.fromList(raw);
          if (_looksEncrypted(bytes)) {
            if (passphrase.trim().isEmpty) return NeuraActionResult.error('Missing passphrase to decrypt.');
            bytes = await vault.decryptBytes(enc: bytes, passphrase: passphrase);
          }

          final text = String.fromCharCodes(bytes);
          return NeuraActionResult.success('OK', data: {'text': text, 'bytes': bytes.length});
        },
      ),
    );
  }

  bool _looksEncrypted(Uint8List bytes) {
    if (bytes.length < 4) return false;
    return bytes[0] == 0x4E && bytes[1] == 0x45 && bytes[2] == 0x4E && bytes[3] == 0x43; // NENC
  }
}
