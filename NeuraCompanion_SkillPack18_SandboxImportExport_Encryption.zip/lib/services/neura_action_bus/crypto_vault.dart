import 'dart:convert';
import 'dart:typed_data';

import 'package:cryptography/cryptography.dart';

/// NeuraCryptoVault
/// - AES-GCM for encryption
/// - PBKDF2(HMAC-SHA256) for key derivation
///
/// File format (bytes):
/// 0..3  : ASCII "NENC"
/// 4..19 : salt (16 bytes)
/// 20..31: nonce (12 bytes)
/// 32..47: mac (16 bytes)
/// 48..  : ciphertext
class NeuraCryptoVault {
  static final AesGcm _cipher = AesGcm.with256bits();
  static const int _saltLen = 16;
  static const int _nonceLen = 12;

  Future<SecretKey> deriveKey({
    required String passphrase,
    required Uint8List salt,
    int iterations = 120000,
  }) async {
    final pbkdf2 = Pbkdf2(
      macAlgorithm: Hmac.sha256(),
      iterations: iterations,
      bits: 256,
    );
    return pbkdf2.deriveKey(
      secretKey: SecretKey(utf8.encode(passphrase)),
      nonce: salt,
    );
  }

  Future<Uint8List> encryptBytes({
    required Uint8List plain,
    required String passphrase,
  }) async {
    final salt = _rand(_saltLen);
    final nonce = _rand(_nonceLen);
    final key = await deriveKey(passphrase: passphrase, salt: salt);
    final box = await _cipher.encrypt(
      plain,
      secretKey: key,
      nonce: nonce,
    );

    final out = BytesBuilder(copy: false);
    out.add(utf8.encode('NENC'));
    out.add(salt);
    out.add(nonce);
    out.add(Uint8List.fromList(box.mac.bytes)); // 16
    out.add(Uint8List.fromList(box.cipherText));
    return out.toBytes();
  }

  Future<Uint8List> decryptBytes({
    required Uint8List enc,
    required String passphrase,
  }) async {
    if (enc.length < 48) throw StateError('Invalid encrypted payload (too small).');
    final magic = utf8.decode(enc.sublist(0, 4));
    if (magic != 'NENC') throw StateError('Invalid encrypted payload (bad header).');

    final salt = Uint8List.fromList(enc.sublist(4, 4 + _saltLen));
    final nonce = Uint8List.fromList(enc.sublist(4 + _saltLen, 4 + _saltLen + _nonceLen));
    final macBytes = enc.sublist(4 + _saltLen + _nonceLen, 4 + _saltLen + _nonceLen + 16);
    final cipherText = enc.sublist(48);

    final key = await deriveKey(passphrase: passphrase, salt: salt);
    final box = SecretBox(
      cipherText,
      nonce: nonce,
      mac: Mac(macBytes),
    );
    final plain = await _cipher.decrypt(box, secretKey: key);
    return Uint8List.fromList(plain);
  }

  Uint8List _rand(int n) {
    final r = Cryptography.instance.randomBytes(n);
    return Uint8List.fromList(r);
  }
}
