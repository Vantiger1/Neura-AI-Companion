# Skill Pack 18 — Sandbox Import/Export + Optional Encryption

This patch adds real-world IO to Neura’s sandbox:
- Import files into sandbox using a file picker (Windows + Android supported by `file_picker`)
- Export sandbox files to a user-selected path
- Read text files (including decrypting `.enc` files)

## What you get
- `crypto_vault.dart`: AES-GCM encryption/decryption format ("NENC" header)
- `sandbox_io_actions.dart`:
  - `sandbox_import_file` (optional encryption)
  - `sandbox_export_file` (decrypts if encrypted)
  - `sandbox_read_text` (decrypts if encrypted)

## Dependencies (add to pubspec.yaml)
```yaml
dependencies:
  file_picker: any
  cryptography: any
```
Also ensure `path_provider` exists (SkillPack17).

Then:
- `flutter pub get`

## Register actions at boot
In your kernel boot, after registering other actions:
```dart
final undo = NeuraUndoStack();
NeuraSandboxActions(undo: undo).registerAll(registry);
NeuraSandboxIOActions(undo: undo).registerAll(registry);
```

## Action args
### sandbox_import_file
- encrypt: bool (default false)
- passphrase: String (required if encrypt==true)
- destName: String (optional; otherwise uses picked filename)

### sandbox_export_file
- path: String (sandbox relative path)
- passphrase: String (required if exporting encrypted file)

### sandbox_read_text
- path: String
- passphrase: String (required if encrypted)

## Why this matters
This is the bridge from “Neura can manipulate a safe sandbox” → “Neura can actually help with user documents/workflows”
without ever touching system directories directly.

## Next
Step 19: “Knowledge Pack → Document workflow” (index imported docs locally + semantic search offline).
