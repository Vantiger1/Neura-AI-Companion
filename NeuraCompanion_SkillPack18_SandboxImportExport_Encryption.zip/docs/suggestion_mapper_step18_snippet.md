/// Add these cases into your existing NeuraSuggestionMapper switch:
///
/// case 'sandbox_import_file':
///   return {'actionId':'sandbox_import_file','args':{
///     'encrypt': (suggestion['encrypt'] ?? false) == true,
///     'passphrase': (suggestion['passphrase'] ?? ''),
///     'destName': (suggestion['destName'] ?? ''),
///   }};
///
/// case 'sandbox_export_file':
///   return {'actionId':'sandbox_export_file','args':{
///     'path': (suggestion['path'] ?? ''),
///     'passphrase': (suggestion['passphrase'] ?? ''),
///   }};
///
/// case 'sandbox_read_text':
///   return {'actionId':'sandbox_read_text','args':{
///     'path': (suggestion['path'] ?? ''),
///     'passphrase': (suggestion['passphrase'] ?? ''),
///   }};
