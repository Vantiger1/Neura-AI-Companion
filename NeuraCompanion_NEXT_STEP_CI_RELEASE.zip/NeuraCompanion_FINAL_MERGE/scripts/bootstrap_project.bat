@echo off
setlocal

echo === Neura Companion Bootstrap ===
where flutter >nul 2>&1
if errorlevel 1 (
  echo Flutter not found in PATH.
  echo Install Flutter, then rerun this script.
  exit /b 1
)

REM Validate that android looks like a Flutter scaffold
set NEED_REPAIR=0
if not exist android\ (
  set NEED_REPAIR=1
) else (
  if not exist android\app\src\main\AndroidManifest.xml set NEED_REPAIR=1
  if not exist android\settings.gradle if not exist android\settings.gradle.kts set NEED_REPAIR=1
)

if "%NEED_REPAIR%"=="1" (
  echo Platform folders missing or not a valid Flutter scaffold. Repairing...
  call scripts\repair_platforms.bat
  if errorlevel 1 exit /b 1
)

echo Running pub get...
flutter pub get || exit /b 1

echo Running analyze...
flutter analyze || exit /b 1

echo Running tests...
flutter test || exit /b 1

echo Done. Next: flutter run
