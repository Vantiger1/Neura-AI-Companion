#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

echo "=== Neura Companion Bootstrap ==="

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter not found in PATH. Install Flutter and retry." >&2
  exit 1
fi

is_flutter_android_scaffold() {
  [ -f "android/settings.gradle" ] || [ -f "android/settings.gradle.kts" ] || return 1
  [ -f "android/app/src/main/AndroidManifest.xml" ] || return 1
  # Flutter-generated android has 'flutter' module reference in settings.gradle(.kts)
  if grep -R "flutter" -n "android" >/dev/null 2>&1; then
    return 0
  fi
  return 1
}

# Repair if missing OR clearly not a Flutter scaffold.
if [ ! -d android ] || ! is_flutter_android_scaffold; then
  echo "Platform folders missing or not a valid Flutter scaffold. Repairing..."
  ./scripts/repair_platforms.sh
fi

flutter pub get
flutter analyze
flutter test

echo "Done. Next: flutter run"
