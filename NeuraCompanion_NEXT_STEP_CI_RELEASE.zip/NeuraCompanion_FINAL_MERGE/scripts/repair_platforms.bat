@echo off
setlocal enabledelayedexpansion

REM Recreate Flutter platform folders if missing or not a valid Flutter scaffold.
set ROOT=%~dp0\..
cd /d "%ROOT%"

where flutter >nul 2>&1
if errorlevel 1 (
  echo Flutter not found in PATH. Install Flutter and retry.
  exit /b 1
)

set STAMP=.platform_backups
if not exist "%STAMP%" mkdir "%STAMP%"

for /f "tokens=1-4 delims=/ " %%a in ('date /t') do set DTS=%%d%%b%%c
for /f "tokens=1-2 delims=: " %%a in ('time /t') do set TTS=%%a%%b
set TS=%DTS%_%TTS%

call :backup android
call :backup ios
call :backup macos
call :backup linux
call :backup windows
call :backup web

echo Recreating Flutter platform folders...
flutter create . --platforms=android,ios,web,windows,macos,linux
if errorlevel 1 exit /b 1

echo Restoring deps...
flutter pub get
if errorlevel 1 exit /b 1

echo Done. Platforms repaired.
exit /b 0

:backup
set DIR=%~1
if exist "%DIR%\" (
  echo Backing up %DIR% to %STAMP%\%DIR%_%TS%.zip
  powershell -NoProfile -Command "Compress-Archive -Path '%DIR%' -DestinationPath '%STAMP%\%DIR%_%TS%.zip' -Force" >nul 2>&1
  rmdir /s /q "%DIR%"
)
exit /b 0
