#!/bin/bash
# Legacy script (Firebase Hosting). Recommended: GitHub Pages via .github/workflows/pages.yml
set -e

echo "This project now defaults to GitHub Pages deployment via GitHub Actions."
echo "If you still want Firebase Hosting, add firebase.json + .firebaserc and install firebase-tools."

echo "Building Flutter Web..."
flutter build web --release

echo "Done. Web build output is in build/web"
