#!/usr/bin/env bash
set -euo pipefail

# Recreate Flutter platform folders if they are missing or not a valid Flutter scaffold.
# This is intentionally destructive to the platform folders, but it backs them up first.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if ! command -v flutter >/dev/null 2>&1; then
  echo "Flutter not found in PATH. Install Flutter and retry." >&2
  exit 1
fi

STAMP_DIR=".platform_backups"
mkdir -p "$STAMP_DIR"
TS="$(date +%Y%m%d_%H%M%S)"

backup_dir() {
  local d="$1"
  if [ -d "$d" ]; then
    echo "Backing up $d -> $STAMP_DIR/${d}_${TS}.zip"
    (cd "$ROOT_DIR" && zip -qr "$STAMP_DIR/${d}_${TS}.zip" "$d") || true
    rm -rf "$d"
  fi
}

# Always recreate these to guarantee a working Flutter scaffold.
backup_dir android
backup_dir ios
backup_dir macos
backup_dir linux
backup_dir windows
backup_dir web

echo "Recreating Flutter platform folders..."
flutter create . --platforms=android,ios,web,windows,macos,linux

echo "Restoring pubspec lock + fetching deps..."
flutter pub get

echo "Done. Platforms repaired."
