# Neura Companion (Final Merge Scaffold)

This bundle is a merged Flutter source tree from the ZIPs you provided.

What I fixed/added:
- `pubspec.yaml` is valid (no duplicate keys) and includes packages referenced by the code.
- Neura modules live in `lib/src/modules/neura/`.
- Bottom nav includes a **Neura** tab.
- Bootstrap scripts that regenerate missing platform folders with `flutter create`.
- `checksums.sha256` + `manifest.json` for integrity.

## Quick start (Windows)
1) Install Flutter and ensure `flutter` is in PATH.
2) Open a terminal in this folder.
3) Run: `scripts\bootstrap_project.bat`
4) Run: `flutter run`

## Quick start (macOS/Linux)
1) Install Flutter and ensure `flutter` is in PATH.
2) In this folder run:
   - `chmod +x scripts/bootstrap_project.sh`
   - `./scripts/bootstrap_project.sh`
3) Run: `flutter run`

## Notes
- The platform folders (`android/`, `ios/`, etc.) were missing in the source ZIPs, so the bootstrap step creates them.
- Azure + Firebase deps are included but are optional until you wire keys/config.
