# Neura Companion Preflight Checklist

## Local build sanity
- Run `scripts/bootstrap_project.(bat|sh)`
- Confirm `flutter analyze` is clean
- Confirm `flutter test` passes

## Android (Play Store)
- Build AAB: `flutter build appbundle --release`
- Set up app signing (keystore) and verify `applicationId` + version
- Verify permissions (microphone, storage) are justified in Play Console

## Web
- Build: `flutter build web --release`
- For GitHub Pages, use `--base-href "/<repo>/"`

## Windows
- Build: `flutter build windows --release`
- Zip `build/windows/x64/runner/Release/`

## Safety & compliance (important)
- Ensure the app clearly states it is not a medical device and not a replacement for professional care.
- Provide crisis resources in the Help screen.
- Verify Privacy Policy + Terms are accessible from Settings.
