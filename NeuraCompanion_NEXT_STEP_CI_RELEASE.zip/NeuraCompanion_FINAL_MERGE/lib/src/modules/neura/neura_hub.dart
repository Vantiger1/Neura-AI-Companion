import 'package:flutter/material.dart';

import 'dream_journal_entry.dart';
import 'neura_dream_calendar_navigator.dart';
import 'neura_dream_journal_screen.dart';
import 'neura_dream_show_player.dart';
import 'neura_joke_panel_animated.dart';

class NeuraHubScreen extends StatelessWidget {
  const NeuraHubScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final entries = <DreamJournalEntry>[];
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Hub')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ListTile(
            leading: const Icon(Icons.book_rounded),
            title: const Text('Dream Journal'),
            subtitle: const Text('Browse entries.'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => NeuraDreamJournalScreen(dreamEntries: entries),
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.calendar_month_rounded),
            title: const Text('Dream Calendar'),
            subtitle: const Text('Navigate by date.'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => NeuraDreamCalendarNavigator(dreamEntries: entries),
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.auto_awesome_motion_rounded),
            title: const Text('Dream Show'),
            subtitle: const Text('Cinematic replay.'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => NeuraDreamShowPlayer(entries: entries),
              ),
            ),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.emoji_emotions_rounded),
            title: const Text('Jokes'),
            subtitle: const Text('Optional humor panel.'),
            trailing: const Icon(Icons.chevron_right_rounded),
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (_) => NeuraJokePanelAnimated(
                  humorEngine: NeuraHumorEngine(),
                  prefs: NeuraJokePreferencesManager()..loadPreferences(),
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}
