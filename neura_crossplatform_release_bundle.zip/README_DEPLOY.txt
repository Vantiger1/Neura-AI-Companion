NEURA CROSS-PLATFORM DEPLOYMENT GUIDE

✅ Android: Place generated APK into android/apk/
✅ Web: Deploy contents of web/ to Firebase or GitHub Pages
✅ Windows: Use Inno Setup with neura_installer_windows.iss
✅ macOS: Use DMG packaging script in macos/
✅ Firebase: Use firebase_dashboard/index.html with Firebase CLI

🔥 ALL MODULES INCLUDED:
- Neura AI Voice & Personality
- BLE & Mood Tracking
- Firebase Sync & Web Dashboard
- Pro Unlock + Onboarding