#!/bin/bash
# Script to package Neura as a macOS DMG
