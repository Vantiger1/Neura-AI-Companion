import 'package:flutter_tts/flutter_tts.dart';

class NeuraVoiceSpeaker {
  final FlutterTts _tts = FlutterTts();

  Future<void> speak(String text, {String tone = "default"}) async {
    await _tts.setLanguage("en-US");
    await _tts.setPitch(tone == "zen" ? 0.9 : tone == "goofy" ? 1.2 : 1.0);
    await _tts.setSpeechRate(tone == "zen" ? 0.4 : tone == "motivational" ? 0.6 : 0.5);
    await _tts.speak(text);
  }
}