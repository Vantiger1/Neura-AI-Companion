import 'package:flutter/material.dart';
import 'dart:math';

class NeuraFaceAnimation extends StatefulWidget {
  final bool isSpeaking;
  final String mood;

  const NeuraFaceAnimation({Key? key, required this.isSpeaking, required this.mood}) : super(key: key);

  @override
  _NeuraFaceAnimationState createState() => _NeuraFaceAnimationState();
}

class _NeuraFaceAnimationState extends State<NeuraFaceAnimation> with TickerProviderStateMixin {
  late AnimationController _blinkController;
  late AnimationController _mouthController;

  @override
  void initState() {
    super.initState();
    _blinkController = AnimationController(vsync: this, duration: Duration(milliseconds: 300))..repeat(reverse: true);
    _mouthController = AnimationController(vsync: this, duration: Duration(milliseconds: 200));
    if (widget.isSpeaking) _mouthController.repeat(reverse: true);
  }

  @override
  void didUpdateWidget(covariant NeuraFaceAnimation oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.isSpeaking) {
      _mouthController.repeat(reverse: true);
    } else {
      _mouthController.stop();
    }
  }

  @override
  void dispose() {
    _blinkController.dispose();
    _mouthController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Image.asset('assets/images/neura_base.png', height: 150),
        Positioned(
          top: 45,
          child: FadeTransition(
            opacity: Tween<double>(begin: 1, end: 0).animate(_blinkController),
            child: Container(width: 60, height: 8, color: Colors.black),
          ),
        ),
        Positioned(
          bottom: 30,
          child: SizeTransition(
            axis: Axis.vertical,
            sizeFactor: _mouthController,
            child: Container(width: 40, height: 10, color: Colors.red),
          ),
        ),
      ],
    );
  }
}