import 'package:flutter/material.dart';

class NeuraOnboarding extends StatelessWidget {
  final Function(String tone) onComplete;

  const NeuraOnboarding({Key? key, required this.onComplete}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final tones = {
      "zen": "🌿 Calm & Reflective",
      "motivational": "🔥 Driven & Uplifting",
      "goofy": "😂 Silly & Playful"
    };

    return Scaffold(
      appBar: AppBar(title: Text("Welcome to Neura")),
      body: Padding(
        padding: EdgeInsets.all(16),
        child: Column(
          children: [
            Text("How should Neura interact with you?", style: TextStyle(fontSize: 18)),
            SizedBox(height: 20),
            ...tones.entries.map((entry) {
              return Card(
                child: ListTile(
                  title: Text(entry.value),
                  onTap: () => onComplete(entry.key),
                ),
              );
            }).toList()
          ],
        ),
      ),
    );
  }
}