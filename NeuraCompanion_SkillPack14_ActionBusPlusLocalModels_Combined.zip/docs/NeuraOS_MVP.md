# Neura OS (Android + Windows) — Fastest Build Path

This defines the **fastest, safest** way to evolve Neura into an OS-layer that can eventually replace traditional operating systems.

## Strategy

### 1) Neura Shell (now)
Run on top of Windows and Android so users can adopt instantly.

**What ships:**
- Always-on Neura presence (avatar + command palette)
- Intent routing (text → actions)
- Safe web search / knowledge view
- Navigation control of internal modules

### 2) Neura Control Plane (next)
Add device actions behind explicit permission gates.

**Windows actions (allowlist):**
- Launch apps
- Search files
- Read calendar/email (optional)
- Run vetted PowerShell scripts

**Android actions (allowlist):**
- Launch apps via intents
- Create reminders/alarms
- Read notifications (with permission)

### 3) Neura Desktop (later)
Replace *parts* of the OS experience:
- Custom desktop/home surface
- Window/workspace manager (optional)
- Full automation hub

## Guardrails (non-negotiable)

- Clear **permission model** for every capability.
- **Explainability**: Neura shows what she will do before she does it.
- **Reversible**: every system-level change has a rollback path.

## This repo’s MVP implementation

In this bundle we added:

- `lib/src/neura_shell/neura_shell_host.dart` — always-on Neura overlay
- `lib/src/neura_shell/command_palette.dart` — command UI
- `lib/src/neura_shell/intent_router.dart` — MVP intent routing
- `lib/screens/web_search_screen.dart` — in-app web search (WebView)
- `scripts/windows/*` — startup + optional shell replacement scripts

## Next concrete upgrades

1. Add speech input to the palette (already dependency: `speech_to_text`).
2. Add a **Plugin Action Bus**:
   - `Action(id, title, requiresPermissions, run())`
   - register module actions + device actions
3. Add **Memory**: short-term session memory + long-term “chapters” (encrypted).
4. Add **Realtime presence**: idle behaviors + mood-reactive expressions.
