# SkillPack14 — ActionBus + Local Models (Combined)

This patch **combines**:
- NeuraShell ActionBus + Command Palette (from `NeuraCompanion_ActionBus_VoicePatch.zip`)
- Desktop local runtime + streaming bridge (from `NeuraCompanion_SkillPack13_WindowsLocalRuntime_StreamingBridge.zip`)

## What you get
- A command palette + allowlisted action system to route user intents.
- A desktop local llama.cpp server runner + OpenAI-compat client that your chat modules can stream from.
- A single place to wire *approvals* (Full Access checklist/disclaimer) before risky actions.

## Quick wiring (Flutter)
1) Ensure these imports exist in your shell host init (or app init):

```dart
// Run once during app startup
await NeuraLocalModelSettings.I.init();
await NeuraDesktopLlmOrchestrator.I.init();
```

2) Make your chat UI call the router:

```dart
final router = NeuraModelRouter.I;
final stream = router.streamChat(prompt, history: history);
```

3) Add 3 commands to your `NeuraIntentRouter`:
- "local model status"
- "start local model" (uses saved model path)
- "stop local model"

## Approval gating
Use your existing Full Access checklist/disclaimer screen to set:
- `neura_full_access_enabled = true/false`
- capability toggles (launch apps, file access, automation, network)

Then, in your action executor, deny or require approval when Full Access is not enabled.

