import 'package:flutter/material.dart';
import 'modules/navigation/enhanced_navigation.dart';
import 'modules/core/ai_engine.dart';
import 'neura_shell/neura_shell_host.dart';

import 'modules/journal/journal.dart';
import 'modules/mood/mood_checkin.dart';
import 'modules/goals/goal_tracker.dart';
import 'modules/meditation/meditation.dart';
import 'modules/settings/settings.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neuro Companion',
      theme: ThemeData.dark(),
      builder: (context, child) => NeuraShellHost(child: child ?? const SizedBox.shrink()),
      home: const EnhancedNavigation(),
      routes: {
        '/home': (_) => const EnhancedNavigation(),
        '/journal': (_) => const JournalScreen(),
        '/checkin': (_) => const MoodCheckinScreen(),
        '/goals': (_) => const GoalTrackerScreen(),
        '/meditation': (_) => const MeditationScreen(),
        '/settings': (_) => const SettingsScreen(),
      },
    );
  }
}