import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

import 'command_palette.dart';
import 'intent_router.dart';
import 'actions/default_registry.dart';
import 'actions/action_registry.dart';
import 'voice/neura_voice_controller.dart';

/// Hosts the main app UI with an always-available Neura presence layered on top.
///
/// This is the first step toward a "Neura OS layer":
/// - The underlying app remains standard Flutter navigation.
/// - Neura is present on every screen.
/// - A command palette allows the user to control the app (and later, the device).
class NeuraShellHost extends StatefulWidget {
  final Widget child;
  const NeuraShellHost({super.key, required this.child});

  @override
  State<NeuraShellHost> createState() => _NeuraShellHostState();
}

class _NeuraShellHostState extends State<NeuraShellHost> {
  bool _paletteOpen = false;
  Offset _pos = const Offset(24, 140);
  late final NeuraActionRegistry _registry;
  final NeuraVoiceController _voice = NeuraVoiceController();
  String _voiceHint = '';

  void _togglePalette() => setState(() => _paletteOpen = !_paletteOpen);
  void _closePalette() => setState(() => _paletteOpen = false);

  @override
  void initState() {
    super.initState();
    _registry = buildDefaultNeuraRegistry();
    _initVoice();
  }

  Future<void> _initVoice() async {
    final ok = await _voice.initialize();
    if (!mounted) return;
    setState(() {
      _voiceHint = ok ? 'Hold mic to talk' : 'Voice unavailable here';
    });
  }

  @override
  void dispose() {
    _voice.dispose();
    super.dispose();
  }

  Future<void> _handleCommand(NeuraIntent intent, String raw) async {
    // Close first to keep UI snappy.
    _closePalette();
    if (!mounted) return;
    await _registry.execute(context, intent: intent, raw: raw, fromVoice: false);
  }

  Future<void> _runVoiceCommand(String utterance) async {
    final raw = utterance.trim();
    if (raw.isEmpty) return;
    final intent = NeuraIntentRouter.route(raw);
    await _registry.execute(context, intent: intent, raw: raw, fromVoice: true);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final isDesktop = !kIsWeb && (defaultTargetPlatform == TargetPlatform.windows || defaultTargetPlatform == TargetPlatform.linux || defaultTargetPlatform == TargetPlatform.macOS);

    // Keep Neura on-screen if the window changes.
    final maxX = math.max(0.0, size.width - 92);
    final maxY = math.max(0.0, size.height - 92);
    _pos = Offset(_pos.dx.clamp(0.0, maxX), _pos.dy.clamp(0.0, maxY));

    return Stack(
      children: [
        widget.child,
        Positioned(
          left: isDesktop ? null : _pos.dx,
          top: isDesktop ? 120 : _pos.dy,
          right: isDesktop ? 18 : null,
          child: _NeuraAvatar(
            onTap: _togglePalette,
            onMicHoldStart: () async {
              if (!_voice.isAvailable) {
                // Minimal friction: fall back to opening the palette.
                _togglePalette();
                return;
              }
              setState(() {});
              await _voice.startListening();
              setState(() {});
            },
            onMicHoldEnd: () async {
              if (!_voice.isAvailable) return;
              await _voice.stopListening();
              final said = _voice.finalResult.trim().isNotEmpty ? _voice.finalResult : _voice.partial;
              setState(() {});
              await _runVoiceCommand(said);
            },
            isListening: _voice.isListening,
            hint: _voiceHint,
            onDrag: (delta) {
              if (isDesktop) return; // desktop is pinned for now
              setState(() => _pos += delta);
            },
          ),
        ),
        if (_paletteOpen)
          NeuraCommandPalette(
            onCommand: _handleCommand,
            onClose: _closePalette,
          ),
      ],
    );
  }
}

class _NeuraAvatar extends StatelessWidget {
  final VoidCallback onTap;
  final VoidCallback onMicHoldStart;
  final VoidCallback onMicHoldEnd;
  final bool isListening;
  final String hint;
  final ValueChanged<Offset> onDrag;
  const _NeuraAvatar({
    required this.onTap,
    required this.onMicHoldStart,
    required this.onMicHoldEnd,
    required this.isListening,
    required this.hint,
    required this.onDrag,
  });

  @override
  Widget build(BuildContext context) {
    final hasLottie = DefaultAssetBundle.of(context)
        .loadString('assets/animations/neura_idle.json')
        .then((_) => true)
        .catchError((_) => false);

    // Note: We intentionally avoid awaiting here; if the asset doesn't exist,
    // the Future completes false and the placeholder is still valid.
    return Tooltip(
      message: hint.isEmpty ? 'Neura' : hint,
      child: GestureDetector(
        onTap: onTap,
        onPanUpdate: (d) => onDrag(d.delta),
        child: Stack(
          clipBehavior: Clip.none,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 180),
              width: 74,
              height: 74,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(18),
                border: Border.all(color: isListening ? Colors.greenAccent.withOpacity(0.8) : Colors.white24),
                color: const Color(0xFF0F0F0F),
                boxShadow: [
                  BoxShadow(
                    blurRadius: isListening ? 28 : 18,
                    spreadRadius: isListening ? 2 : 1,
                    color: Colors.black54,
                  ),
                ],
              ),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: FutureBuilder<bool>(
                  future: hasLottie,
                  builder: (context, snap) {
                    final ok = snap.data == true;
                    if (ok) {
                      return Lottie.asset('assets/animations/neura_idle.json', fit: BoxFit.cover);
                    }
                    return Image.asset('assets/images/ai_avatar.png', fit: BoxFit.cover);
                  },
                ),
              ),
            ),
            Positioned(
              right: -6,
              bottom: -6,
              child: GestureDetector(
                onLongPressStart: (_) => onMicHoldStart(),
                onLongPressEnd: (_) => onMicHoldEnd(),
                child: Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: isListening ? Colors.greenAccent.withOpacity(0.9) : const Color(0xFF1B1B1B),
                    border: Border.all(color: Colors.white24),
                  ),
                  child: Icon(
                    isListening ? Icons.graphic_eq : Icons.mic,
                    size: 16,
                    color: isListening ? Colors.black : Colors.white70,
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
