import 'package:flutter/foundation.dart';

/// Text → Intent.
///
/// This is intentionally deterministic and allowlisted.
///
/// Later upgrades:
/// - LLM classification (with guardrails)
/// - per-user custom commands
/// - multi-step plans
class NeuraIntentRouter {
  static NeuraIntent route(String raw) {
    final text = raw.trim();
    final lower = text.toLowerCase();

    if (text.isEmpty) return const NeuraIntent.none();

    // Web search patterns.
    if (lower.startsWith('search ') || lower.startsWith('google ') || lower.startsWith('web ')) {
      final q = text.substring(text.indexOf(' ') + 1).trim();
      return NeuraIntent.action('web.search', args: q.isEmpty ? text : q);
    }
    if (lower.startsWith('find ')) {
      final q = text.substring(5).trim();
      return NeuraIntent.action('web.search', args: q);
    }

    // Navigation shortcuts.
    if (lower == 'journal' || lower.contains('open journal')) {
      return const NeuraIntent.action('nav.journal');
    }
    if (lower == 'checkin' || lower == 'check-in' || lower.contains('check in') || lower.contains('open check')) {
      return const NeuraIntent.action('nav.checkin');
    }
    if (lower == 'mood' || lower.contains('open mood')) {
      return const NeuraIntent.action('nav.checkin');
    }
    if (lower == 'goals' || lower.contains('open goals')) {
      return const NeuraIntent.action('nav.goals');
    }
    if (lower == 'meditation' || lower.contains('open meditation')) {
      return const NeuraIntent.action('nav.meditation');
    }
    if (lower == 'settings' || lower.contains('open settings')) {
      return const NeuraIntent.action('nav.settings');
    }
    if (lower == 'home' || lower.contains('dashboard')) {
      return const NeuraIntent.action('nav.home');
    }

    // OS / device intents (still allowlisted; may be no-op if unsupported).
    if (lower.startsWith('open app ')) {
      final name = text.substring('open app '.length).trim();
      return NeuraIntent.action('device.open_app', args: name);
    }
    if (lower.startsWith('open file ')) {
      final path = text.substring('open file '.length).trim();
      return NeuraIntent.action('device.open_file', args: path);
    }

    // Help.
    if (lower == 'help' || lower.contains('what can you do')) {
      return const NeuraIntent.action('ui.help');
    }

    // Default: safe web search. (Useful + non-destructive.)
    return NeuraIntent.action('web.search', args: text);
  }
}

@immutable
class NeuraIntent {
  final String actionId;
  final String? args;

  const NeuraIntent._(this.actionId, this.args);

  const NeuraIntent.none() : this._('none', null);

  const NeuraIntent.action(this.actionId, {this.args}) : this._(actionId, args);

  bool get isNone => actionId == 'none';
}
