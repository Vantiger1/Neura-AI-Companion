import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

/// Cross-platform voice capture façade.
///
/// - On supported platforms, uses speech_to_text.
/// - On unsupported platforms, it fails closed (unavailable) so the app still runs.
class NeuraVoiceController {
  final stt.SpeechToText _stt = stt.SpeechToText();

  bool _available = false;
  bool _listening = false;
  String _partial = '';
  String _final = '';

  final StreamController<String> _partialStream = StreamController<String>.broadcast();
  final StreamController<String> _finalStream = StreamController<String>.broadcast();

  bool get isAvailable => _available;
  bool get isListening => _listening;
  String get partial => _partial;
  String get finalResult => _final;

  Stream<String> get partialResults => _partialStream.stream;
  Stream<String> get finalResults => _finalStream.stream;

  Future<bool> initialize() async {
    // Conservative: only attempt init on mobile + desktop where plugins may exist.
    try {
      _available = await _stt.initialize(
        onError: (e) {
          _available = false;
        },
      );
    } catch (_) {
      _available = false;
    }
    return _available;
  }

  Future<void> startListening() async {
    if (!_available || _listening) return;
    _partial = '';
    _final = '';
    _listening = true;

    try {
      await _stt.listen(
        onResult: (r) {
          if (r.finalResult) {
            _final = r.recognizedWords;
            _finalStream.add(_final);
          } else {
            _partial = r.recognizedWords;
            _partialStream.add(_partial);
          }
        },
        listenMode: stt.ListenMode.confirmation,
        cancelOnError: true,
        partialResults: true,
      );
    } catch (_) {
      _listening = false;
    }
  }

  Future<void> stopListening() async {
    if (!_listening) return;
    _listening = false;
    try {
      await _stt.stop();
    } catch (_) {}
  }

  Future<void> dispose() async {
    try {
      await stopListening();
      await _partialStream.close();
      await _finalStream.close();
    } catch (_) {}
  }
}

/// Quick platform signal for UI hints.
bool neuraVoiceProbablySupported() {
  if (kIsWeb) return true;
  return defaultTargetPlatform == TargetPlatform.android ||
      defaultTargetPlatform == TargetPlatform.iOS ||
      defaultTargetPlatform == TargetPlatform.macOS ||
      defaultTargetPlatform == TargetPlatform.windows;
}
