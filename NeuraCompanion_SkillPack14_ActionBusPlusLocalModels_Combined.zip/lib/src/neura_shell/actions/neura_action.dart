import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

/// A single allowlisted capability Neura may perform.
///
/// Key principles:
/// - deterministic (no hidden behaviors)
/// - composable (easy to add new actions)
/// - permissioned (capabilities can be gated)
@immutable
abstract class NeuraAction {
  String get id;
  String get title;
  String get description;

  /// Simple, human examples for discovery (command palette, docs).
  List<String> get examples;

  /// Capability gates (soft gates). Actions should still behave safely if a
  /// capability is missing (e.g., show a dialog that it's unavailable).
  Set<NeuraCapability> get requiredCapabilities;

  Future<void> run(BuildContext context, NeuraActionRequest request);
}

@immutable
class NeuraActionRequest {
  final String raw;
  final String? args;
  final bool fromVoice;
  const NeuraActionRequest({required this.raw, this.args, this.fromVoice = false});
}

/// High-level gates. These are not OS permissions directly; they're app-level
/// flags you can enforce per platform / per user.
enum NeuraCapability {
  navigation,
  webSearch,
  deviceOpenApp,
  deviceOpenFile,
  microphone,
  localModels,
}

/// A small helper that keeps dialogs consistent across actions.
Future<void> neuraInfoDialog(BuildContext context, {required String title, required String message}) {
  return showDialog<void>(
    context: context,
    builder: (_) => AlertDialog(
      title: Text(title),
      content: Text(message),
      actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('OK'))],
    ),
  );
}
