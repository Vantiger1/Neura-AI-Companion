import 'action_registry.dart';
import 'builtin_actions.dart';

/// Default allowlist shipped with the app.
NeuraActionRegistry buildDefaultNeuraRegistry() {
  final reg = NeuraActionRegistry();

  // Navigation actions
  reg.register(NavAction(
    id: 'nav.home',
    title: 'Home',
    description: 'Return to the dashboard.',
    route: '/home',
    examples: const ['home', 'open dashboard'],
  ));
  reg.register(NavAction(
    id: 'nav.journal',
    title: 'Journal',
    description: 'Open the Companion Journal.',
    route: '/journal',
    examples: const ['open journal', 'journal'],
  ));
  reg.register(NavAction(
    id: 'nav.checkin',
    title: 'Check-In',
    description: 'Open the Mood Check-In.',
    route: '/checkin',
    examples: const ['open check-in', 'check in'],
  ));
  reg.register(NavAction(
    id: 'nav.goals',
    title: 'Goals',
    description: 'Open the Goal Tracker.',
    route: '/goals',
    examples: const ['open goals', 'goals'],
  ));
  reg.register(NavAction(
    id: 'nav.meditation',
    title: 'Meditation',
    description: 'Open the Meditation module.',
    route: '/meditation',
    examples: const ['open meditation', 'meditation'],
  ));
  reg.register(NavAction(
    id: 'nav.settings',
    title: 'Settings',
    description: 'Open settings.',
    route: '/settings',
    examples: const ['open settings', 'settings'],
  ));

  // Utility actions
  reg.register(WebSearchAction());
  reg.register(HelpAction());

  // Device actions (desktop allowlisted)
  reg.register(DeviceOpenAppAction());
  reg.register(DeviceOpenFileAction());

  return reg;
}
