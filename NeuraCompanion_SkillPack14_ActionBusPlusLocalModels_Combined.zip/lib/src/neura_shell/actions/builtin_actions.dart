import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

import '../../../screens/web_search_screen.dart';
import 'neura_action.dart';
import 'platform/desktop_process.dart';

/// First-party allowlisted actions.
///
/// If you want Neura to do more device stuff, add a new action here and keep
/// it permissioned + auditable.

class NavAction extends NeuraAction {
  final String route;
  final List<String> _examples;
  @override
  final String id;
  @override
  final String title;
  @override
  final String description;

  NavAction({
    required this.id,
    required this.title,
    required this.description,
    required this.route,
    List<String>? examples,
  }) : _examples = examples ?? ['open ${title.toLowerCase()}'];

  @override
  List<String> get examples => _examples;

  @override
  Set<NeuraCapability> get requiredCapabilities => {NeuraCapability.navigation};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    Navigator.of(context).pushNamed(route);
  }
}

class WebSearchAction extends NeuraAction {
  @override
  String get id => 'web.search';

  @override
  String get title => 'Web Search';

  @override
  String get description => 'Opens a safe in-app web search for the query.';

  @override
  List<String> get examples => ['search breathing exercise', 'find CBT grounding'];

  @override
  Set<NeuraCapability> get requiredCapabilities => {NeuraCapability.webSearch};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    final q = (request.args ?? request.raw).trim();
    if (q.isEmpty) {
      await neuraInfoDialog(context, title: 'Search', message: 'Give me something to search for.');
      return;
    }
    Navigator.of(context).push(MaterialPageRoute(builder: (_) => WebSearchScreen(query: q)));
  }
}

class HelpAction extends NeuraAction {
  @override
  String get id => 'ui.help';

  @override
  String get title => 'Help';

  @override
  String get description => 'Shows what Neura can do right now.';

  @override
  List<String> get examples => ['help', 'what can you do'];

  @override
  Set<NeuraCapability> get requiredCapabilities => const {};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    await neuraInfoDialog(
      context,
      title: 'Neura Actions (MVP)',
      message:
          'Try:\n'
          '• open journal\n'
          '• open check-in\n'
          '• open goals\n'
          '• open meditation\n'
          '• open settings\n'
          '• search <anything>\n\n'
          'Voice: tap-and-hold the mic on Neura (if supported on this device).',
    );
  }
}

class DeviceOpenAppAction extends NeuraAction {
  @override
  String get id => 'device.open_app';

  @override
  String get title => 'Open App';

  @override
  String get description =>
      'Attempts to launch an allowlisted app (desktop only). On Android, this is intentionally disabled.';

  @override
  List<String> get examples => ['open app notepad', 'open app calculator'];

  @override
  Set<NeuraCapability> get requiredCapabilities => {NeuraCapability.deviceOpenApp};

  static const Map<String, List<String>> windowsAllowlist = {
    'notepad': ['notepad.exe'],
    'calculator': ['calc.exe'],
    'chrome': ['cmd', '/c', 'start', 'chrome'],
    'edge': ['cmd', '/c', 'start', 'msedge'],
  };

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    final name = (request.args ?? '').trim().toLowerCase();
    if (name.isEmpty) {
      await neuraInfoDialog(context, title: 'Open App', message: 'Say: "open app notepad".');
      return;
    }

    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.windows) {
      final cmd = windowsAllowlist[name];
      if (cmd == null) {
        await neuraInfoDialog(
          context,
          title: 'Open App (allowlisted)',
          message:
              '"$name" is not allowlisted yet.\n\nAllowlisted: ${windowsAllowlist.keys.join(', ')}',
        );
        return;
      }
      try {
        await startProcess(cmd);
      } catch (e) {
        await neuraInfoDialog(context, title: 'Open App failed', message: 'Error: $e');
      }
      return;
    }

    await neuraInfoDialog(
      context,
      title: 'Open App unavailable',
      message: 'This action is currently desktop-only and allowlisted for safety.',
    );
  }
}

class DeviceOpenFileAction extends NeuraAction {
  @override
  String get id => 'device.open_file';

  @override
  String get title => 'Open File';

  @override
  String get description => 'Opens a local file path (desktop only) using the system handler.';

  @override
  List<String> get examples => ['open file C:\\Users\\me\\notes.txt'];

  @override
  Set<NeuraCapability> get requiredCapabilities => {NeuraCapability.deviceOpenFile};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    final path = (request.args ?? '').trim();
    if (path.isEmpty) {
      await neuraInfoDialog(context, title: 'Open File', message: 'Say: "open file C:\\path\\to\\file"');
      return;
    }
    try {
      final uri = Uri.file(path);
      final ok = await launchUrl(uri);
      if (!ok) {
        await neuraInfoDialog(context, title: 'Open File', message: 'No handler for: $path');
      }
    } catch (e) {
      await neuraInfoDialog(context, title: 'Open File failed', message: 'Error: $e');
    }
  }
}
