Future<void> startProcess(List<String> cmd) {
  throw UnsupportedError('Process execution is not available on this platform.');
}
