import 'dart:io';

Future<void> startProcess(List<String> cmd) async {
  if (cmd.isEmpty) return;
  await Process.start(cmd.first, cmd.skip(1).toList());
}
