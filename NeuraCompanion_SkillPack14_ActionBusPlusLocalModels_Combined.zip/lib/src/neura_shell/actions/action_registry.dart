import 'package:flutter/material.dart';

import '../intent_router.dart';
import 'neura_action.dart';

/// Central allowlist + dispatch.
///
/// This is the backbone of making Neura feel "OS-level" without being unsafe.
class NeuraActionRegistry {
  final Map<String, NeuraAction> _actions = {};

  void register(NeuraAction action) {
    _actions[action.id] = action;
  }

  NeuraAction? get(String id) => _actions[id];

  Iterable<NeuraAction> get all => _actions.values;

  Future<void> execute(
    BuildContext context, {
    required NeuraIntent intent,
    required String raw,
    bool fromVoice = false,
  }) async {
    if (intent.isNone) return;
    final action = _actions[intent.actionId];
    if (action == null) {
      await neuraInfoDialog(
        context,
        title: 'Neura can\'t do that yet',
        message:
            'No allowlisted action exists for "${intent.actionId}".\n\nTry: open journal, open goals, search <topic>.',
      );
      return;
    }

    await action.run(
      context,
      NeuraActionRequest(raw: raw, args: intent.args, fromVoice: fromVoice),
    );
  }
}
