import 'package:flutter/material.dart';

import 'neura_action.dart';

import '../../../services/local_models/neura_desktop_llm_orchestrator.dart';
import '../../../services/local_models/neura_local_model_settings.dart';
import '../../../services/local_models/neura_llama_server_runner.dart';

class LocalModelStatusAction extends NeuraAction {
  @override
  String get id => 'llm.status';

  @override
  String get title => 'Local Model: Status';

  @override
  String get description => 'Shows whether the local llama.cpp server is running (desktop only).';

  @override
  List<String> get examples => const ['local model status', 'llm status', 'model status'];

  @override
  Set<NeuraCapability> get requiredCapabilities => const {NeuraCapability.localModels};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    final running = NeuraLlamaServerRunner.I.isRunning;
    final port = NeuraLlamaServerRunner.I.port;
    final msg = running
        ? 'Local model server is running on 127.0.0.1:$port.'
        : 'Local model server is not running.';
    await neuraInfoDialog(context, title: 'Local Model', message: msg);
  }
}

class LocalModelStartAction extends NeuraAction {
  @override
  String get id => 'llm.start';

  @override
  String get title => 'Local Model: Start';

  @override
  String get description =>
      'Starts the local llama.cpp server using a GGUF model file. Pass a model path in the command (or set it in Local Model Settings).';

  @override
  List<String> get examples => const [
        'start local model C:\\models\\mistral.gguf',
        'start local model /models/mistral.gguf',
        'llm start',
      ];

  @override
  Set<NeuraCapability> get requiredCapabilities => const {NeuraCapability.localModels};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    if (!NeuraLocalModelSettings.I.isReady) {
      await NeuraLocalModelSettings.I.init();
    }
    if (!NeuraDesktopLlmOrchestrator.I.isReady) {
      await NeuraDesktopLlmOrchestrator.I.init();
    }

    final modelFromArgs = (request.args ?? '').trim();
    final modelPath = modelFromArgs.isNotEmpty ? modelFromArgs : NeuraLocalModelSettings.I.defaultModelPath;

    if (modelPath.trim().isEmpty) {
      await neuraInfoDialog(
        context,
        title: 'Local Model: Missing Model',
        message:
            'I need a GGUF model path.\n\nExample:\n  start local model C:\\models\\mistral.gguf\n\nOr set a default model path in settings.',
      );
      return;
    }

    final port = NeuraLocalModelSettings.I.serverPort;
    final ok = await NeuraDesktopLlmOrchestrator.I.startRunnerWithModel(
      modelPath,
      port: port,
    );

    await neuraInfoDialog(
      context,
      title: 'Local Model',
      message: ok
          ? 'Started local model server on 127.0.0.1:$port\nModel: $modelPath'
          : 'Failed to start local model server. Check logs and ensure llama-server + model exist.',
    );
  }
}

class LocalModelStopAction extends NeuraAction {
  @override
  String get id => 'llm.stop';

  @override
  String get title => 'Local Model: Stop';

  @override
  String get description => 'Stops the local llama.cpp server if it is running.';

  @override
  List<String> get examples => const ['stop local model', 'llm stop'];

  @override
  Set<NeuraCapability> get requiredCapabilities => const {NeuraCapability.localModels};

  @override
  Future<void> run(BuildContext context, NeuraActionRequest request) async {
    await NeuraLlamaServerRunner.I.stop();
    await neuraInfoDialog(context, title: 'Local Model', message: 'Stopped local model server.');
  }
}
