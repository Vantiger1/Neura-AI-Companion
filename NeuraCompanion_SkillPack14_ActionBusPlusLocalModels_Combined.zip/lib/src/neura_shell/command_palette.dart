import 'package:flutter/material.dart';
import 'intent_router.dart';

typedef NeuraCommandHandler = Future<void> Function(NeuraIntent intent, String raw);

class NeuraCommandPalette extends StatefulWidget {
  final NeuraCommandHandler onCommand;
  final VoidCallback onClose;

  const NeuraCommandPalette({
    super.key,
    required this.onCommand,
    required this.onClose,
  });

  @override
  State<NeuraCommandPalette> createState() => _NeuraCommandPaletteState();
}

class _NeuraCommandPaletteState extends State<NeuraCommandPalette> {
  final TextEditingController _controller = TextEditingController();
  final FocusNode _focus = FocusNode();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _focus.requestFocus());
  }

  @override
  void dispose() {
    _controller.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _submit() async {
    final raw = _controller.text;
    if (raw.trim().isEmpty) return;
    final intent = NeuraIntentRouter.route(raw);
    await widget.onCommand(intent, raw);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Material(
      color: Colors.black54,
      child: SafeArea(
        child: Align(
          alignment: Alignment.topCenter,
          child: Container(
            margin: const EdgeInsets.all(12),
            padding: const EdgeInsets.all(12),
            constraints: const BoxConstraints(maxWidth: 820),
            decoration: BoxDecoration(
              color: const Color(0xFF121212),
              borderRadius: BorderRadius.circular(16),
              border: Border.all(color: Colors.white12),
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: TextField(
                        controller: _controller,
                        focusNode: _focus,
                        textInputAction: TextInputAction.search,
                        onSubmitted: (_) => _submit(),
                        decoration: const InputDecoration(
                          hintText: 'Ask Neura… (e.g., “open journal”, “search CBT grounding”)',
                          border: OutlineInputBorder(),
                          isDense: true,
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    IconButton(
                      tooltip: 'Close',
                      onPressed: widget.onClose,
                      icon: const Icon(Icons.close),
                    )
                  ],
                ),
                const SizedBox(height: 10),
                _QuickChips(
                  onPick: (text) {
                    _controller.text = text;
                    _controller.selection = TextSelection.fromPosition(
                      TextPosition(offset: _controller.text.length),
                    );
                    _submit();
                  },
                ),
                const SizedBox(height: 8),
                Text(
                  'Tip: keep it short. Neura will route your request to the right module or open a safe web search.',
                  style: theme.textTheme.bodySmall?.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

class _QuickChips extends StatelessWidget {
  final ValueChanged<String> onPick;
  const _QuickChips({required this.onPick});

  @override
  Widget build(BuildContext context) {
    final items = <String>[
      'open journal',
      'open check-in',
      'open goals',
      'open meditation',
      'search breathing exercise for anxiety',
      'help',
    ];
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        for (final s in items)
          ActionChip(
            label: Text(s),
            onPressed: () => onPick(s),
          ),
      ],
    );
  }
}
