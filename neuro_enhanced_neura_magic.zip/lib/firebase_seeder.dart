import 'package:cloud_firestore/cloud_firestore.dart';

class FirebaseSeeder {
  static Future<void> seedHealthData() async {
    final col = FirebaseFirestore.instance.collection('health_data');
    for (int i = 0; i < 10; i++) {
      await col.add({
        'heartRate': 60 + i,
        'timestamp': DateTime.now().subtract(Duration(minutes: i * 10))
      });
    }
    print("Seeded test data to Firebase.");
  }
}