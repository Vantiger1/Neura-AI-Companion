class MockBleScanner {
  static Future<Map<String, dynamic>> connectAndFetch() async {
    await Future.delayed(Duration(seconds: 2));
    return {
      'heartRate': 76,
      'timestamp': DateTime.now().toIso8601String(),
    };
  }
}