import 'package:flutter/material.dart';
import 'dart:math' as math;

class NeuraLaunchWidget extends StatefulWidget {
  @override
  _NeuraLaunchWidgetState createState() => _NeuraLaunchWidgetState();
}

class _NeuraLaunchWidgetState extends State<NeuraLaunchWidget>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      child: Image.asset('assets/images/neura.png', height: 150),
      builder: (context, child) {
        return Transform.rotate(
          angle: _controller.value * 2 * math.pi,
          child: Opacity(
            opacity: 0.5 + (_controller.value * 0.5),
            child: child,
          ),
        );
      },
    );
  }
}