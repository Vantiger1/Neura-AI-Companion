import 'package:shared_preferences/shared_preferences.dart';

class ProStatus {
  static Future<bool> isProUser() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool('pro_enabled') ?? false;
  }

  static Future<void> enablePro() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool('pro_enabled', true);
  }
}