
import 'package:flutter/material.dart';

class JoyLoungeRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Container(color: Colors.pink)),
          Center(child: Text('Joy Lounge', style: TextStyle(fontSize: 32, color: Colors.white))),
        ],
      ),
    );
  }
}
