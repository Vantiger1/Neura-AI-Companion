
import 'package:flutter/material.dart';

class DreamTheaterRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Container(color: Colors.deepPurple)),
          Center(child: Text('Dream Theater', style: TextStyle(fontSize: 32, color: Colors.white))),
        ],
      ),
    );
  }
}
