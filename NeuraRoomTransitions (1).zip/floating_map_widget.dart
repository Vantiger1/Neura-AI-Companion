
import 'package:flutter/material.dart';

class RoomInfo {
  final String name;
  final Widget room;
  final IconData icon;
  RoomInfo(this.name, this.room, this.icon);
}

class NeuraFloatingMap extends StatelessWidget {
  final List<RoomInfo> rooms;

  const NeuraFloatingMap({required this.rooms});

  @override
  Widget build(BuildContext context) {
    return Positioned(
      bottom: 40,
      right: 20,
      child: FloatingActionButton(
        child: Icon(Icons.map),
        onPressed: () {
          showModalBottomSheet(
            context: context,
            builder: (_) => Wrap(
              children: rooms.map((room) {
                return ListTile(
                  leading: Icon(room.icon),
                  title: Text(room.name),
                  onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => room.room)),
                );
              }).toList(),
            ),
          );
        },
      ),
    );
  }
}
