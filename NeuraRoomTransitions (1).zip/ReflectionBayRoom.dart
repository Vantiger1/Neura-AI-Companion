
import 'package:flutter/material.dart';

class ReflectionBayRoom extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Positioned.fill(child: Container(color: Colors.blue)),
          Center(child: Text('Reflection Bay', style: TextStyle(fontSize: 32, color: Colors.white))),
        ],
      ),
    );
  }
}
