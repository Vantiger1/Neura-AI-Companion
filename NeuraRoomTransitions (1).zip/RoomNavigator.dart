
import 'package:flutter/material.dart';

class RoomNavigator {
  static Future<void> walkToRoom(BuildContext context, Widget destination) async {
    await Navigator.push(
      context,
      PageRouteBuilder(
        pageBuilder: (_, __, ___) => destination,
        transitionsBuilder: (_, animation, __, child) {
          return FadeTransition(opacity: animation, child: child);
        },
        transitionDuration: Duration(milliseconds: 600),
      ),
    );
  }
}
