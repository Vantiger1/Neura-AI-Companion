
import 'package:flutter/material.dart';
import 'rooms.dart'; // Import your room widgets

void handleVoiceCommand(BuildContext context, String command) {
  final lower = command.toLowerCase();
  if (lower.contains("joy lounge")) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => JoyLoungeRoom()));
  } else if (lower.contains("dream theater")) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => DreamTheaterRoom()));
  } else if (lower.contains("reflection bay")) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => ReflectionBayRoom()));
  }
}
