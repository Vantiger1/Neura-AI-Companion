#!/usr/bin/env bash
set -e
SRC="assets_final/animations"
DST="packages/core/assets/animations"
echo "Cleaning old placeholders..."
rm -rf "$DST"/*
mkdir -p "$DST"
echo "Copying final assets..."
cp "$SRC"/* "$DST"/
echo "Assets deployed to $DST"
