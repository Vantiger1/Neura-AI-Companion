import 'package:flutter/material.dart';

class NeuraSuggestionPopup extends StatefulWidget {
  final String suggestion;

  const NeuraSuggestionPopup({Key? key, required this.suggestion}) : super(key: key);

  @override
  _NeuraSuggestionPopupState createState() => _NeuraSuggestionPopupState();
}

class _NeuraSuggestionPopupState extends State<NeuraSuggestionPopup>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scale;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: Duration(milliseconds: 500));
    _scale = CurvedAnimation(parent: _controller, curve: Curves.elasticOut);
    _controller.forward();
  }

  @override
  Widget build(BuildContext context) {
    return Center(
      child: ScaleTransition(
        scale: _scale,
        child: AlertDialog(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
          title: Text("Neura Suggests"),
          content: Text(widget.suggestion),
          actions: [
            TextButton(
              child: Text("Got it"),
              onPressed: () => Navigator.of(context).pop(),
            )
          ],
        ),
      ),
    );
  }
}