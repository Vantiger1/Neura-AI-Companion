import 'package:flutter/material.dart';

class TrendBasedAvatar extends StatelessWidget {
  final String dominantMood;

  const TrendBasedAvatar({Key? key, required this.dominantMood}) : super(key: key);

  String getAvatarAsset() {
    switch (dominantMood) {
      case "happy": return "assets/images/neura_happy.png";
      case "sad": return "assets/images/neura_sad.png";
      case "calm": return "assets/images/neura_calm.png";
      case "excited": return "assets/images/neura_excited.png";
      case "angry": return "assets/images/neura_angry.png";
      default: return "assets/images/neura_neutral.png";
    }
  }

  @override
  Widget build(BuildContext context) {
    return CircleAvatar(
      radius: 50,
      backgroundImage: AssetImage(getAvatarAsset()),
    );
  }
}