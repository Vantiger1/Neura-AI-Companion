import 'package:flutter/material.dart';

class MoodCheckInSwipe extends StatelessWidget {
  final Function(String mood) onSelected;

  const MoodCheckInSwipe({Key? key, required this.onSelected}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final moods = {
      'happy': '😊',
      'sad': '😢',
      'excited': '🤩',
      'calm': '😌',
      'angry': '😠'
    };

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      child: Row(
        children: moods.entries.map((entry) {
          return GestureDetector(
            onTap: () => onSelected(entry.key),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Column(
                children: [
                  Text(entry.value, style: TextStyle(fontSize: 36)),
                  Text(entry.key),
                ],
              ),
            ),
          );
        }).toList(),
      ),
    );
  }
}