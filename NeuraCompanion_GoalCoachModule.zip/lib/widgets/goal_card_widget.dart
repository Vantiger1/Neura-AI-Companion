import 'package:flutter/material.dart';
import '../models/goal_model.dart';

class GoalCard extends StatelessWidget {
  final Goal goal;
  final VoidCallback onTap;

  const GoalCard({required this.goal, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text(goal.title),
        subtitle: Text(goal.description),
        trailing: Column(
          children: [
            Text('${goal.progress}%'),
            SizedBox(height: 4),
            LinearProgressIndicator(value: goal.progress / 100.0),
          ],
        ),
        onTap: onTap,
      ),
    );
  }
}
