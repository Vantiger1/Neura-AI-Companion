import '../models/quest_model.dart';

class QuestService {
  final List<Quest> _quests = [
    Quest(id: 'q1', title: 'Log a Mood', description: 'Complete your first mood check-in.'),
    Quest(id: 'q2', title: 'Journal Today', description: 'Write a personal journal entry.'),
    Quest(id: 'q3', title: 'Try a Meditation', description: 'Open the meditation module and begin.'),
    Quest(id: 'q4', title: 'Dream Entry', description: 'Log a dream in your dream journal.'),
    Quest(id: 'q5', title: 'Visit Neura World', description: 'Post to the Neura Feed at least once.'),
  ];

  int xp = 0;

  List<Quest> get quests => List.unmodifiable(_quests);

  void completeQuest(String id) {
    final index = _quests.indexWhere((q) => q.id == id && !q.completed);
    if (index != -1) {
      final completed = _quests[index].markCompleted();
      _quests[index] = completed;
      xp += completed.xp;
    }
  }

  int get currentXP => xp;
}
