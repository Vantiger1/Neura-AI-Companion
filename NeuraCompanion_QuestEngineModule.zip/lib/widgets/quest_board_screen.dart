import 'package:flutter/material.dart';
import '../services/quest_service.dart';
import '../models/quest_model.dart';

class QuestBoardScreen extends StatefulWidget {
  final QuestService service;
  const QuestBoardScreen({required this.service});

  @override
  State<QuestBoardScreen> createState() => _QuestBoardScreenState();
}

class _QuestBoardScreenState extends State<QuestBoardScreen> {
  @override
  Widget build(BuildContext context) {
    final quests = widget.service.quests;
    final xp = widget.service.currentXP;

    return Scaffold(
      appBar: AppBar(title: Text('Neura Quests')),
      body: Column(
        children: [
          Padding(
            padding: EdgeInsets.all(12),
            child: Text('XP: $xp', style: TextStyle(fontSize: 20)),
          ),
          Expanded(
            child: ListView(
              children: quests.map((q) => Card(
                child: ListTile(
                  title: Text(q.title),
                  subtitle: Text(q.description),
                  trailing: q.completed
                      ? Icon(Icons.check_circle, color: Colors.green)
                      : ElevatedButton(
                          child: Text('Complete'),
                          onPressed: () {
                            setState(() {
                              widget.service.completeQuest(q.id);
                            });
                          },
                        ),
                ),
              )).toList(),
            ),
          )
        ],
      ),
    );
  }
}
