#!/usr/bin/env bash
set -euo pipefail
TARGET="${1:-}"
if [[ -z "$TARGET" ]]; then
  echo "Usage: $0 /path/to/YourFlutterApp"
  exit 1
fi
mkdir -p "$TARGET/lib/neura" "$TARGET/lib/neura/ui/screens" "$TARGET/lib/neura/services"
mkdir -p "$TARGET/assets/audio" "$TARGET/assets/config"
cp -r "./lib/neura/rooms" "$TARGET/lib/neura/"
cp -r "./lib/neura/avatar" "$TARGET/lib/neura/"
cp "./lib/neura/ui/screens/rooms_screen.dart" "$TARGET/lib/neura/ui/screens/"
cp "./lib/neura/services/audio_service.dart" "$TARGET/lib/neura/services/"
cp -r "./assets/audio/"* "$TARGET/assets/audio/" || true
cp "./assets/config/outfits.json" "$TARGET/assets/config/outfits.json"
{
  echo ""
  echo "# === Neura Module 3 (Rooms/Audio/Outfits) ==="
  echo "flutter:"
  echo "  assets:"
  echo "    - assets/audio/"
  echo "    - assets/config/outfits.json"
} >> "$TARGET/pubspec.yaml"
pushd "$TARGET" >/dev/null
flutter pub get
popd >/dev/null
echo "Done."
