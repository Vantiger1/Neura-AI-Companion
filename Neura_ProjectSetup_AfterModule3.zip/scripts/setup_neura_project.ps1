param([Parameter(Mandatory=$true)][string]$Target)
New-Item -ItemType Directory -Force -Path "$Target\lib\neura" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\lib\neura\ui\screens" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\lib\neura\services" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\assets\audio" | Out-Null
New-Item -ItemType Directory -Force -Path "$Target\assets\config" | Out-Null
Copy-Item -Recurse -Force ".\lib\neura\rooms" "$Target\lib\neura\rooms"
Copy-Item -Recurse -Force ".\lib\neura\avatar" "$Target\lib\neura\avatar"
Copy-Item -Force ".\lib\neura\ui\screens\rooms_screen.dart" "$Target\lib\neura\ui\screens"
Copy-Item -Force ".\lib\neura\services\audio_service.dart" "$Target\lib\neura\services"
Copy-Item -Recurse -Force ".\assets\audio" "$Target\assets\audio"
Copy-Item -Force ".\assets\config\outfits.json" "$Target\assets\config\outfits.json"
Add-Content "$Target\pubspec.yaml" "`n# === Neura Module 3 (Rooms/Audio/Outfits) ==="
Add-Content "$Target\pubspec.yaml" "flutter:"
Add-Content "$Target\pubspec.yaml" "  assets:"
Add-Content "$Target\pubspec.yaml" "    - assets/audio/"
Add-Content "$Target\pubspec.yaml" "    - assets/config/outfits.json"
Push-Location $Target
flutter pub get
Pop-Location
Write-Host "Done."
