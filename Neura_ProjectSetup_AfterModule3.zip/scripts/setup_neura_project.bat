@echo off
setlocal ENABLEDELAYEDEXPANSION
if "%~1"=="" (
  echo Usage: setup_neura_project.bat C:\path\to\YourFlutterApp
  exit /b 1
)
set TARGET=%~1
mkdir "%TARGET%\lib\neura" 2>nul
mkdir "%TARGET%\lib\neura\ui\screens" 2>nul
mkdir "%TARGET%\lib\neura\services" 2>nul
mkdir "%TARGET%\assets\audio" 2>nul
mkdir "%TARGET%\assets\config" 2>nul
xcopy /E /I /Y ".\lib\neura\rooms" "%TARGET%\lib\neura\rooms" >nul
xcopy /E /I /Y ".\lib\neura\avatar" "%TARGET%\lib\neura\avatar" >nul
xcopy /E /I /Y ".\lib\neura\ui\screens\rooms_screen.dart" "%TARGET%\lib\neura\ui\screens" >nul
xcopy /E /I /Y ".\lib\neura\services\audio_service.dart" "%TARGET%\lib\neura\services" >nul
xcopy /E /I /Y ".\assets\audio" "%TARGET%\assets\audio" >nul
xcopy /E /I /Y ".\assets\config\outfits.json" "%TARGET%\assets\config" >nul
echo.>> "%TARGET%\pubspec.yaml"
echo # === Neura Module 3 (Rooms/Audio/Outfits) ===>> "%TARGET%\pubspec.yaml"
echo flutter:>> "%TARGET%\pubspec.yaml"
echo   assets:>> "%TARGET%\pubspec.yaml"
echo     - assets/audio/>> "%TARGET%\pubspec.yaml"
echo     - assets/config/outfits.json>> "%TARGET%\pubspec.yaml"
pushd "%TARGET%"
flutter pub get
popd
echo Done.
