import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../../services/neura_local_core_daemon.dart';

class NeuraCommandConsoleScreen extends StatefulWidget {
  const NeuraCommandConsoleScreen({super.key});

  @override
  State<NeuraCommandConsoleScreen> createState() => _NeuraCommandConsoleScreenState();
}

class _NeuraCommandConsoleScreenState extends State<NeuraCommandConsoleScreen> {
  final _type = TextEditingController(text: 'write_note');
  final _params = TextEditingController(
    text: jsonEncode({
      'title': 'Hello from Neura',
      'body': 'This note was created by a safe on-device action.',
    }),
  );

  bool _busy = false;
  String _out = '';

  Future<Map<String, dynamic>> _postJson(String path, Map<String, dynamic> body) async {
    final port = NeuraLocalCoreDaemon.I.port ?? 7788;
    final uri = Uri.parse('http://127.0.0.1:$port$path');

    final client = HttpClient();
    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(body));
      final res = await req.close();
      final txt = await utf8.decodeStream(res);
      final map = (jsonDecode(txt) as Map).cast<String, dynamic>();
      map['_statusCode'] = res.statusCode;
      return map;
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _out = '';
    });

    try {
      final type = _type.text.trim();
      final params = (jsonDecode(_params.text) as Map).cast<String, dynamic>();
      final res = await _postJson('/execute', {'type': type, 'params': params});

      if ((res['status'] ?? '') == 'needs_approval') {
        final approvalId = (res['approvalId'] ?? '').toString();
        final summary = (res['summary'] ?? '').toString();
        final reason = (res['reason'] ?? '').toString();

        final approved = await showDialog<bool>(
          context: context,
          builder: (_) => _ApprovalDialog(summary: summary, reason: reason),
        );

        if (approved == true) {
          final res2 = await _postJson('/approve', {'approvalId': approvalId, 'approve': true});
          setState(() => _out = const JsonEncoder.withIndent('  ').convert(res2));
        } else {
          await _postJson('/approve', {'approvalId': approvalId, 'approve': false});
          setState(() => _out = 'Action rejected.');
        }
      } else {
        setState(() => _out = const JsonEncoder.withIndent('  ').convert(res));
      }
    } catch (e) {
      setState(() => _out = 'Error: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _type.dispose();
    _params.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final port = NeuraLocalCoreDaemon.I.port;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Command Console'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Center(child: Text(port == null ? 'daemon: ?' : 'daemon: $port')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Safe OS Actions (Allowlist) — Skill Pack 1'),
          const SizedBox(height: 12),
          TextField(
            controller: _type,
            decoration: const InputDecoration(
              labelText: 'Action Type',
              hintText: 'write_note | open_url | desktop_launch_app | desktop_open_folder',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _params,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'Params (JSON)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _busy ? null : _run,
            icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow),
            label: const Text('Run'),
          ),
          const SizedBox(height: 12),
          const Text('Output'),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white24),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SelectableText(_out.isEmpty ? '—' : _out),
          ),
        ],
      ),
    );
  }
}

class _ApprovalDialog extends StatelessWidget {
  final String summary;
  final String reason;
  const _ApprovalDialog({required this.summary, required this.reason});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Approve Action?'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(summary),
          const SizedBox(height: 10),
          Text('Policy: $reason', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          const Text('Tip: Keep automation conservative. Neura asks because she respects your device.'),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Reject')),
        ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Approve')),
      ],
    );
  }
}
