import 'dart:io' show Platform;
import '../models/ai_avatar.dart';
import 'local_models/neura_ondevice_android_client.dart';

class DualChatService {
  final NeuraOnDeviceAndroidClient _android = NeuraOnDeviceAndroidClient();

  /// Sends user message to the AI and returns response from specified avatar.
  ///
  /// Current strategy:
  /// - Android: if on-device runtime is available, stream-generate and return aggregated response.
  /// - Otherwise: placeholder (keeps app stable until you wire your preferred local runner/server).
  Future<String> sendMessage(String message, AIAvatar avatar) async {
    final prompt = message.trim();
    if (prompt.isEmpty) return '';

    if (Platform.isAndroid) {
      try {
        final h = await _android.health();
        if (h['ok'] == true) {
          // NOTE: You must call initModel once from your settings/onboarding screen with a valid GGUF path.
          final buf = StringBuffer();
          await for (final tok in _android.generateStream(
            prompt: prompt,
            system: 'You are ${avatar.name}. Be helpful, kind, and practical.',
            temperature: 0.4,
            maxTokens: 256,
          )) {
            buf.write(tok);
          }
          final out = buf.toString().trim();
          if (out.isNotEmpty) return out;
        }
      } catch (_) {
        // swallow and fall through
      }
    }

    return 'Response from ${avatar.name}: (offline runtime not initialized yet)';
  }
}
