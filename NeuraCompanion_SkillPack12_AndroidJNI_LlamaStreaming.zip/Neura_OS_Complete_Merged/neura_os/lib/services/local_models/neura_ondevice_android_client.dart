import 'dart:async';
import 'dart:io' show Platform;
import 'package:flutter/services.dart';

/// Flutter-side bridge for Android on-device LLM.
///
/// MethodChannel:  neura_llm
/// EventChannel:   neura_llm_stream
class NeuraOnDeviceAndroidClient {
  static const MethodChannel _ch = MethodChannel('neura_llm');
  static const EventChannel _ev = EventChannel('neura_llm_stream');

  Stream<dynamic>? _rawStream;

  Future<Map<String, dynamic>> health() async {
    if (!Platform.isAndroid) return {'ok': false, 'error': 'Not Android'};
    final r = await _ch.invokeMethod('health') as Map? ?? {};
    return Map<String, dynamic>.from(r);
  }

  Future<Map<String, dynamic>> initModel({
    required String modelPath,
    int threads = 4,
    int contextTokens = 2048,
    bool useGpu = false,
  }) async {
    if (!Platform.isAndroid) return {'ok': false, 'error': 'Not Android'};
    final r = await _ch.invokeMethod('initModel', {
      'modelPath': modelPath,
      'threads': threads,
      'contextTokens': contextTokens,
      'useGpu': useGpu,
    }) as Map? ?? {};
    return Map<String, dynamic>.from(r);
  }

  Future<Map<String, dynamic>> freeModel() async {
    if (!Platform.isAndroid) return {'ok': false, 'error': 'Not Android'};
    final r = await _ch.invokeMethod('freeModel') as Map? ?? {};
    return Map<String, dynamic>.from(r);
  }

  /// Start a streaming generation and return a stream of token pieces.
  ///
  /// Consumers should join tokens into a String buffer.
  Stream<String> generateStream({
    required String prompt,
    String system = '',
    double temperature = 0.3,
    int maxTokens = 256,
  }) {
    if (!Platform.isAndroid) {
      return Stream.error('Not Android');
    }

    final controller = StreamController<String>();

    _rawStream ??= _ev.receiveBroadcastStream();

    late StreamSubscription sub;

    Future<void> start() async {
      final r = await _ch.invokeMethod('startStream', {
        'prompt': prompt,
        'system': system,
        'temperature': temperature,
        'maxTokens': maxTokens,
      }) as Map? ?? {};

      final map = Map<String, dynamic>.from(r);
      if (map['ok'] != true) {
        controller.addError(map['error']?.toString() ?? 'startStream failed');
        await controller.close();
        return;
      }

      final rid = (map['rid'] as num).toInt();

      sub = _rawStream!.listen((event) {
        if (event is Map) {
          final e = Map<String, dynamic>.from(event);
          if (e['rid'] != rid) return;
          if (e['error'] != null) {
            controller.addError(e['error'].toString());
          }
          final tok = e['token'];
          if (tok is String && tok.isNotEmpty) {
            controller.add(tok);
          }
          if (e['done'] == true) {
            controller.close();
            sub.cancel();
          }
        }
      }, onError: (err) {
        controller.addError(err);
        controller.close();
      });

      controller.onCancel = () async {
        try {
          await _ch.invokeMethod('cancelStream', {'rid': rid});
        } catch (_) {}
        await sub.cancel();
      };
    }

    start();
    return controller.stream;
  }
}
