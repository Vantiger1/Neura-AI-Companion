# SkillPack 12 — Android On‑Device LLM (Streaming JNI)

This patch upgrades the Android on-device LLM bridge to support **token streaming** via:

- MethodChannel: `neura_llm`
- EventChannel: `neura_llm_stream`

It ships with a **safe stub**: if you do not build the native library, Neura will not crash; `health` will report `ok: false`.

## What you get

- `LlamaNativeV2` JNI surface (init/free/start/poll/cancel)
- `LlamaStreamEngine` that emits streaming token events
- Updated `MainActivity` registration
- Flutter-side `NeuraOnDeviceAndroidClient` that consumes the stream

## How to make it *real*

### Option A (recommended): embed llama.cpp

1. Add llama.cpp as a subfolder:

```
android/app/src/main/cpp/third_party/llama/
```

2. Ensure `llama.h` is present at:

```
android/app/src/main/cpp/third_party/llama/llama.h
```

3. If your llama.cpp folder contains a CMake project, you can wire it in `CMakeLists.txt` by uncommenting the `add_subdirectory(...)` block and linking the proper target.

> llama.cpp's target name varies across versions (`llama`, `llama_static`, etc.). If the build fails, open `third_party/llama/CMakeLists.txt` and align the target name.

### Option B: ship a prebuilt lib

- Build `libllama.so` / `libneura_llama.so` separately and drop it in:

```
android/app/src/main/jniLibs/<abi>/libneura_llama.so
```

## Model location

This patch expects you to provide a GGUF path at runtime (e.g., picked via file picker or pre-bundled in app storage) and call:

- `initModel({ modelPath })`

## Notes

- The sampling implementation is a simple greedy/temperature sampler to keep dependencies minimal.
- Cancel is best-effort; it stops generation loop and emits a final event.
- For production, you will likely want:
  - prompt templates per model
  - context reuse / KV caching strategy
  - memory limits and device capability gating

