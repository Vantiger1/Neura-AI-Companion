package com.neurocompanion.app.neura

import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.EventChannel

object NeuraLlamaStreamChannel {
  private const val CHANNEL = "neura_llm_stream"

  fun register(engine: FlutterEngine) {
    val eventChannel = EventChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
    eventChannel.setStreamHandler(object : EventChannel.StreamHandler {
      override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
        LlamaStreamEngine.attachSink(events)
      }

      override fun onCancel(arguments: Any?) {
        LlamaStreamEngine.attachSink(null)
      }
    })
  }
}
