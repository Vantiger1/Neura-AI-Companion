package com.neurocompanion.app.neura

/**
 * V2 JNI bridge that supports streaming token generation.
 *
 * Native library: libneura_llama.so
 *
 * Notes:
 * - `init` must be called before any generation.
 * - Generation uses request IDs so Flutter can multiplex requests.
 */
object LlamaNativeV2 {
  external fun version(): String

  external fun init(modelPath: String, contextTokens: Int, threads: Int, useGpu: Boolean): Boolean
  external fun free()

  /** Start streaming generation; returns requestId (>0) on success, 0 on failure. */
  external fun start(system: String, prompt: String, temperature: Double, maxTokens: Int): Long

  /**
   * Poll next token piece for requestId.
   * - returns null when no token is available yet
   * - returns "" (empty string) when generation is complete
   */
  external fun poll(requestId: Long): String?

  /** True when request is complete (or cancelled). */
  external fun isDone(requestId: Long): Boolean

  /** Cancel an in-flight request. */
  external fun cancel(requestId: Long)
}
