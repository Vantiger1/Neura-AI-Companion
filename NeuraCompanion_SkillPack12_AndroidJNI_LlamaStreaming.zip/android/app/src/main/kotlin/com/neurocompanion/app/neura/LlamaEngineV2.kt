package com.neurocompanion.app.neura

import java.util.concurrent.atomic.AtomicBoolean

/**
 * Loads the native library and provides safe wrappers.
 */
object LlamaEngineV2 {
  private val loaded = AtomicBoolean(false)
  private var loadError: String? = null

  private fun ensureLoaded() {
    if (loaded.get()) return
    try {
      System.loadLibrary("neura_llama")
      loaded.set(true)
    } catch (t: Throwable) {
      loadError = t.toString()
      loaded.set(false)
    }
  }

  fun health(): Map<String, Any?> {
    ensureLoaded()
    if (!loaded.get()) {
      return mapOf(
        "ok" to false,
        "error" to (loadError ?: "Native library not loaded."),
        "hint" to "Android on-device LLM requires building libneura_llama.so (see docs/skillpack12_android_llama_streaming.md).",
      )
    }

    return try {
      mapOf(
        "ok" to true,
        "version" to LlamaNativeV2.version(),
      )
    } catch (t: Throwable) {
      mapOf(
        "ok" to false,
        "error" to t.toString(),
      )
    }
  }

  fun init(modelPath: String, contextTokens: Int, threads: Int, useGpu: Boolean): Map<String, Any?> {
    ensureLoaded()
    if (!loaded.get()) {
      return mapOf("ok" to false, "error" to (loadError ?: "Native library not loaded."))
    }

    if (modelPath.isBlank()) return mapOf("ok" to false, "error" to "Missing modelPath.")

    return try {
      val ok = LlamaNativeV2.init(modelPath, contextTokens, threads, useGpu)
      mapOf("ok" to ok)
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }

  fun free(): Map<String, Any?> {
    ensureLoaded()
    if (!loaded.get()) {
      return mapOf("ok" to false, "error" to (loadError ?: "Native library not loaded."))
    }

    return try {
      LlamaNativeV2.free()
      mapOf("ok" to true)
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }
}
