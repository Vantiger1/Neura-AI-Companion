package com.neurocompanion.app.neura

import io.flutter.plugin.common.EventChannel
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * Streams tokens from the native runtime to Flutter via EventChannel.
 */
object LlamaStreamEngine {
  private val executor = Executors.newCachedThreadPool()
  private val running = ConcurrentHashMap<Long, AtomicBoolean>()
  @Volatile private var sink: EventChannel.EventSink? = null

  fun attachSink(eventSink: EventChannel.EventSink?) {
    sink = eventSink
  }

  fun startStream(system: String, prompt: String, temperature: Double, maxTokens: Int): Map<String, Any?> {
    val h = LlamaEngineV2.health()
    if (h["ok"] != true) return mapOf("ok" to false, "error" to (h["error"] ?: "Native engine not available."))

    val requestId = try {
      LlamaNativeV2.start(system, prompt, temperature, maxTokens)
    } catch (t: Throwable) {
      return mapOf("ok" to false, "error" to t.toString())
    }

    if (requestId <= 0) return mapOf("ok" to false, "error" to "Failed to start generation.")

    val flag = AtomicBoolean(true)
    running[requestId] = flag

    executor.execute {
      try {
        while (flag.get()) {
          val token = try {
            LlamaNativeV2.poll(requestId)
          } catch (t: Throwable) {
            sink?.success(mapOf("rid" to requestId, "error" to t.toString(), "done" to true))
            break
          }

          if (!flag.get()) break

          if (token == null) {
            Thread.sleep(10)
            continue
          }

          if (token.isEmpty()) {
            sink?.success(mapOf("rid" to requestId, "done" to true))
            break
          }

          sink?.success(mapOf("rid" to requestId, "token" to token, "done" to false))
        }
      } finally {
        running.remove(requestId)
      }
    }

    return mapOf("ok" to true, "rid" to requestId)
  }

  fun cancelStream(requestId: Long): Map<String, Any?> {
    val flag = running[requestId]
    flag?.set(false)
    return try {
      LlamaNativeV2.cancel(requestId)
      mapOf("ok" to true)
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }
}
