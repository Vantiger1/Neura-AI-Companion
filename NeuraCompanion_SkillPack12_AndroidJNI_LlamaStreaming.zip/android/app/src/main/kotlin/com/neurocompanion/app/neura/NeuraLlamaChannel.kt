package com.neurocompanion.app.neura

import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

object NeuraLlamaChannel {
  private const val CHANNEL = "neura_llm"

  fun register(engine: FlutterEngine) {
    val channel = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)
    channel.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
      when (call.method) {
        "health" -> {
          // Prefer V2 if available; fallback to V1.
          val r = LlamaEngineV2.health()
          if (r["ok"] == true) result.success(r) else result.success(LlamaEngine.health())
        }
        "initModel" -> {
          val args = call.arguments as? Map<*, *>
          val modelPath = (args?.get("modelPath") as? String)?.trim() ?: ""
          val threads = (args?.get("threads") as? Number)?.toInt() ?: 4
          val ctx = (args?.get("contextTokens") as? Number)?.toInt() ?: 2048
          val useGpu = (args?.get("useGpu") as? Boolean) ?: false
          val r = LlamaEngineV2.init(modelPath, ctx, threads, useGpu)
          result.success(r)
        }
        "freeModel" -> {
          val r = LlamaEngineV2.free()
          result.success(r)
        }
        "startStream" -> {
          val args = call.arguments as? Map<*, *>
          val prompt = (args?.get("prompt") as? String)?.trim() ?: ""
          val system = (args?.get("system") as? String)?.trim() ?: ""
          val temperature = (args?.get("temperature") as? Number)?.toDouble() ?: 0.3
          val maxTokens = (args?.get("maxTokens") as? Number)?.toInt() ?: 256
          val r = LlamaStreamEngine.startStream(system, prompt, temperature, maxTokens)
          result.success(r)
        }
        "cancelStream" -> {
          val args = call.arguments as? Map<*, *>
          val rid = (args?.get("rid") as? Number)?.toLong() ?: 0L
          val r = LlamaStreamEngine.cancelStream(rid)
          result.success(r)
        }
        "chat" -> {
          // Legacy non-stream path; keep as stable fallback.
          val args = call.arguments as? Map<*, *>
          val prompt = (args?.get("prompt") as? String)?.trim() ?: ""
          val system = (args?.get("system") as? String)?.trim() ?: ""
          val temperature = (args?.get("temperature") as? Number)?.toDouble() ?: 0.3
          val maxTokens = (args?.get("maxTokens") as? Number)?.toInt() ?: 256
          val threads = (args?.get("threads") as? Number)?.toInt() ?: 4
          val ctx = (args?.get("contextTokens") as? Number)?.toInt() ?: 2048
          val useGpu = (args?.get("useGpu") as? Boolean) ?: false

          val r = LlamaEngine.chat(
            prompt = prompt,
            system = system,
            temperature = temperature,
            maxTokens = maxTokens,
            threads = threads,
            contextTokens = ctx,
            useGpu = useGpu,
          )
          result.success(r)
        }
        else -> result.notImplemented()
      }
    }
  }
}
