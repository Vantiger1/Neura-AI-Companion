#include <jni.h>
#include <string>
#include <mutex>
#include <unordered_map>
#include <queue>
#include <thread>
#include <atomic>
#include <random>
#include <vector>
#include <cmath>
#include <android/log.h>

#define LOG_TAG "neura_llama"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

#if __has_include("llama.h")
  #include "llama.h"
  #define NEURA_HAS_LLAMA 1
#else
  #define NEURA_HAS_LLAMA 0
#endif

namespace {
  struct Request {
    std::mutex m;
    std::queue<std::string> q;
    std::atomic<bool> done{false};
    std::atomic<bool> cancelled{false};
    std::thread worker;
  };

  std::mutex g_mutex;
  std::unordered_map<long long, Request*> g_requests;
  std::atomic<long long> g_next_id{1};

  void cleanup_request(long long id) {
    Request* r = nullptr;
    {
      std::lock_guard<std::mutex> lk(g_mutex);
      auto it = g_requests.find(id);
      if (it == g_requests.end()) return;
      r = it->second;
      g_requests.erase(it);
    }
    if (!r) return;
    if (r->worker.joinable()) {
      try { r->worker.join(); } catch (...) {}
    }
    delete r;
  }

#if NEURA_HAS_LLAMA
  llama_model* g_model = nullptr;
  llama_context* g_ctx = nullptr;
  std::mutex g_llama_mutex; // protect ctx use

  std::vector<llama_token> tokenize(const std::string& s, bool add_bos=true) {
    std::vector<llama_token> tokens;
    tokens.resize(s.size() + 8);
    // NOTE: signature in modern llama.cpp:
    // int llama_tokenize(const llama_model*, const char*, int, llama_token*, int, bool, bool);
    int n = llama_tokenize(g_model, s.c_str(), (int)s.size(), tokens.data(), (int)tokens.size(), add_bos, true);
    if (n < 0) {
      // if buffer too small, n is -required
      tokens.resize((size_t)(-n));
      n = llama_tokenize(g_model, s.c_str(), (int)s.size(), tokens.data(), (int)tokens.size(), add_bos, true);
    }
    if (n > 0) tokens.resize((size_t)n);
    else tokens.clear();
    return tokens;
  }

  std::string token_to_piece(llama_token t) {
    char buf[256];
    int n = llama_token_to_piece(g_model, t, buf, (int)sizeof(buf));
    if (n <= 0) return std::string();
    return std::string(buf, buf + n);
  }

  llama_token sample_next_token(double temperature, std::mt19937& rng) {
    const float* logits = llama_get_logits(g_ctx);
    int n_vocab = llama_n_vocab(g_model);

    if (temperature <= 0.0) {
      // Greedy
      int best = 0;
      float best_v = logits[0];
      for (int i = 1; i < n_vocab; ++i) {
        if (logits[i] > best_v) {
          best_v = logits[i];
          best = i;
        }
      }
      return (llama_token)best;
    }

    // Temperature sampling
    std::vector<double> probs;
    probs.reserve((size_t)n_vocab);

    double max_logit = logits[0];
    for (int i = 1; i < n_vocab; ++i) max_logit = std::max(max_logit, (double)logits[i]);

    double sum = 0.0;
    for (int i = 0; i < n_vocab; ++i) {
      double x = ((double)logits[i] - max_logit) / temperature;
      double p = std::exp(x);
      probs.push_back(p);
      sum += p;
    }

    if (sum <= 0.0) {
      return (llama_token)0;
    }

    for (double& p : probs) p /= sum;

    std::discrete_distribution<int> dist(probs.begin(), probs.end());
    int idx = dist(rng);
    return (llama_token)idx;
  }
#endif

}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_version(JNIEnv* env, jobject) {
#if NEURA_HAS_LLAMA
  return env->NewStringUTF("neura_llama_v2_llama_cpp");
#else
  return env->NewStringUTF("neura_llama_v2_stub");
#endif
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_init(JNIEnv* env, jobject, jstring modelPath, jint contextTokens, jint threads, jboolean useGpu) {
  const char* mp = env->GetStringUTFChars(modelPath, nullptr);
  std::string path = mp ? mp : "";
  env->ReleaseStringUTFChars(modelPath, mp);

#if !NEURA_HAS_LLAMA
  (void)path; (void)contextTokens; (void)threads; (void)useGpu;
  LOGE("llama.h not found: built in stub mode");
  return JNI_FALSE;
#else
  std::lock_guard<std::mutex> lk(g_llama_mutex);
  try {
    if (g_ctx) {
      llama_free(g_ctx);
      g_ctx = nullptr;
    }
    if (g_model) {
      llama_free_model(g_model);
      g_model = nullptr;
    }

    llama_backend_init(false);

    llama_model_params mparams = llama_model_default_params();
    // GPU flags vary by build; keep conservative.
    (void)useGpu;

    g_model = llama_load_model_from_file(path.c_str(), mparams);
    if (!g_model) {
      LOGE("Failed to load model: %s", path.c_str());
      return JNI_FALSE;
    }

    llama_context_params cparams = llama_context_default_params();
    cparams.n_ctx = (int)contextTokens;
    cparams.n_threads = (int)threads;
    cparams.n_threads_batch = (int)threads;

    g_ctx = llama_new_context_with_model(g_model, cparams);
    if (!g_ctx) {
      LOGE("Failed to create context");
      llama_free_model(g_model);
      g_model = nullptr;
      return JNI_FALSE;
    }

    LOGI("Model loaded ok. ctx=%d threads=%d", (int)contextTokens, (int)threads);
    return JNI_TRUE;
  } catch (...) {
    LOGE("Exception in init");
    return JNI_FALSE;
  }
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_free(JNIEnv*, jobject) {
#if NEURA_HAS_LLAMA
  std::lock_guard<std::mutex> lk(g_llama_mutex);
  if (g_ctx) {
    llama_free(g_ctx);
    g_ctx = nullptr;
  }
  if (g_model) {
    llama_free_model(g_model);
    g_model = nullptr;
  }
  llama_backend_free();
#endif
}

extern "C" JNIEXPORT jlong JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_start(JNIEnv* env, jobject, jstring system, jstring prompt, jdouble temperature, jint maxTokens) {
  const char* sys = env->GetStringUTFChars(system, nullptr);
  const char* prm = env->GetStringUTFChars(prompt, nullptr);
  std::string sysS = sys ? sys : "";
  std::string prmS = prm ? prm : "";
  env->ReleaseStringUTFChars(system, sys);
  env->ReleaseStringUTFChars(prompt, prm);

#if !NEURA_HAS_LLAMA
  (void)sysS; (void)prmS; (void)temperature; (void)maxTokens;
  return 0;
#else
  {
    std::lock_guard<std::mutex> lk(g_llama_mutex);
    if (!g_model || !g_ctx) {
      LOGE("start called without init");
      return 0;
    }
  }

  long long id = g_next_id.fetch_add(1);
  auto* r = new Request();
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    g_requests[id] = r;
  }

  r->worker = std::thread([id, r, sysS, prmS, temperature, maxTokens]() {
    std::mt19937 rng((unsigned)std::random_device{}());

    auto push = [&](const std::string& s) {
      std::lock_guard<std::mutex> lk(r->m);
      r->q.push(s);
    };

    auto finish = [&]() {
      r->done.store(true);
      // push empty marker to allow poll() to return "" and terminate on Kotlin side
      push(std::string());
    };

    try {
      if (r->cancelled.load()) { finish(); return; }

      std::string full;
      if (!sysS.empty()) {
        full += "System: " + sysS + "\n";
      }
      full += "User: " + prmS + "\nAssistant:";

      std::lock_guard<std::mutex> lk(g_llama_mutex);

      // Reset context between runs (simple + safe).
      llama_kv_cache_clear(g_ctx);

      std::vector<llama_token> inp = tokenize(full, true);
      if (inp.empty()) {
        push("[Neura] Failed to tokenize prompt.");
        finish();
        return;
      }

      llama_batch batch = llama_batch_init((int)inp.size(), 0, 1);
      for (int i = 0; i < (int)inp.size(); ++i) {
        batch.token[i] = inp[i];
        batch.pos[i] = i;
        batch.seq_id[i] = 0;
        batch.n_seq_id[i] = 1;
        batch.logits[i] = (i == (int)inp.size() - 1);
      }
      batch.n_tokens = (int)inp.size();

      if (llama_decode(g_ctx, batch) != 0) {
        llama_batch_free(batch);
        push("[Neura] Model decode failed.");
        finish();
        return;
      }
      llama_batch_free(batch);

      int n_past = (int)inp.size();
      for (int i = 0; i < maxTokens; ++i) {
        if (r->cancelled.load()) {
          push("[cancelled]");
          break;
        }

        llama_token next = sample_next_token((double)temperature, rng);
        if (next == llama_token_eos(g_model)) {
          break;
        }

        std::string piece = token_to_piece(next);
        if (!piece.empty()) {
          push(piece);
        }

        llama_batch b2 = llama_batch_init(1, 0, 1);
        b2.token[0] = next;
        b2.pos[0] = n_past;
        b2.seq_id[0] = 0;
        b2.n_seq_id[0] = 1;
        b2.logits[0] = true;
        b2.n_tokens = 1;

        if (llama_decode(g_ctx, b2) != 0) {
          llama_batch_free(b2);
          break;
        }
        llama_batch_free(b2);
        n_past++;
      }

      finish();
    } catch (...) {
      push("[Neura] Native generation exception.");
      finish();
    }
  });

  return (jlong)id;
#endif
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_poll(JNIEnv* env, jobject, jlong requestId) {
  Request* r = nullptr;
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    auto it = g_requests.find((long long)requestId);
    if (it == g_requests.end()) return nullptr;
    r = it->second;
  }

  std::lock_guard<std::mutex> lk(r->m);
  if (r->q.empty()) {
    return nullptr; // no token yet
  }

  std::string s = r->q.front();
  r->q.pop();
  // empty string marks completion
  if (s.empty()) {
    cleanup_request((long long)requestId);
    return env->NewStringUTF("");
  }
  return env->NewStringUTF(s.c_str());
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_isDone(JNIEnv*, jobject, jlong requestId) {
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    auto it = g_requests.find((long long)requestId);
    if (it == g_requests.end()) return JNI_TRUE;
    if (!it->second->done.load()) return JNI_FALSE;
  }
  cleanup_request((long long)requestId);
  return JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNativeV2_cancel(JNIEnv*, jobject, jlong requestId) {
  Request* r = nullptr;
  {
    std::lock_guard<std::mutex> lk(g_mutex);
    auto it = g_requests.find((long long)requestId);
    if (it == g_requests.end()) return;
    r = it->second;
  }
  r->cancelled.store(true);
}
