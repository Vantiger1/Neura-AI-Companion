const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const port = 3000;

// In-memory permissions and event queue
let userFeaturePermissions = {};
let eventQueue = [];

// Task 12: /api/neura/event handler
app.post('/api/neura/event', bodyParser.json(), (req, res) => {
  const { event, data } = req.body;
  if (event === 'toggleFeature') {
    const { feature, enabled } = data;
    userFeaturePermissions[feature] = enabled;
    console.log(`Feature ${feature} set to`, enabled);
  } else {
    // enqueue event for AI pipeline
    eventQueue.push({ event, data, perms: userFeaturePermissions });
    console.log('Event enqueued:', event, data);
  }
  res.sendStatus(202);
});

// Task 13: /api/neura/next-action endpoint
app.get('/api/neura/next-action', (req, res) => {
  // pop next action from queue or idle
  const aiDecision = {
    action: 'idle',
    params: {}
  };
  // Example: respond to emergencyRequest immediately
  const idx = eventQueue.findIndex(e=>e.event==='emergencyRequest');
  if (idx >= 0) {
    eventQueue.splice(idx, 1);
    aiDecision.action = 'emergencyResponse';
    aiDecision.params = { message: 'Help is on the way! Stay calm.' };
  }
  res.json(aiDecision);
});

app.use(express.static('.'));
app.listen(port, () => console.log(`Server running on http://localhost:${port}`));