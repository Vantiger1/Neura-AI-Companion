import 'neura_knowledge_index.dart';

/// Loads and indexes the built-in knowledge packs (offline).
///
/// This is the replacement for "web search" when Neura is in strict offline mode.
/// Packs are assets shipped with the app and indexed locally.
class NeuraKnowledgeService {
  static final NeuraKnowledgeService I = NeuraKnowledgeService._();
  NeuraKnowledgeService._();

  final NeuraKnowledgeIndex _index = NeuraKnowledgeIndex();
  bool _ready = false;

  bool get ready => _ready;

  Future<void> init() async {
    if (_ready) return;

    // Keep this list short and curated. Add more packs as you expand Neura.
    const packs = <String>[
      'assets/knowledge_packs/core_pack.json',
    ];

    await _index.loadFromAssets(packs);
    _ready = true;
  }

  List<NeuraKnowledgeHit> search(String query, {int topK = 5}) {
    return _index.search(query, topK: topK);
  }
}
