import 'dart:convert';
import 'dart:math';

import 'package:flutter/services.dart' show rootBundle;

class NeuraKnowledgeDoc {
  final String id;
  final String title;
  final List<String> tags;
  final String body;

  /// Optional list of suggested actions compatible with the Console.
  /// Each item: {type, params, capability, risk, rationale}
  final List<Map<String, dynamic>> suggestions;

  NeuraKnowledgeDoc({
    required this.id,
    required this.title,
    required this.tags,
    required this.body,
    required this.suggestions,
  });

  factory NeuraKnowledgeDoc.fromJson(Map<String, dynamic> j) {
    return NeuraKnowledgeDoc(
      id: (j['id'] ?? '').toString(),
      title: (j['title'] ?? '').toString(),
      tags: ((j['tags'] as List?) ?? const <dynamic>[]).map((e) => e.toString()).toList(),
      body: (j['body'] ?? '').toString(),
      suggestions: ((j['suggestions'] as List?) ?? const <dynamic>[])
          .whereType<Map>()
          .map((m) => m.cast<String, dynamic>())
          .toList(),
    );
  }
}

class NeuraKnowledgeHit {
  final NeuraKnowledgeDoc doc;
  final double score;
  final String snippet;
  NeuraKnowledgeHit({required this.doc, required this.score, required this.snippet});
}

/// Small, fast, fully-offline search.
///
/// Uses BM25 scoring (fast, effective, and fully offline).
/// NOTE: This is "semantic-ish" via token normalization + BM25; you can later
/// swap in local embeddings if you want deeper semantic recall.
class NeuraKnowledgeIndex {
  final List<NeuraKnowledgeDoc> _docs = <NeuraKnowledgeDoc>[];

  // BM25 fields
  final Map<String, int> _df = <String, int>{};
  final List<Map<String, int>> _tf = <Map<String, int>>[];
  final List<int> _docLen = <int>[];
  double _avgLen = 0;

  bool get ready => _docs.isNotEmpty;
  int get docCount => _docs.length;

  Future<void> loadFromAssets(List<String> packAssets) async {
    final loaded = <NeuraKnowledgeDoc>[];

    for (final asset in packAssets) {
      final raw = await rootBundle.loadString(asset);
      final parsed = jsonDecode(raw);

      // Support two formats:
      // 1) { packId, title, docs: [ ... ] }
      // 2) [ ...docs... ]
      final dynamic docsNode = (parsed is Map) ? parsed['docs'] : parsed;
      if (docsNode is List) {
        for (final item in docsNode) {
          if (item is Map) {
            loaded.add(NeuraKnowledgeDoc.fromJson(item.cast<String, dynamic>()));
          }
        }
      }
    }

    _docs
      ..clear()
      ..addAll(loaded.where((d) => d.id.isNotEmpty && d.title.isNotEmpty));

    _buildBm25();
  }

  List<NeuraKnowledgeHit> search(String query, {int topK = 5}) {
    if (_docs.isEmpty) return const [];
    final qTokens = _tokenize(query);
    if (qTokens.isEmpty) return const [];

    final scores = <int, double>{};
    for (int i = 0; i < _docs.length; i++) {
      final s = _bm25Score(qTokens, i);
      if (s > 0) scores[i] = s;
    }

    final ranked = scores.entries.toList()..sort((a, b) => b.value.compareTo(a.value));
    final out = <NeuraKnowledgeHit>[];

    for (final e in ranked.take(topK.clamp(1, 15))) {
      final doc = _docs[e.key];
      out.add(NeuraKnowledgeHit(doc: doc, score: e.value, snippet: _makeSnippet(doc, qTokens)));
    }

    return out;
  }

  double _bm25Score(List<String> qTokens, int docIndex) {
    // Standard BM25
    const k1 = 1.2;
    const b = 0.75;

    final tf = _tf[docIndex];
    final dl = _docLen[docIndex].toDouble();
    final N = _docs.length;

    double score = 0;
    for (final t in qTokens) {
      final f = (tf[t] ?? 0).toDouble();
      if (f <= 0) continue;

      final df = (_df[t] ?? 0).toDouble();
      // log((N - df + 0.5)/(df + 0.5) + 1)
      final idf = log((N - df + 0.5) / (df + 0.5) + 1);

      final denom = f + k1 * (1 - b + b * (dl / _avgLen));
      score += idf * (f * (k1 + 1)) / denom;
    }
    return score;
  }

  void _buildBm25() {
    _df.clear();
    _tf.clear();
    _docLen.clear();

    int totalLen = 0;

    for (final doc in _docs) {
      final tokens = _tokenize('${doc.title} ${doc.tags.join(' ')} ${doc.body}');
      totalLen += tokens.length;
      _docLen.add(max(1, tokens.length));

      final tf = <String, int>{};
      for (final t in tokens) {
        tf[t] = (tf[t] ?? 0) + 1;
      }
      _tf.add(tf);

      for (final t in tf.keys) {
        _df[t] = (_df[t] ?? 0) + 1;
      }
    }

    _avgLen = _docs.isEmpty ? 1 : max(1, totalLen) / _docs.length;
  }

  String _makeSnippet(NeuraKnowledgeDoc doc, List<String> qTokens) {
    final text = doc.body.replaceAll(RegExp(r'\s+'), ' ').trim();
    if (text.length <= 220) return text;

    final lower = text.toLowerCase();
    int best = -1;
    for (final t in qTokens) {
      final idx = lower.indexOf(t);
      if (idx >= 0) {
        best = idx;
        break;
      }
    }

    if (best < 0) {
      return '${text.substring(0, 220)}…';
    }

    final start = max(0, best - 60);
    final end = min(text.length, start + 220);
    final prefix = start > 0 ? '…' : '';
    final suffix = end < text.length ? '…' : '';
    return '$prefix${text.substring(start, end)}$suffix';
  }

  List<String> _tokenize(String input) {
    final lower = input.toLowerCase();
    final cleaned = lower.replaceAll(RegExp(r'[^a-z0-9\s]'), ' ');
    final parts = cleaned.split(RegExp(r'\s+')).where((p) => p.trim().isNotEmpty).toList();

    final out = <String>[];
    for (final p in parts) {
      final w = _normalize(p);
      if (w.length < 2) continue;
      if (_stop.contains(w)) continue;
      out.add(w);
    }
    return out;
  }

  static const Set<String> _stop = {
    'the','a','an','and','or','to','of','in','on','for','with','is','are','was','were','be','been','it','this','that','as','at','by','from','into','your','you','we','our','not'
  };

  String _normalize(String w) {
    // light stemming
    if (w.endsWith('ing') && w.length > 5) w = w.substring(0, w.length - 3);
    if (w.endsWith('ed') && w.length > 4) w = w.substring(0, w.length - 2);
    if (w.endsWith('s') && w.length > 3) w = w.substring(0, w.length - 1);
    return w;
  }
}
