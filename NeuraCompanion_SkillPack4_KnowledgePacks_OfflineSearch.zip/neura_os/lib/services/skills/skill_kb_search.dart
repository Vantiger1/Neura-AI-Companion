import '../knowledge/neura_knowledge_service.dart';
import '../neura_policy.dart';
import 'skills/neura_skill.dart';

class SkillKbSearch implements NeuraSkill {
  @override
  String get type => 'kb_search';

  @override
  NeuraCapability get capability => NeuraCapability.localKnowledge;

  @override
  NeuraRisk get risk => NeuraRisk.low;

  @override
  String summarize(NeuraActionRequest req) {
    final q = (req.params['query'] ?? '').toString();
    return 'Search local knowledge packs for: "$q"';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    await NeuraKnowledgeService.I.init();

    final q = (req.params['query'] ?? '').toString().trim();
    final topK = int.tryParse((req.params['topK'] ?? '').toString()) ?? 5;

    if (q.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing query.');
    }

    final hits = NeuraKnowledgeService.I.search(q, topK: topK.clamp(1, 10));

    final items = hits.map((h) {
      return {
        'docId': h.doc.id,
        'title': h.doc.title,
        'tags': h.doc.tags,
        'score': h.score,
        'snippet': h.snippet,
        'suggestions': h.doc.suggestions,
      };
    }).toList();

    // Also surface suggestions at top-level for the console "Suggested next actions" UI.
    final topSuggestions = <Map<String, dynamic>>[];
    for (final h in hits) {
      for (final s in h.doc.suggestions) {
        if (topSuggestions.length >= 8) break;
        // Basic de-dup by type+params
        final key = '${s['type']}|${s['params']}';
        if (!topSuggestions.any((e) => '${e['type']}|${e['params']}' == key)) {
          topSuggestions.add(s);
        }
      }
    }

    return NeuraActionResult(
      ok: true,
      message: 'Local knowledge results (${items.length}).',
      data: {
        'query': q,
        'items': items,
        'suggestions': topSuggestions,
        'offline': true,
      },
    );
  }
}
