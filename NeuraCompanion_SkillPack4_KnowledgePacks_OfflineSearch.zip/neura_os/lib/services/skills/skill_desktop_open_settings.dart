import 'dart:io';

import '../neura_policy.dart';
import 'neura_skill.dart';

/// Opens a specific Windows Settings panel via an allowlisted ms-settings URI.
/// This is intentionally conservative: only a small set of panels are supported.
class SkillDesktopOpenSettings extends NeuraSkill {
  @override
  String get type => 'desktop_open_settings';

  @override
  NeuraCapability get capability => NeuraCapability.systemAutomation;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  static const Map<String, String> _panelToUri = {
    'windows_update': 'ms-settings:windowsupdate',
    'bluetooth': 'ms-settings:bluetooth',
    'wifi': 'ms-settings:network-wifi',
    'network': 'ms-settings:network',
    'display': 'ms-settings:display',
    'sound': 'ms-settings:sound',
    'privacy_microphone': 'ms-settings:privacy-microphone',
    'apps_features': 'ms-settings:appsfeatures',
    'storage': 'ms-settings:storagesense',
    'time_date': 'ms-settings:dateandtime',
  };

  @override
  String summarize(NeuraActionRequest req) {
    final panel = (req.params['panel'] ?? '').toString();
    return 'Open Windows Settings panel: $panel';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    if (!Platform.isWindows) {
      return const NeuraActionResult(ok: false, message: 'desktop_open_settings is supported on Windows only.');
    }

    final panel = (req.params['panel'] ?? '').toString().trim();
    final uri = _panelToUri[panel];
    if (uri == null) {
      return NeuraActionResult(
        ok: false,
        message:
            'Unsupported panel "$panel". Allowed: ${_panelToUri.keys.join(', ')}',
      );
    }

    try {
      // cmd /c start "" "ms-settings:xyz"
      await Process.start('cmd', ['/c', 'start', '', uri], runInShell: true);
      return NeuraActionResult(ok: true, message: 'Opened Settings: $panel', data: {'panel': panel, 'uri': uri});
    } catch (e) {
      return NeuraActionResult(ok: false, message: 'Failed to open Settings panel: $e');
    }
  }
}
