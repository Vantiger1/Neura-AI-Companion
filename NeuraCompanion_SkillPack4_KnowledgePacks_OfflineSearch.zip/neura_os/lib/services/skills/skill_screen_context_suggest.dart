import 'dart:io';
import 'dart:typed_data';

import 'package:flusseract/flusseract.dart' as flusseract;
import 'package:path_provider/path_provider.dart';
import 'package:screen_capturer/screen_capturer.dart';

import '../neura_policy.dart';
import 'neura_skill.dart';

/// Screen-aware suggestion engine (offline).
///
/// Captures the desktop screen (optional) and runs OCR, then proposes *safe* next actions.
/// It does NOT execute anything automatically. Execution always goes through policy + approval.
class SkillScreenContextSuggest extends NeuraSkill {
  static bool _tessReady = false;

  @override
  String get type => 'screen_context_suggest';

  @override
  NeuraCapability get capability => NeuraCapability.systemAutomation;

  @override
  NeuraRisk get risk => NeuraRisk.high;

  @override
  String summarize(NeuraActionRequest req) => 'Analyze the current screen (offline OCR) and propose safe next actions.';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    // Desktop only for now.
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return const NeuraActionResult(
        ok: false,
        message: 'screen_context_suggest is supported on desktop (Windows/macOS/Linux) only.',
      );
    }

    final autoCapture = (req.params['autoCapture'] ?? true) == true;
    String text = (req.params['text'] ?? '').toString();

    String? imagePath;
    try {
      if (autoCapture) {
        final tmp = await getTemporaryDirectory();
        imagePath = '${tmp.path}${Platform.pathSeparator}neura_context_${DateTime.now().millisecondsSinceEpoch}.png';

        final cap = await screenCapturer.capture(
          mode: CaptureMode.screen,
          imagePath: imagePath,
          copyToClipboard: false,
        );
        if (cap == null) {
          return const NeuraActionResult(ok: false, message: 'Screen capture cancelled.');
        }

        if (!_tessReady) {
          await flusseract.TessData.init();
          _tessReady = true;
        }

        final bytes = await File(imagePath).readAsBytes();
        final pix = flusseract.PixImage.fromBytes(Uint8List.fromList(bytes));
        final tesseract = flusseract.Tesseract(tessDataPath: flusseract.TessData.tessDataPath);
        text = (await tesseract.utf8Text(pix)).trim();
      }

      final summary = _summarize(text);
      final suggestions = await _suggest(text, imagePath);

      return NeuraActionResult(
        ok: true,
        message: suggestions.isEmpty ? 'No obvious safe suggestions found.' : 'Suggestions ready.',
        data: {
          'imagePath': imagePath,
          'text': _cap(text, 6000),
          'summary': summary,
          'suggestions': suggestions,
        },
      );
    } catch (e) {
      final hint = 'If this is the first run: add assets/tessdata/eng.traineddata (see assets/tessdata/README_TESSDATA.txt).';
      return NeuraActionResult(ok: false, message: 'Screen context failed: $e\n$hint');
    }
  }

  String _cap(String s, int max) => s.length <= max ? s : s.substring(0, max);

  String _summarize(String text) {
    if (text.trim().isEmpty) return '';
    final lines = text.split(RegExp(r'\r?\n')).map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
    return lines.take(10).join(' | ');
  }

  Future<List<Map<String, dynamic>>> _suggest(String raw, String? imagePath) async {
    final text = raw.toLowerCase();
    final List<Map<String, dynamic>> out = [];

    // Useful local folders (computed at runtime)
    final docs = await getApplicationDocumentsDirectory();
    final notesDir = Directory('${docs.path}/neura_notes');
    if (!await notesDir.exists()) {
      await notesDir.create(recursive: true);
    }
    final tmp = await getTemporaryDirectory();

    void add({
      required String type,
      required Map<String, dynamic> params,
      required String summary,
      required NeuraCapability capability,
      required NeuraRisk risk,
      String? rationale,
    }) {
      out.add({
        'type': type,
        'params': params,
        'summary': summary,
        'capability': capability.name,
        'risk': risk.name,
        if (rationale != null) 'rationale': rationale,
      });
    }

    if (imagePath != null) {
      add(
        type: 'desktop_open_folder',
        params: {'path': tmp.path},
        summary: 'Open Neura\'s temporary capture folder.',
        capability: NeuraCapability.fileAccess,
        risk: NeuraRisk.medium,
        rationale: 'Contains the most recent captured screenshots (local only).',
      );
    }

    // Always offer: save what we saw into a local note (safe).
    if (raw.trim().isNotEmpty) {
      add(
        type: 'write_note',
        params: {
          'title': 'Screen snapshot (OCR)',
          'body': raw.length > 8000 ? raw.substring(0, 8000) : raw,
        },
        summary: 'Save the screen text into a local note.',
        capability: NeuraCapability.fileAccess,
        risk: NeuraRisk.low,
        rationale: 'Keeps a local record without sending anything anywhere.',
      );
    }

    // Error / crash patterns.
    final isError = text.contains('error') ||
        text.contains('exception') ||
        text.contains('failed') ||
        text.contains('stack trace') ||
        text.contains('not responding') ||
        text.contains('access is denied') ||
        text.contains('permission denied');

    if (isError) {
      if (Platform.isWindows) {
        add(
        type: 'desktop_open_folder',
        params: {'path': notesDir.path},
        summary: 'Open Neura\'s notes folder.',
        capability: NeuraCapability.fileAccess,
        risk: NeuraRisk.medium,
        rationale: 'When something breaks, logs are the receipts.',
      );
      add(
        type: 'desktop_open_settings',
        params: {'panel': 'windows_update'},
        summary: 'Open Windows Update settings.',
        capability: NeuraCapability.systemAutomation,
        risk: NeuraRisk.medium,
        rationale: 'Many driver/runtime issues resolve via updates.',
      );
      }
    }

    // Network hints.
    final net = text.contains('wifi') || text.contains('wi-fi') || text.contains('network') || text.contains('internet') || text.contains('dns');
    if (Platform.isWindows && net) {
      add(
        type: 'desktop_open_settings',
        params: {'panel': 'wifi'},
        summary: 'Open Wi‑Fi settings.',
        capability: NeuraCapability.systemAutomation,
        risk: NeuraRisk.medium,
        rationale: 'Quickly inspect connectivity without guessing.',
      );
    }

    // Bluetooth hints.
    if (Platform.isWindows && (text.contains('bluetooth') || text.contains('pair') || text.contains('pairing'))) {
      add(
        type: 'desktop_open_settings',
        params: {'panel': 'bluetooth'},
        summary: 'Open Bluetooth settings.',
        capability: NeuraCapability.systemAutomation,
        risk: NeuraRisk.medium,
        rationale: 'Pairing issues usually live here.',
      );
    }

    // Microphone / permissions hints.
    if (Platform.isWindows && (text.contains('microphone') || text.contains('mic') || text.contains('recording'))) {
      add(
        type: 'desktop_open_settings',
        params: {'panel': 'privacy_microphone'},
        summary: 'Open Microphone privacy settings.',
        capability: NeuraCapability.systemAutomation,
        risk: NeuraRisk.medium,
        rationale: 'If STT isn’t hearing you, permissions are often the culprit.',
      );
    }

    // Storage / disk full.
    if (Platform.isWindows && text.contains('disk') && (text.contains('full') || text.contains('low'))) {
      add(
        type: 'desktop_open_settings',
        params: {'panel': 'storage'},
        summary: 'Open Storage settings.',
        capability: NeuraCapability.systemAutomation,
        risk: NeuraRisk.medium,
        rationale: 'Low disk space breaks everything in creative ways.',
      );
    }

    // If the user is clearly in a browser context, offer *optional* web search (but offline defaults block network).
    final looksBrowser = text.contains('chrome') || text.contains('edge') || text.contains('firefox') || text.contains('safari') || text.contains('http');
    if (looksBrowser && isError) {
      add(
        type: 'open_url',
        params: {'url': 'https://duckduckgo.com/?q=fix+' + Uri.encodeComponent(_extractKeywords(raw))},
        summary: 'Open a web search for the on‑screen error (requires Network Access).',
        capability: NeuraCapability.networkAccess,
        risk: NeuraRisk.medium,
        rationale: 'Only if the user enables Network Access. Default is offline.',
      );
    }

    // Deduplicate by type+params.
    final seen = <String>{};
    final deduped = <Map<String, dynamic>>[];
    for (final s in out) {
      final key = '${s['type']}|${s['params']}';
      if (seen.add(key)) deduped.add(s);
    }
    return deduped.take(12).toList();
  }

  String _extractKeywords(String raw) {
    final t = raw
        .replaceAll(RegExp(r'[^A-Za-z0-9 _\-]'), ' ')
        .split(RegExp(r'\s+'))
        .where((w) => w.length >= 4)
        .take(8)
        .join(' ');
    return t.trim().isEmpty ? 'error help' : t.trim();
  }
}
