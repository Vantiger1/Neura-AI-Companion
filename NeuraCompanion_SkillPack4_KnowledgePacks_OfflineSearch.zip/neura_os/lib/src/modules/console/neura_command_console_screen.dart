import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../../services/neura_local_core_daemon.dart';

class NeuraCommandConsoleScreen extends StatefulWidget {
  const NeuraCommandConsoleScreen({super.key});

  @override
  State<NeuraCommandConsoleScreen> createState() => _NeuraCommandConsoleScreenState();
}

class _NeuraCommandConsoleScreenState extends State<NeuraCommandConsoleScreen> {
  final _type = TextEditingController(text: 'write_note');
  final _params = TextEditingController(
    text: jsonEncode({
      'title': 'Hello from Neura',
      'body': 'This note was created by a safe on-device action.',
    }),
  );

  bool _busy = false;
  String _out = '';
  List<Map<String, dynamic>> _suggestions = const [];

  Future<Map<String, dynamic>> _postJson(String path, Map<String, dynamic> body) async {
    final port = NeuraLocalCoreDaemon.I.port ?? 7788;
    final uri = Uri.parse('http://127.0.0.1:$port$path');

    final client = HttpClient();
    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(body));
      final res = await req.close();
      final txt = await utf8.decodeStream(res);
      final map = (jsonDecode(txt) as Map).cast<String, dynamic>();
      map['_statusCode'] = res.statusCode;
      return map;
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _run() async {
    setState(() {
      _busy = true;
      _out = '';
    });

    try {
      final type = _type.text.trim();
      final params = (jsonDecode(_params.text) as Map).cast<String, dynamic>();
      final res = await _postJson('/execute', {'type': type, 'params': params});

      if ((res['status'] ?? '') == 'needs_approval') {
        final approvalId = (res['approvalId'] ?? '').toString();
        final summary = (res['summary'] ?? '').toString();
        final reason = (res['reason'] ?? '').toString();

        final approved = await showDialog<bool>(
          context: context,
          builder: (_) => _ApprovalDialog(summary: summary, reason: reason),
        );

        if (approved == true) {
          final res2 = await _postJson('/approve', {'approvalId': approvalId, 'approve': true});
          setState(() {
            _out = const JsonEncoder.withIndent('  ').convert(res2);
            final data = (res2['data'] as Map?)?.cast<String, dynamic>();
            final sugg = (data?['suggestions'] as List?)?.cast<dynamic>();
            if (sugg != null) {
              _suggestions = sugg.map((e) => (e as Map).cast<String, dynamic>()).toList();
            }
          });
        } else {
          await _postJson('/approve', {'approvalId': approvalId, 'approve': false});
          setState(() => _out = 'Action rejected.');
        }
      } else {
        setState(() {
          _out = const JsonEncoder.withIndent('  ').convert(res);
          final data = (res['data'] as Map?)?.cast<String, dynamic>();
          final sugg = (data?['suggestions'] as List?)?.cast<dynamic>();
          if (sugg != null) {
            _suggestions = sugg.map((e) => (e as Map).cast<String, dynamic>()).toList();
          }
        });
      }
    } catch (e) {
      setState(() => _out = 'Error: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _type.dispose();
    _params.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final port = NeuraLocalCoreDaemon.I.port;
    final isDesktop = Platform.isWindows || Platform.isLinux || Platform.isMacOS;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Command Console'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Center(child: Text(port == null ? 'daemon: ?' : 'daemon: $port')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Neura Command Console — Safe Actions + Screen-Aware Tools'),
          const SizedBox(height: 12),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              OutlinedButton(
                onPressed: _busy
                    ? null
                    : () {
                        _type.text = 'kb_search';
                        _params.text = jsonEncode({'query': 'windows update', 'topK': 6});
                        setState(() {});
                      },
                child: const Text('kb_search'),
              ),
              OutlinedButton(
                onPressed: _busy
                    ? null
                    : () {
                        _type.text = 'write_note';
                        _params.text = jsonEncode({
                          'title': 'Hello from Neura',
                          'body': 'This note was created by a safe on-device action.',
                        });
                        setState(() {});
                      },
                child: const Text('write_note'),
              ),
              OutlinedButton(
                onPressed: _busy
                    ? null
                    : () {
                        _type.text = 'desktop_launch_app';
                        _params.text = jsonEncode({'app': 'notepad'});
                        setState(() {});
                      },
                child: const Text('launch notepad'),
              ),
              OutlinedButton(
                onPressed: _busy
                    ? null
                    : () {
                        _type.text = 'desktop_open_folder';
                        _params.text = jsonEncode({'path': 'Documents'});
                        setState(() {});
                      },
                child: const Text('open Documents'),
              ),
              if (isDesktop)
                OutlinedButton(
                  onPressed: _busy
                      ? null
                      : () {
                          _type.text = 'screen_ocr';
                          _params.text = jsonEncode({});
                          setState(() {});
                        },
                  child: const Text('screen_ocr (desktop)'),
                ),
              if (isDesktop)
                OutlinedButton(
                  onPressed: _busy
                      ? null
                      : () {
                          _type.text = 'screen_context_suggest';
                          _params.text = jsonEncode({'autoCapture': true});
                          setState(() {});
                        },
                  child: const Text('screen_context_suggest'),
                ),
              if (Platform.isWindows)
                OutlinedButton(
                  onPressed: _busy
                      ? null
                      : () {
                          _type.text = 'desktop_open_settings';
                          _params.text = jsonEncode({'panel': 'windows_update'});
                          setState(() {});
                        },
                  child: const Text('open Windows Update'),
                ),
            ],
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _type,
            decoration: const InputDecoration(
              labelText: 'Action Type',
              hintText: 'kb_search | write_note | open_url | desktop_launch_app | desktop_open_folder | desktop_open_settings | screen_ocr | screen_context_suggest',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 10),
          TextField(
            controller: _params,
            maxLines: 8,
            decoration: const InputDecoration(
              labelText: 'Params (JSON)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            onPressed: _busy ? null : _run,
            icon: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.play_arrow),
            label: const Text('Run'),
          ),
          const SizedBox(height: 12),
          const Text('Output'),
          const SizedBox(height: 8),
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              border: Border.all(color: Colors.white24),
              borderRadius: BorderRadius.circular(12),
            ),
            child: SelectableText(_out.isEmpty ? '—' : _out),
          ),
          const SizedBox(height: 16),
          if (_suggestions.isNotEmpty) ...[
            const Text('Suggested next actions'),
            const SizedBox(height: 8),
            ..._suggestions.map((s) => _SuggestionCard(
                  suggestion: s,
                  onRun: _busy
                      ? null
                      : () async {
                          final type = (s['type'] ?? '').toString();
                          final params = (s['params'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{};
                          _type.text = type;
                          _params.text = jsonEncode(params);
                          setState(() {});
                          await _run();
                        },
                )),
          ],

        ],
      ),
    );
  }
}

class _ApprovalDialog extends StatelessWidget {
  final String summary;
  final String reason;
  const _ApprovalDialog({required this.summary, required this.reason});

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: const Text('Approve Action?'),
      content: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(summary),
          const SizedBox(height: 10),
          Text('Policy: $reason', style: Theme.of(context).textTheme.bodySmall),
          const SizedBox(height: 12),
          const Text('Tip: Keep automation conservative. Neura asks because she respects your device.'),
        ],
      ),
      actions: [
        TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Reject')),
        ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Approve')),
      ],
    );
  }
}

class _SuggestionCard extends StatelessWidget {
  final Map<String, dynamic> suggestion;
  final VoidCallback? onRun;
  const _SuggestionCard({required this.suggestion, required this.onRun});

  @override
  Widget build(BuildContext context) {
    final type = (suggestion['type'] ?? '').toString();
    final rationale = (suggestion['rationale'] ?? '').toString();
    final cap = (suggestion['capability'] ?? '').toString();
    final risk = (suggestion['risk'] ?? '').toString();

    return Card(
      child: ListTile(
        leading: const Icon(Icons.play_circle_outline),
        title: Text(type),
        subtitle: Text(rationale.isEmpty ? '$cap • $risk' : '$rationale\n$cap • $risk'),
        trailing: TextButton(
          onPressed: onRun,
          child: const Text('Run'),
        ),
      ),
    );
  }
}
