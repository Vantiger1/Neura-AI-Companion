import 'dart:convert';
import 'dart:io';

import 'package:flutter/material.dart';

import '../../../services/neura_local_core_daemon.dart';

class NeuraKnowledgeLibraryScreen extends StatefulWidget {
  const NeuraKnowledgeLibraryScreen({super.key});

  @override
  State<NeuraKnowledgeLibraryScreen> createState() => _NeuraKnowledgeLibraryScreenState();
}

class _NeuraKnowledgeLibraryScreenState extends State<NeuraKnowledgeLibraryScreen> {
  final _q = TextEditingController();
  bool _busy = false;
  List<Map<String, dynamic>> _items = const [];
  List<Map<String, dynamic>> _suggestions = const [];
  String _status = '';

  Future<Map<String, dynamic>> _postJson(String path, Map<String, dynamic> body) async {
    final port = NeuraLocalCoreDaemon.I.port ?? 7788;
    final uri = Uri.parse('http://127.0.0.1:$port$path');

    final client = HttpClient();
    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(body));
      final res = await req.close();
      final txt = await utf8.decodeStream(res);
      final map = (jsonDecode(txt) as Map).cast<String, dynamic>();
      map['_statusCode'] = res.statusCode;
      return map;
    } finally {
      client.close(force: true);
    }
  }

  Future<void> _search() async {
    final query = _q.text.trim();
    if (query.isEmpty) return;

    setState(() {
      _busy = true;
      _status = '';
      _items = const [];
      _suggestions = const [];
    });

    try {
      final res = await _postJson('/execute', {
        'type': 'kb_search',
        'params': {'query': query, 'topK': 6},
      });

      if (res['ok'] == true) {
        final data = (res['data'] as Map?)?.cast<String, dynamic>() ?? const {};
        final items = ((data['items'] as List?) ?? const <dynamic>[]).map((e) => (e as Map).cast<String, dynamic>()).toList();
        final sugg = ((data['suggestions'] as List?) ?? const <dynamic>[]).map((e) => (e as Map).cast<String, dynamic>()).toList();
        setState(() {
          _items = items;
          _suggestions = sugg;
          _status = data['offline'] == true ? 'Offline results' : 'Results';
        });
      } else {
        setState(() => _status = (res['error'] ?? res['message'] ?? 'Search failed').toString());
      }
    } catch (e) {
      setState(() => _status = 'Error: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _runSuggestion(Map<String, dynamic> s) async {
    final type = (s['type'] ?? '').toString();
    final params = (s['params'] as Map?)?.cast<String, dynamic>() ?? const {};

    // Use the Console flow (execute -> approval if needed) by reusing the same endpoints.
    final res = await _postJson('/execute', {'type': type, 'params': params});
    if ((res['status'] ?? '') == 'needs_approval') {
      final approvalId = (res['approvalId'] ?? '').toString();
      final summary = (res['summary'] ?? '').toString();
      final reason = (res['reason'] ?? '').toString();

      final approved = await showDialog<bool>(
        context: context,
        builder: (_) => AlertDialog(
          title: const Text('Approve Action?'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(summary),
              const SizedBox(height: 10),
              Text('Policy: $reason', style: Theme.of(context).textTheme.bodySmall),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.of(context).pop(false), child: const Text('Reject')),
            ElevatedButton(onPressed: () => Navigator.of(context).pop(true), child: const Text('Approve')),
          ],
        ),
      );

      await _postJson('/approve', {'approvalId': approvalId, 'approve': approved == true});
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(approved == true ? 'Action executed.' : 'Action rejected.')));
    } else {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Action executed.')));
    }
  }

  @override
  void dispose() {
    _q.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final port = NeuraLocalCoreDaemon.I.port;
    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Knowledge Library'),
        actions: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Center(child: Text(port == null ? 'daemon: ?' : 'daemon: $port')),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('Offline help packs (local search).'),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextField(
                  controller: _q,
                  onSubmitted: (_) => _search(),
                  decoration: const InputDecoration(
                    labelText: 'Search',
                    hintText: 'e.g., windows update, offline mode, full access',
                    border: OutlineInputBorder(),
                  ),
                ),
              ),
              const SizedBox(width: 10),
              ElevatedButton(
                onPressed: _busy ? null : _search,
                child: _busy ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Search'),
              ),
            ],
          ),
          if (_status.isNotEmpty) ...[
            const SizedBox(height: 10),
            Text(_status, style: Theme.of(context).textTheme.bodySmall),
          ],
          if (_suggestions.isNotEmpty) ...[
            const SizedBox(height: 16),
            Text('Suggested actions', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ..._suggestions.map((s) => Card(
                  child: ListTile(
                    leading: const Icon(Icons.play_circle_outline),
                    title: Text((s['type'] ?? '').toString()),
                    subtitle: Text((s['rationale'] ?? '').toString()),
                    trailing: TextButton(
                      onPressed: _busy ? null : () => _runSuggestion(s),
                      child: const Text('Run'),
                    ),
                  ),
                )),
          ],
          const SizedBox(height: 16),
          if (_items.isEmpty) ...[
            const Text('No results yet.'),
          ] else ...[
            Text('Matches', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 8),
            ..._items.map((it) => Card(
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text((it['title'] ?? '').toString(), style: Theme.of(context).textTheme.titleMedium),
                        const SizedBox(height: 6),
                        Text((it['snippet'] ?? '').toString()),
                        const SizedBox(height: 8),
                        Wrap(
                          spacing: 6,
                          children: ((it['tags'] as List?) ?? const <dynamic>[]).map((t) => Chip(label: Text(t.toString()))).toList(),
                        ),
                      ],
                    ),
                  ),
                )),
          ],
        ],
      ),
    );
  }
}
