import 'package:flutter/material.dart';

import '../../../services/neura_automation_prefs.dart';

class AutomationFullAccessScreen extends StatefulWidget {
  const AutomationFullAccessScreen({super.key});

  @override
  State<AutomationFullAccessScreen> createState() => _AutomationFullAccessScreenState();
}

class _AutomationFullAccessScreenState extends State<AutomationFullAccessScreen> {
  bool c1 = false;
  bool c2 = false;
  bool c3 = false;
  bool c4 = false;

  final initials = TextEditingController();
  final phrase = TextEditingController();

  bool _loading = true;
  bool _fullAccess = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await NeuraAutomationPrefs.I.init();
    setState(() {
      _fullAccess = NeuraAutomationPrefs.I.fullAccessEnabled;
      initials.text = NeuraAutomationPrefs.I.fullAccessInitials;
      _loading = false;
    });
  }

  bool get _checklistOk => c1 && c2 && c3 && c4;

  String get _requiredPhrase => 'I UNDERSTAND';

  Future<void> _enableFullAccess() async {
    final init = initials.text.trim();
    if (init.length < 2) {
      _toast('Please enter initials (2+ characters).');
      return;
    }
    if (phrase.text.trim().toUpperCase() != _requiredPhrase) {
      _toast('Type the phrase exactly: $_requiredPhrase');
      return;
    }
    if (!_checklistOk) {
      _toast('Complete the checklist first.');
      return;
    }
    await NeuraAutomationPrefs.I.setFullAccess(enabled: true, initials: init);
    setState(() => _fullAccess = true);
    _toast('Full Access enabled.');
  }

  Future<void> _disableFullAccess() async {
    await NeuraAutomationPrefs.I.setFullAccess(enabled: false, initials: '');
    setState(() => _fullAccess = false);
    _toast('Full Access disabled.');
  }

  Future<void> _setCap(String key, bool v) async {
    await NeuraAutomationPrefs.I.setCapability(key: key, value: v);
    setState(() {});
  }

  void _toast(String msg) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  @override
  void dispose() {
    initials.dispose();
    phrase.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) return const Scaffold(body: Center(child: CircularProgressIndicator()));

    final prefs = NeuraAutomationPrefs.I;

    return Scaffold(
      appBar: AppBar(title: const Text('Automation & Full Access')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Full Access Automation Disclaimer', style: Theme.of(context).textTheme.titleMedium),
                  const SizedBox(height: 8),
                  const Text(
                    'Enabling Full Access allows Neura to perform automated actions that may affect your device, files, apps, or settings.\n\n'
                    'By enabling Full Access you agree that:\n'
                    '• Neura is provided “as-is” and may produce unexpected results.\n'
                    '• You are responsible for reviewing, approving, and supervising automation.\n'
                    '• The creators are not liable for damages, data loss, misconfiguration, downtime, or other consequences from use of automation.\n'
                    '• Neura is not medical, legal, or financial advice and is not a substitute for licensed professionals.\n\n'
                    'If you do not agree, do not enable Full Access.',
                  ),
                  const SizedBox(height: 12),
                  Wrap(
                    spacing: 12,
                    runSpacing: 8,
                    children: [
                      Chip(
                        label: Text(_fullAccess ? 'FULL ACCESS: ON' : 'FULL ACCESS: OFF'),
                      ),
                      if (prefs.fullAccessAcceptedAt != null)
                        Chip(label: Text('Accepted: ${prefs.fullAccessAcceptedAt!.toLocal()}')),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),

          Card(
            child: Column(
              children: [
                SwitchListTile(
                  value: prefs.capLocalKnowledge || prefs.fullAccessEnabled,
                  onChanged: prefs.fullAccessEnabled ? null : (v) => _setCap(NeuraAutomationPrefs.capKeyLocalKnowledge(), v),
                  title: const Text('Local Knowledge Library'),
                  subtitle: Text(prefs.fullAccessEnabled
                      ? 'Overridden by Full Access.'
                      : 'Allow Neura to search built-in offline help packs (recommended ON).'),
                  secondary: const Icon(Icons.library_books_outlined),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: prefs.capLaunchApps || prefs.fullAccessEnabled,
                  onChanged: prefs.fullAccessEnabled ? null : (v) => _setCap(NeuraAutomationPrefs.capKeyLaunchApps(), v),
                  title: const Text('Launch Apps'),
                  subtitle: Text(prefs.fullAccessEnabled
                      ? 'Overridden by Full Access.'
                      : 'Allow Neura to launch allowlisted apps.'),
                  secondary: const Icon(Icons.apps_outlined),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: prefs.capFileAccess || prefs.fullAccessEnabled,
                  onChanged: prefs.fullAccessEnabled ? null : (v) => _setCap(NeuraAutomationPrefs.capKeyFileAccess(), v),
                  title: const Text('File Access'),
                  subtitle: Text(prefs.fullAccessEnabled
                      ? 'Overridden by Full Access.'
                      : 'Allow Neura to read/write inside safe app folders.'),
                  secondary: const Icon(Icons.folder_outlined),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: prefs.capSystemAutomation || prefs.fullAccessEnabled,
                  onChanged: prefs.fullAccessEnabled ? null : (v) => _setCap(NeuraAutomationPrefs.capKeySystemAutomation(), v),
                  title: const Text('System Automation'),
                  subtitle: Text(prefs.fullAccessEnabled
                      ? 'Overridden by Full Access.'
                      : 'Allow OS-level automation (always approval-gated).'),
                  secondary: const Icon(Icons.settings_suggest_outlined),
                ),
                const Divider(height: 1),
                SwitchListTile(
                  value: prefs.capNetworkAccess || prefs.fullAccessEnabled,
                  onChanged: prefs.fullAccessEnabled ? null : (v) => _setCap(NeuraAutomationPrefs.capKeyNetworkAccess(), v),
                  title: const Text('Network Access'),
                  subtitle: Text(prefs.fullAccessEnabled
                      ? 'Overridden by Full Access.'
                      : 'Allow opening URLs / “web” actions. Default OFF for strict offline mode.'),
                  secondary: const Icon(Icons.public_outlined),
                ),
              ],
            ),
          ),

          const SizedBox(height: 16),
          if (!_fullAccess) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('Full Access Checklist', style: Theme.of(context).textTheme.titleMedium),
                    const SizedBox(height: 8),
                    CheckboxListTile(
                      value: c1,
                      onChanged: (v) => setState(() => c1 = v ?? false),
                      title: const Text('I understand automation can cause unintended changes.'),
                    ),
                    CheckboxListTile(
                      value: c2,
                      onChanged: (v) => setState(() => c2 = v ?? false),
                      title: const Text('I will review and approve actions before they run.'),
                    ),
                    CheckboxListTile(
                      value: c3,
                      onChanged: (v) => setState(() => c3 = v ?? false),
                      title: const Text('I have backups for important data.'),
                    ),
                    CheckboxListTile(
                      value: c4,
                      onChanged: (v) => setState(() => c4 = v ?? false),
                      title: const Text('I accept the disclaimer and assume responsibility.'),
                    ),
                    const SizedBox(height: 8),
                    TextField(
                      controller: initials,
                      decoration: const InputDecoration(
                        labelText: 'Initials',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 10),
                    TextField(
                      controller: phrase,
                      decoration: InputDecoration(
                        labelText: 'Type the phrase: $_requiredPhrase',
                        border: const OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 12),
                    ElevatedButton.icon(
                      onPressed: _enableFullAccess,
                      icon: const Icon(Icons.verified_user_outlined),
                      label: const Text('Enable Full Access'),
                    ),
                  ],
                ),
              ),
            ),
          ] else ...[
            ElevatedButton.icon(
              style: ElevatedButton.styleFrom(backgroundColor: Colors.redAccent),
              onPressed: _disableFullAccess,
              icon: const Icon(Icons.lock_outline),
              label: const Text('Disable Full Access'),
            ),
          ],
        ],
      ),
    );
  }
}
