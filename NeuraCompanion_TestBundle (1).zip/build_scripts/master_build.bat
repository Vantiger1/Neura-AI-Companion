@echo off
REM ---------------------------------------------
REM Master Build for Neura Companion
REM ---------------------------------------------
REM 0. Clean previous builds
rd /s /q builds installers NeuraCompanion.zip

REM 1. Generate asset placeholders
bash build_scripts/generate_placeholders.sh

REM 2. Scaffold feature packages
bash build_scripts/scaffold_modules.sh

REM 3. Run all tests
bash build_scripts/run_tests.sh
if %ERRORLEVEL% NEQ 0 (
  echo Tests failed. Aborting build.
  exit /b %ERRORLEVEL%
)

REM 4. Build all Flutter targets
bash build_scripts/build_all.sh

REM 5. Package installers
bash build_scripts/package_installers.sh

REM 6. Package individual feature zips
for %%p in (core ritual_mode dream_visualizer mood_tracker error_handling voice_journaling mirror_mode store_front social_feed neuro_fetch neuro_responsive) do (
  rd /s /q temp_package
  mkdir temp_package\%%p
  xcopy packages\%%p temp_package\%%p /E /I /Y
  powershell -Command "Compress-Archive -Path temp_package\%%p -DestinationPath installers\%%p.zip -Force"
)
rd /s /q temp_package

REM 7. Final assembly
powershell -Command "Compress-Archive -Path installers -DestinationPath NeuraCompanion.zip -Force"

echo Master build complete. Output: NeuraCompanion.zip and individual module zips in installers\
