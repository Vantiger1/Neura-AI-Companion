@echo off
REM ---------------------------------------------
REM Final Build Execution for Public Testing
REM ---------------------------------------------
REM Ensure all phase zips are present
for %%Z in (Phase0_release.zip Phase1.zip Phase2_release.zip Phase3_release.zip Phase4_release.zip Phase5_release.zip Phase6_release.zip) do (
  if not exist %%Z (
    echo Missing %%Z - please generate phase zips first.
    exit /b 1
  )
)

REM Unzip all phases into a merged workspace
mkdir merged_workspace
powershell -Command "Expand-Archive Phase0_release.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase1.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase2_release.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase3_release.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase4_release.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase5_release.zip -DestinationPath merged_workspace -Force"
powershell -Command "Expand-Archive Phase6_release.zip -DestinationPath merged_workspace -Force"

REM Copy merged contents into project root
xcopy merged_workspace\* . /E /I /Y

REM Call master build to compile and package
call build_scripts\master_build.bat

REM Cleanup merged workspace
rd /s /q merged_workspace

echo Final build and packaging complete.
