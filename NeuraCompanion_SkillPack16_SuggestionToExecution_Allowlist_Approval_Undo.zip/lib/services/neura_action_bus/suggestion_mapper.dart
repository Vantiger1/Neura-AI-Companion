import 'dart:io';

/// Strict mapping of a suggestion object into a concrete allowlisted action.
/// If we can't prove it's safe + known, we refuse.
class NeuraSuggestionMapper {
  Map<String, dynamic>? toAction(Map<String, dynamic> suggestion) {
    final directActionId = suggestion['actionId'];
    if (directActionId is String && _allowlistedActionIds.contains(directActionId)) {
      final args = (suggestion['args'] is Map) ? Map<String, dynamic>.from(suggestion['args']) : <String, dynamic>{};
      return {'actionId': directActionId, 'args': args};
    }

    final type = (suggestion['type'] as String?)?.toLowerCase().trim();
    if (type == null || type.isEmpty) return null;

    switch (type) {
      case 'open_settings':
        if (!Platform.isWindows) return null;
        final target = (suggestion['target'] as String?)?.toLowerCase().trim();
        if (target == null || !_windowsSettingsTargets.contains(target)) return null;
        return {'actionId': 'desktop_open_settings', 'args': {'target': target}};
      case 'launch_app':
        if (!Platform.isWindows) return null;
        final app = (suggestion['app'] as String?)?.toLowerCase().trim();
        if (app == null || !_windowsApps.contains(app)) return null;
        return {'actionId': 'desktop_launch_app', 'args': {'app': app}};
      case 'open_folder':
        if (!Platform.isWindows) return null;
        final path = (suggestion['path'] as String?)?.trim();
        if (path == null || path.isEmpty) return null;
        if (path.contains('..')) return null;
        return {'actionId': 'desktop_open_folder', 'args': {'path': path}};
      case 'write_note':
        final filename = (suggestion['filename'] as String?)?.trim();
        final content = (suggestion['content'] as String?) ?? '';
        if (filename == null || filename.isEmpty) return null;
        if (filename.contains('..') || filename.contains('/') || filename.contains('\\')) return null;
        return {'actionId': 'write_note', 'args': {'filename': filename, 'content': content}};
      case 'open_url':
        final url = (suggestion['url'] as String?)?.trim();
        if (url == null || url.isEmpty) return null;
        if (!(url.startsWith('http://') || url.startsWith('https://'))) return null;
        return {'actionId': 'open_url', 'args': {'url': url}};
      default:
        return null;
    }
  }

  static const Set<String> _allowlistedActionIds = {
    'desktop_open_settings',
    'desktop_launch_app',
    'desktop_open_folder',
    'write_note',
    'open_url',
  };

  static const Set<String> _windowsApps = {'notepad', 'calc', 'calculator', 'explorer', 'cmd', 'powershell'};

  static const Set<String> _windowsSettingsTargets = {
    'windows_update',
    'bluetooth',
    'wifi',
    'network',
    'display',
    'sound',
    'privacy_microphone',
    'apps_features',
    'storage',
    'time_date',
  };
}
