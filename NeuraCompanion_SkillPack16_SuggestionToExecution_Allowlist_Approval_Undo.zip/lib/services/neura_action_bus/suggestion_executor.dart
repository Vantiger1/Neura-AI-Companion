import 'neura_executor.dart';
import 'suggestion_mapper.dart';
import 'undo_stack.dart';

class NeuraSuggestionExecutionResult {
  final bool ok;
  final String message;
  final Map<String, dynamic> data;

  const NeuraSuggestionExecutionResult(this.ok, this.message, this.data);

  factory NeuraSuggestionExecutionResult.ok(String message, Map<String, dynamic> data) =>
      NeuraSuggestionExecutionResult(true, message, data);

  factory NeuraSuggestionExecutionResult.err(String message, [Map<String, dynamic>? data]) =>
      NeuraSuggestionExecutionResult(false, message, data ?? const {});
}

class NeuraSuggestionExecutor {
  final NeuraActionExecutor executor;
  final NeuraSuggestionMapper mapper;
  final NeuraUndoStack undo;

  NeuraSuggestionExecutor({
    required this.executor,
    required this.mapper,
    required this.undo,
  });

  Future<NeuraSuggestionExecutionResult> executeSuggestion(Map<String, dynamic> suggestion) async {
    final mapped = mapper.toAction(suggestion);
    if (mapped == null) {
      return NeuraSuggestionExecutionResult.err('Suggestion not allowlisted (blocked).', {'suggestion': suggestion});
    }

    final actionId = mapped['actionId'] as String;
    final args = (mapped['args'] as Map<String, dynamic>?) ?? <String, dynamic>{};

    final r = await executor.execute(actionId, args: args);
    if (r.ok) {
      _maybePushUndo(actionId, args, r.data);
      return NeuraSuggestionExecutionResult.ok(r.message, {'actionId': actionId, 'result': r.data});
    }

    if (r.message == 'APPROVAL_REQUIRED') {
      return NeuraSuggestionExecutionResult.err('APPROVAL_REQUIRED', {'meta': r.data, 'actionId': actionId, 'args': args});
    }

    return NeuraSuggestionExecutionResult.err(r.message, {'actionId': actionId});
  }

  Future<NeuraSuggestionExecutionResult> approveAndExecute(String actionId, Map<String, dynamic> args) async {
    final r = await executor.approveAndExecute(actionId, args: args);
    if (r.ok) {
      _maybePushUndo(actionId, args, r.data);
      return NeuraSuggestionExecutionResult.ok(r.message, {'actionId': actionId, 'result': r.data});
    }
    return NeuraSuggestionExecutionResult.err(r.message, {'actionId': actionId});
  }

  void _maybePushUndo(String actionId, Map<String, dynamic> args, Map<String, dynamic> resultData) {
    if (actionId == 'write_note') {
      final prev = resultData['previousContent'];
      final filename = args['filename'];
      if (filename is String) {
        undo.push(
          NeuraUndoEntry(
            title: 'Undo note write: $filename',
            undoActionId: 'write_note',
            undoArgs: {'filename': filename, 'content': prev ?? ''},
          ),
        );
      }
    }
  }
}
