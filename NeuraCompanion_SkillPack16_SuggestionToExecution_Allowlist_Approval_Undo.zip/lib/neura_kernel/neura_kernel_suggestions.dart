import '../services/neura_action_bus/suggestion_executor.dart';
import '../services/neura_action_bus/suggestion_mapper.dart';
import '../services/neura_action_bus/undo_stack.dart';

/// Additive support: this file introduces the primitives needed to run
/// "suggested actions" via the same policy + approval flow.
class NeuraKernelSuggestionSupport {
  final NeuraUndoStack undoStack = NeuraUndoStack();

  NeuraSuggestionExecutor buildSuggestionExecutor(dynamic kernelExecutor) {
    return NeuraSuggestionExecutor(
      executor: kernelExecutor,
      mapper: NeuraSuggestionMapper(),
      undo: undoStack,
    );
  }
}
