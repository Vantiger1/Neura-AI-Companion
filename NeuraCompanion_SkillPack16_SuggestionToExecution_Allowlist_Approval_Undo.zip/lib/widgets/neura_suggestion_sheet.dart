import 'package:flutter/material.dart';

import '../neura_kernel/neura_kernel.dart';
import '../services/neura_action_bus/suggestion_executor.dart';
import '../services/neura_action_bus/suggestion_mapper.dart';
import '../services/neura_action_bus/undo_stack.dart';

class NeuraSuggestionSheet extends StatefulWidget {
  final List<Map<String, dynamic>> suggestions;
  const NeuraSuggestionSheet({super.key, required this.suggestions});

  @override
  State<NeuraSuggestionSheet> createState() => _NeuraSuggestionSheetState();
}

class _NeuraSuggestionSheetState extends State<NeuraSuggestionSheet> {
  String _status = 'Ready';

  late final NeuraSuggestionExecutor _exec = NeuraSuggestionExecutor(
    executor: NeuraKernel.I.executor,
    mapper: NeuraSuggestionMapper(),
    undo: NeuraUndoStack(),
  );

  Future<void> _run(Map<String, dynamic> suggestion) async {
    setState(() => _status = 'Running...');
    final r = await _exec.executeSuggestion(suggestion);
    if (!mounted) return;

    if (r.ok) {
      setState(() => _status = 'OK: ${r.message}');
      return;
    }

    if (r.message == 'APPROVAL_REQUIRED') {
      final meta = (r.data['meta'] as Map).cast<String, dynamic>();
      final actionId = r.data['actionId'] as String;
      final args = (r.data['args'] as Map).cast<String, dynamic>();

      final approved = await _askApproval(meta);
      if (!approved) {
        setState(() => _status = 'Cancelled');
        return;
      }
      final r2 = await _exec.approveAndExecute(actionId, args);
      setState(() => _status = r2.ok ? 'OK: ${r2.message}' : 'ERR: ${r2.message}');
      return;
    }

    setState(() => _status = 'Blocked: ${r.message}');
  }

  Future<bool> _askApproval(Map<String, dynamic> meta) async {
    return (await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('Approve action (${meta['risk']})'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${meta['title']}'),
                const SizedBox(height: 8),
                Text('${meta['description']}'),
                const SizedBox(height: 12),
                const Text('This action requires Full Access and explicit approval.'),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Approve')),
            ],
          ),
        )) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.lightbulb),
                const SizedBox(width: 8),
                const Expanded(child: Text('Suggested Next Actions')),
                Text(_status, style: const TextStyle(fontSize: 12)),
              ],
            ),
            const SizedBox(height: 10),
            ...widget.suggestions.map((s) {
              final title = (s['title'] as String?) ?? (s['type'] as String?) ?? 'Suggestion';
              final rationale = (s['rationale'] as String?) ?? '';
              return Card(
                child: ListTile(
                  title: Text(title),
                  subtitle: rationale.isEmpty ? null : Text(rationale),
                  trailing: ElevatedButton(
                    onPressed: () => _run(s),
                    child: const Text('Run'),
                  ),
                ),
              );
            }),
            const SizedBox(height: 8),
            const Text(
              'Only allowlisted suggestions can run. High/Critical require Full Access + approval.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}
