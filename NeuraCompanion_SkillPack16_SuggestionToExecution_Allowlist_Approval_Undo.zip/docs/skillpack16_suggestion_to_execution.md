# Skill Pack 16 — Suggestion → Real Execution (Allowlist + Approval + Undo)

This patch wires *suggested actions* (from Knowledge Packs and Screen Context) into real, allowlisted execution.

## What you get
- `NeuraSuggestionMapper`: strict mapping of suggestion objects to allowlisted action IDs + args
- `NeuraSuggestionExecutor`: executes through your policy gate; bubbles approval metadata to UI
- `NeuraUndoStack`: lightweight undo stack (currently supports write_note revert)
- `NeuraSuggestionSheet`: UI sheet that lists suggestions and runs them safely

## Supported suggestion formats
Direct:
{ "actionId": "desktop_open_settings", "args": {"target":"windows_update"} }

Normalized:
{ "type": "open_settings", "target": "windows_update", "title":"Open Windows Update", "rationale":"..." }

Also supported:
- launch_app (Windows allowlist: notepad/calc/explorer/cmd/powershell)
- write_note (filename only, no paths)
- open_url (http/https; your existing Network Access gate should apply)

## Integration
When you have suggestions in hand:
```dart
showModalBottomSheet(
  context: context,
  builder: (_) => NeuraSuggestionSheet(suggestions: suggestionsList),
);
```

## Important
This patch assumes the action IDs exist in your project. If an action doesn't exist, the mapper blocks instead of guessing.

## Next
Step 17: Expand allowlist (safe file ops inside sandbox) + real undo for those ops.
