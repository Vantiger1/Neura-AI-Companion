# Android Gradle / NDK changes to enable JNI build

In `android/app/build.gradle` (or `build.gradle.kts`):

## Groovy
```groovy
android {
  defaultConfig {
    externalNativeBuild {
      cmake {
        cppFlags "-std=c++17"
      }
    }
    ndk {
      abiFilters "arm64-v8a" // add others if needed
    }
  }
  externalNativeBuild {
    cmake {
      path "src/main/cpp/CMakeLists.txt"
      version "3.22.1"
    }
  }
}
```

## Kotlin DSL
```kotlin
android {
  defaultConfig {
    externalNativeBuild {
      cmake {
        cppFlags += "-std=c++17"
      }
    }
    ndk {
      abiFilters += setOf("arm64-v8a")
    }
  }
  externalNativeBuild {
    cmake {
      path = file("src/main/cpp/CMakeLists.txt")
      version = "3.22.1"
    }
  }
}
```

Also ensure you have NDK + CMake installed.
