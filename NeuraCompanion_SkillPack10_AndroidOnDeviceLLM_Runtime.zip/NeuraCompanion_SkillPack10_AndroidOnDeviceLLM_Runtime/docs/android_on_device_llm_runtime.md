# Skill Pack 10 — Android On‑Device LLM Runtime (JNI + Streaming)

## What this patch adds
- A **real Android on-device inference runtime hook** using **JNI**.
- **Token streaming** from native → Kotlin → Flutter via an **EventChannel**.
- A build that:
  - **Compiles with a stub** if llama.cpp sources are not present (no crashes).
  - **Compiles with full llama.cpp** if you place sources under `android/app/src/main/cpp/third_party/llama`.

## Why this structure
You asked for **100% offline** with **advanced local models**. On Android, the most practical path is:
- GGUF models
- llama.cpp native core
- minimal glue code (JNI)

## Files you must add (one time)
### 1) Vendor llama.cpp sources (offline)
Place the llama.cpp source tree here:

```
android/app/src/main/cpp/third_party/llama
```

You should see:
- `CMakeLists.txt`
- `ggml.*` sources
- `llama.*` sources

If the folder is missing, the build falls back to a stub that returns an explanatory error.

### 2) Add the NDK + CMake
In Android Studio:
- SDK Manager → SDK Tools
  - Android NDK (Side by side)
  - CMake

## How to use
1) Copy a GGUF model into:
   `Android/data/<package>/files/neura_models/`
2) In the app:
   Settings → Local Models → Android On-Device Engine
   - enable
   - choose model
3) In Neura Command Console:
   - call `llm_chat` (it will prefer on-device if enabled)

## Notes
- This runtime is **single-model at a time**.
- For best stability, keep `context <= 2048` and `threads <= (big cores)`.
