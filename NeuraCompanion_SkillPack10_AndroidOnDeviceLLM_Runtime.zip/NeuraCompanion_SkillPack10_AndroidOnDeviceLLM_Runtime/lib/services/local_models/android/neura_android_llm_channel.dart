import 'dart:async';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Android on-device LLM channel.
///
/// - MethodChannel: neura_llm
/// - EventChannel:  neura_llm_stream
class NeuraAndroidLlmChannel {
  static const MethodChannel _mc = MethodChannel('neura_llm');
  static const EventChannel _ec = EventChannel('neura_llm_stream');

  Stream<Map<String, dynamic>>? _stream;

  Stream<Map<String, dynamic>> get stream {
    _stream ??= _ec.receiveBroadcastStream().map((e) {
      if (e is Map) {
        return Map<String, dynamic>.from(e);
      }
      return <String, dynamic>{'type': 'unknown', 'value': e};
    });
    return _stream!;
  }

  Future<String> nativeInfo() async {
    try {
      final v = await _mc.invokeMethod<String>('nativeInfo');
      return v ?? 'unknown';
    } catch (e) {
      return 'nativeInfo error: $e';
    }
  }

  Future<bool> loadModel({
    required String path,
    int nCtx = 2048,
    int nThreads = 4,
    bool useGpu = false,
  }) async {
    try {
      final ok = await _mc.invokeMethod<bool>('loadModel', {
        'path': path,
        'nCtx': nCtx,
        'nThreads': nThreads,
        'useGpu': useGpu,
      });
      return ok ?? false;
    } catch (e) {
      if (kDebugMode) print('loadModel error: $e');
      return false;
    }
  }

  Future<bool> unloadModel() async {
    try {
      await _mc.invokeMethod('unloadModel');
      return true;
    } catch (e) {
      if (kDebugMode) print('unloadModel error: $e');
      return false;
    }
  }

  Future<bool> generate({
    required String prompt,
    int maxTokens = 256,
    double temperature = 0.7,
  }) async {
    try {
      final ok = await _mc.invokeMethod<bool>('generate', {
        'prompt': prompt,
        'maxTokens': maxTokens,
        'temperature': temperature,
      });
      return ok ?? false;
    } catch (e) {
      if (kDebugMode) print('generate error: $e');
      return false;
    }
  }

  Future<void> stop() async {
    try {
      await _mc.invokeMethod('stop');
    } catch (_) {}
  }
}
