# Neura Companion — Skill Pack 10

**Android On‑Device LLM Runtime (JNI + Streaming)**

This patch adds the Android native bridge (MethodChannel + EventChannel) and a CMake native library.

## What you get immediately
- Your app compiles with a **stub** native lib.
- Streaming pipeline works end-to-end.

## What enables real on-device inference
Vendor llama.cpp sources at:
`android/app/src/main/cpp/third_party/llama`

Then rebuild Android.

Docs:
- `docs/android_on_device_llm_runtime.md`
- `docs/android_gradle_ndk_changes.md`
