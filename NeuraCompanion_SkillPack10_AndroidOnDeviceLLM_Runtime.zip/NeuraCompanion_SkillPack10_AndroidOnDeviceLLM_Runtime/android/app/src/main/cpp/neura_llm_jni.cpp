#include <jni.h>
#include <string>
#include <atomic>
#include <android/log.h>

#define LOG_TAG "NeuraLLM"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, LOG_TAG, __VA_ARGS__)
#define LOGE(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

static JavaVM* g_vm = nullptr;
static jclass g_bridgeClass = nullptr;
static std::atomic<bool> g_stop{false};

static void emitToken(JNIEnv* env, const std::string& token) {
    if (!g_bridgeClass) return;
    jmethodID mid = env->GetStaticMethodID(g_bridgeClass, "onTokenFromNative", "(Ljava/lang/String;)V");
    if (!mid) return;
    jstring jtok = env->NewStringUTF(token.c_str());
    env->CallStaticVoidMethod(g_bridgeClass, mid, jtok);
    env->DeleteLocalRef(jtok);
}

static void emitDone(JNIEnv* env) {
    if (!g_bridgeClass) return;
    jmethodID mid = env->GetStaticMethodID(g_bridgeClass, "onDoneFromNative", "()V");
    if (!mid) return;
    env->CallStaticVoidMethod(g_bridgeClass, mid);
}

extern "C" JNIEXPORT jint JNICALL
JNI_OnLoad(JavaVM* vm, void*) {
    g_vm = vm;
    return JNI_VERSION_1_6;
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neura_companion_llm_NeuraLlmBridge_nativeInfo(JNIEnv* env, jobject) {
#if NEURA_HAS_LLAMA
    return env->NewStringUTF("neura_llm: llama.cpp enabled");
#else
    return env->NewStringUTF("neura_llm: STUB (vendor llama.cpp under android/app/src/main/cpp/third_party/llama)");
#endif
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neura_companion_llm_NeuraLlmBridge_loadModel(JNIEnv* env, jobject, jstring path, jint nCtx, jint nThreads, jboolean useGpu) {
    (void)nCtx; (void)nThreads; (void)useGpu;
#if NEURA_HAS_LLAMA
    const char* cpath = env->GetStringUTFChars(path, nullptr);
    LOGI("loadModel path=%s", cpath);
    env->ReleaseStringUTFChars(path, cpath);
    // TODO: integrate llama.cpp model loading.
    return JNI_TRUE;
#else
    (void)path;
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_neura_companion_llm_NeuraLlmBridge_unloadModel(JNIEnv*, jobject) {
    // TODO: unload llama model.
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neura_companion_llm_NeuraLlmBridge_generate(JNIEnv* env, jobject, jstring prompt, jint maxTokens, jdouble temperature) {
    (void)temperature;
    g_stop.store(false);

    // Cache bridge class for callbacks
    jclass cls = env->FindClass("com/neura/companion/llm/NeuraLlmBridge");
    if (cls) {
        g_bridgeClass = (jclass)env->NewGlobalRef(cls);
        env->DeleteLocalRef(cls);
    }

#if NEURA_HAS_LLAMA
    const char* cprompt = env->GetStringUTFChars(prompt, nullptr);
    std::string text(cprompt ? cprompt : "");
    env->ReleaseStringUTFChars(prompt, cprompt);

    // TODO: Real llama.cpp token loop. For now, stream a deterministic placeholder.
    emitToken(env, "[On-device engine ready. Wire llama.cpp eval loop here.]\n");
    emitToken(env, "Prompt: ");
    emitToken(env, text);
    emitToken(env, "\n");

    int tokens = (int)maxTokens;
    for (int i = 0; i < tokens; i++) {
        if (g_stop.load()) break;
        emitToken(env, ".");
        // Minimal throttling
        // In production, throttle from Dart PerfGuard too.
    }
    emitDone(env);
    return JNI_TRUE;
#else
    (void)prompt; (void)maxTokens;
    emitToken(env, "On-device LLM is not built yet.\n");
    emitToken(env, "To enable: vendor llama.cpp under android/app/src/main/cpp/third_party/llama and rebuild.\n");
    emitDone(env);
    return JNI_FALSE;
#endif
}

extern "C" JNIEXPORT void JNICALL
Java_com_neura_companion_llm_NeuraLlmBridge_stop(JNIEnv*, jobject) {
    g_stop.store(true);
}
