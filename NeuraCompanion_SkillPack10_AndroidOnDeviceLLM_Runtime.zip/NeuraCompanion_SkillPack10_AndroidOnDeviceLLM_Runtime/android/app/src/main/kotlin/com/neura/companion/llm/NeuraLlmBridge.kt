package com.neura.companion.llm

import android.os.Handler
import android.os.Looper
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.EventChannel
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Android On-Device LLM bridge.
 *
 * Provides:
 * - MethodChannel: neura_llm
 * - EventChannel:  neura_llm_stream
 *
 * Native JNI methods are implemented in libneura_llm.so (or stub).
 */
class NeuraLlmBridge : FlutterPlugin, MethodChannel.MethodCallHandler {

    private lateinit var methodChannel: MethodChannel
    private lateinit var eventChannel: EventChannel

    private val mainHandler = Handler(Looper.getMainLooper())
    @Volatile private var streamSink: EventChannel.EventSink? = null

    override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        methodChannel = MethodChannel(binding.binaryMessenger, "neura_llm")
        methodChannel.setMethodCallHandler(this)

        eventChannel = EventChannel(binding.binaryMessenger, "neura_llm_stream")
        eventChannel.setStreamHandler(object : EventChannel.StreamHandler {
            override fun onListen(arguments: Any?, events: EventChannel.EventSink?) {
                streamSink = events
            }
            override fun onCancel(arguments: Any?) {
                streamSink = null
            }
        })

        // Attempt to load native library. If it fails, we keep going with graceful errors.
        try {
            System.loadLibrary("neura_llm")
        } catch (t: Throwable) {
            // No-op; native calls will return stub errors.
        }
    }

    override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) {
        methodChannel.setMethodCallHandler(null)
        streamSink = null
    }

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        try {
            when (call.method) {
                "nativeInfo" -> {
                    result.success(nativeInfo())
                }
                "loadModel" -> {
                    val path = call.argument<String>("path") ?: ""
                    val nCtx = call.argument<Int>("nCtx") ?: 2048
                    val nThreads = call.argument<Int>("nThreads") ?: 4
                    val useGpu = call.argument<Boolean>("useGpu") ?: false
                    val ok = loadModel(path, nCtx, nThreads, useGpu)
                    result.success(ok)
                }
                "unloadModel" -> {
                    unloadModel()
                    result.success(true)
                }
                "generate" -> {
                    val prompt = call.argument<String>("prompt") ?: ""
                    val maxTokens = call.argument<Int>("maxTokens") ?: 256
                    val temperature = call.argument<Double>("temperature") ?: 0.7
                    // Generation runs native-side; tokens stream via onToken callback.
                    val ok = generate(prompt, maxTokens, temperature)
                    result.success(ok)
                }
                "stop" -> {
                    stop()
                    result.success(true)
                }
                else -> result.notImplemented()
            }
        } catch (t: Throwable) {
            result.error("NEURA_LLM_BRIDGE_ERROR", t.message, null)
        }
    }

    // Called from JNI to stream tokens.
    fun emitToken(token: String) {
        val sink = streamSink ?: return
        mainHandler.post {
            try {
                sink.success(mapOf("type" to "token", "value" to token))
            } catch (_: Throwable) {
                // ignore
            }
        }
    }

    // Called from JNI to signal completion.
    fun emitDone() {
        val sink = streamSink ?: return
        mainHandler.post {
            try {
                sink.success(mapOf("type" to "done"))
            } catch (_: Throwable) {
                // ignore
            }
        }
    }

    // JNI functions
    private external fun nativeInfo(): String
    private external fun loadModel(path: String, nCtx: Int, nThreads: Int, useGpu: Boolean): Boolean
    private external fun unloadModel()
    private external fun generate(prompt: String, maxTokens: Int, temperature: Double): Boolean
    private external fun stop()

    companion object {
        // Singleton accessor for JNI to call into.
        @Volatile private var instance: NeuraLlmBridge? = null

        fun setInstance(bridge: NeuraLlmBridge) {
            instance = bridge
        }

        @JvmStatic fun onTokenFromNative(token: String) {
            instance?.emitToken(token)
        }

        @JvmStatic fun onDoneFromNative() {
            instance?.emitDone()
        }
    }
}
