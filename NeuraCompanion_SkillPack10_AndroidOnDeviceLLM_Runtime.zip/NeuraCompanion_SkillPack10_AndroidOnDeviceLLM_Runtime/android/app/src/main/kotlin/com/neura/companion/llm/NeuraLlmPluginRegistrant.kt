package com.neura.companion.llm

import io.flutter.embedding.engine.FlutterEngine

object NeuraLlmPluginRegistrant {
    fun register(engine: FlutterEngine) {
        val bridge = NeuraLlmBridge()
        NeuraLlmBridge.setInstance(bridge)
        bridge.onAttachedToEngine(engine.plugins.getPluginBinding(NeuraLlmBridge::class.java) ?: return)
    }
}
