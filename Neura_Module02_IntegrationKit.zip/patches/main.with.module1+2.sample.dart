// sample main
import 'package:flutter/material.dart';
void main()=>runApp(const A());
class A extends StatelessWidget{const A({super.key}); @override Widget build(BuildContext c)=>MaterialApp(home: Scaffold(appBar: AppBar(title: const Text('Neura')), body: const Center(child: Text('Hook Module 2 routes here'))));}
