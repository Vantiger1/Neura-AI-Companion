import 'package:flutter/material.dart';

import 'modules/core/app_log.dart';
import 'modules/core/error_handler.dart';
import 'src/app.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Don't let logging crash startup.
  await AppLog.instance.init();
  ErrorHandler.install();

  runApp(const NeuroCompanionApp());
}
