class PrivacyTexts {
  static const privacyPolicy = '''
# Privacy Policy (Short Draft)

Neura Companion / Neura OS stores your data **locally on your device**.

## What we store
- App settings and preferences.
- Module data you create (including **Legacy Vault** capsules and attachments).

## Sharing
Neura does not automatically upload or share your data. Exports are created only when you tap **Export** and are shared using your device's share sheet.

## Optional cloud
If a future build enables cloud sync, it will be opt-in and clearly labeled.

## Deletion
Use **Data Controls** to delete your Legacy Vault or wipe local data.

## Contact
Support: support@neura.app
''';

  static const termsOfService = '''
# Terms of Service (Short Draft)

By using Neura Companion / Neura OS, you agree that:

- The app provides general information and coaching prompts and is **not medical, legal, or financial advice**.
- You are responsible for how you use the app and for any data you choose to export or share.
- The app is provided “as is” without warranties.

If you are in immediate danger or considering self-harm, contact local emergency services or a crisis hotline in your region.
''';

  static const disclaimer = '''
# Safety Disclaimer

Neura Companion / Neura OS can be supportive and reflective, but it is not a substitute for a licensed professional.

If you feel unsafe, overwhelmed, or at risk of harming yourself or others, seek immediate help from local emergency services or a qualified professional.
''';
}
