import 'package:flutter/material.dart';

import '../../neura_shell/screens/neura_os_shell_settings_screen.dart';
import '../legacy/legacy_home_screen.dart';
import '../privacy/privacy_home_screen.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          ListTile(
            leading: const Icon(Icons.lock_outline),
            title: const Text('Privacy & Safety'),
            subtitle: const Text('Data, backups, and what Neura does (and doesn\'t) do.'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const PrivacyHomeScreen()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.auto_stories),
            title: const Text('Legacy Vault'),
            subtitle: const Text('Time capsules, messages, and “future-you” archives.'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const LegacyHomeScreen()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.public),
            title: const Text('Neura OS Shell'),
            subtitle: const Text('Ambient FX, Neura overlay, and room audio.'),
            onTap: () {
              Navigator.of(context).push(
                MaterialPageRoute(builder: (_) => const NeuraOsShellSettingsScreen()),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.palette_outlined),
            title: const Text('Themes & Avatars'),
            subtitle: const Text('Coming soon: mood-adaptive skins and Neura expressions.'),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Theme controls stub.')),
              );
            },
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.help_outline),
            title: const Text('Help'),
            subtitle: const Text('Troubleshooting and tips.'),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                const SnackBar(content: Text('Help screen stub.')),
              );
            },
          ),
        ],
      ),
    );
  }
}
