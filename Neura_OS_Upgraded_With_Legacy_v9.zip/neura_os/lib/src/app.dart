import 'package:flutter/material.dart';

import '../modules/chat/neura_chat_screen.dart';
import '../modules/core/error_handler.dart';
import '../modules/navigation/enhanced_navigation.dart';
import '../neura_shell/models/neura_room.dart';
import '../neura_shell/state/neura_nav_controller.dart';
import '../neura_shell/state/neura_shell_scope.dart';
import '../neura_shell/state/neura_shell_state.dart';
import '../neura_shell/widgets/neura_shell_scaffold.dart';

class NeuroCompanionApp extends StatefulWidget {
  const NeuroCompanionApp({super.key});

  @override
  State<NeuroCompanionApp> createState() => _NeuroCompanionAppState();
}

class _NeuroCompanionAppState extends State<NeuroCompanionApp> {
  late final NeuraShellState _shell = NeuraShellState();
  late final NeuraNavController _nav = NeuraNavController(0);

  @override
  void initState() {
    super.initState();
    // Async load, but keep defaults so the app boots instantly.
    _shell.init().then((_) {
      final idx = kCoreRooms.indexWhere((r) => r.id == _shell.roomId);
      if (idx >= 0) _nav.setIndex(idx);
    });
    // Keep room selection in sync with tab changes.
    _nav.addListener(() {
      final idx = _nav.value;
      if (idx >= 0 && idx < kCoreRooms.length) {
        _shell.setRoom(kCoreRooms[idx].id);
      }
    });
  }

  @override
  void dispose() {
    _nav.dispose();
    _shell.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura OS',
      theme: ThemeData.dark(),
      scaffoldMessengerKey: ErrorHandler.scaffoldMessengerKey,
      home: NeuraShellScope(
        shell: _shell,
        child: Builder(
          builder: (ctx) {
            return NeuraShellScaffold(
              nav: _nav,
              onNeuraTap: () {
                Navigator.of(ctx).push(
                  MaterialPageRoute(builder: (_) => const NeuraChatScreen()),
                );
              },
              child: EnhancedNavigation(
                nav: _nav,
                onIndexChanged: (i) {
                  if (i >= 0 && i < kCoreRooms.length) {
                    _shell.setRoom(kCoreRooms[i].id);
                  }
                },
              ),
            );
          },
        ),
      ),
    );
  }
}
