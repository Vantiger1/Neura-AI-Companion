import 'dart:math';

import 'package:flutter/material.dart';

/// Animated backdrop for the current room.
///
/// It's intentionally lightweight: gradients + a few drifting particles. No
/// heavy shaders, no 3D engine, no phone-melting.
class NeuraRoomBackdrop extends StatefulWidget {
  final Color accent;
  final bool ambientEnabled;

  const NeuraRoomBackdrop({
    super.key,
    required this.accent,
    required this.ambientEnabled,
  });

  @override
  State<NeuraRoomBackdrop> createState() => _NeuraRoomBackdropState();
}

class _NeuraRoomBackdropState extends State<NeuraRoomBackdrop>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 14),
  )..repeat();

  final _rng = Random(42);
  late final List<_Particle> _particles = List.generate(18, (_) {
    return _Particle(
      x: _rng.nextDouble(),
      y: _rng.nextDouble(),
      r: 6 + _rng.nextDouble() * 18,
      s: 0.02 + _rng.nextDouble() * 0.06,
      p: _rng.nextDouble() * pi * 2,
    );
  });

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final base = Theme.of(context).brightness == Brightness.dark
        ? Colors.black
        : Colors.white;

    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = _c.value;
        final a = widget.accent;
        return CustomPaint(
          painter: _BackdropPainter(
            t: t,
            base: base,
            accent: a,
            ambient: widget.ambientEnabled,
            particles: _particles,
          ),
          child: const SizedBox.expand(),
        );
      },
    );
  }
}

class _Particle {
  final double x;
  final double y;
  final double r;
  final double s;
  final double p;

  _Particle({required this.x, required this.y, required this.r, required this.s, required this.p});
}

class _BackdropPainter extends CustomPainter {
  final double t;
  final Color base;
  final Color accent;
  final bool ambient;
  final List<_Particle> particles;

  _BackdropPainter({
    required this.t,
    required this.base,
    required this.accent,
    required this.ambient,
    required this.particles,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;

    final a = Color.lerp(accent, Colors.white, 0.15) ?? accent;
    final b = Color.lerp(accent, Colors.black, 0.35) ?? accent;

    final g = LinearGradient(
      begin: Alignment(-1, -1),
      end: Alignment(1, 1),
      colors: [base, b.withOpacity(0.55), a.withOpacity(0.35), base],
      stops: const [0, 0.35, 0.7, 1],
      transform: GradientRotation(t * pi * 2),
    );
    canvas.drawRect(rect, Paint()..shader = g.createShader(rect));

    if (!ambient) return;

    // Soft particles.
    for (final p in particles) {
      final dx = (p.x + cos(t * 2 * pi + p.p) * p.s) * size.width;
      final dy = (p.y + sin(t * 2 * pi + p.p) * p.s) * size.height;
      final paint = Paint()
        ..color = accent.withOpacity(0.09)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 18);
      canvas.drawCircle(Offset(dx, dy), p.r, paint);
    }

    // A subtle center glow.
    final center = Offset(size.width * 0.5, size.height * 0.35);
    canvas.drawCircle(
      center,
      size.shortestSide * 0.55,
      Paint()
        ..color = accent.withOpacity(0.05)
        ..maskFilter = const MaskFilter.blur(BlurStyle.normal, 40),
    );
  }

  @override
  bool shouldRepaint(covariant _BackdropPainter oldDelegate) {
    return oldDelegate.t != t || oldDelegate.accent != accent || oldDelegate.ambient != ambient;
  }
}
