import 'package:flutter/material.dart';

import '../state/neura_nav_controller.dart';
import '../state/neura_shell_scope.dart';
import 'neura_avatar_orb.dart';
import 'neura_focus_banner.dart';
import 'neura_room_backdrop.dart';
import 'neura_room_map_sheet.dart';

/// Wraps the whole app in the Neura OS "world layer": backdrop, ambient FX,
/// room map, and a small Neura presence.
class NeuraShellScaffold extends StatelessWidget {
  final Widget child;
  final NeuraNavController nav;
  final VoidCallback onNeuraTap;

  const NeuraShellScaffold({
    super.key,
    required this.child,
    required this.nav,
    required this.onNeuraTap,
  });

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    return GestureDetector(
      behavior: HitTestBehavior.translucent,
      onLongPress: () => showNeuraRoomMapSheet(context, nav: nav),
      child: Stack(
        children: [
          // Backdrop
          Positioned.fill(
            child: AnimatedSwitcher(
              duration: const Duration(milliseconds: 450),
              child: NeuraRoomBackdrop(
                key: ValueKey(shell.roomId),
                accent: shell.currentRoom.accent,
                ambientEnabled: shell.ambientFxEnabled,
              ),
            ),
          ),

          // Actual app UI
          Positioned.fill(child: child),

          // Focus banner
          const Positioned.fill(child: NeuraFocusBanner()),

          // Neura orb
          if (shell.avatarOverlayEnabled)
            Positioned(
              right: 14,
              bottom: 108,
              child: NeuraAvatarOrb(
                accent: shell.currentRoom.accent,
                onTap: onNeuraTap,
              ),
            ),
        ],
      ),
    );
  }
}
