import 'package:flutter/material.dart';

import '../../modules/diagnostics/diagnostics_screen.dart';
import '../../modules/mood/mood_checkin_screen.dart';
import '../../modules/mood/mood_history_screen.dart';
import '../../src/modules/legacy/legacy_guard_screen.dart';
import '../models/neura_room.dart';
import '../state/neura_nav_controller.dart';
import '../state/neura_shell_scope.dart';
import '../state/neura_shell_state.dart';
import '../screens/neura_focus_office_screen.dart';

Future<void> showNeuraRoomMapSheet(
  BuildContext context, {
  required NeuraNavController nav,
}) async {
  await showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    showDragHandle: true,
    backgroundColor: Colors.black.withOpacity(0.9),
    builder: (ctx) {
      return _RoomMapBody(nav: nav);
    },
  );
}

class _RoomAction {
  final String title;
  final String subtitle;
  final IconData icon;
  final Color accent;
  final VoidCallback run;

  _RoomAction({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    required this.run,
  });
}

class _RoomMapBody extends StatefulWidget {
  final NeuraNavController nav;

  const _RoomMapBody({required this.nav});

  @override
  State<_RoomMapBody> createState() => _RoomMapBodyState();
}

class _RoomMapBodyState extends State<_RoomMapBody> {
  String q = '';

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    final actions = _buildActions(context, shell);

    final core = kCoreRooms
        .where((r) => _matches(q, r.title) || _matches(q, r.subtitle))
        .toList();
    final extra = actions
        .where((a) => _matches(q, a.title) || _matches(q, a.subtitle))
        .toList();

    return SafeArea(
      child: Padding(
        padding: EdgeInsets.only(
          left: 14,
          right: 14,
          bottom: 14 + MediaQuery.of(context).viewInsets.bottom,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Row(
              children: [
                const Icon(Icons.public, color: Colors.white70),
                const SizedBox(width: 8),
                Text('Rooms Map', style: Theme.of(context).textTheme.titleLarge),
                const Spacer(),
                Text(
                  'Hold anywhere to open',
                  style: Theme.of(context).textTheme.bodySmall?.copyWith(color: Colors.white60),
                ),
              ],
            ),
            const SizedBox(height: 10),
            TextField(
              onChanged: (v) => setState(() => q = v.trim()),
              decoration: InputDecoration(
                prefixIcon: const Icon(Icons.search),
                hintText: 'Search rooms and tools...',
                filled: true,
                fillColor: Colors.white.withOpacity(0.06),
                border: OutlineInputBorder(borderRadius: BorderRadius.circular(14)),
              ),
            ),
            const SizedBox(height: 14),
            Flexible(
              child: ListView(
                shrinkWrap: true,
                children: [
                  _Section(title: 'Core Rooms', children: [
                    for (final r in core)
                      _RoomTile(
                        icon: r.icon,
                        title: r.title,
                        subtitle: r.subtitle,
                        accent: r.accent,
                        selected: shell.roomId == r.id,
                        onTap: () async {
                          await shell.setRoom(r.id);
                          if (r.tabIndex != null) widget.nav.setIndex(r.tabIndex!);
                          if (context.mounted) Navigator.of(context).pop();
                        },
                      ),
                  ]),
                  const SizedBox(height: 10),
                  _Section(title: 'Tools', children: [
                    for (final a in extra)
                      _RoomTile(
                        icon: a.icon,
                        title: a.title,
                        subtitle: a.subtitle,
                        accent: a.accent,
                        selected: false,
                        onTap: () {
                          Navigator.of(context).pop();
                          a.run();
                        },
                      ),
                  ]),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  List<_RoomAction> _buildActions(BuildContext context, NeuraShellState shell) {
    return [
      _RoomAction(
        title: 'Focus Office',
        subtitle: 'Set a focus mode: Deep Work, Reflection, Social, Wind Down.',
        icon: Icons.center_focus_strong,
        accent: const Color(0xFF00BFA5),
        run: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const NeuraFocusOfficeScreen()),
        ),
      ),
      _RoomAction(
        title: 'Mood Check‑In',
        subtitle: 'Log your emotional weather.',
        icon: Icons.favorite_border,
        accent: const Color(0xFFFF5252),
        run: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const MoodCheckInScreen()),
        ),
      ),
      _RoomAction(
        title: 'Mood History',
        subtitle: 'Trends, streaks, and the “why”.',
        icon: Icons.timeline,
        accent: const Color(0xFFFFD54F),
        run: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const MoodHistoryScreen()),
        ),
      ),
      _RoomAction(
        title: 'Legacy Guard',
        subtitle: 'Dead‑man switch check‑ins and delivery prep.',
        icon: Icons.shield_outlined,
        accent: const Color(0xFF40C4FF),
        run: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const LegacyGuardScreen()),
        ),
      ),
      _RoomAction(
        title: 'Diagnostics',
        subtitle: 'Logs + Dimensional Sync (multiverse debug button).',
        icon: Icons.bug_report_outlined,
        accent: const Color(0xFFB388FF),
        run: () => Navigator.of(context).push(
          MaterialPageRoute(builder: (_) => const DiagnosticsScreen()),
        ),
      ),
    ];
  }

  bool _matches(String q, String s) {
    if (q.isEmpty) return true;
    return s.toLowerCase().contains(q.toLowerCase());
  }
}

class _Section extends StatelessWidget {
  final String title;
  final List<Widget> children;

  const _Section({required this.title, required this.children});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(color: Colors.white70)),
        const SizedBox(height: 8),
        ...children,
      ],
    );
  }
}

class _RoomTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  final Color accent;
  final bool selected;
  final VoidCallback onTap;

  const _RoomTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.accent,
    required this.selected,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white.withOpacity(0.06),
      child: ListTile(
        leading: CircleAvatar(
          backgroundColor: accent.withOpacity(0.18),
          child: Icon(icon, color: Colors.white),
        ),
        title: Text(title),
        subtitle: Text(subtitle, maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: selected ? const Icon(Icons.check_circle, color: Colors.greenAccent) : null,
        onTap: onTap,
      ),
    );
  }
}
