import 'dart:math';

import 'package:flutter/material.dart';

/// A tiny Neura presence that floats above the UI.
///
/// Not a full body rig yet — just a friendly "I'm here" orb using your
/// `assets/images/ai_avatar.png`.
class NeuraAvatarOrb extends StatefulWidget {
  final Color accent;
  final VoidCallback onTap;

  const NeuraAvatarOrb({super.key, required this.accent, required this.onTap});

  @override
  State<NeuraAvatarOrb> createState() => _NeuraAvatarOrbState();
}

class _NeuraAvatarOrbState extends State<NeuraAvatarOrb>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController(
    vsync: this,
    duration: const Duration(seconds: 4),
  )..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _c,
      builder: (context, _) {
        final t = _c.value;
        final bob = sin(t * pi * 2) * 6;
        return Transform.translate(
          offset: Offset(0, bob),
          child: Material(
            color: Colors.transparent,
            child: InkWell(
              borderRadius: BorderRadius.circular(999),
              onTap: widget.onTap,
              child: Container(
                width: 64,
                height: 64,
                decoration: BoxDecoration(
                  shape: BoxShape.circle,
                  color: Colors.black.withOpacity(0.35),
                  border: Border.all(color: widget.accent.withOpacity(0.4), width: 1),
                  boxShadow: [
                    BoxShadow(
                      blurRadius: 24,
                      spreadRadius: 2,
                      color: widget.accent.withOpacity(0.18),
                    ),
                  ],
                ),
                padding: const EdgeInsets.all(6),
                child: ClipOval(
                  child: Image.asset(
                    'assets/images/ai_avatar.png',
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) {
                      return Center(
                        child: Icon(Icons.auto_awesome, color: widget.accent),
                      );
                    },
                  ),
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
