import 'package:flutter/material.dart';

import '../state/neura_shell_scope.dart';
import '../state/neura_shell_state.dart';

class NeuraFocusBanner extends StatelessWidget {
  const NeuraFocusBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    final mode = shell.focusMode;
    if (mode == NeuraFocusMode.none) return const SizedBox.shrink();

    final (title, icon) = switch (mode) {
      NeuraFocusMode.deepWork => ('Deep Work mode', Icons.center_focus_strong),
      NeuraFocusMode.reflection => ('Reflection mode', Icons.self_improvement),
      NeuraFocusMode.social => ('Social mode', Icons.groups_outlined),
      NeuraFocusMode.windDown => ('Wind Down mode', Icons.nights_stay_outlined),
      _ => ('Focus', Icons.tune),
    };

    return Align(
      alignment: Alignment.topCenter,
      child: SafeArea(
        child: Padding(
          padding: const EdgeInsets.only(top: 8),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: BoxDecoration(
              color: Colors.black.withOpacity(0.55),
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: shell.currentRoom.accent.withOpacity(0.35)),
            ),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Icon(icon, size: 18, color: Colors.white),
                const SizedBox(width: 8),
                Text(title, style: const TextStyle(color: Colors.white)),
                const SizedBox(width: 10),
                TextButton(
                  onPressed: () => shell.setFocusMode(NeuraFocusMode.none),
                  child: const Text('Clear'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
