import 'package:flutter/material.dart';

/// A "room" is an OS-level context: it changes the backdrop/ambient feel and
/// can optionally jump you to a tab or route.
class NeuraRoom {
  final String id;
  final String title;
  final String subtitle;
  final IconData icon;

  /// If set, selecting the room switches the bottom-tab index.
  final int? tabIndex;

  /// If set, selecting the room pushes this route.
  final WidgetBuilder? routeBuilder;

  /// Optional ambient sound asset path.
  final String? ambientAsset;

  /// A color used by the backdrop.
  final Color accent;

  const NeuraRoom({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.accent,
    this.tabIndex,
    this.routeBuilder,
    this.ambientAsset,
  });
}

/// Core rooms that match the main bottom navigation.
const List<NeuraRoom> kCoreRooms = [
  NeuraRoom(
    id: 'penthouse',
    title: 'Penthouse',
    subtitle: 'Home base. Systems online.',
    icon: Icons.dashboard_outlined,
    tabIndex: 0,
    ambientAsset: 'assets/sounds/ambient_loop.mp3',
    accent: Color(0xFF7C4DFF),
  ),
  NeuraRoom(
    id: 'journal',
    title: 'Journal Room',
    subtitle: 'Words become wiring.',
    icon: Icons.edit_note,
    tabIndex: 1,
    ambientAsset: 'assets/sounds/wind.mp3',
    accent: Color(0xFF00BFA5),
  ),
  NeuraRoom(
    id: 'dreams',
    title: 'Dream Atrium',
    subtitle: 'Where weird becomes data.',
    icon: Icons.nights_stay_outlined,
    tabIndex: 2,
    ambientAsset: 'assets/sounds/ocean.mp3',
    accent: Color(0xFF40C4FF),
  ),
  NeuraRoom(
    id: 'legacy',
    title: 'Legacy Hall',
    subtitle: 'Messages for future-you (and Grandma).',
    icon: Icons.auto_stories,
    tabIndex: 3,
    ambientAsset: 'assets/sounds/breathe.mp3',
    accent: Color(0xFFFFD54F),
  ),
  NeuraRoom(
    id: 'settings',
    title: 'Control Deck',
    subtitle: 'Privacy, safety, and switches.',
    icon: Icons.settings_outlined,
    tabIndex: 4,
    ambientAsset: null,
    accent: Color(0xFF90A4AE),
  ),
];
