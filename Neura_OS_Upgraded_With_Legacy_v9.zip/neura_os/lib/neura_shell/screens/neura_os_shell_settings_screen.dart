import 'package:flutter/material.dart';

import '../state/neura_shell_scope.dart';

class NeuraOsShellSettingsScreen extends StatelessWidget {
  const NeuraOsShellSettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);

    return Scaffold(
      appBar: AppBar(title: const Text('Neura OS Shell')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          const _SectionTitle('World Layer'),
          SwitchListTile(
            value: shell.ambientFxEnabled,
            onChanged: (v) => shell.setAmbientFx(v),
            title: const Text('Ambient Visual FX'),
            subtitle: const Text('Gentle particles + glow. Disable for max battery life.'),
          ),
          SwitchListTile(
            value: shell.avatarOverlayEnabled,
            onChanged: (v) => shell.setAvatarOverlay(v),
            title: const Text('Neura Overlay'),
            subtitle: const Text('Shows Neura’s floating avatar on top of modules.'),
          ),
          SwitchListTile(
            value: shell.ambientAudioEnabled,
            onChanged: (v) => shell.setAmbientAudio(v),
            title: const Text('Ambient Audio'),
            subtitle: const Text('Loops a room soundscape (assets/sounds/*).'),
          ),
          const SizedBox(height: 8),
          Card(
            child: ListTile(
              leading: const Icon(Icons.shield_outlined),
              title: const Text('Safety note'),
              subtitle: const Text(
                'Ambient audio is optional and runs locally. No microphone access is used for this feature.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  final String text;
  const _SectionTitle(this.text);

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(text, style: Theme.of(context).textTheme.titleMedium),
    );
  }
}
