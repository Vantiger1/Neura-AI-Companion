import 'package:flutter/material.dart';

import '../state/neura_shell_scope.dart';
import '../state/neura_shell_state.dart';

class NeuraFocusOfficeScreen extends StatelessWidget {
  const NeuraFocusOfficeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Focus Office')),
      body: ListView(
        padding: const EdgeInsets.all(14),
        children: [
          Text(
            'Pick a focus mode. Neura adjusts the OS vibes accordingly.\n'
            'No, this does not grant you superpowers — but it does reduce tab-hopping.',
            style: Theme.of(context).textTheme.bodyMedium,
          ),
          const SizedBox(height: 14),
          _ModeTile(
            mode: NeuraFocusMode.none,
            icon: Icons.do_not_disturb_on_outlined,
            title: 'None',
            subtitle: 'Normal mode. Maximum chaos, minimum judgement.',
          ),
          _ModeTile(
            mode: NeuraFocusMode.deepWork,
            icon: Icons.center_focus_strong,
            title: 'Deep Work',
            subtitle: 'Fewer distractions. More “I did the thing.”',
          ),
          _ModeTile(
            mode: NeuraFocusMode.reflection,
            icon: Icons.self_improvement,
            title: 'Reflection',
            subtitle: 'Journal + calm. Breathe, then type like a philosopher.',
          ),
          _ModeTile(
            mode: NeuraFocusMode.social,
            icon: Icons.groups_outlined,
            title: 'Social',
            subtitle: 'Reach out, be human, practice kindness.',
          ),
          _ModeTile(
            mode: NeuraFocusMode.windDown,
            icon: Icons.nights_stay_outlined,
            title: 'Wind Down',
            subtitle: 'Lower stimulation. Sleep mode vibes.',
          ),
          const SizedBox(height: 10),
          Card(
            child: ListTile(
              leading: const Icon(Icons.info_outline),
              title: const Text('What changes?'),
              subtitle: const Text(
                'Right now: a banner + room accent + optional ambient audio.\n'
                'Next: auto-scheduling, notification nudges, and module filtering.',
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _ModeTile extends StatelessWidget {
  final NeuraFocusMode mode;
  final IconData icon;
  final String title;
  final String subtitle;

  const _ModeTile({
    required this.mode,
    required this.icon,
    required this.title,
    required this.subtitle,
  });

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    final selected = shell.focusMode == mode;
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        subtitle: Text(subtitle),
        trailing: selected ? const Icon(Icons.check_circle, color: Colors.greenAccent) : null,
        onTap: () async {
          await shell.setFocusMode(mode);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Focus mode set: $title')),
            );
          }
        },
      ),
    );
  }
}
