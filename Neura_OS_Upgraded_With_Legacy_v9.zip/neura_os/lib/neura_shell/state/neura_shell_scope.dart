import 'package:flutter/material.dart';

import 'neura_shell_state.dart';

/// Inherited access to [NeuraShellState].
class NeuraShellScope extends InheritedNotifier<NeuraShellState> {
  const NeuraShellScope({
    super.key,
    required NeuraShellState shell,
    required Widget child,
  }) : super(notifier: shell, child: child);

  static NeuraShellState of(BuildContext context) {
    final scope = context.dependOnInheritedWidgetOfExactType<NeuraShellScope>();
    assert(scope != null, 'NeuraShellScope missing above context');
    return scope!.notifier!;
  }
}
