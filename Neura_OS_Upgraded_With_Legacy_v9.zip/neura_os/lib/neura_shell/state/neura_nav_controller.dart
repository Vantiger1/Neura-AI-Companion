import 'package:flutter/foundation.dart';

/// Shared tab index controller so the "shell" can drive navigation (rooms)
/// and the nav bar can drive the shell (current room).
class NeuraNavController extends ValueNotifier<int> {
  NeuraNavController([super.value = 0]);

  void setIndex(int i) {
    if (i == value) return;
    value = i;
  }
}
