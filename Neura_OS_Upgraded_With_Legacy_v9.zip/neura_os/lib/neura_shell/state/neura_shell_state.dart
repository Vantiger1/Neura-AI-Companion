import 'dart:async';

import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/neura_room.dart';

enum NeuraFocusMode { none, deepWork, reflection, social, windDown }

/// Persistent shell state for the Neura OS "world layer".
class NeuraShellState extends ChangeNotifier {
  static const String _kRoomId = 'neura.shell.roomId';
  static const String _kAmbientFx = 'neura.shell.ambientFx';
  static const String _kAvatarOverlay = 'neura.shell.avatarOverlay';
  static const String _kAmbientAudio = 'neura.shell.ambientAudio';
  static const String _kFocusMode = 'neura.shell.focusMode';

  NeuraShellState();

  SharedPreferences? _prefs;
  final AudioPlayer _player = AudioPlayer();

  String _roomId = kCoreRooms.first.id;
  bool _ambientFxEnabled = true;
  bool _avatarOverlayEnabled = true;
  bool _ambientAudioEnabled = false;
  NeuraFocusMode _focusMode = NeuraFocusMode.none;

  String get roomId => _roomId;
  bool get ambientFxEnabled => _ambientFxEnabled;
  bool get avatarOverlayEnabled => _avatarOverlayEnabled;
  bool get ambientAudioEnabled => _ambientAudioEnabled;
  NeuraFocusMode get focusMode => _focusMode;

  NeuraRoom get currentRoom =>
      kCoreRooms.firstWhere((r) => r.id == _roomId, orElse: () => kCoreRooms.first);

  Future<void> init() async {
    _prefs ??= await SharedPreferences.getInstance();
    _roomId = _prefs!.getString(_kRoomId) ?? _roomId;
    _ambientFxEnabled = _prefs!.getBool(_kAmbientFx) ?? _ambientFxEnabled;
    _avatarOverlayEnabled = _prefs!.getBool(_kAvatarOverlay) ?? _avatarOverlayEnabled;
    _ambientAudioEnabled = _prefs!.getBool(_kAmbientAudio) ?? _ambientAudioEnabled;
    _focusMode = NeuraFocusMode.values[_prefs!.getInt(_kFocusMode) ?? 0];
    if (_ambientAudioEnabled) {
      unawaited(_playAmbientForRoom(currentRoom));
    }
    notifyListeners();
  }

  Future<void> setRoom(String id) async {
    if (id == _roomId) return;
    _roomId = id;
    await _prefs?.setString(_kRoomId, id);
    if (_ambientAudioEnabled) {
      unawaited(_playAmbientForRoom(currentRoom));
    }
    notifyListeners();
  }

  Future<void> setAmbientFx(bool enabled) async {
    _ambientFxEnabled = enabled;
    await _prefs?.setBool(_kAmbientFx, enabled);
    notifyListeners();
  }

  Future<void> setAvatarOverlay(bool enabled) async {
    _avatarOverlayEnabled = enabled;
    await _prefs?.setBool(_kAvatarOverlay, enabled);
    notifyListeners();
  }

  Future<void> setAmbientAudio(bool enabled) async {
    _ambientAudioEnabled = enabled;
    await _prefs?.setBool(_kAmbientAudio, enabled);
    if (!enabled) {
      await _player.stop();
    } else {
      unawaited(_playAmbientForRoom(currentRoom));
    }
    notifyListeners();
  }

  Future<void> setFocusMode(NeuraFocusMode mode) async {
    _focusMode = mode;
    await _prefs?.setInt(_kFocusMode, mode.index);
    notifyListeners();
  }

  Future<void> _playAmbientForRoom(NeuraRoom room) async {
    try {
      final asset = room.ambientAsset;
      if (asset == null) {
        await _player.stop();
        return;
      }
      await _player.setReleaseMode(ReleaseMode.loop);
      await _player.play(AssetSource(asset.replaceFirst('assets/', '')));
    } catch (_) {
      // No sound? No crash.
    }
  }

  @override
  void dispose() {
    _player.dispose();
    super.dispose();
  }
}
