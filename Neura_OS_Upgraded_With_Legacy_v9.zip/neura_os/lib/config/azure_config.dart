class AzureConfig {
  final String accountName;
  final String accountKey;

  AzureConfig({required this.accountName, required this.accountKey});
}

/// Optional Azure configuration.
///
/// Neura OS is designed to run fully offline-first. If you later decide to
/// wire cloud backup, you can populate these fields from Settings.
const AzureConfig kDefaultAzureConfig = AzureConfig(
  accountName: 'your_account_name',
  accountKey: 'your_account_key',
);
