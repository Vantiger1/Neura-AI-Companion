# Neura OS v9 – Shell + Rooms + Focus Office

What you just gained:

- **Neura OS Shell (world layer):** animated backdrop + optional ambient FX + optional Neura avatar overlay.
- **Rooms Map:** long‑press *anywhere* to open, or tap **Rooms Map** on the dashboard.
  - Core rooms sync with the bottom nav (Penthouse / Journal / Dreams / Legacy / Control Deck).
  - Extra tools: Focus Office, Mood Check‑In, Mood History, Legacy Guard, Diagnostics.
- **Focus Office:** sets a focus mode; shows a small banner so you don’t forget you toggled it.
- **Ambient Audio (optional):** loops a room soundscape using your existing `assets/sounds/*`.

What I cleaned up:

- Removed Azure + Riverpod + Crashlytics coupling from the default build path. Neura OS stays offline‑first.
- Added `assets/images/` and `assets/sounds/` to pubspec so `ai_avatar.png` and soundscapes actually load.

Key files (new):

- `lib/neura_shell/state/neura_shell_state.dart`
- `lib/neura_shell/widgets/neura_shell_scaffold.dart`
- `lib/neura_shell/widgets/neura_room_map_sheet.dart`
- `lib/neura_shell/screens/neura_focus_office_screen.dart`
- `lib/neura_shell/screens/neura_os_shell_settings_screen.dart`

Next obvious upgrade (v10 candidate):

- **Room‑specific module filtering** (e.g., Wind Down hides high‑stimulation tiles)
- **Room presets** (background + sound + default tab + “Neura mood”) saved per user
- **Penthouse walk‑cycle prototype** (Rive/Lottie sprite sheet) layered into the shell