import 'package:flutter/material.dart';

import '../../../services/neura_automation_prefs.dart';
import '../../../services/local_models/neura_local_llm_service.dart';
import '../../../services/local_models/neura_local_model_settings.dart';
import '../../../services/local_models/neura_model_pack_manager.dart';
import '../../../services/local_models/neura_llama_server_runner.dart';

class LocalModelsScreen extends StatefulWidget {
  const LocalModelsScreen({super.key});

  @override
  State<LocalModelsScreen> createState() => _LocalModelsScreenState();
}

class _LocalModelsScreenState extends State<LocalModelsScreen> {
  final _baseUrl = TextEditingController();
  final _model = TextEditingController();
  final _timeout = TextEditingController();
  double _temp = 0.3;

  // Model pack manager
  final _importPath = TextEditingController();
  final _runnerExe = TextEditingController();
  final _runnerPort = TextEditingController();
  bool _autostart = false;

  bool _busy = false;
  String _status = '—';

  Future<void> _load() async {
    await NeuraAutomationPrefs.I.init();
    await NeuraLocalModelSettings.I.init();

    _baseUrl.text = NeuraLocalModelSettings.I.llmBaseUrl;
    _model.text = NeuraLocalModelSettings.I.llmModel;
    _timeout.text = NeuraLocalModelSettings.I.llmTimeoutMs.toString();
    _temp = NeuraLocalModelSettings.I.llmTemperature;

    await NeuraModelPackManager.I.init();
    _runnerExe.text = NeuraLocalModelSettings.I.runnerExecutablePath;
    _runnerPort.text = NeuraLocalModelSettings.I.runnerPort.toString();
    _autostart = NeuraLocalModelSettings.I.runnerAutostart;

    setState(() {});
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await NeuraLocalModelSettings.I.setLlmBaseUrl(_baseUrl.text);
      await NeuraLocalModelSettings.I.setLlmModel(_model.text);
      final t = int.tryParse(_timeout.text.trim()) ?? 120000;
      await NeuraLocalModelSettings.I.setLlmTimeoutMs(t);
      await NeuraLocalModelSettings.I.setLlmTemperature(_temp);

      await NeuraLocalModelSettings.I.setRunnerExecutablePath(_runnerExe.text);
      final rp = int.tryParse(_runnerPort.text.trim()) ?? 8080;
      await NeuraLocalModelSettings.I.setRunnerPort(rp);
      await NeuraLocalModelSettings.I.setRunnerAutostart(_autostart);
      setState(() => _status = 'Saved.');
    } catch (e) {
      setState(() => _status = 'Save failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _test() async {
    setState(() {
      _busy = true;
      _status = 'Testing local model server…';
    });
    final res = await NeuraLocalLlmService.I.health();
    setState(() {
      _busy = false;
      _status = res['ok'] == true
          ? 'OK (HTTP ${res['statusCode'] ?? '?'})'
          : 'Not reachable: ${(res['error'] ?? res['statusCode'] ?? 'unknown')}';
    });
  }

  Future<void> _importModel() async {
    setState(() {
      _busy = true;
      _status = 'Importing model pack…';
    });
    try {
      final p = _importPath.text.trim();
      if (p.isEmpty) {
        setState(() => _status = 'Provide a local file path to a GGUF first.');
        return;
      }
      final pack = await NeuraModelPackManager.I.importFromPath(sourcePath: p);
      setState(() => _status = 'Imported: ${pack.fileName}');
    } catch (e) {
      setState(() => _status = 'Import failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _selectModel(String id) async {
    setState(() {
      _busy = true;
      _status = 'Selecting model…';
    });
    try {
      await NeuraModelPackManager.I.select(id);
      final p = NeuraModelPackManager.I.byId(id);
      setState(() => _status = 'Selected: ${p?.fileName ?? id}');
    } catch (e) {
      setState(() => _status = 'Select failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _startRunner() async {
    setState(() {
      _busy = true;
      _status = 'Starting local runner…';
    });
    final res = await NeuraLlamaServerRunner.I.start();
    setState(() {
      _busy = false;
      _status = res['ok'] == true
          ? 'Runner started on :${res['port']}'
          : 'Runner failed: ${(res['error'] ?? 'unknown')}';
    });
  }

  Future<void> _stopRunner() async {
    setState(() {
      _busy = true;
      _status = 'Stopping local runner…';
    });
    final res = await NeuraLlamaServerRunner.I.stop();
    setState(() {
      _busy = false;
      _status = res['ok'] == true ? 'Runner stopped.' : 'Stop failed: ${res['error']}';
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _baseUrl.dispose();
    _model.dispose();
    _timeout.dispose();
    _importPath.dispose();
    _runnerExe.dispose();
    _runnerPort.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prefs = NeuraAutomationPrefs.I;
    final enabled = prefs.capLocalModels || prefs.fullAccessEnabled;

    return Scaffold(
      appBar: AppBar(title: const Text('Local Models (Offline AI Core)')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Neura can talk to a local model endpoint (offline).\n\n'
            'Recommended for Windows: run a local OpenAI-compatible server on 127.0.0.1 (llama.cpp, Ollama, etc.).\n'
            'Android on-device runners can be wired later; this screen is ready for it.',
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: Icon(enabled ? Icons.check_circle : Icons.block),
              title: Text(enabled ? 'Enabled' : 'Disabled'),
              subtitle: const Text('Controlled by Privacy & Safety → Local Models.'),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _baseUrl,
            decoration: const InputDecoration(
              labelText: 'Base URL',
              helperText: 'Example: http://127.0.0.1:8080',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _model,
            decoration: const InputDecoration(
              labelText: 'Model name',
              helperText: 'Whatever your local server reports; can be any string for llama.cpp.',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _timeout,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Timeout (ms)',
              helperText: 'Default 120000',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Text('Temperature: ${_temp.toStringAsFixed(2)}'),
          Slider(
            value: _temp,
            min: 0.0,
            max: 1.0,
            divisions: 20,
            onChanged: (v) => setState(() => _temp = v),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              ElevatedButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.save),
                label: const Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _test,
                icon: const Icon(Icons.health_and_safety),
                label: const Text('Test local server'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text('Status: $_status'),
            ),
          ),
          const SizedBox(height: 12),
          const Divider(),
          const Text('Model Packs (GGUF, Offline)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: _importPath,
            decoration: const InputDecoration(
              labelText: 'Import GGUF file path (desktop)',
              helperText: 'Example: C:\\models\\neura.gguf  (Android SAF import coming soon)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              ElevatedButton.icon(
                onPressed: _busy || !enabled ? null : _importModel,
                icon: const Icon(Icons.add_box),
                label: const Text('Import'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Builder(builder: (context) {
            final packs = NeuraModelPackManager.I.list();
            final selectedId = NeuraModelPackManager.I.selected?.id ?? '';
            if (packs.isEmpty) {
              return const Text('No model packs imported yet.');
            }
            return Column(
              children: packs.map((p) {
                final isSel = p.id == selectedId;
                return Card(
                  child: ListTile(
                    leading: Icon(isSel ? Icons.radio_button_checked : Icons.radio_button_off),
                    title: Text(p.fileName),
                    subtitle: Text('${(p.bytes / (1024 * 1024)).toStringAsFixed(1)} MB  •  ${p.addedAt.substring(0, 10)}'),
                    trailing: TextButton(
                      onPressed: _busy || !enabled ? null : () => _selectModel(p.id),
                      child: const Text('Select'),
                    ),
                  ),
                );
              }).toList(),
            );
          }),
          const SizedBox(height: 12),
          const Divider(),
          const Text('Local Runner (Desktop)', style: TextStyle(fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          TextField(
            controller: _runnerExe,
            decoration: const InputDecoration(
              labelText: 'llama.cpp server executable path',
              helperText: 'Example: C:\\llama\\llama-server.exe (or server.exe)',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 8),
          TextField(
            controller: _runnerPort,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Runner port',
              helperText: 'Default 8080',
              border: OutlineInputBorder(),
            ),
          ),
          SwitchListTile(
            value: _autostart,
            onChanged: _busy ? null : (v) => setState(() => _autostart = v),
            title: const Text('Autostart runner when Neura starts'),
            subtitle: const Text('Desktop only. Requires Save.'),
          ),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              OutlinedButton.icon(
                onPressed: _busy || !enabled ? null : _startRunner,
                icon: const Icon(Icons.play_arrow),
                label: const Text('Start runner'),
              ),
              OutlinedButton.icon(
                onPressed: _busy || !enabled ? null : _stopRunner,
                icon: const Icon(Icons.stop),
                label: const Text('Stop runner'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          const Text(
            'Windows quickstart (llama.cpp example):\n'
            '1) Build or download llama.cpp\n'
            '2) Run: server --host 127.0.0.1 --port 8080 --model <path-to-gguf>\n'
            '3) Set Base URL to http://127.0.0.1:8080\n'
            '4) Use Neura Command Console → llm_chat',
          ),
        ],
      ),
    );
  }
}
