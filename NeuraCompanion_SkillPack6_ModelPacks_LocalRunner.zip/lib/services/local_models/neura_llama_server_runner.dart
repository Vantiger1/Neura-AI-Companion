import 'dart:io';

import 'neura_local_model_settings.dart';
import 'neura_model_pack_manager.dart';

/// Desktop-only local runner for llama.cpp's `server` / `llama-server`.
///
/// This intentionally does not ship binaries. Users can point Neura at a local
/// executable path and a GGUF file imported through the Model Pack Manager.
class NeuraLlamaServerRunner {
  static final NeuraLlamaServerRunner I = NeuraLlamaServerRunner._();
  NeuraLlamaServerRunner._();

  Process? _proc;

  bool get isRunning => _proc != null;

  int get port => NeuraLocalModelSettings.I.runnerPort;

  Future<Map<String, dynamic>> start() async {
    await NeuraLocalModelSettings.I.init();
    await NeuraModelPackManager.I.init();

    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return {
        'ok': false,
        'error': 'Local runner is desktop-only for now.'
      };
    }
    if (_proc != null) {
      return {'ok': true, 'message': 'Already running', 'port': port};
    }

    final exe = NeuraLocalModelSettings.I.runnerExecutablePath;
    if (exe.isEmpty || !File(exe).existsSync()) {
      return {
        'ok': false,
        'error': 'Runner executable not set or not found. Set it in Settings → Local Models.'
      };
    }

    final pack = NeuraModelPackManager.I.selected;
    if (pack == null || pack.path.isEmpty || !File(pack.path).existsSync()) {
      return {
        'ok': false,
        'error': 'No selected model pack. Import a GGUF and select it first.'
      };
    }

    final args = <String>[
      '--host',
      '127.0.0.1',
      '--port',
      port.toString(),
      '--model',
      pack.path,
    ];

    try {
      _proc = await Process.start(exe, args, runInShell: true);
      // Best effort: ignore output.
      _proc!.stdout.listen((_) {});
      _proc!.stderr.listen((_) {});
      return {
        'ok': true,
        'message': 'Started',
        'port': port,
        'model': pack.fileName,
      };
    } catch (e) {
      _proc = null;
      return {'ok': false, 'error': e.toString()};
    }
  }

  Future<Map<String, dynamic>> stop() async {
    final p = _proc;
    _proc = null;
    if (p == null) return {'ok': true, 'message': 'Not running'};
    try {
      p.kill(ProcessSignal.sigterm);
      return {'ok': true, 'message': 'Stopped'};
    } catch (e) {
      return {'ok': false, 'error': e.toString()};
    }
  }
}
