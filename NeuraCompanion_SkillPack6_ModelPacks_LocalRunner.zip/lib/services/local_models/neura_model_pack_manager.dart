import 'dart:convert';
import 'dart:io';

import 'package:path_provider/path_provider.dart';

import 'neura_local_model_settings.dart';

class NeuraModelPack {
  final String id;
  final String fileName;
  final String path;
  final int bytes;
  final String addedAt;
  final String description;

  const NeuraModelPack({
    required this.id,
    required this.fileName,
    required this.path,
    required this.bytes,
    required this.addedAt,
    required this.description,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'fileName': fileName,
        'path': path,
        'bytes': bytes,
        'addedAt': addedAt,
        'description': description,
      };

  factory NeuraModelPack.fromJson(Map<String, dynamic> j) => NeuraModelPack(
        id: (j['id'] ?? '').toString(),
        fileName: (j['fileName'] ?? '').toString(),
        path: (j['path'] ?? '').toString(),
        bytes: (j['bytes'] ?? 0) is int ? (j['bytes'] as int) : int.tryParse('${j['bytes']}') ?? 0,
        addedAt: (j['addedAt'] ?? '').toString(),
        description: (j['description'] ?? '').toString(),
      );
}

/// Offline model pack manager.
///
/// Notes:
/// - We intentionally avoid network downloads here to keep strict offline mode.
/// - Users import GGUF files locally (desktop file path). Android support can be
///   extended later via SAF.
/// - Integrity: this stores size + timestamp. If you want cryptographic hashes,
///   add `crypto` and compute sha256.
class NeuraModelPackManager {
  static final NeuraModelPackManager I = NeuraModelPackManager._();
  NeuraModelPackManager._();

  Directory? _root;
  File? _registry;
  final List<NeuraModelPack> _packs = <NeuraModelPack>[];

  Future<void> init() async {
    if (_root != null) return;
    final base = await getApplicationSupportDirectory();
    _root = Directory('${base.path}${Platform.pathSeparator}neura_models');
    if (!_root!.existsSync()) _root!.createSync(recursive: true);

    _registry = File('${_root!.path}${Platform.pathSeparator}registry.json');
    await NeuraLocalModelSettings.I.init();
    await _load();
  }

  List<NeuraModelPack> list() => List.unmodifiable(_packs);

  NeuraModelPack? byId(String id) {
    for (final p in _packs) {
      if (p.id == id) return p;
    }
    return null;
  }

  NeuraModelPack? get selected {
    final id = NeuraLocalModelSettings.I.selectedModelId;
    if (id.isEmpty) return null;
    return byId(id);
  }

  Future<void> select(String id) async {
    await NeuraLocalModelSettings.I.setSelectedModelId(id);
  }

  Future<NeuraModelPack> importFromPath({
    required String sourcePath,
    String description = '',
  }) async {
    await init();
    final src = File(sourcePath);
    if (!src.existsSync()) {
      throw Exception('Model file not found: $sourcePath');
    }
    final name = src.uri.pathSegments.isNotEmpty ? src.uri.pathSegments.last : 'model.gguf';
    final id = DateTime.now().millisecondsSinceEpoch.toString();
    final dstPath = '${_root!.path}${Platform.pathSeparator}$id-$name';
    final dst = await src.copy(dstPath);
    final bytes = await dst.length();

    final pack = NeuraModelPack(
      id: id,
      fileName: name,
      path: dst.path,
      bytes: bytes,
      addedAt: DateTime.now().toIso8601String(),
      description: description,
    );
    _packs.insert(0, pack);
    await _save();

    // Auto-select first import.
    if (NeuraLocalModelSettings.I.selectedModelId.isEmpty) {
      await NeuraLocalModelSettings.I.setSelectedModelId(id);
    }
    return pack;
  }

  Future<bool> remove(String id) async {
    await init();
    final p = byId(id);
    if (p == null) return false;
    try {
      final f = File(p.path);
      if (f.existsSync()) {
        await f.delete();
      }
    } catch (_) {
      // ignore
    }
    _packs.removeWhere((e) => e.id == id);
    if (NeuraLocalModelSettings.I.selectedModelId == id) {
      await NeuraLocalModelSettings.I.setSelectedModelId(_packs.isNotEmpty ? _packs.first.id : '');
    }
    await _save();
    return true;
  }

  Future<void> _load() async {
    if (_registry == null) return;
    if (!_registry!.existsSync()) {
      _packs.clear();
      return;
    }
    try {
      final raw = await _registry!.readAsString();
      final j = jsonDecode(raw);
      final items = (j['packs'] as List?) ?? const [];
      _packs
        ..clear()
        ..addAll(items.map((e) => NeuraModelPack.fromJson((e as Map).cast<String, dynamic>())));
    } catch (_) {
      _packs.clear();
    }
  }

  Future<void> _save() async {
    if (_registry == null) return;
    final j = {
      'version': 1,
      'savedAt': DateTime.now().toIso8601String(),
      'packs': _packs.map((e) => e.toJson()).toList(),
    };
    await _registry!.writeAsString(const JsonEncoder.withIndent('  ').convert(j));
  }
}
