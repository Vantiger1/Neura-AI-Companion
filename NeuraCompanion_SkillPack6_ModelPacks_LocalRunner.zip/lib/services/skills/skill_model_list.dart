import '../local_models/neura_model_pack_manager.dart';
import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillModelList extends NeuraSkill {
  @override
  String get type => 'model_list';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.low;

  @override
  String summarize(NeuraActionRequest req) => 'List installed local model packs.';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    await NeuraModelPackManager.I.init();
    final selected = NeuraModelPackManager.I.selected;
    final packs = NeuraModelPackManager.I.list().map((p) => p.toJson()).toList();
    return NeuraActionResult(
      ok: true,
      message: 'OK',
      data: {
        'selectedId': selected?.id ?? '',
        'selectedName': selected?.fileName ?? '',
        'packs': packs,
      },
    );
  }
}
