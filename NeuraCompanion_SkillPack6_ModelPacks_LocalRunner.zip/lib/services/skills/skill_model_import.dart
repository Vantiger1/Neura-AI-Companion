import '../local_models/neura_model_pack_manager.dart';
import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillModelImport extends NeuraSkill {
  @override
  String get type => 'model_import';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.high;

  @override
  String summarize(NeuraActionRequest req) {
    final p = (req.params['path'] ?? '').toString();
    return 'Import local model file: ${p.isEmpty ? '(missing path)' : p}';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final path = (req.params['path'] ?? '').toString().trim();
    final desc = (req.params['description'] ?? '').toString();
    if (path.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing param: path');
    }
    await NeuraModelPackManager.I.init();
    try {
      final pack = await NeuraModelPackManager.I.importFromPath(sourcePath: path, description: desc);
      return NeuraActionResult(ok: true, message: 'Imported', data: pack.toJson());
    } catch (e) {
      return NeuraActionResult(ok: false, message: 'Import failed: $e');
    }
  }
}
