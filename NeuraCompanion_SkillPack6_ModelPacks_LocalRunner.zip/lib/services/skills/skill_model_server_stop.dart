import '../local_models/neura_llama_server_runner.dart';
import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillModelServerStop extends NeuraSkill {
  @override
  String get type => 'model_server_stop';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  @override
  String summarize(NeuraActionRequest req) => 'Stop local llama server runner.';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final res = await NeuraLlamaServerRunner.I.stop();
    return NeuraActionResult(
      ok: res['ok'] == true,
      message: (res['message'] ?? res['error'] ?? 'unknown').toString(),
      data: res,
    );
  }
}
