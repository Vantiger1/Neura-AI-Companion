import '../local_models/neura_llama_server_runner.dart';
import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillModelServerStart extends NeuraSkill {
  @override
  String get type => 'model_server_start';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.high;

  @override
  String summarize(NeuraActionRequest req) => 'Start local llama server runner (desktop).';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final res = await NeuraLlamaServerRunner.I.start();
    return NeuraActionResult(
      ok: res['ok'] == true,
      message: (res['message'] ?? res['error'] ?? 'unknown').toString(),
      data: res,
    );
  }
}
