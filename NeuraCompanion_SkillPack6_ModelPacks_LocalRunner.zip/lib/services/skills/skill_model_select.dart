import '../local_models/neura_model_pack_manager.dart';
import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillModelSelect extends NeuraSkill {
  @override
  String get type => 'model_select';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  @override
  String summarize(NeuraActionRequest req) {
    final id = (req.params['id'] ?? '').toString();
    return 'Select local model pack: ${id.isEmpty ? '(missing id)' : id}';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final id = (req.params['id'] ?? '').toString().trim();
    if (id.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing param: id');
    }
    await NeuraModelPackManager.I.init();
    final p = NeuraModelPackManager.I.byId(id);
    if (p == null) {
      return NeuraActionResult(ok: false, message: 'Unknown model id: $id');
    }
    await NeuraModelPackManager.I.select(id);
    return NeuraActionResult(ok: true, message: 'Selected', data: p.toJson());
  }
}
