# Neura Companion – Skill Pack 6 (Model Packs + Desktop Runner)

## What this adds
- **Offline Model Pack Manager**: import GGUF files into app storage and manage selection.
- **Desktop Local Runner**: optional ability to start/stop a llama.cpp server executable from inside Neura (Windows/Linux/macOS).
- **New Skills** (Action Bus):
  - `model_list`
  - `model_import` (high risk: requires Full Access approval)
  - `model_select`
  - `model_server_start` (high risk: requires Full Access approval)
  - `model_server_stop`

## How to use (Windows)
1. Put a GGUF model file somewhere on your PC.
2. In Neura → Settings → Local Models:
   - paste GGUF file path → **Import**
   - select the imported pack
   - set llama.cpp server executable path (e.g. `llama-server.exe`)
   - optionally turn on **Autostart** → Save
   - press **Start runner**
3. Set Base URL to `http://127.0.0.1:8080` (or your chosen port) → **Test local server**.

## Notes
- Android runner is intentionally not enabled yet (needs native libs). Import UI shows placeholder.
