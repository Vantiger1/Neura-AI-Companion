import 'package:flutter/material.dart';

class EmotionPageRoute extends PageRouteBuilder {
  final Widget page;
  final String mood;

  EmotionPageRoute({required this.page, required this.mood})
      : super(
          pageBuilder: (context, animation, secondaryAnimation) => page,
          transitionsBuilder: (context, animation, secondaryAnimation, child) {
            Offset begin;
            switch (mood) {
              case "happy":
                begin = Offset(1.0, 0.0);
                break;
              case "sad":
                begin = Offset(-1.0, 0.0);
                break;
              case "excited":
                begin = Offset(0.0, 1.0);
                break;
              case "calm":
                begin = Offset(0.0, -1.0);
                break;
              default:
                begin = Offset.zero;
            }
            final end = Offset.zero;
            final curve = Curves.easeInOut;
            final tween = Tween(begin: begin, end: end).chain(CurveTween(curve: curve));
            return SlideTransition(position: animation.drive(tween), child: child);
          },
        );
}