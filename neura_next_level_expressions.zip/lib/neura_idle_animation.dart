import 'package:flutter/material.dart';

class NeuraIdleAnimation extends StatefulWidget {
  final Widget child;

  const NeuraIdleAnimation({Key? key, required this.child}) : super(key: key);

  @override
  _NeuraIdleAnimationState createState() => _NeuraIdleAnimationState();
}

class _NeuraIdleAnimationState extends State<NeuraIdleAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Offset> _float;

  @override
  void initState() {
    _controller = AnimationController(
      duration: Duration(seconds: 3),
      vsync: this,
    )..repeat(reverse: true);

    _float = Tween<Offset>(
      begin: Offset(0, 0),
      end: Offset(0, -0.03),
    ).animate(CurvedAnimation(parent: _controller, curve: Curves.easeInOut));

    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return SlideTransition(position: _float, child: widget.child);
  }
}