import 'package:flutter/material.dart';

class MoodTimeline extends StatelessWidget {
  final List<Map<String, dynamic>> entries;

  const MoodTimeline({Key? key, required this.entries}) : super(key: key);

  Color getColor(String mood) {
    switch (mood) {
      case "happy":
        return Colors.yellow;
      case "sad":
        return Colors.indigo;
      case "calm":
        return Colors.teal;
      case "excited":
        return Colors.orange;
      default:
        return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: entries.length,
      itemBuilder: (context, index) {
        final entry = entries[index];
        return ListTile(
          leading: CircleAvatar(backgroundColor: getColor(entry['mood'])),
          title: Text(entry['mood']),
          subtitle: Text(entry['time']),
        );
      },
    );
  }
}