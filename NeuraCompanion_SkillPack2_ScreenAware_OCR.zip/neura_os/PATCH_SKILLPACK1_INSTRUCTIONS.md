# Neura Skill Pack 1: Safe OS Actions + Approval Gates

This patch adds:
- Local Core Daemon (localhost) with `/execute` + `/approve`
- Policy engine + Full Access checklist & disclaimer
- Safe allowlisted skills: `write_note`, `open_url`, `desktop_launch_app`, `desktop_open_folder`
- Neura Command Console UI to test actions
- Privacy & Safety → Automation & Full Access screen

## Install
Copy the files from this ZIP into your Flutter project root (merge/overwrite).

Then run:
```bash
flutter pub get
```

## Test
1. Launch app
2. Go to **Settings → Privacy & Safety → Automation & Full Access**
3. Enable capabilities (or Full Access)
4. Go to **Settings → Neura Command Console**
5. Try:
- `write_note` (always allowed)
- `desktop_launch_app` with params: `{"app":"notepad"}`
- `open_url` requires Network Access toggle (default OFF)

## Notes
- Windows-only actions will return a clear error on Android.
- `open_url` is gated behind Network Access to preserve strict offline mode.
