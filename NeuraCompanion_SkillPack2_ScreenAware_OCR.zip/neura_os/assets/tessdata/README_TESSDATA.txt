Neura Screen-Aware OCR requires Tesseract tessdata language files.

Minimum required file:
  - eng.traineddata

Place it in this folder:
  assets/tessdata/eng.traineddata

Offline-friendly options:
  1) Copy a trusted eng.traineddata file you already have.
  2) If you temporarily allow internet, run the helper script:
       scripts/get_tessdata.ps1   (Windows PowerShell)
       scripts/get_tessdata.sh    (macOS/Linux)

After adding tessdata, run:
  flutter pub get
  flutter run
