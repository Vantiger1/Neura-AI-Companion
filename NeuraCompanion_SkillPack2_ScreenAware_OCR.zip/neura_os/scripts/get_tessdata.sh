#!/usr/bin/env bash
set -euo pipefail

# Downloads Tesseract language data needed for offline OCR.
# Source: Official tessdata repository (tesseract-ocr/tessdata).
# Run from project root:
#   bash scripts/get_tessdata.sh

DEST_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/../assets/tessdata"
mkdir -p "$DEST_DIR"

DEST="$DEST_DIR/eng.traineddata"
URL="https://raw.githubusercontent.com/tesseract-ocr/tessdata/main/eng.traineddata"

echo "Downloading eng.traineddata -> $DEST"
curl -L "$URL" -o "$DEST"
echo "Done."
