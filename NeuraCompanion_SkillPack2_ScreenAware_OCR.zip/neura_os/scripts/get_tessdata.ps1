# Downloads Tesseract language data needed for offline OCR.
# Source: Official tessdata repository (tesseract-ocr/tessdata).
# Run from project root:
#   powershell -ExecutionPolicy Bypass -File scripts/get_tessdata.ps1

$ErrorActionPreference = 'Stop'

$destDir = Join-Path $PSScriptRoot '..'
$destDir = Join-Path $destDir 'assets'
$destDir = Join-Path $destDir 'tessdata'
New-Item -ItemType Directory -Force -Path $destDir | Out-Null

$dest = Join-Path $destDir 'eng.traineddata'

# Note: This requires internet access at download time.
$url = 'https://raw.githubusercontent.com/tesseract-ocr/tessdata/main/eng.traineddata'

Write-Host "Downloading eng.traineddata -> $dest"
Invoke-WebRequest -Uri $url -OutFile $dest -UseBasicParsing
Write-Host 'Done.'
