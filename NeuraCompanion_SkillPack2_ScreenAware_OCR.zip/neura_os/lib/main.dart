import 'package:flutter/material.dart';

import 'modules/core/app_log.dart';
import 'modules/core/error_handler.dart';
import 'src/app.dart';
import 'src/modules/focus/focus_controller.dart';
import 'src/shell/shell_prefs.dart';
import 'services/neura_voice_pack.dart';
import 'services/neura_local_core_daemon.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Don't let logging crash startup.
  await AppLog.instance.init();
  ErrorHandler.install();

  // OS-level state
  await ShellPrefsController.instance.init();
  await FocusController.instance.init();

  // Local core daemon (policy + skills + audit timeline)
  try {
    await NeuraLocalCoreDaemon.I.init();
  } catch (_) {
    // Core daemon failure should not prevent UI boot.
  }

  // Voice/talk/viseme stream for the Rive resident (non-blocking safety)
  try {
    await NeuraVoicePack.I.init(enableMic: true);
  } catch (_) {
    // If mic permissions / audio init fail, the OS should still boot.
  }

  runApp(const NeuroCompanionApp());
}
