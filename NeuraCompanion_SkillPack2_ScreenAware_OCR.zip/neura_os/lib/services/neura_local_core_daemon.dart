import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'neura_automation_prefs.dart';
import 'neura_policy.dart';
import 'skills/neura_skill.dart';
import 'skills/neura_skill_registry.dart';
import 'skills/skill_desktop_launch_app.dart';
import 'skills/skill_desktop_open_folder.dart';
import 'skills/skill_open_url.dart';
import 'skills/skill_screen_ocr.dart';
import 'skills/skill_write_note.dart';

class _PendingApproval {
  final String id;
  final NeuraActionRequest req;
  final String summary;
  final DateTime createdAt;
  _PendingApproval({required this.id, required this.req, required this.summary, required this.createdAt});

  Map<String, dynamic> toJson() => {
        'id': id,
        'req': req.toJson(),
        'summary': summary,
        'createdAt': createdAt.toIso8601String(),
      };
}

/// Local-only HTTP server that centralizes actions, policy, and audit logging.
/// Runs inside the app process (MVP); can later be promoted to a true OS service.
class NeuraLocalCoreDaemon {
  static final NeuraLocalCoreDaemon I = NeuraLocalCoreDaemon._();
  NeuraLocalCoreDaemon._();

  HttpServer? _server;
  int? _port;
  DateTime? _startedAt;

  final List<Map<String, dynamic>> _timeline = <Map<String, dynamic>>[];
  final Map<String, _PendingApproval> _pending = {};

  int? get port => _port;
  DateTime? get startedAt => _startedAt;

  Future<void> init() async {
    await NeuraAutomationPrefs.I.init();

    // register skills (safe pack v1)
    final reg = NeuraSkillRegistry.I;
    reg.register(SkillWriteNote());
    reg.register(SkillOpenUrl());
    reg.register(SkillDesktopLaunchApp());
    reg.register(SkillDesktopOpenFolder());
    reg.register(SkillScreenOcr());
    reg.register(SkillScreenOcr());

    // bind
    if (_server != null) return;
    _server = await _bind();
    _startedAt = DateTime.now();
    _port = _server!.port;

    unawaited(_serve(_server!));
    _log('daemon_started', {'port': _port});
  }

  Future<HttpServer> _bind() async {
    const preferred = 7788;
    try {
      return await HttpServer.bind(InternetAddress.loopbackIPv4, preferred, shared: true);
    } catch (_) {
      // fallback to ephemeral
      return await HttpServer.bind(InternetAddress.loopbackIPv4, 0, shared: true);
    }
  }

  Future<void> _serve(HttpServer server) async {
    await for (final req in server) {
      try {
        await _handle(req);
      } catch (e) {
        _writeJson(req.response, 500, {'ok': false, 'error': e.toString()});
      }
    }
  }

  Future<void> _handle(HttpRequest req) async {
    final path = req.uri.path;

    if (req.method == 'GET' && path == '/health') {
      _writeJson(req.response, 200, {
        'ok': true,
        'port': _port,
        'startedAt': _startedAt?.toIso8601String(),
        'skills': NeuraSkillRegistry.I.types,
      });
      return;
    }

    if (req.method == 'GET' && path == '/memory/timeline') {
      final limit = int.tryParse(req.uri.queryParameters['limit'] ?? '') ?? 50;
      final slice = _timeline.reversed.take(limit).toList();
      _writeJson(req.response, 200, {'ok': true, 'items': slice});
      return;
    }

    if (req.method == 'GET' && path == '/pending') {
      _writeJson(req.response, 200, {'ok': true, 'items': _pending.values.map((p) => p.toJson()).toList()});
      return;
    }

    if (req.method == 'POST' && path == '/execute') {
      final body = await utf8.decodeStream(req);
      final jsonBody = (json.decode(body) as Map).cast<String, dynamic>();
      final actionReq = NeuraActionRequest.fromJson(jsonBody);

      final skill = NeuraSkillRegistry.I.get(actionReq.type);
      if (skill == null) {
        _log('execute_blocked', {'reason': 'unknown_skill', 'req': actionReq.toJson()});
        _writeJson(req.response, 400, {'ok': false, 'error': 'Unknown action type: ${actionReq.type}'});
        return;
      }

      final decision = NeuraPolicyEngine.I.decide(capability: skill.capability, risk: skill.risk);

      final summary = skill.summarize(actionReq);

      if (!decision.allowed) {
        _log('execute_denied', {'reason': decision.reason, 'summary': summary, 'req': actionReq.toJson()});
        _writeJson(req.response, 403, {
          'ok': false,
          'status': 'denied',
          'reason': decision.reason,
          'summary': summary,
        });
        return;
      }

      if (decision.needsApproval) {
        final id = _newId();
        _pending[id] = _PendingApproval(id: id, req: actionReq, summary: summary, createdAt: DateTime.now());
        _log('execute_needs_approval', {'approvalId': id, 'summary': summary, 'req': actionReq.toJson()});
        _writeJson(req.response, 202, {
          'ok': true,
          'status': 'needs_approval',
          'approvalId': id,
          'summary': summary,
          'reason': decision.reason,
        });
        return;
      }

      final res = await skill.run(actionReq);
      _log('execute', {'summary': summary, 'result': res.toJson()});
      _writeJson(req.response, 200, res.toJson());
      return;
    }

    if (req.method == 'POST' && path == '/approve') {
      final body = await utf8.decodeStream(req);
      final jsonBody = (json.decode(body) as Map).cast<String, dynamic>();
      final id = (jsonBody['approvalId'] ?? '').toString();
      final approve = jsonBody['approve'] == true;

      final pending = _pending.remove(id);
      if (pending == null) {
        _writeJson(req.response, 404, {'ok': false, 'error': 'Unknown approvalId.'});
        return;
      }

      if (!approve) {
        _log('approval_rejected', {'approvalId': id, 'summary': pending.summary});
        _writeJson(req.response, 200, {'ok': true, 'message': 'Rejected.'});
        return;
      }

      final skill = NeuraSkillRegistry.I.get(pending.req.type);
      if (skill == null) {
        _log('approval_failed', {'approvalId': id, 'reason': 'skill_missing'});
        _writeJson(req.response, 400, {'ok': false, 'error': 'Skill missing.'});
        return;
      }

      final res = await skill.run(pending.req);
      _log('approval_executed', {'approvalId': id, 'summary': pending.summary, 'result': res.toJson()});
      _writeJson(req.response, 200, res.toJson());
      return;
    }

    _writeJson(req.response, 404, {'ok': false, 'error': 'Not found'});
  }

  void _writeJson(HttpResponse res, int status, Map<String, dynamic> body) {
    res.statusCode = status;
    res.headers.contentType = ContentType.json;
    res.write(json.encode(body));
    res.close();
  }

  void _log(String type, Map<String, dynamic> data) {
    _timeline.add({
      'ts': DateTime.now().toIso8601String(),
      'type': type,
      'data': data,
    });
  }

  String _newId() {
    final ms = DateTime.now().millisecondsSinceEpoch;
    final r = (ms ^ (ms << 13) ^ (ms >> 7)) & 0x7fffffff;
    return '$ms-$r';
  }
}
