import 'neura_automation_prefs.dart';

enum NeuraRisk { low, medium, high, critical }

class PolicyDecision {
  final bool allowed;
  final bool needsApproval;
  final String reason;
  const PolicyDecision({
    required this.allowed,
    required this.needsApproval,
    required this.reason,
  });

  Map<String, dynamic> toJson() => {
        'allowed': allowed,
        'needsApproval': needsApproval,
        'reason': reason,
      };
}

/// Capabilities used to gate OS-level actions.
/// Keep this conservative.
enum NeuraCapability {
  launchApps,
  fileAccess,
  systemAutomation,
  networkAccess,
}

class NeuraPolicyEngine {
  static final NeuraPolicyEngine I = NeuraPolicyEngine._();
  NeuraPolicyEngine._();

  PolicyDecision decide({
    required NeuraCapability capability,
    required NeuraRisk risk,
  }) {
    final prefs = NeuraAutomationPrefs.I;

    bool capEnabled = switch (capability) {
      NeuraCapability.launchApps => prefs.capLaunchApps,
      NeuraCapability.fileAccess => prefs.capFileAccess,
      NeuraCapability.systemAutomation => prefs.capSystemAutomation,
      NeuraCapability.networkAccess => prefs.capNetworkAccess,
    };

    // Critical always needs explicit approval per action, even with Full Access.
    if (risk == NeuraRisk.critical) {
      if (!prefs.fullAccessEnabled) {
        return const PolicyDecision(
          allowed: false,
          needsApproval: false,
          reason: 'Full Access is required for critical actions.',
        );
      }
      return const PolicyDecision(
        allowed: true,
        needsApproval: true,
        reason: 'Critical action requires per-action approval.',
      );
    }

    // High risk requires Full Access.
    if (risk == NeuraRisk.high) {
      if (!prefs.fullAccessEnabled) {
        return const PolicyDecision(
          allowed: false,
          needsApproval: false,
          reason: 'Full Access is required for high-risk actions.',
        );
      }
      return const PolicyDecision(
        allowed: true,
        needsApproval: true,
        reason: 'High-risk action requires approval.',
      );
    }

    // Medium/Low require capability toggle (or Full Access).
    if (!capEnabled && !prefs.fullAccessEnabled) {
      return const PolicyDecision(
        allowed: false,
        needsApproval: false,
        reason: 'Capability disabled. Enable the capability (or Full Access) to proceed.',
      );
    }

    // For medium actions, ask for approval if Full Access isn't enabled (extra safety).
    if (risk == NeuraRisk.medium && !prefs.fullAccessEnabled) {
      return const PolicyDecision(
        allowed: true,
        needsApproval: true,
        reason: 'Medium-risk action requires approval.',
      );
    }

    return const PolicyDecision(
      allowed: true,
      needsApproval: false,
      reason: 'Allowed.',
    );
  }
}
