import '../neura_policy.dart';

class NeuraActionRequest {
  final String type;
  final Map<String, dynamic> params;
  NeuraActionRequest({required this.type, required this.params});

  factory NeuraActionRequest.fromJson(Map<String, dynamic> json) {
    return NeuraActionRequest(
      type: (json['type'] ?? '').toString(),
      params: (json['params'] as Map?)?.cast<String, dynamic>() ?? const <String, dynamic>{},
    );
  }

  Map<String, dynamic> toJson() => {'type': type, 'params': params};
}

class NeuraActionResult {
  final bool ok;
  final String message;
  final Map<String, dynamic> data;
  const NeuraActionResult({required this.ok, required this.message, this.data = const {}});

  Map<String, dynamic> toJson() => {'ok': ok, 'message': message, 'data': data};
}

abstract class NeuraSkill {
  String get type;

  /// Capability that the action consumes.
  NeuraCapability get capability;

  /// Risk classification.
  NeuraRisk get risk;

  /// A short user-facing summary (for approval dialogs).
  String summarize(NeuraActionRequest req);

  /// Execute the action (must be deterministic; never “invent” OS actions).
  Future<NeuraActionResult> run(NeuraActionRequest req);
}
