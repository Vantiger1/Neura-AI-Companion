import 'dart:io';

import 'package:path_provider/path_provider.dart';

import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillWriteNote implements NeuraSkill {
  @override
  String get type => 'write_note';

  @override
  NeuraCapability get capability => NeuraCapability.fileAccess;

  @override
  NeuraRisk get risk => NeuraRisk.low;

  @override
  String summarize(NeuraActionRequest req) {
    final title = (req.params['title'] ?? 'Note').toString();
    return 'Write a note: $title';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final title = (req.params['title'] ?? 'Note').toString();
    final body = (req.params['body'] ?? '').toString();

    final dir = await getApplicationDocumentsDirectory();
    final safeDir = Directory('${dir.path}/neura_notes');
    if (!await safeDir.exists()) {
      await safeDir.create(recursive: true);
    }

    final safeName = title.replaceAll(RegExp(r'[^a-zA-Z0-9 _\-]'), '').trim();
    final file = File('${safeDir.path}/${safeName.isEmpty ? 'note' : safeName}_${DateTime.now().millisecondsSinceEpoch}.txt');
    await file.writeAsString(body);

    return NeuraActionResult(
      ok: true,
      message: 'Note saved locally.',
      data: {'path': file.path},
    );
  }
}
