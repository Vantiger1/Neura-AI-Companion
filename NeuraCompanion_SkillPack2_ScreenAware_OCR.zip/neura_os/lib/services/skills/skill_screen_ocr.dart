import 'dart:io';
import 'dart:typed_data';

import 'package:flusseract/flusseract.dart' as flusseract;
import 'package:path_provider/path_provider.dart';
import 'package:screen_capturer/screen_capturer.dart';

import '../neura_policy.dart';
import 'neura_skill.dart';

/// Captures the current desktop screen and extracts visible text via offline OCR.
///
/// Privacy note: this can capture sensitive on-screen information, so we treat it as HIGH risk.
/// The policy engine will require Full Access + per-action approval.
class SkillScreenOcr extends NeuraSkill {
  static bool _tessReady = false;

  @override
  String get type => 'screen_ocr';

  @override
  NeuraCapability get capability => NeuraCapability.systemAutomation;

  @override
  NeuraRisk get risk => NeuraRisk.high;

  @override
  String summarize(NeuraActionRequest req) => 'Capture the desktop screen and read visible text (OCR).';

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    if (!(Platform.isWindows || Platform.isLinux || Platform.isMacOS)) {
      return const NeuraActionResult(
        ok: false,
        message: 'screen_ocr is currently supported on desktop (Windows/macOS/Linux) only.',
      );
    }

    try {
      final tmp = await getTemporaryDirectory();
      final outPath = '${tmp.path}${Platform.pathSeparator}neura_screen_${DateTime.now().millisecondsSinceEpoch}.png';

      final cap = await screenCapturer.capture(
        mode: CaptureMode.screen,
        imagePath: outPath,
        copyToClipboard: false,
      );

      if (cap == null) {
        return const NeuraActionResult(ok: false, message: 'Screen capture cancelled.');
      }

      // Initialize tessdata (requires assets/tessdata/eng.traineddata).
      if (!_tessReady) {
        await flusseract.TessData.init();
        _tessReady = true;
      }

      final bytes = await File(outPath).readAsBytes();
      final pix = flusseract.PixImage.fromBytes(Uint8List.fromList(bytes));
      final tesseract = flusseract.Tesseract(tessDataPath: flusseract.TessData.tessDataPath);
      final text = (await tesseract.utf8Text(pix)).trim();

      final summary = _summarize(text);

      return NeuraActionResult(
        ok: true,
        message: text.isEmpty ? 'No readable text detected.' : 'OCR complete.',
        data: {
          'imagePath': outPath,
          'text': text,
          'summary': summary,
          'chars': text.length,
        },
      );
    } catch (e) {
      final hint = 'If this is the first run: add assets/tessdata/eng.traineddata (see assets/tessdata/README_TESSDATA.txt).';
      return NeuraActionResult(ok: false, message: 'OCR failed: $e\n$hint');
    }
  }

  String _summarize(String text) {
    if (text.trim().isEmpty) return '';

    // Heuristic summary: first non-empty lines, capped.
    final lines = text.split(RegExp(r'\r?\n')).map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
    final take = lines.take(12).toList();
    var out = take.join(' | ');
    if (out.length > 500) out = out.substring(0, 500);
    return out;
  }
}
