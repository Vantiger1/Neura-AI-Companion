import 'neura_skill.dart';

class NeuraSkillRegistry {
  static final NeuraSkillRegistry I = NeuraSkillRegistry._();
  NeuraSkillRegistry._();

  final Map<String, NeuraSkill> _skills = {};

  void register(NeuraSkill skill) {
    _skills[skill.type] = skill;
  }

  NeuraSkill? get(String type) => _skills[type];

  List<String> get types => _skills.keys.toList()..sort();
}
