import 'dart:io';

import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillDesktopOpenFolder implements NeuraSkill {
  @override
  String get type => 'desktop_open_folder';

  @override
  NeuraCapability get capability => NeuraCapability.fileAccess;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  @override
  String summarize(NeuraActionRequest req) {
    final path = (req.params['path'] ?? '').toString();
    return 'Open folder: $path';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    if (!Platform.isWindows) {
      return const NeuraActionResult(ok: false, message: 'desktop_open_folder is Windows-only.');
    }
    final path = (req.params['path'] ?? '').toString().trim();
    if (path.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing path.');
    }
    final dir = Directory(path);
    if (!await dir.exists()) {
      return const NeuraActionResult(ok: false, message: 'Folder does not exist.');
    }

    try {
      await Process.start('explorer.exe', [path]);
      return const NeuraActionResult(ok: true, message: 'Opened folder.');
    } catch (e) {
      return NeuraActionResult(ok: false, message: 'Failed to open folder: $e');
    }
  }
}
