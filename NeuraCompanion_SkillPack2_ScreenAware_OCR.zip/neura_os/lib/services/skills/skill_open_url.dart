import 'package:url_launcher/url_launcher.dart';

import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillOpenUrl implements NeuraSkill {
  @override
  String get type => 'open_url';

  @override
  NeuraCapability get capability => NeuraCapability.networkAccess;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  @override
  String summarize(NeuraActionRequest req) {
    final url = (req.params['url'] ?? '').toString();
    return 'Open URL: $url';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final url = (req.params['url'] ?? '').toString().trim();
    if (url.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing url.');
    }

    Uri? uri;
    try {
      uri = Uri.parse(url);
    } catch (_) {
      return const NeuraActionResult(ok: false, message: 'Invalid URL.');
    }

    final ok = await launchUrl(uri, mode: LaunchMode.externalApplication);
    if (!ok) {
      return const NeuraActionResult(ok: false, message: 'Could not open URL.');
    }
    return const NeuraActionResult(ok: true, message: 'Opened URL.');
  }
}
