import 'dart:io';

import '../neura_policy.dart';
import 'neura_skill.dart';

class SkillDesktopLaunchApp implements NeuraSkill {
  @override
  String get type => 'desktop_launch_app';

  @override
  NeuraCapability get capability => NeuraCapability.launchApps;

  @override
  NeuraRisk get risk => NeuraRisk.medium;

  static const Map<String, List<String>> _allowlisted = {
    'notepad': ['notepad.exe'],
    'calculator': ['calc.exe'],
    'explorer': ['explorer.exe'],
    'cmd': ['cmd.exe'],
    'powershell': ['powershell.exe'],
  };

  @override
  String summarize(NeuraActionRequest req) {
    final app = (req.params['app'] ?? '').toString();
    return 'Launch desktop app: $app';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    if (!Platform.isWindows) {
      return const NeuraActionResult(ok: false, message: 'desktop_launch_app is Windows-only.');
    }
    final app = (req.params['app'] ?? '').toString().toLowerCase().trim();
    if (app.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing app.');
    }

    final cmd = _allowlisted[app];
    if (cmd == null) {
      return const NeuraActionResult(
        ok: false,
        message: 'App not allowlisted. Only: notepad, calculator, explorer, cmd, powershell.',
      );
    }

    try {
      await Process.start(cmd.first, cmd.length > 1 ? cmd.sublist(1) : const []);
      return const NeuraActionResult(ok: true, message: 'Launched.');
    } catch (e) {
      return NeuraActionResult(ok: false, message: 'Failed to launch: $e');
    }
  }
}
