# Screen-Aware Neura (Skill Pack 2) — Desktop Notes

## What it does
- Captures the current desktop screen (local-only)
- Runs offline OCR (Tesseract) to extract visible text

## Privacy
Screen capture can include sensitive data. In Neura's policy engine this skill is **HIGH risk**:
- Requires **Full Access** enabled
- Requires **per-action approval**

## Windows build requirement (for screen_capturer)
The screen capture plugin uses native Windows components. Ensure Visual Studio Build Tools include:
- **C++ ATL for latest v142 build tools (x86 & x64)**

(Reference: screen_capturer plugin README.)

## OCR data requirement (tessdata)
You must provide at minimum:
- `assets/tessdata/eng.traineddata`

Use helper scripts:
- `scripts/get_tessdata.ps1`
- `scripts/get_tessdata.sh`

