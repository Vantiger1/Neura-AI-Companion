# PATCH INSTRUCTIONS — Skill Pack 9

## Apply (copy/merge)
1. Unzip this patch.
2. Copy the `lib/` folder into your project root (overwrite when prompted).

## What changed
- `DualChatService` now calls a **local/offline OpenAI-compatible** endpoint.
- `DualChatScreen` now **streams** the assistant response (incremental updates).

## Configure local server
By default the app uses:
- Base URL: `http://127.0.0.1:8080/v1`
- Model name: `local-model`

To change these, set prefs via code using `NeuraLocalModelConfig.save()` or expose a settings screen.

## Safety/performance
The Performance Guard defaults are conservative:
- ~25 tokens/sec cap
- min 16ms between UI emits

Adjust in `NeuraLocalModelConfig` if you want faster or slower streaming.

## If you get "local AI offline server not reachable"
That means the local server isn't running or isn't reachable from the device.
- Windows: ensure your server is running on the same machine.
- Android: for true offline on-device inference, you must run a native runtime (planned next patch).
