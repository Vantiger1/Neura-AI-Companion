import 'dart:async';

import '../models/ai_avatar.dart';
import 'local_models/neura_local_model_config.dart';
import 'local_models/neura_openai_compat_client.dart';
import 'local_models/neura_perf_guard.dart';

class DualChatService {
  /// Streams an assistant response chunk-by-chunk from a **local/offline** LLM.
  ///
  /// Requires an OpenAI-compatible server reachable at [NeuraLocalModelConfig.baseUrl].
  /// If not available, the stream yields a single helpful error message.
  Stream<String> streamMessage(String userMessage, AIAvatar avatar) async* {
    final cfg = await NeuraLocalModelConfig.load();
    final client = NeuraOpenAICompatClient(cfg);

    final messages = <Map<String, String>>[
      {
        'role': 'system',
        'content': 'You are ${avatar.name}, Neura\'s companion persona. Be helpful, concise, and kind. Offline-only.',
      },
      {
        'role': 'user',
        'content': userMessage,
      },
    ];

    final guard = NeuraPerfGuard(
      enabled: cfg.perfGuardEnabled,
      tokensPerSecondCap: cfg.tokensPerSecondCap,
      minChunkDelayMs: cfg.minChunkDelayMs,
    );

    try {
      if (cfg.useStreaming) {
        yield* client.chatStream(messages: messages, perfGuard: guard);
      } else {
        final once = await client.chatOnce(messages: messages);
        yield once;
      }
    } catch (e) {
      // Never throw into the UI; yield a safe error response.
      yield 'Response from ${avatar.name}: (local AI offline server not reachable)\n\nError: $e';
    }
  }

  /// Sends user message and returns the full response from specified avatar.
  ///
  /// Uses streaming under the hood when enabled, but returns a single String.
  Future<String> sendMessage(String message, AIAvatar avatar) async {
    final buffer = StringBuffer();
    await for (final chunk in streamMessage(message, avatar)) {
      buffer.write(chunk);
    }
    return 'Response from ${avatar.name}: ${buffer.toString()}';
  }
}
