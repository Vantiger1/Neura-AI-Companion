import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'neura_local_model_config.dart';
import 'neura_perf_guard.dart';

/// Minimal OpenAI-compatible client intended for **local/offline** servers
/// (e.g., llama.cpp server, LM Studio, vLLM in local mode).
///
/// Supports:
/// - chat completions (non-stream)
/// - chat completions (streamed SSE)
class NeuraOpenAICompatClient {
  final NeuraLocalModelConfig config;

  NeuraOpenAICompatClient(this.config);

  Uri _endpoint(String path) {
    final base = config.baseUrl.endsWith('/')
        ? config.baseUrl.substring(0, config.baseUrl.length - 1)
        : config.baseUrl;
    return Uri.parse('$base$path');
  }

  Future<String> chatOnce({
    required List<Map<String, String>> messages,
    String? model,
    double? temperature,
    int? maxTokens,
  }) async {
    final uri = _endpoint('/chat/completions');
    final body = {
      'model': model ?? config.model,
      'messages': messages,
      'temperature': temperature ?? config.temperature,
      'max_tokens': maxTokens ?? config.maxTokens,
      'stream': false,
    };

    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: config.timeoutMs);

    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(body));
      final resp = await req.close();
      final text = await utf8.decodeStream(resp);

      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        throw HttpException('Local LLM error ${resp.statusCode}: $text');
      }

      final json = jsonDecode(text) as Map<String, dynamic>;
      final choices = json['choices'] as List<dynamic>?;
      if (choices == null || choices.isEmpty) return '';
      final msg = (choices.first as Map<String, dynamic>)['message'] as Map<String, dynamic>?;
      return (msg?['content'] as String?) ?? '';
    } finally {
      client.close(force: true);
    }
  }

  /// Streams assistant tokens/chunks.
  ///
  /// Yields incremental text fragments (already in-order) suitable for appending.
  Stream<String> chatStream({
    required List<Map<String, String>> messages,
    NeuraPerfGuard? perfGuard,
    String? model,
    double? temperature,
    int? maxTokens,
  }) async* {
    final guard = perfGuard;
    final uri = _endpoint('/chat/completions');
    final body = {
      'model': model ?? config.model,
      'messages': messages,
      'temperature': temperature ?? config.temperature,
      'max_tokens': maxTokens ?? config.maxTokens,
      'stream': true,
    };

    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: config.timeoutMs);

    HttpClientRequest req;
    try {
      req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.headers.set('Accept', 'text/event-stream');
      req.write(jsonEncode(body));

      final resp = await req.close();
      if (resp.statusCode < 200 || resp.statusCode >= 300) {
        final err = await utf8.decodeStream(resp);
        throw HttpException('Local LLM stream error ${resp.statusCode}: $err');
      }

      // Parse SSE: lines with "data: {...}" and "data: [DONE]".
      final decoder = utf8.decoder;
      final lines = resp.transform(decoder).transform(const LineSplitter());

      for await (final line in lines) {
        if (line.isEmpty) continue;
        if (!line.startsWith('data:')) continue;
        final payload = line.substring(5).trim();
        if (payload == '[DONE]') break;

        Map<String, dynamic> json;
        try {
          json = jsonDecode(payload) as Map<String, dynamic>;
        } catch (_) {
          // Some servers send keep-alives or non-json; ignore.
          continue;
        }

        final choices = json['choices'] as List<dynamic>?;
        if (choices == null || choices.isEmpty) continue;
        final delta = (choices.first as Map<String, dynamic>)['delta'] as Map<String, dynamic>?;
        final chunk = (delta?['content'] as String?) ?? '';
        if (chunk.isEmpty) continue;

        if (guard != null) {
          // Best-effort token estimate: ~4 chars/token.
          final tokenEstimate = (chunk.length / 4.0).ceil().clamp(1, 999999);
          await guard.gate(tokenCount: tokenEstimate);
        }

        yield chunk;
      }
    } finally {
      client.close(force: true);
    }
  }
}
