import 'package:shared_preferences/shared_preferences.dart';

/// Local model + streaming configuration.
///
/// Defaults target an OpenAI-compatible local server (e.g., llama.cpp server)
/// reachable at localhost.
class NeuraLocalModelConfig {
  static const _kBaseUrl = 'neura.localModel.baseUrl';
  static const _kModelName = 'neura.localModel.modelName';
  static const _kTimeoutMs = 'neura.localModel.timeoutMs';
  static const _kTemperature = 'neura.localModel.temperature';
  static const _kMaxTokens = 'neura.localModel.maxTokens';
  static const _kUseStreaming = 'neura.localModel.useStreaming';

  static const _kPerfGuardEnabled = 'neura.perfGuard.enabled';
  static const _kTokensPerSecondCap = 'neura.perfGuard.tpsCap';
  static const _kMinChunkDelayMs = 'neura.perfGuard.minChunkDelayMs';

  static const defaultBaseUrl = 'http://127.0.0.1:8080/v1';
  static const defaultModel = 'local-model';
  static const defaultTimeoutMs = 45000;
  static const defaultTemperature = 0.6;
  static const defaultMaxTokens = 512;
  static const defaultUseStreaming = true;

  static const defaultPerfGuardEnabled = true;
  static const defaultTokensPerSecondCap = 25.0;
  static const defaultMinChunkDelayMs = 16;

  final String baseUrl;
  final String model;
  final int timeoutMs;
  final double temperature;
  final int maxTokens;
  final bool useStreaming;

  final bool perfGuardEnabled;
  final double tokensPerSecondCap;
  final int minChunkDelayMs;

  const NeuraLocalModelConfig({
    required this.baseUrl,
    required this.model,
    required this.timeoutMs,
    required this.temperature,
    required this.maxTokens,
    required this.useStreaming,
    required this.perfGuardEnabled,
    required this.tokensPerSecondCap,
    required this.minChunkDelayMs,
  });

  NeuraLocalModelConfig copyWith({
    String? baseUrl,
    String? model,
    int? timeoutMs,
    double? temperature,
    int? maxTokens,
    bool? useStreaming,
    bool? perfGuardEnabled,
    double? tokensPerSecondCap,
    int? minChunkDelayMs,
  }) {
    return NeuraLocalModelConfig(
      baseUrl: baseUrl ?? this.baseUrl,
      model: model ?? this.model,
      timeoutMs: timeoutMs ?? this.timeoutMs,
      temperature: temperature ?? this.temperature,
      maxTokens: maxTokens ?? this.maxTokens,
      useStreaming: useStreaming ?? this.useStreaming,
      perfGuardEnabled: perfGuardEnabled ?? this.perfGuardEnabled,
      tokensPerSecondCap: tokensPerSecondCap ?? this.tokensPerSecondCap,
      minChunkDelayMs: minChunkDelayMs ?? this.minChunkDelayMs,
    );
  }

  static Future<NeuraLocalModelConfig> load() async {
    final prefs = await SharedPreferences.getInstance();
    return NeuraLocalModelConfig(
      baseUrl: prefs.getString(_kBaseUrl) ?? defaultBaseUrl,
      model: prefs.getString(_kModelName) ?? defaultModel,
      timeoutMs: prefs.getInt(_kTimeoutMs) ?? defaultTimeoutMs,
      temperature: prefs.getDouble(_kTemperature) ?? defaultTemperature,
      maxTokens: prefs.getInt(_kMaxTokens) ?? defaultMaxTokens,
      useStreaming: prefs.getBool(_kUseStreaming) ?? defaultUseStreaming,
      perfGuardEnabled: prefs.getBool(_kPerfGuardEnabled) ?? defaultPerfGuardEnabled,
      tokensPerSecondCap: prefs.getDouble(_kTokensPerSecondCap) ?? defaultTokensPerSecondCap,
      minChunkDelayMs: prefs.getInt(_kMinChunkDelayMs) ?? defaultMinChunkDelayMs,
    );
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kBaseUrl, baseUrl);
    await prefs.setString(_kModelName, model);
    await prefs.setInt(_kTimeoutMs, timeoutMs);
    await prefs.setDouble(_kTemperature, temperature);
    await prefs.setInt(_kMaxTokens, maxTokens);
    await prefs.setBool(_kUseStreaming, useStreaming);
    await prefs.setBool(_kPerfGuardEnabled, perfGuardEnabled);
    await prefs.setDouble(_kTokensPerSecondCap, tokensPerSecondCap);
    await prefs.setInt(_kMinChunkDelayMs, minChunkDelayMs);
  }
}
