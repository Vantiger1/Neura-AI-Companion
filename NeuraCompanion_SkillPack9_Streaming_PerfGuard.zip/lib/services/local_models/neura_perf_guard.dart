import 'dart:async';

/// Simple performance guard that rate-limits streamed token updates.
///
/// Goals:
/// - Keep UI smooth (avoid rebuilding on every tiny token).
/// - Keep devices cooler by enforcing a soft tokens-per-second cap.
///
/// It is intentionally conservative and platform-agnostic. If you later add
/// true thermal/battery telemetry, plug it in by tightening the cap dynamically.
class NeuraPerfGuard {
  final bool enabled;
  final double tokensPerSecondCap;
  final int minChunkDelayMs;

  // Internal
  DateTime _lastEmit = DateTime.fromMillisecondsSinceEpoch(0);
  double _tokenBudget = 0;
  DateTime _budgetTs = DateTime.now();

  NeuraPerfGuard({
    required this.enabled,
    required this.tokensPerSecondCap,
    required this.minChunkDelayMs,
  });

  /// Called before emitting a chunk to the UI.
  ///
  /// [tokenCount] is a best-effort estimate (characters/4 is acceptable).
  Future<void> gate({required int tokenCount}) async {
    if (!enabled) return;

    // Enforce minimum inter-chunk delay to prevent UI spam.
    final now = DateTime.now();
    final elapsedMs = now.difference(_lastEmit).inMilliseconds;
    if (elapsedMs < minChunkDelayMs) {
      await Future.delayed(Duration(milliseconds: minChunkDelayMs - elapsedMs));
    }

    // Token budget (leaky bucket): allow tokensPerSecondCap tokens/sec.
    final now2 = DateTime.now();
    final dt = now2.difference(_budgetTs).inMilliseconds / 1000.0;
    _budgetTs = now2;
    _tokenBudget += tokensPerSecondCap * dt;

    // Clamp budget to avoid infinite накопление when idle.
    if (_tokenBudget > tokensPerSecondCap * 2) {
      _tokenBudget = tokensPerSecondCap * 2;
    }

    if (_tokenBudget < tokenCount) {
      final deficit = tokenCount - _tokenBudget;
      final waitSec = deficit / tokensPerSecondCap;
      final waitMs = (waitSec * 1000).ceil();
      await Future.delayed(Duration(milliseconds: waitMs));
      // After wait, spend budget.
      _tokenBudget = 0;
    } else {
      _tokenBudget -= tokenCount;
    }

    _lastEmit = DateTime.now();
  }
}
