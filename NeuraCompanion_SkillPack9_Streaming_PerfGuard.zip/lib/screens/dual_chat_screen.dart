import 'dart:async';

import 'package:flutter/material.dart';

import '../avatar/avatar_globals.dart';
import '../models/ai_avatar.dart';
import '../services/dual_chat_service.dart';
import '../services/avatar_service.dart';

class DualChatScreen extends StatefulWidget {
  @override
  _DualChatScreenState createState() => _DualChatScreenState();
}

class _DualChatScreenState extends State<DualChatScreen> {
  final _avatarService = AvatarService.instance;
  final _chatService = DualChatService();
  List<AIAvatar> _avatars = [];
  AIAvatar? _current;
  final _controller = TextEditingController();
  final List<String> _messages = [];
  StreamSubscription<String>? _streamSub;

  @override
  void initState() {
    super.initState();
    _avatars = _avatarService.getAvailableAvatars();
    _avatarService.getSelectedAvatar().then((a) {
      setState(() => _current = a);
    });
  }

  @override
  void dispose() {
    _streamSub?.cancel();
    _controller.dispose();
    super.dispose();
  }

  Future<void> _send() async {
    final text = _controller.text.trim();
    if (text.isEmpty || _current == null) return;

    await _streamSub?.cancel();

    setState(() {
      _messages.add('You: $text');
      // Placeholder assistant message we will update as tokens stream.
      _messages.add('Response from ${_current!.name}: ');
      _controller.clear();
    });

    final assistantIndex = _messages.length - 1;

    AvatarGlobals.controller.setThinking(true);

    final buffer = StringBuffer();
    _streamSub = _chatService.streamMessage(text, _current!).listen(
      (chunk) {
        buffer.write(chunk);
        setState(() {
          _messages[assistantIndex] = 'Response from ${_current!.name}: ${buffer.toString()}';
        });
      },
      onError: (_) {
        // streamMessage should not throw, but keep this as a safety net.
        setState(() {
          _messages[assistantIndex] = 'Response from ${_current!.name}: (stream error)';
        });
      },
      onDone: () {
        AvatarGlobals.controller.setThinking(false);
      },
    );
  }

  @override
  Widget build(BuildContext ctx) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Chat with AI'),
        actions: [
          PopupMenuButton<AIAvatar>(
            onSelected: (a) => setState(() => _current = a),
            itemBuilder: (_) => _avatars
                .map((a) => PopupMenuItem(value: a, child: Text(a.name)))
                .toList(),
          )
        ],
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView(
              children: _messages.map((m) => ListTile(title: Text(m))).toList(),
            ),
          ),
          const Divider(height: 1),
          Padding(
            padding: const EdgeInsets.all(8),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(
                      hintText: 'Message Neura… (offline local model)',
                      border: OutlineInputBorder(),
                      isDense: true,
                    ),
                    onSubmitted: (_) => _send(),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(icon: const Icon(Icons.send), onPressed: _send),
              ],
            ),
          )
        ],
      ),
    );
  }
}
