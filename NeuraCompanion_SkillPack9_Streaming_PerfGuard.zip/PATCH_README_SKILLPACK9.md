# Neura Companion — Skill Pack 9
## Token Streaming + Performance Guard (Android + Windows)

This patch upgrades the AI chat pipeline to **stream tokens** from a **local/offline** LLM server (OpenAI-compatible) and adds a platform-agnostic **Performance Guard** so Neura doesn't melt user devices or spam UI rebuilds.

### What you get
- **SSE token streaming** (`/v1/chat/completions` with `stream=true`)
- **Rate-limited UI updates** (tokens-per-second cap + minimum chunk delay)
- **Fallback behavior**: if the local server isn't reachable, Neura returns a helpful offline error (no crashes)

### Server expectation
- OpenAI-compatible local endpoint (default):
  - Base URL: `http://127.0.0.1:8080/v1`
  - Endpoint: `POST /chat/completions`

### Files included
- `lib/services/local_models/neura_local_model_config.dart`
- `lib/services/local_models/neura_openai_compat_client.dart`
- `lib/services/local_models/neura_perf_guard.dart`
- `lib/services/dual_chat_service.dart` (updated)
- `lib/screens/dual_chat_screen.dart` (updated)

### Quick test
1. Start your local model server (desktop)
2. Run the app
3. Open **Dual Chat** and send a message
4. Watch Neura stream the response in-place
