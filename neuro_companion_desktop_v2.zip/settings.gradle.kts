rootProject.name = "neuro-companion-desktop"
