package ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.launch
import org.koin.java.KoinJavaComponent.get
import viewmodel.RitualViewModel

@Composable
fun RitualScreen(onNavigate: (String) -> Unit) {
    val vm: RitualViewModel = get(RitualViewModel::class.java)
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Ritual Mode", style = androidx.compose.material3.MaterialTheme.typography.headlineSmall)
        Button(onClick = { scope.launch { vm.loadRitual() } }) {
            Text("Generate Ritual")
        }
        Text(vm.ritualSuggestion, modifier = Modifier.padding(top = 8.dp))
        Button(onClick = { onNavigate("dashboard") }) {
            Text("Back to Dashboard")
        }
    }
}
