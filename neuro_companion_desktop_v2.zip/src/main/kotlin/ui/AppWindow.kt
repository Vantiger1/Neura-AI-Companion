package ui

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import ui.screens.DashboardScreen

@Composable
fun AppWindow() {
    var currentScreen by remember { mutableStateOf("dashboard") }
    Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
        when(currentScreen) {
            "dashboard" -> DashboardScreen { currentScreen = it }
            "ritual" -> RitualScreen { currentScreen = it }
            // TODO: other screens
        }
    }
}
