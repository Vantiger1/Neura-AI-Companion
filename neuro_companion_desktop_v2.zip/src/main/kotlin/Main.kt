import androidx.compose.ui.window.Window
import androidx.compose.ui.window.application
import org.koin.core.context.startKoin
import di.appModule
import ui.AppWindow

fun main() = application {
    startKoin { modules(appModule) }
    Window(onCloseRequest = ::exitApplication, title = "Neuro Companion") {
        AppWindow()
    }
}
