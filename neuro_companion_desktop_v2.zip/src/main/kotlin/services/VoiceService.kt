package services

import com.microsoft.cognitiveservices.speech.SpeechConfig
import com.microsoft.cognitiveservices.speech.SpeechRecognizer

class VoiceService {
    private val config = SpeechConfig.fromSubscription("YOUR_KEY", "YOUR_REGION")
    private val recognizer = SpeechRecognizer(config)

    suspend fun transcribe(): String {
        val result = recognizer.recognizeOnceAsync().get()
        return if (result.reason == com.microsoft.cognitiveservices.speech.ResultReason.RecognizedSpeech) {
            result.text
        } else {
            ""
        }
    }
}
