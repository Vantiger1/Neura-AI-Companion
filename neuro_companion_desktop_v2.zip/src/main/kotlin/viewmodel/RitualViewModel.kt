package viewmodel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import services.AIService
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class RitualViewModel(private val ai: AIService) {
    var ritualSuggestion by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun loadRitual() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            ritualSuggestion = try {
                ai.generateText("Suggest a daily self-care ritual for mindfulness.")
            } catch (e: Exception) {
                "Failed to generate ritual."
            } finally {
                isBusy = false
            }
        }
    }
}
