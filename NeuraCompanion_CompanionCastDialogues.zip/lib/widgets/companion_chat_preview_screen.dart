import 'package:flutter/material.dart';
import '../services/companion_cast_service.dart';

class CompanionCastScreen extends StatelessWidget {
  final CompanionCastService service;

  const CompanionCastScreen({required this.service});

  @override
  Widget build(BuildContext context) {
    final companions = service.all;

    return Scaffold(
      appBar: AppBar(title: Text('Choose Your Companion')),
      body: ListView(
        children: companions.map((c) => Card(
          margin: EdgeInsets.all(12),
          child: ListTile(
            leading: Icon(Icons.person),
            title: Text(c.name),
            subtitle: Text('${c.personality}\n"${c.greeting}"'),
            onTap: () {
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('${c.name} is ready to chat!')),
              );
            },
          ),
        )).toList(),
      ),
    );
  }
}
