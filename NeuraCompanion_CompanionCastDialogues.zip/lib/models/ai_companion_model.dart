import 'package:flutter/foundation.dart';

@immutable
class AICompanion {
  final String id;
  final String name;
  final String personality;
  final String greeting;

  const AICompanion({
    required this.id,
    required this.name,
    required this.personality,
    required this.greeting,
  });
}
