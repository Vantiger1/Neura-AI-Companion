import '../models/ai_companion_model.dart';

class CompanionCastService {
  final List<AICompanion> _cast = [
    AICompanion(
      id: 'neura',
      name: 'Neura',
      personality: 'Nurturing, gentle, warm',
      greeting: 'Hey sunshine. Ready to take a breath together?',
    ),
    AICompanion(
      id: 'neuro',
      name: 'Neuro',
      personality: 'Logical, efficient, focused',
      greeting: 'Welcome back. Let’s optimize your mind today.',
    ),
    AICompanion(
      id: 'luna',
      name: 'Luna',
      personality: 'Poetic, dreamy, introspective',
      greeting: 'The night is soft, and so is your soul. What dreams whisper to you today?',
    ),
  ];

  List<AICompanion> get all => List.unmodifiable(_cast);

  AICompanion? findById(String id) {
    return _cast.firstWhere((c) => c.id == id, orElse: () => _cast[0]);
  }
}
