import '../models/evolving_avatar_model.dart';

class AvatarAgeSelector {
  static EvolvingAvatar getAvatarForAge(int age) {
    String stage = 'baby';
    int level = 1;

    if (age < 3) {
      stage = 'baby';
      level = 1;
    } else if (age < 6) {
      stage = 'toddler';
      level = 2;
    } else if (age < 13) {
      stage = 'child';
      level = 3;
    } else if (age < 20) {
      stage = 'teen';
      level = 4;
    } else if (age < 40) {
      stage = 'young_adult';
      level = 5;
    } else if (age < 65) {
      stage = 'adult';
      level = 6;
    } else {
      stage = 'grandma';
      level = 7;
    }

    return EvolvingAvatar(
      id: 'neura_$stage',
      name: 'Neura ($stage)',
      animationPath: 'assets/avatars/neura_$stage.json',
      level: level,
    );
  }
}
