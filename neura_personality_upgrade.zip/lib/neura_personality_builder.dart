class NeuraPersonality {
  int helpfulness = 0;
  int empathy = 0;
  int humor = 0;

  void adjust({int help = 0, int care = 0, int fun = 0}) {
    helpfulness += help;
    empathy += care;
    humor += fun;
  }

  String describe() {
    if (helpfulness + empathy + humor < 5) {
      return "Neura is just getting to know you.";
    } else if (helpfulness > empathy && helpfulness > humor) {
      return "Neura is becoming a loyal assistant.";
    } else if (empathy > helpfulness && empathy > humor) {
      return "Neura is growing into a compassionate companion.";
    } else if (humor > helpfulness && humor > empathy) {
      return "Neura is developing a playful, goofy style.";
    } else {
      return "Neura is well-rounded and emotionally tuned.";
    }
  }
}