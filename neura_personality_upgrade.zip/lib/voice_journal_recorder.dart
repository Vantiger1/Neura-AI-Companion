import 'package:flutter/material.dart';

class VoiceJournalRecorder extends StatelessWidget {
  final bool isRecording;

  const VoiceJournalRecorder({Key? key, required this.isRecording}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      decoration: BoxDecoration(
        color: isRecording ? Colors.red.shade50 : Colors.grey.shade100,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: isRecording ? Colors.red : Colors.grey,
          width: 2,
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(isRecording ? Icons.mic : Icons.mic_none, size: 40),
          SizedBox(height: 10),
          Text(isRecording ? "Recording..." : "Tap to record a voice journal"),
          if (isRecording)
            Padding(
              padding: const EdgeInsets.only(top: 10),
              child: LinearProgressIndicator(),
            ),
        ],
      ),
    );
  }
}