import 'package:flutter/material.dart';
import 'dart:math';

class SparkleOverlay extends StatefulWidget {
  final Widget child;

  const SparkleOverlay({Key? key, required this.child}) : super(key: key);

  @override
  _SparkleOverlayState createState() => _SparkleOverlayState();
}

class _SparkleOverlayState extends State<SparkleOverlay>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  final Random _random = Random();

  @override
  void initState() {
    _controller = AnimationController(
      duration: const Duration(seconds: 3),
      vsync: this,
    )..repeat();
    super.initState();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Widget _buildSparkle() {
    final size = _random.nextDouble() * 10 + 5;
    final left = _random.nextDouble() * 200;
    final top = _random.nextDouble() * 300;
    return Positioned(
      left: left,
      top: top,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.8),
          shape: BoxShape.circle,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        ...List.generate(10, (index) => _buildSparkle()),
      ],
    );
  }
}