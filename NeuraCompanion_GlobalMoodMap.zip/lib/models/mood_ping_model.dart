import 'package:flutter/foundation.dart';

@immutable
class MoodPing {
  final String emoji;
  final String location;
  final DateTime timestamp;

  const MoodPing({
    required this.emoji,
    required this.location,
    required this.timestamp,
  });
}
