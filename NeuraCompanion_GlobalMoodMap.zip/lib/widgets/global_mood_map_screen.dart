import 'package:flutter/material.dart';
import '../models/mood_ping_model.dart';

class GlobalMoodMapScreen extends StatelessWidget {
  final List<MoodPing> moodPings = [
    MoodPing(emoji: '😊', location: 'USA', timestamp: DateTime.now()),
    MoodPing(emoji: '😔', location: 'Canada', timestamp: DateTime.now()),
    MoodPing(emoji: '😴', location: 'Japan', timestamp: DateTime.now()),
    MoodPing(emoji: '🔥', location: 'Brazil', timestamp: DateTime.now()),
    MoodPing(emoji: '🧘', location: 'India', timestamp: DateTime.now()),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Global Mood Map')),
      body: ListView.builder(
        itemCount: moodPings.length,
        itemBuilder: (ctx, i) {
          final mood = moodPings[i];
          return ListTile(
            leading: Text(mood.emoji, style: TextStyle(fontSize: 32)),
            title: Text(mood.location),
            subtitle: Text('Logged at ${mood.timestamp.hour}:${mood.timestamp.minute}'),
          );
        },
      ),
    );
  }
}
