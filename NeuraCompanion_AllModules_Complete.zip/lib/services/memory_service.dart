import 'package:hive/hive.dart';
import '../models/user_memory.dart';

class MemoryService {
  static const _boxName = 'user_memory';
  late Box box;

  Future<void> init() async {
    box = await Hive.openBox(_boxName);
  }

  Future<void> saveMemory(UserMemory memory) async {
    await box.put(memory.id, memory.toMap());
  }

  List<UserMemory> getAllMemories() {
    return box.values
        .map((e) => UserMemory.fromMap(Map<String, dynamic>.from(e)))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  List<UserMemory> recentByMood(String mood) {
    return getAllMemories().where((m) => m.moodTag == mood).toList();
  }
}
