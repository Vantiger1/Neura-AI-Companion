import 'dart:io';
import 'package:intl/intl.dart';
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../models/user_memory.dart';
import 'memory_service.dart';

class LifeReportService {
  final MemoryService memoryService;

  LifeReportService(this.memoryService);

  Future<String> generateLifeReport() async {
    final doc = pw.Document();
    final memories = memoryService.getAllMemories();
    final summary = _buildSummary(memories);

    doc.addPage(
      pw.MultiPage(
        build: (ctx) => [
          pw.Header(level: 0, child: pw.Text('Neura Life Report')),
          pw.Paragraph(text: summary),
          pw.SizedBox(height: 20),
          ...memories.map((m) => pw.Paragraph(text:
              '${DateFormat.yMd().add_jm().format(m.timestamp)} • Mood: ${m.moodTag} • ${m.keywords.join(", ")}')),
        ],
      ),
    );

    final dir = await getApplicationDocumentsDirectory();
    final file = File('${dir.path}/neura_life_report.pdf');
    await file.writeAsBytes(await doc.save());
    return file.path;
  }

  String _buildSummary(List<UserMemory> memories) {
    if (memories.isEmpty) return "No emotional data recorded yet.";
    final moodCount = <String, int>{};
    for (var m in memories) {
      moodCount[m.moodTag] = (moodCount[m.moodTag] ?? 0) + 1;
    }
    final sorted = moodCount.entries.toList()
      ..sort((a, b) => b.value.compareTo(a.value));
    final topMood = sorted.first.key;
    return "Over the past sessions, your most frequent mood was "$topMood". Keep reflecting!";
  }
}
