import 'package:hive/hive.dart';
import '../models/goal_model.dart';

class GoalService {
  static const _boxName = 'goals';
  late Box box;

  Future<void> init() async {
    box = await Hive.openBox(_boxName);
  }

  Future<void> saveGoal(Goal goal) async {
    await box.put(goal.id, goal.toMap());
  }

  List<Goal> getAllGoals() {
    return box.values
        .map((e) => Goal.fromMap(Map<String, dynamic>.from(e)))
        .toList();
  }

  Future<void> updateProgress(String id, int progress) async {
    final goal = Goal.fromMap(Map<String, dynamic>.from(box.get(id)));
    final updated = goal.copyWith(progress: progress);
    await box.put(id, updated.toMap());
  }

  Future<void> deleteGoal(String id) async {
    await box.delete(id);
  }
}
