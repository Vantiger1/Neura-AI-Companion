class RitualCurationService {
  final Map<String, List<String>> moodToRituals = {
    'anxious': ['Deep breathing', 'Progressive muscle relaxation', 'Write worries'],
    'happy': ['Dance break', 'Gratitude log', 'Call a friend'],
    'sad': ['Journaling', 'Walk outside', 'Listen to uplifting music'],
    'tired': ['Power nap', 'Stretching', 'Drink water'],
    'focused': ['Pomodoro session', 'Silent reading', 'Clear task list'],
  };

  /// Get ritual suggestions based on user’s mood
  List<String> getSuggestions(String mood) {
    return moodToRituals[mood.toLowerCase()] ?? ['Reflect', 'Hydrate', 'Stretch'];
  }

  /// Suggest new habits to reinforce goal types
  List<String> suggestForGoalType(String goal) {
    final keyword = goal.toLowerCase();
    if (keyword.contains('health')) {
      return ['Drink water', 'Log meals', 'Morning walk'];
    } else if (keyword.contains('focus')) {
      return ['Pomodoro timer', 'Quiet journaling', 'Brain dump'];
    } else if (keyword.contains('calm')) {
      return ['Evening wind-down', 'Gratitude log', 'Soft instrumental music'];
    } else {
      return ['Check-in ritual', 'Stretch', 'Mindful breath'];
    }
  }
}
