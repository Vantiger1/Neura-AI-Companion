import 'package:flutter/foundation.dart';

@immutable
class TherapyPrompt {
  final String id;
  final String title;
  final String instruction;
  final String method; // e.g., CBT, DBT, ACT

  const TherapyPrompt({
    required this.id,
    required this.title,
    required this.instruction,
    required this.method,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'instruction': instruction,
        'method': method,
      };

  factory TherapyPrompt.fromMap(Map<String, dynamic> map) => TherapyPrompt(
        id: map['id'],
        title: map['title'],
        instruction: map['instruction'],
        method: map['method'],
      );
}
