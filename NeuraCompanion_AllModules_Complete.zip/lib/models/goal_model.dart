import 'package:flutter/foundation.dart';

@immutable
class Goal {
  final String id;
  final String title;
  final String description;
  final int progress; // 0-100
  final DateTime createdAt;

  const Goal({
    required this.id,
    required this.title,
    required this.description,
    required this.progress,
    required this.createdAt,
  });

  Goal copyWith({int? progress}) {
    return Goal(
      id: id,
      title: title,
      description: description,
      progress: progress ?? this.progress,
      createdAt: createdAt,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'title': title,
        'description': description,
        'progress': progress,
        'createdAt': createdAt.toIso8601String(),
      };

  factory Goal.fromMap(Map<String, dynamic> map) => Goal(
        id: map['id'],
        title: map['title'],
        description: map['description'],
        progress: map['progress'],
        createdAt: DateTime.parse(map['createdAt']),
      );
}
