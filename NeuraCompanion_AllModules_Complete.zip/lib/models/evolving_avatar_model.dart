import 'package:flutter/foundation.dart';

@immutable
class EvolvingAvatar {
  final String id;
  final String name;
  final String animationPath;
  final int level;

  const EvolvingAvatar({
    required this.id,
    required this.name,
    required this.animationPath,
    required this.level,
  });

  EvolvingAvatar evolve() {
    final newLevel = (level + 1).clamp(1, 5);
    return EvolvingAvatar(
      id: id,
      name: name,
      animationPath: 'assets/avatars/$id_level$newLevel.json',
      level: newLevel,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'name': name,
        'animationPath': animationPath,
        'level': level,
      };

  factory EvolvingAvatar.fromMap(Map<String, dynamic> map) => EvolvingAvatar(
        id: map['id'],
        name: map['name'],
        animationPath: map['animationPath'],
        level: map['level'],
      );
}
