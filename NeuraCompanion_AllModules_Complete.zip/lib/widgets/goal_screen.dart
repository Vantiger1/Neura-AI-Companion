import 'package:flutter/material.dart';
import 'package:uuid/uuid.dart';
import '../services/goal_service.dart';
import '../widgets/goal_card_widget.dart';
import '../models/goal_model.dart';

class GoalScreen extends StatefulWidget {
  final GoalService service;
  GoalScreen({required this.service});

  @override
  _GoalScreenState createState() => _GoalScreenState();
}

class _GoalScreenState extends State<GoalScreen> {
  late List<Goal> goals;

  @override
  void initState() {
    super.initState();
    goals = widget.service.getAllGoals();
  }

  void _addGoal() async {
    final id = Uuid().v4();
    final newGoal = Goal(
      id: id,
      title: 'New Goal',
      description: 'Describe your goal here.',
      progress: 0,
      createdAt: DateTime.now(),
    );
    await widget.service.saveGoal(newGoal);
    setState(() => goals = widget.service.getAllGoals());
  }

  void _updateProgress(Goal goal) async {
    final newProgress = (goal.progress + 10).clamp(0, 100);
    await widget.service.updateProgress(goal.id, newProgress);
    setState(() => goals = widget.service.getAllGoals());
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('My Goals')),
      body: ListView(
        children: goals
            .map((g) => GoalCard(goal: g, onTap: () => _updateProgress(g)))
            .toList(),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: _addGoal,
        child: Icon(Icons.add),
      ),
    );
  }
}
