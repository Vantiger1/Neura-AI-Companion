import 'package:flutter/material.dart';
import '../models/therapy_path_model.dart';

class TherapyPromptCard extends StatelessWidget {
  final TherapyPrompt prompt;
  final VoidCallback onTap;

  const TherapyPromptCard({required this.prompt, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8),
      child: ListTile(
        title: Text(prompt.title),
        subtitle: Text(prompt.instruction),
        onTap: onTap,
      ),
    );
  }
}
