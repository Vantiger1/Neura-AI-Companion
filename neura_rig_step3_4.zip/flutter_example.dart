
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class NeuraView extends StatefulWidget {
  const NeuraView({super.key});
  @override
  State<NeuraView> createState() => _NeuraViewState();
}

class _NeuraViewState extends State<NeuraView> {
  late final WebViewController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset('assets/neura/index.html');
  }
  Future<void> neuraAct(Map<String, dynamic> action) async {
    final jsonStr = jsonEncode(action);
    await _ctrl.runJavaScript('NeuraRig.act($jsonStr);');
  }
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Stack(children: [
          WebViewWidget(controller: _ctrl),
          Positioned(right: 12, bottom: 12, child: Column(children: [
            ElevatedButton(onPressed: ()=> neuraAct({'blink':'auto','micro':true,'breathe':true}), child: const Text('Idle')),
            ElevatedButton(onPressed: ()=> neuraAct({'affectPlus': {'squintL': .8, 'squintR': .6, 'cheek': .4, 'nose': .6, 'browTilt': -4}}), child: const Text('Wince')),
            ElevatedButton(onPressed: ()=> neuraAct({'affect': {'browLift': 6, 'smile': .6}}), child: const Text('Smile')),
          ]))
        ])),
    );
  }
}
