(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("neuraRig not found"); return; }
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };
  function showViseme(n){ $$(".viseme").forEach(v=>v.classList.add("hidden")); (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden"); }
  function setGaze(dx,dy){ [["L",460],["R",540]].forEach(([s,cx])=>{ const i=$(`#iris_${s}`), p=$(`#pupil_${s}`); if(i&&p){ i.setAttribute("cx",cx+dx); i.setAttribute("cy",780+dy); p.setAttribute("cx",cx+dx); p.setAttribute("cy",780+dy);} }); }
  function setLids(open=1){
    let oL,oR; if(Array.isArray(open)){ oL=open[0]; oR=open[1]??open[0]; } else { oL=oR=open; }
    oL=Math.max(0,Math.min(1,oL)); oR=Math.max(0,Math.min(1,oR));
    const span=22;
    const setEye=(side,open)=>{ const u=$(`#lidU_${side}`), l=$(`#lidL_${side}`); if(!u||!l) return;
      const upperH=(1-open)*span, lowerH=(1-open)*span;
      u.setAttribute("y",780-22); u.setAttribute("height",upperH);
      l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
    };
    setEye("L",oL); setEye("R",oR);
  }
  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }
  let blinking=false, timer=null;
  function blinkOnce(d=120){ setLids(0); setTimeout(()=>setLids(1), d); }
  function autoBlink(on=true,min=2200,max=5200){ blinking=on; if(timer){clearTimeout(timer); timer=null;}
    const loop=()=>{ if(!blinking) return; blinkOnce(120); timer=setTimeout(loop, Math.random()*(max-min)+min); };
    if(on) loop(); }
  function setAffect({browLift=0,smile=0}={}){
    const bl=$("#brow_left"), br=$("#brow_right"), neutral=$("#viseme_X");
    if(bl&&br){
      bl.setAttribute("d", `M440,${740-browLift} C455,${730-browLift} 470,${730-browLift} 485,${740-browLift}`);
      br.setAttribute("d", `M515,${740-browLift} C530,${730-browLift} 545,${730-browLift} 560,${740-browLift}`);
    }
    if(neutral){ const lift=10*smile; neutral.setAttribute("d", `M455,${845-lift} Q500,${860+lift} 545,${845-lift}`); }
  }
  function setPose(p={}){
    [["#head","head"],["#neck","neck"],["#torso","torso"],
     ["#arm_L","armL"],["#forearm_L","forearmL"],
     ["#arm_R","armR"],["#forearm_R","forearmR"],
     ["#leg_L","legL"],["#shin_L","shinL"],
     ["#leg_R","legR"],["#shin_R","shinR"]]
    .forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); });
  }
  let breatheId=null;
  function breathe(on=true, amp=1.5, period=3000){
    if(breatheId) cancelAnimationFrame(breatheId), breatheId=null;
    if(!on) return;
    const torso=$("#torso"); let start=null;
    const step=(ts)=>{ if(!start) start=ts; const t=(ts-start)/period;
      const s=1+Math.sin(t*2*Math.PI)*amp/100; if(torso) torso.style.transform=`scale(${s})`;
      breatheId=requestAnimationFrame(step); };
    breatheId=requestAnimationFrame(step);
  }
  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=Math.max(0,Math.min(1,i)); }
  let microId=null;
  function microIdle(on=true){
    if(microId){ clearInterval(microId); microId=null; }
    if(!on) return;
    microId=setInterval(()=>{
      const dx=(Math.random()-.5)*4, dy=(Math.random()-.5)*3; setGaze(dx,dy);
      const head=$("#head"); if(head) setRotation(head,(Math.random()-.5)*4);
    }, 450+Math.random()*400);
  }
  function setAffectPlus({squintL=0,squintR=0,cheek=0,nose=0,browTilt=0}={}){
    const openL=Math.max(0,Math.min(1, 1-0.6*squintL));
    const openR=Math.max(0,Math.min(1, 1-0.6*squintR));
    setLids([openL,openR]);
    const neutral=$("#viseme_X");
    if(neutral){
      const lift=8*cheek;
      neutral.setAttribute("d", `M455,${845-lift} Q500,${860+lift*0.6} 545,${845-lift}`);
    }
    const bl=$("#brow_left"), br=$("#brow_right");
    if(bl&&br){
      const shift=6*nose, tilt=browTilt||0;
      bl.setAttribute("d", `M440,${740-shift+tilt*0.2} C455,${730-shift+tilt*0.2} 470,${730-shift} 485,${740-shift}`);
      br.setAttribute("d", `M515,${740-shift-tilt*0.2} C530,${730-shift-tilt*0.2} 545,${730-shift} 560,${740-shift}`);
    }
  }
  function wince(intensity=1){ intensity=Math.max(0,Math.min(1,intensity)); setAffectPlus({squintL:intensity*0.9,squintR:intensity*0.7,cheek:intensity*0.4,nose:intensity*0.8,browTilt:-6*intensity}); }
  const MAP={ A:["AA","AH","AO"], EE:["IY","IH","EH","EY","AE"], WQ:["UW","W"], O:["OW","OH","UH","UW"], FV:["F","V"], L:["L"], TH:["TH","DH"], MBP:["M","B","P"], X:["SIL","REST"] };
  function phonemeToViseme(ph){ ph=(ph||"").toUpperCase(); for(const [v,arr] of Object.entries(MAP)) if(arr.includes(ph)) return v; return "X"; }
  function scheduleVisemes(audio,timeline,lead=0){ if(!timeline||!timeline.length) return; const start=performance.now()+50; audio.currentTime=0; audio.play().catch(()=>{});
    timeline.forEach(({t,ph})=>{ const when=start+t-lead; setTimeout(()=>showViseme(phonemeToViseme(ph)), Math.max(0, when-performance.now())); }); }
  const API={ showViseme,setGaze,blinkOnce,autoBlink,setAffect,setAffectPlus,wince,setPose,breathe,setGlow,microIdle,setLids,setPupil,phonemeToViseme,scheduleVisemes,
    act(json){ try{ const c=(typeof json==='string')?JSON.parse(json):json; if(c.viseme)showViseme(c.viseme); if(c.gaze)setGaze(c.gaze[0],c.gaze[1]);
      if(c.blink)(c.blink==='auto'?autoBlink(true):blinkOnce(c.blink)); if(c.affect)setAffect(c.affect); if(c.affectPlus)setAffectPlus(c.affectPlus); if(c.wince!==undefined)wince(c.wince);
      if(c.pose)setPose(c.pose); if(c.breathe!==undefined)breathe(!!c.breathe,c.breatheAmp||1.5,c.breathePeriod||3000); if(c.glow!==undefined)setGlow(c.glow);
      if(c.micro!==undefined)microIdle(!!c.micro); if(c.lids!==undefined)setLids(c.lids); if(c.pupil!==undefined)setPupil(c.pupil); }catch(e){console.error('Neura API act error',e);} } };
  global.NeuraRig=API;
})(window);