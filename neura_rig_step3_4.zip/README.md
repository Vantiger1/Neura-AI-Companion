
# Neura Rig v1.3 — Step 3 & Step 4
Adds squint/wince and cheek-lift controls, keeps all prior APIs, and includes Flutter WebView wiring.

## New APIs
- `setAffectPlus({ squintL, squintR, cheek, nose, browTilt })`
- `wince(intensity=1)`
- `setLids([openL, openR])`

## Example
```js
NeuraRig.setAffectPlus({ squintL:.8, squintR:.6, cheek:.4, nose:.6, browTilt:-4 });
NeuraRig.wince(0.7);
NeuraRig.act({ affectPlus:{cheek:.5}, lids:[.9,.7] });
```

## Flutter
- Place `index.html` + `portrait.webp` in `assets/neura/`.
- Use `NeuraView` (see `flutter_example.dart`).
- Send actions with `neuraAct({...})`.
