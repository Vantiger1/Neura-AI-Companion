# Neura Companion

A cross-platform AI companion for mood, dreams, and wellbeing. Scaffolded by Sourcery.
