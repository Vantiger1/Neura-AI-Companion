#!/bin/bash
echo 'Setting up Neura Companion...'
