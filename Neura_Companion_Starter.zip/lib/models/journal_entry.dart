
class JournalEntry {
  final String id;
  final String content;
  final DateTime date;

  JournalEntry({required this.id, required this.content, required this.date});
}
