
class AIAvatar {
  final String name;
  final String mood;
  final String avatarAsset;

  AIAvatar({required this.name, required this.mood, required this.avatarAsset});
}
