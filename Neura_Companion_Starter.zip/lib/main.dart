
import 'package:flutter/material.dart';

void main() => runApp(NeuraCompanionApp());

class NeuraCompanionApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: DashboardScreen(),
    );
  }
}

class DashboardScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Neura Companion Dashboard')),
      body: Center(child: Text('Heart Rate: -- bpm
[Stub UI]')),
    );
  }
}
