// Notifications module stub
