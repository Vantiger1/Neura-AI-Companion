// CBT exercises stub
