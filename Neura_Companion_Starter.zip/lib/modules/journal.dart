// Journal stub
