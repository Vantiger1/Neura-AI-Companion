## Architecture Overview

- Flutter cross-platform core
- Firestore integration
- Modular feature structure
