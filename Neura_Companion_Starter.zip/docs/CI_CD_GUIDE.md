## CI/CD Guide

- GitHub Actions workflow: test, analyze, build
- Linting, deploy scripts
