## API Reference

- JournalEntry API
- DreamEntry API
- AIAvatar methods
