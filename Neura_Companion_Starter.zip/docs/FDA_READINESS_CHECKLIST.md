## FDA Readiness Checklist

- [ ] Risk analysis
- [ ] Traceability
