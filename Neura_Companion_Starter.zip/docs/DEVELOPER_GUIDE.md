## Developer Guide

How to contribute, structure, expand modules, run tests.
