#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-vantiger1/Neura-Companion-App}"
PAT="${2:?Usage: ./scripts/tools/push_to_github.sh <OWNER/REPO> <GITHUB_PAT> [branch] [tag]}"
BRANCH="${3:-main}"
TAG="${4:-v0.1.0}"

if [ ! -d .git ]; then
  git init
  git checkout -b "$BRANCH"
fi

git config user.name "Neura Auto Push"
git config user.email "neura-auto@users.noreply.github.com"

git add .
git commit -m "Neura: initial push with Pages + Release workflows" -m "Auto-tag ${TAG}" -m "Repo: ${REPO}" -m "Branch: ${BRANCH}" || true

git remote remove origin 2>/dev/null || true
git remote add origin "https://${PAT}@github.com/${REPO}.git"

git push -u origin "$BRANCH"

if ! git tag --list "${TAG}" | grep -q "^${TAG}$"; then
  git tag "${TAG}"
fi

git push origin "${TAG}"

echo "Push complete to ${REPO} (${BRANCH}). Tag pushed: ${TAG}"
