param(
  [string]$Repo = "vantiger1/Neura-Companion-App",
  [Parameter(Mandatory=$true)][string]$Pat,
  [string]$Branch = "main",
  [string]$Tag = "v0.1.0"
)
$ErrorActionPreference = "Stop"

function Run($cmd) { Write-Host ">>> $cmd" -ForegroundColor Cyan; iex $cmd }

if (-not (Test-Path ".git")) { Run "git init"; Run "git checkout -b $Branch" }

Run 'git config user.name "Neura Auto Push"'
Run 'git config user.email "neura-auto@users.noreply.github.com"'

Run "git add ."
Run 'git commit -m "Neura: initial push with Pages + Release workflows" -m "Auto-tag $Tag" -m "Repo: $Repo" -m "Branch: $Branch" -ErrorAction SilentlyContinue'

$remote = "https://$Pat@github.com/$Repo.git"
if ((git remote) -notcontains "origin") { Run "git remote add origin $remote" } else { Run "git remote set-url origin $remote" }

Run "git push -u origin $Branch"

$existing = git tag --list $Tag
if (-not $existing) { Run "git tag $Tag" }

Run "git push origin $Tag"
Write-Host "Push complete to $Repo ($Branch). Tag pushed: $Tag" -ForegroundColor Green
