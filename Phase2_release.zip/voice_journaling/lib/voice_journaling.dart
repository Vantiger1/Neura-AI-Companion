// voice_journaling package stub
void initVoiceJournaling() {}