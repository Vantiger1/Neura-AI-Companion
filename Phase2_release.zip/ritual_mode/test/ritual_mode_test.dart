// Test for ritual_mode module
