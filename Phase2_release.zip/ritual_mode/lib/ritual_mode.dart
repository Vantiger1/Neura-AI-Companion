// ritual_mode package stub
void initRitualMode() {}