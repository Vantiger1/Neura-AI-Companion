// mood_tracker package stub
void initMoodTracker() {}