// neuro_fetch package stub
void initNeuroFetch() {}