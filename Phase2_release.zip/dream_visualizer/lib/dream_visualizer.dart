// dream_visualizer package stub
void initDreamVisualizer() {}