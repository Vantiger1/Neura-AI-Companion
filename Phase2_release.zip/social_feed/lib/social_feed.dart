// social_feed package stub
void initSocialFeed() {}