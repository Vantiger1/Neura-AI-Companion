// mirror_mode package stub
void initMirrorMode() {}