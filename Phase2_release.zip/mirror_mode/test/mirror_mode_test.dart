// Test for mirror_mode module
