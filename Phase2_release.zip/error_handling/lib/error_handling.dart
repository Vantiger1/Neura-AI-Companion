// error_handling package stub
void initErrorHandling() {}