// store_front package stub
void initStoreFront() {}