// Test for store_front module
