// neuro_responsive package stub
void initNeuroResponsive() {}