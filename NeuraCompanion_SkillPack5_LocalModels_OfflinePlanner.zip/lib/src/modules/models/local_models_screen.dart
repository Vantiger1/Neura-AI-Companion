import 'package:flutter/material.dart';

import '../../../services/neura_automation_prefs.dart';
import '../../../services/local_models/neura_local_llm_service.dart';
import '../../../services/local_models/neura_local_model_settings.dart';

class LocalModelsScreen extends StatefulWidget {
  const LocalModelsScreen({super.key});

  @override
  State<LocalModelsScreen> createState() => _LocalModelsScreenState();
}

class _LocalModelsScreenState extends State<LocalModelsScreen> {
  final _baseUrl = TextEditingController();
  final _model = TextEditingController();
  final _timeout = TextEditingController();
  double _temp = 0.3;

  bool _busy = false;
  String _status = '—';

  Future<void> _load() async {
    await NeuraAutomationPrefs.I.init();
    await NeuraLocalModelSettings.I.init();

    _baseUrl.text = NeuraLocalModelSettings.I.llmBaseUrl;
    _model.text = NeuraLocalModelSettings.I.llmModel;
    _timeout.text = NeuraLocalModelSettings.I.llmTimeoutMs.toString();
    _temp = NeuraLocalModelSettings.I.llmTemperature;

    setState(() {});
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await NeuraLocalModelSettings.I.setLlmBaseUrl(_baseUrl.text);
      await NeuraLocalModelSettings.I.setLlmModel(_model.text);
      final t = int.tryParse(_timeout.text.trim()) ?? 120000;
      await NeuraLocalModelSettings.I.setLlmTimeoutMs(t);
      await NeuraLocalModelSettings.I.setLlmTemperature(_temp);
      setState(() => _status = 'Saved.');
    } catch (e) {
      setState(() => _status = 'Save failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _test() async {
    setState(() {
      _busy = true;
      _status = 'Testing local model server…';
    });
    final res = await NeuraLocalLlmService.I.health();
    setState(() {
      _busy = false;
      _status = res['ok'] == true
          ? 'OK (HTTP ${res['statusCode'] ?? '?'})'
          : 'Not reachable: ${(res['error'] ?? res['statusCode'] ?? 'unknown')}';
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _baseUrl.dispose();
    _model.dispose();
    _timeout.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prefs = NeuraAutomationPrefs.I;
    final enabled = prefs.capLocalModels || prefs.fullAccessEnabled;

    return Scaffold(
      appBar: AppBar(title: const Text('Local Models (Offline AI Core)')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Neura can talk to a local model endpoint (offline).\n\n'
            'Recommended for Windows: run a local OpenAI-compatible server on 127.0.0.1 (llama.cpp, Ollama, etc.).\n'
            'Android on-device runners can be wired later; this screen is ready for it.',
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: Icon(enabled ? Icons.check_circle : Icons.block),
              title: Text(enabled ? 'Enabled' : 'Disabled'),
              subtitle: const Text('Controlled by Privacy & Safety → Local Models.'),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _baseUrl,
            decoration: const InputDecoration(
              labelText: 'Base URL',
              helperText: 'Example: http://127.0.0.1:8080',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _model,
            decoration: const InputDecoration(
              labelText: 'Model name',
              helperText: 'Whatever your local server reports; can be any string for llama.cpp.',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _timeout,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Timeout (ms)',
              helperText: 'Default 120000',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Text('Temperature: ${_temp.toStringAsFixed(2)}'),
          Slider(
            value: _temp,
            min: 0.0,
            max: 1.0,
            divisions: 20,
            onChanged: (v) => setState(() => _temp = v),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              ElevatedButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.save),
                label: const Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _test,
                icon: const Icon(Icons.health_and_safety),
                label: const Text('Test local server'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text('Status: $_status'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Windows quickstart (llama.cpp example):\n'
            '1) Build or download llama.cpp\n'
            '2) Run: server --host 127.0.0.1 --port 8080 --model <path-to-gguf>\n'
            '3) Set Base URL to http://127.0.0.1:8080\n'
            '4) Use Neura Command Console → llm_chat',
          ),
        ],
      ),
    );
  }
}
