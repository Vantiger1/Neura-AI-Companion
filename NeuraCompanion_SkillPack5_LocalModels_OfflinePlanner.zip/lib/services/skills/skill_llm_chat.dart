import 'neura_skill.dart';
import '../local_models/neura_local_llm_service.dart';
import '../neura_policy.dart';

class SkillLlmChat implements NeuraSkill {
  @override
  String get type => 'llm_chat';

  @override
  NeuraCapability get capability => NeuraCapability.localModels;

  @override
  NeuraRisk get risk => NeuraRisk.low;

  @override
  String summarize(NeuraActionRequest req) {
    final p = (req.params['prompt'] ?? '').toString();
    final snippet = p.length > 80 ? '${p.substring(0, 80)}…' : p;
    return 'Ask local model: "$snippet"';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final prompt = (req.params['prompt'] ?? '').toString().trim();
    if (prompt.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing prompt.');
    }

    final system = (req.params['system'] as String?)?.trim();
    final history = (req.params['history'] as List?)
        ?.cast<dynamic>()
        .map((e) => (e as Map).cast<String, dynamic>())
        .map((m) => {
              'role': (m['role'] ?? 'user').toString(),
              'content': (m['content'] ?? '').toString(),
            })
        .toList()
        .cast<Map<String, String>>();

    final res = await NeuraLocalLlmService.I.chat(prompt: prompt, system: system, history: history);

    if (res['ok'] == true) {
      return NeuraActionResult(
        ok: true,
        message: 'Local model replied.',
        data: {
          'content': res['content'],
          'model': res['model'],
        },
      );
    }

    return NeuraActionResult(
      ok: false,
      message: 'Local model unavailable.',
      data: res,
    );
  }
}
