import 'neura_skill.dart';
import '../planner/neura_planner.dart';
import '../neura_policy.dart';

class SkillPlanOffline implements NeuraSkill {
  @override
  String get type => 'plan_offline';

  @override
  NeuraCapability get capability => NeuraCapability.localKnowledge;

  @override
  NeuraRisk get risk => NeuraRisk.low;

  @override
  String summarize(NeuraActionRequest req) {
    final q = (req.params['query'] ?? '').toString();
    return 'Create an offline plan for: "$q"';
  }

  @override
  Future<NeuraActionResult> run(NeuraActionRequest req) async {
    final query = (req.params['query'] ?? '').toString().trim();
    final topK = (req.params['topK'] ?? 6);
    final k = topK is int ? topK : int.tryParse(topK.toString()) ?? 6;

    if (query.isEmpty) {
      return const NeuraActionResult(ok: false, message: 'Missing query.');
    }

    final plan = await NeuraPlanner.I.plan(query, topK: k);

    return NeuraActionResult(
      ok: true,
      message: 'Plan created.',
      data: plan,
    );
  }
}
