import 'dart:convert';
import 'dart:io';

import '../neura_automation_prefs.dart';
import '../neura_policy.dart';
import 'neura_local_model_settings.dart';

/// Local LLM service that talks to a localhost OpenAI-compatible endpoint.
///
/// This keeps Neura offline: no cloud calls. If the local endpoint is not
/// running, Neura returns a helpful error and falls back to Knowledge Packs.
class NeuraLocalLlmService {
  static final NeuraLocalLlmService I = NeuraLocalLlmService._();
  NeuraLocalLlmService._();

  Future<void> init() async {
    await NeuraAutomationPrefs.I.init();
    await NeuraLocalModelSettings.I.init();
  }

  bool get enabled => NeuraAutomationPrefs.I.capLocalModels || NeuraAutomationPrefs.I.fullAccessEnabled;

  PolicyDecision policyDecision() {
    return NeuraPolicyEngine.I.decide(capability: NeuraCapability.localModels, risk: NeuraRisk.low);
  }

  Future<Map<String, dynamic>> health() async {
    await init();
    if (!enabled) {
      return {
        'ok': false,
        'error': 'Local Models capability is disabled.',
      };
    }

    final base = NeuraLocalModelSettings.I.llmBaseUrl;
    final uri = Uri.parse('$base/v1/models');
    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: NeuraLocalModelSettings.I.llmTimeoutMs);
    try {
      final req = await client.getUrl(uri);
      final res = await req.close();
      final txt = await utf8.decodeStream(res);
      return {
        'ok': res.statusCode >= 200 && res.statusCode < 300,
        'statusCode': res.statusCode,
        'body': txt,
      };
    } catch (e) {
      return {
        'ok': false,
        'error': e.toString(),
      };
    } finally {
      client.close(force: true);
    }
  }

  Future<Map<String, dynamic>> chat({
    required String prompt,
    String? system,
    List<Map<String, String>>? history,
  }) async {
    await init();

    final decision = policyDecision();
    if (!decision.allowed) {
      return {
        'ok': false,
        'error': decision.reason,
      };
    }
    if (!enabled) {
      return {
        'ok': false,
        'error': 'Local Models capability is disabled. Enable it in Privacy & Safety.',
      };
    }

    final base = NeuraLocalModelSettings.I.llmBaseUrl;
    final model = NeuraLocalModelSettings.I.llmModel;
    final temp = NeuraLocalModelSettings.I.llmTemperature;
    final timeoutMs = NeuraLocalModelSettings.I.llmTimeoutMs;

    final uri = Uri.parse('$base/v1/chat/completions');

    final messages = <Map<String, String>>[];
    messages.add({
      'role': 'system',
      'content': system ??
          'You are Neura, an offline-first assistant. '
              'Prefer the provided offline knowledge. '
              'Be concise, safe, and practical.',
    });

    if (history != null && history.isNotEmpty) {
      // keep it small; we are offline-first and must avoid huge payloads
      messages.addAll(history.take(10));
    }

    messages.add({'role': 'user', 'content': prompt});

    final payload = <String, dynamic>{
      'model': model,
      'temperature': temp,
      'messages': messages,
    };

    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: timeoutMs);

    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(payload));
      final res = await req.close();
      final txt = await utf8.decodeStream(res);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        return {
          'ok': false,
          'statusCode': res.statusCode,
          'error': 'Local model server returned HTTP ${res.statusCode}.',
          'body': txt,
          'hint':
              'Start a local OpenAI-compatible server on ${NeuraLocalModelSettings.I.llmBaseUrl}. '
                  'For llama.cpp, run: server --host 127.0.0.1 --port 8080 --model <path-to-gguf>.',
        };
      }

      final map = (jsonDecode(txt) as Map).cast<String, dynamic>();
      final choices = (map['choices'] as List?)?.cast<dynamic>() ?? const [];
      final first = choices.isEmpty ? null : (choices.first as Map).cast<String, dynamic>();
      final msg = (first?['message'] as Map?)?.cast<String, dynamic>();
      final content = (msg?['content'] ?? '').toString();

      return {
        'ok': true,
        'model': model,
        'content': content,
        'raw': map,
      };
    } catch (e) {
      return {
        'ok': false,
        'error': e.toString(),
        'hint':
            'If you are on Windows, make sure a local model server is running. '
                'If you are on Android, this feature is currently best used with a companion desktop host '
                'or a future on-device runner.',
      };
    } finally {
      client.close(force: true);
    }
  }
}
