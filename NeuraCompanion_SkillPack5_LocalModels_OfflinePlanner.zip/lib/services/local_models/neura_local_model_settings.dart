import 'package:shared_preferences/shared_preferences.dart';

/// Settings for locally hosted models.
///
/// Goal: keep Neura fully offline-capable. A "local model" can be:
/// - on-device (future)
/// - localhost server (today): llama.cpp, Ollama, etc.
class NeuraLocalModelSettings {
  static const _kLlmBaseUrl = 'neura.llm.base_url';
  static const _kLlmModel = 'neura.llm.model';
  static const _kLlmTimeoutMs = 'neura.llm.timeout_ms';
  static const _kLlmTemperature = 'neura.llm.temperature';

  static final NeuraLocalModelSettings I = NeuraLocalModelSettings._();
  NeuraLocalModelSettings._();

  SharedPreferences? _sp;

  Future<void> init() async {
    _sp ??= await SharedPreferences.getInstance();
  }

  String get llmBaseUrl => _sp?.getString(_kLlmBaseUrl) ?? 'http://127.0.0.1:8080';
  String get llmModel => _sp?.getString(_kLlmModel) ?? 'local-model';
  int get llmTimeoutMs => _sp?.getInt(_kLlmTimeoutMs) ?? 120000;
  double get llmTemperature => _sp?.getDouble(_kLlmTemperature) ?? 0.3;

  Future<void> setLlmBaseUrl(String v) async => _sp?.setString(_kLlmBaseUrl, v.trim());
  Future<void> setLlmModel(String v) async => _sp?.setString(_kLlmModel, v.trim());
  Future<void> setLlmTimeoutMs(int v) async => _sp?.setInt(_kLlmTimeoutMs, v);
  Future<void> setLlmTemperature(double v) async => _sp?.setDouble(_kLlmTemperature, v);
}
