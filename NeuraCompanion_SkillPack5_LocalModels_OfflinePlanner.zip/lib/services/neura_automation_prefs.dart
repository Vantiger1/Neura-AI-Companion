import 'package:shared_preferences/shared_preferences.dart';

/// Stores user-approved automation capabilities.
/// Default: locked down.
class NeuraAutomationPrefs {
  static const _kFullAccessEnabled = 'neura.full_access.enabled';
  static const _kFullAccessInitials = 'neura.full_access.initials';
  static const _kFullAccessAcceptedAt = 'neura.full_access.accepted_at';
  static const _kCapLaunchApps = 'neura.cap.launch_apps';
  static const _kCapFileAccess = 'neura.cap.file_access';
  static const _kCapSystemAutomation = 'neura.cap.system_automation';
  static const _kCapNetworkAccess = 'neura.cap.network_access';
  static const _kCapLocalKnowledge = 'neura.cap.local_knowledge';
  static const _kCapLocalModels = 'neura.cap.local_models';

  static final NeuraAutomationPrefs I = NeuraAutomationPrefs._();
  NeuraAutomationPrefs._();

  SharedPreferences? _sp;

  Future<void> init() async {
    _sp ??= await SharedPreferences.getInstance();
  }

  bool get fullAccessEnabled => _sp?.getBool(_kFullAccessEnabled) ?? false;

  String get fullAccessInitials => _sp?.getString(_kFullAccessInitials) ?? '';

  DateTime? get fullAccessAcceptedAt {
    final v = _sp?.getString(_kFullAccessAcceptedAt);
    if (v == null || v.isEmpty) return null;
    return DateTime.tryParse(v);
  }

  bool get capLaunchApps => _sp?.getBool(_kCapLaunchApps) ?? false;
  bool get capFileAccess => _sp?.getBool(_kCapFileAccess) ?? false;
  bool get capSystemAutomation => _sp?.getBool(_kCapSystemAutomation) ?? false;
  bool get capNetworkAccess => _sp?.getBool(_kCapNetworkAccess) ?? false;
  /// Local-only help library. Default ON.
  bool get capLocalKnowledge => _sp?.getBool(_kCapLocalKnowledge) ?? true;
  /// Local-only AI models (LLM, STT, TTS). Default ON.
  bool get capLocalModels => _sp?.getBool(_kCapLocalModels) ?? true;


  Future<void> setCapability({
    required String key,
    required bool value,
  }) async {
    await _sp?.setBool(key, value);
  }

  Future<void> setFullAccess({
    required bool enabled,
    required String initials,
  }) async {
    await _sp?.setBool(_kFullAccessEnabled, enabled);
    if (enabled) {
      await _sp?.setString(_kFullAccessInitials, initials.trim());
      await _sp?.setString(_kFullAccessAcceptedAt, DateTime.now().toIso8601String());
    } else {
      await _sp?.remove(_kFullAccessInitials);
      await _sp?.remove(_kFullAccessAcceptedAt);
    }
  }

  static String capKeyLaunchApps() => _kCapLaunchApps;
  static String capKeyFileAccess() => _kCapFileAccess;
  static String capKeySystemAutomation() => _kCapSystemAutomation;
  static String capKeyNetworkAccess() => _kCapNetworkAccess;
  static String capKeyLocalKnowledge() => _kCapLocalKnowledge;
  static String capKeyLocalModels() => _kCapLocalModels;
}
