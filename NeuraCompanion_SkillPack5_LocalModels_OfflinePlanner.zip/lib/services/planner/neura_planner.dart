import 'dart:convert';
import 'dart:io';

import '../knowledge/neura_knowledge_service.dart';
import '../local_models/neura_local_llm_service.dart';

class NeuraPlanner {
  static final NeuraPlanner I = NeuraPlanner._();
  NeuraPlanner._();

  Future<void> init() async {
    await NeuraKnowledgeService.I.init();
    await NeuraLocalLlmService.I.init();
  }

  String _platformTag() {
    if (Platform.isWindows) return 'windows';
    if (Platform.isAndroid) return 'android';
    if (Platform.isMacOS) return 'macos';
    if (Platform.isLinux) return 'linux';
    if (Platform.isIOS) return 'ios';
    return 'unknown';
  }

  Map<String, dynamic> _heuristicPlan(String query, List<Map<String, dynamic>> hits) {
    final q = query.toLowerCase();
    final steps = <String>[];
    final suggestions = <Map<String, dynamic>>[];

    steps.add('Clarify the goal in one sentence (what "done" looks like).');
    if (hits.isNotEmpty) {
      steps.add('Use the Offline Knowledge Library results below for the safest steps.');
    } else {
      steps.add('No matching offline pack entries found; proceed cautiously and stay offline.');
    }

    final p = _platformTag();
    if (p == 'windows') {
      if (q.contains('update')) {
        steps.add('Open Windows Update and check for updates.');
        suggestions.add({
          'type': 'desktop_open_settings',
          'params': {'panel': 'windows_update'},
          'capability': 'systemAutomation',
          'risk': 'medium',
          'rationale': 'User asked about updates; open the right Settings panel.',
        });
      } else if (q.contains('wifi') || q.contains('network') || q.contains('internet')) {
        steps.add('Open Windows Network settings and verify Wi‑Fi and airplane mode.');
        suggestions.add({
          'type': 'desktop_open_settings',
          'params': {'panel': 'network'},
          'capability': 'systemAutomation',
          'risk': 'medium',
          'rationale': 'Quick path to Wi‑Fi/Network settings.',
        });
      }
    }

    if (p == 'android') {
      if (q.contains('wifi') || q.contains('network') || q.contains('internet')) {
        steps.add('Open Android Wi‑Fi settings and verify connection.');
      }
      if (q.contains('storage') || q.contains('space')) {
        steps.add('Open Storage settings and clear cached files for large apps.');
      }
    }

    return {
      'platform': p,
      'query': query,
      'steps': steps,
      'suggestions': suggestions,
      'knowledgeHits': hits,
      'source': 'heuristic',
    };
  }

  Future<Map<String, dynamic>> plan(String query, {int topK = 6}) async {
    await init();

    final hits = NeuraKnowledgeService.I.search(query, topK: topK)
        .map((h) => {
              'id': h.id,
              'title': h.title,
              'tags': h.tags,
              'snippet': h.snippet,
            })
        .toList();

    // Baseline plan always available.
    final baseline = _heuristicPlan(query, hits);

    // If local LLM is available, ask it to convert baseline + hits into a cleaner plan.
    final llm = NeuraLocalLlmService.I;
    if (!llm.enabled) return baseline;

    final prompt = StringBuffer()
      ..writeln('Create an actionable plan for the user request. Output STRICT JSON only.')
      ..writeln('Rules:')
      ..writeln('- Offline-first. Do not instruct internet browsing unless capability is enabled (it is usually OFF).')
      ..writeln('- Keep steps short and practical.')
      ..writeln('- Suggestions are optional. If included, each suggestion must match one of the known action types.')
      ..writeln('- Known action types: kb_search, write_note, desktop_launch_app, desktop_open_folder, desktop_open_settings, screen_ocr, screen_context_suggest')
      ..writeln('')
      ..writeln('User query: ${jsonEncode(query)}')
      ..writeln('Platform: ${jsonEncode(baseline['platform'])}')
      ..writeln('Offline knowledge hits:')
      ..writeln(jsonEncode(hits))
      ..writeln('')
      ..writeln('Return JSON with keys: steps (string[]), suggestions (object[]), rationale (string).');

    final res = await llm.chat(
      prompt: prompt.toString(),
      system: 'You are a planner. You produce STRICT JSON only. No markdown. No extra text.',
    );

    if (res['ok'] != true) {
      return baseline..['llmError'] = res;
    }

    final txt = (res['content'] ?? '').toString().trim();
    try {
      final plan = (jsonDecode(txt) as Map).cast<String, dynamic>();
      plan['platform'] = baseline['platform'];
      plan['query'] = query;
      plan['knowledgeHits'] = hits;
      plan['source'] = 'local_llm';
      return plan;
    } catch (_) {
      return baseline
        ..['llmRaw'] = txt
        ..['source'] = 'heuristic_with_llm_raw';
    }
  }
}
