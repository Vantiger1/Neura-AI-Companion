# Skill Pack 5 — Local Model Router + Offline Planner (Knowledge-first)

This patch adds two new offline-first capabilities:

1) **plan_offline** — creates a practical step-by-step plan for a user request, **preferring Offline Knowledge Packs first**.
2) **llm_chat** — calls a **local** (localhost) OpenAI-compatible LLM endpoint for enhanced reasoning and nicer plans.

## What’s new

### New Skills (Neura Command Console)
- `plan_offline` (capability: `localKnowledge`, risk: `low`)
  - params:
    - `query` (string) — the user request
    - `topK` (int, optional) — number of KB hits to include (default 6)

- `llm_chat` (capability: `localModels`, risk: `low`)
  - params:
    - `prompt` (string) — prompt text
    - `system` (string, optional) — system prompt
    - `history` (list, optional) — chat history items: `{role, content}`

### New Settings
- **Settings → Local Models (Offline AI Core)**
  - Configure:
    - Base URL (default `http://127.0.0.1:8080`)
    - Model name (default `local-model`)
    - Timeout
    - Temperature
  - Health test button

### New Privacy Capability
- **Privacy & Safety → Full Access & Approval Gates**
  - Adds **Local Models (Offline AI Core)** toggle
  - Default: ON (still offline; no cloud calls)

## Local LLM Quickstart (Windows, llama.cpp example)

You can run a local OpenAI-compatible endpoint with llama.cpp.

1) Build/download llama.cpp
2) Start server (example):
   - `server --host 127.0.0.1 --port 8080 --model <path-to-gguf>`
3) In Neura:
   - Settings → Local Models → Base URL = `http://127.0.0.1:8080`
4) Try:
   - Neura Command Console → type `llm_chat`
   - params: `{"prompt":"Explain how to free disk space on Windows safely."}`

If the endpoint isn’t running, Neura returns a helpful error and falls back to Knowledge Packs.

## Integration notes
- No new pubspec dependencies.
- Networking uses `dart:io` `HttpClient` (localhost).
- Cloud calls remain disabled unless you explicitly add network skills and enable capability toggles.

