# Run a local llama.cpp OpenAI-compatible server (example).
# Prereq: llama.cpp built and 'server.exe' available.
# Usage: ./run_llama_windows.ps1 -ModelPath "C:\Models\my.gguf" -Port 8080

param(
  [Parameter(Mandatory=$true)][string]$ModelPath,
  [int]$Port = 8080,
  [string]$Host = "127.0.0.1"
)

$server = "server.exe"

Write-Host "Starting llama.cpp server on $Host:$Port"
Write-Host "Model: $ModelPath"
Write-Host ""
Write-Host "Command:"
Write-Host "  $server --host $Host --port $Port --model `"$ModelPath`""
Write-Host ""

& $server --host $Host --port $Port --model $ModelPath
