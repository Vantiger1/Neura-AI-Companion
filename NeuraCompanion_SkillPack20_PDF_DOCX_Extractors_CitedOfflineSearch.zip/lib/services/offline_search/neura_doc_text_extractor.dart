\
import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:txt_docx/txt_docx.dart';

// Android/iOS PDF extraction (plugin)
// Package: pdf_text_extract
// Library import per docs:
import 'package:pdf_text/pdf_text.dart' as mobile_pdf;

// Desktop PDF extraction (xpdf wrapper; requires native libs on Windows/Linux)
import 'package:pdf_text_extraction/pdf_text_extraction.dart' as desktop_pdf;

/// Best-effort text extractor for common document types.
/// Supported:
/// - .txt .md .log .json .csv : UTF-8 decode (allowMalformed)
/// - .docx : stream decode via txt_docx
/// - .pdf : Android/iOS via pdf_text; Windows/Linux via pdf_text_extraction
///
/// Large docs are truncated to [maxChars].
class NeuraDocTextExtractor {
  final int maxChars;
  final int maxPdfPages;

  const NeuraDocTextExtractor({
    this.maxChars = 220000,
    this.maxPdfPages = 30,
  });

  Future<String> extractText(File f, String relPath) async {
    final lower = relPath.toLowerCase();

    if (_isPlainText(lower)) return _readUtf8BestEffort(f);

    if (lower.endsWith('.docx')) return await _extractDocx(f);

    if (lower.endsWith('.pdf')) return await _extractPdf(f);

    return '';
  }

  bool _isPlainText(String lower) {
    return lower.endsWith('.txt') ||
        lower.endsWith('.md') ||
        lower.endsWith('.log') ||
        lower.endsWith('.json') ||
        lower.endsWith('.csv');
  }

  String _readUtf8BestEffort(File f) {
    try {
      final bytes = f.readAsBytesSync();
      final s = const Utf8Decoder(allowMalformed: true).convert(bytes);
      return _truncate(s);
    } catch (_) {
      return '';
    }
  }

  Future<String> _extractDocx(File f) async {
    try {
      final sb = StringBuffer();
      int count = 0;

      await for (final chunk in DocxDecoder().stream(f.path)) {
        if (chunk.isEmpty) continue;
        final remaining = maxChars - count;
        if (remaining <= 0) break;

        if (chunk.length <= remaining) {
          sb.write(chunk);
          count += chunk.length;
        } else {
          sb.write(chunk.substring(0, remaining));
          count += remaining;
          break;
        }
      }
      return sb.toString();
    } catch (_) {
      return '';
    }
  }

  Future<String> _extractPdf(File f) async {
    try {
      if (Platform.isAndroid || Platform.isIOS) {
        final doc = await mobile_pdf.PDFDoc.fromFile(f);
        final text = await doc.text;
        return _truncate(text);
      }

      final service = desktop_pdf.PDFToTextWrappingService();
      String extracted = '';
      await service.run((wrapper) {
        final pages = wrapper.getPagesCount(f.path);
        final endPage = pages <= 0 ? 0 : (pages < maxPdfPages ? pages : maxPdfPages);
        extracted = wrapper.extractText(f.path, startPage: 1, endPage: endPage);
      });
      return _truncate(extracted);
    } catch (_) {
      return '';
    }
  }

  String _truncate(String s) => (s.length <= maxChars) ? s : s.substring(0, maxChars);
}
