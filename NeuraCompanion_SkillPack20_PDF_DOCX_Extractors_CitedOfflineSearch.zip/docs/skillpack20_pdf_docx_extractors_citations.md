# Skill Pack 20 — PDF/DOCX Extractors + Citation-Ready Offline Search

This patch upgrades Neura’s offline search to understand **PDF** and **DOCX** files, and adds a
citation-friendly search action for trustworthy “local knowledge” answers.

## What you get
- `NeuraDocTextExtractor`
  - `.docx` text extraction via `txt_docx`
  - `.pdf` extraction:
    - Android/iOS: `pdf_text_extract` (PdfBox / PDFKit)
    - Windows/Linux: `pdf_text_extraction` (xpdf wrapper; requires native libs)
- Updated `NeuraDocIndex` (schema bump to v2) to use async extraction.
- New action: `offline_search_cited`
  - Returns `citations: [{id, path, excerpt, score}]`

## Dependencies (pubspec.yaml)
```yaml
dependencies:
  txt_docx: any
  pdf_text_extract: any
  pdf_text_extraction: any
  crypto: any
  sqlite3: any
  sqlite3_flutter_libs: any
```

Then:
- `flutter pub get`

## IMPORTANT (Windows Desktop)
`pdf_text_extraction` requires shipping native libs alongside your Windows executable:
- `pdftotext.dll`
- `TextExtraction.dll`

These must be next to your .exe or available on PATH.

## IMPORTANT (Encrypted .enc files)
The indexer intentionally skips `.enc` files (privacy-first).
Step 21 will add an “unlock encrypted sandbox” flow to index decrypted content only after user approval.

## Next
Step 21: encrypted sandbox unlock + scoped indexing session + “forget decrypted view” timer.
