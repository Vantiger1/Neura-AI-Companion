// main.sample.dart — drop-in wiring for Module 1
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neura/core/event_bus.dart';
import 'neura/core/emotion_engine.dart';
import 'neura/core/personality_engine.dart';
import 'neura/services/audio_service.dart';
import 'neura/ui/screens/emotion_debug_screen.dart';

void main() => runApp(const NeuraApp());

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});
  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        Provider(create: (_) => NeuraEventBus()),
        ProxyProvider<NeuraEventBus, EmotionEngine>(
          update: (_, bus, __) => EmotionEngine(bus),
        ),
        ProxyProvider<NeuraEventBus, PersonalityEngine>(
          update: (_, bus, __) => PersonalityEngine(bus),
        ),
        Provider(create: (_) => AudioService()),
      ],
      child: MaterialApp(
        title: 'Neura Companion',
        theme: ThemeData.dark(useMaterial3: true),
        home: const Home(),
      ),
    );
  }
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Companion')),
      body: Center(
        child: ElevatedButton(
          onPressed: (){
            Navigator.of(context).push(MaterialPageRoute(builder: (_)=>const EmotionDebugHost()));
          },
          child: const Text('Open Emotion Debug'),
        ),
      ),
    );
  }
}
