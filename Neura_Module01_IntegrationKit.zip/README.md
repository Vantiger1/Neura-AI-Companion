# Neura Companion — Module 1 Integration Kit

This kit **hooks Emotion & Personality Core + Safety Guard** into your main Flutter build with minimal changes.

## 1) Copy Files
- Copy the entire `lib/neura/` folder into your app’s `lib/`.
- Copy `assets/config/` and `assets/audio/` into your app’s `assets/`.

## 2) Merge pubspec.yaml
Append the contents of `patches/pubspec.merge.yaml` to your `pubspec.yaml` (merge dependencies and assets).

## 3) Wire Providers & Screens
- Replace your `main.dart` with `patches/main.sample.dart` **or** copy the provider wiring from it into your existing `main.dart`.
- Add a route/button to open `EmotionDebugHost()` somewhere in your UI.

## 4) Test
```bash
flutter pub get
flutter run
```
Open the Emotion Debug screen and verify that mood changes, glow, ambient audio, and personality adaptation all work.

## Troubleshooting
- If assets aren’t found, confirm `flutter clean`, then `flutter pub get`, and that the paths in `pubspec.yaml` match where you placed the files.
- On Android, make sure microphone/audio permissions are added if you later expand audio features.

