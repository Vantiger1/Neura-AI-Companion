import 'dart:async';
class NeuraEvent { final String type; final Map<String, dynamic>? payload; NeuraEvent(this.type, {this.payload}); }
class NeuraEventBus { final _c = StreamController<NeuraEvent>.broadcast(); Stream<NeuraEvent> get stream => _c.stream; void emit(NeuraEvent e)=>_c.add(e); void dispose()=>_c.close(); }
