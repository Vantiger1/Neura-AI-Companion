#!/usr/bin/env bash
set -euo pipefail
# Usage: ./copy_into_project.sh /path/to/your/flutter/app
TARGET="${1:-}"
if [ -z "$TARGET" ]; then
  echo "Usage: $0 /path/to/your/flutter/app"
  exit 1
fi
mkdir -p "$TARGET/lib/neura"
mkdir -p "$TARGET/assets/config"
mkdir -p "$TARGET/assets/audio"
cp -r "./lib/neura" "$TARGET/lib/"
cp -r "./assets/config/"* "$TARGET/assets/config/"
cp -r "./assets/audio/"* "$TARGET/assets/audio/"
echo "Copied Module 1 files into $TARGET"
