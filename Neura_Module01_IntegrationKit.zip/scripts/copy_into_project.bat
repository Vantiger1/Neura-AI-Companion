@echo off
REM Usage: copy_into_project.bat C:\path\to\your\flutter\app
set TARGET=%1
if "%TARGET%"=="" (
  echo Usage: copy_into_project.bat C:\path\to\your\flutter\app
  exit /b 1
)
if not exist "%TARGET%\lib" mkdir "%TARGET%\lib"
if not exist "%TARGET%\lib\neura" mkdir "%TARGET%\lib\neura"
if not exist "%TARGET%\assets\config" mkdir "%TARGET%\assets\config"
if not exist "%TARGET%\assets\audio" mkdir "%TARGET%\assets\audio"

xcopy /E /I /Y ".\lib\neura" "%TARGET%\lib\neura"
xcopy /E /I /Y ".\assets\config" "%TARGET%\assets\config"
xcopy /E /I /Y ".\assets\audio" "%TARGET%\assets\audio"

echo Copied Module 1 files into %TARGET%
