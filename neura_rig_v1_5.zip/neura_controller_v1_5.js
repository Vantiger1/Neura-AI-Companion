
(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("neuraRig not found"); return; }
  const clamp01=x=>Math.max(0,Math.min(1,x));

  // ---------- Core helpers ----------
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };
  const now=()=>performance.now();

  function showViseme(n){ $$(".viseme").forEach(v=>v.classList.add("hidden")); (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden"); }

  // Smoothed gaze target (head + eyes follow)
  let gazeTarget={x:0,y:0}, gazeState={x:0,y:0}, gazeOn=false, gazeRAF=null;
  function setGaze(dx,dy){ // immediate
    [["L",460],["R",540]].forEach(([s,cx])=>{
      const i=$(`#iris_${s}`), p=$(`#pupil_${s}`);
      if(i&&p){ i.setAttribute("cx",cx+dx); i.setAttribute("cy",780+dy); p.setAttribute("cx",cx+dx); p.setAttribute("cy",780+dy); }
    });
  }
  function lookAt(x,y, stiffness=0.18, damping=0.9){
    gazeTarget={x,y}; if(gazeOn) return;
    gazeOn=true;
    const step=()=>{
      const dx=gazeTarget.x-gazeState.x;
      const dy=gazeTarget.y-gazeState.y;
      gazeState.x += dx*stiffness;
      gazeState.y += dy*stiffness;
      gazeState.x *= damping; gazeState.y *= damping*1 + 0; // keep simple
      setGaze(gazeState.x, gazeState.y);
      const head=$("#head");
      if(head) setRotation(head, Math.max(-6, Math.min(6, gazeState.x*0.6)));
      if(Math.hypot(dx,dy) > 0.05) gazeRAF=requestAnimationFrame(step);
      else { gazeOn=false; }
    };
    step();
  }

  // Lids
  function setLids(open=1){
    let oL,oR; if(Array.isArray(open)){ oL=open[0]; oR=open[1]??open[0]; } else { oL=oR=open; }
    oL=clamp01(oL); oR=clamp01(oR);
    setEyeOpenness("L",oL); setEyeOpenness("R",oR);
  }
  function setEyeOpenness(side, open){
    const span=22;
    const u=$(`#lidU_${side}`), l=$(`#lidL_${side}`);
    if(!u||!l) return;
    const upperH=(1-open)*span, lowerH=(1-open)*span;
    u.setAttribute("y",780-22); u.setAttribute("height",upperH);
    l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
  }

  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }

  // Blink with optional asymmetry
  let blinking=false, timerL=null, timerR=null, blinkSkew=0;
  function setBlinkAsymmetry(skew=0){ // -1 left first, +1 right first
    blinkSkew=Math.max(-1, Math.min(1, skew));
  }
  function blinkOnce(duration=120){
    const skewMs = 40 * blinkSkew;
    setTimeout(()=> setLids([0,1]), Math.max(0, -skewMs));
    setTimeout(()=> setLids([1,0]), Math.max(0,  skewMs));
    setTimeout(()=> setLids(1), duration + Math.abs(skewMs));
  }
  function autoBlink(on=true, min=2200, max=5200){
    blinking=on;
    const loop=()=>{
      if(!blinking) return;
      blinkOnce(120);
      const t = Math.random()*(max-min)+min;
      setTimeout(loop, t);
    };
    if(on) loop();
  }

  // Affect base
  function setAffect({browLift=0, smile=0}={}){
    const bl=$("#brow_left"), br=$("#brow_right"), neutral=$("#viseme_X");
    if(bl&&br){
      bl.setAttribute("d", `M440,${740-browLift} C455,${730-browLift} 470,${730-browLift} 485,${740-browLift}`);
      br.setAttribute("d", `M515,${740-browLift} C530,${730-browLift} 545,${730-browLift} 560,${740-browLift}`);
    }
    if(neutral){
      const mid = 860 + 10*smile;
      const corner = 845 - 12*Math.max(0,smile);
      neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
      applyCheekLowerLid(Math.max(0,smile));
    }
  }

  // AffectPlus with cheek/lids/brows
  function setAffectPlus({squintL=0, squintR=0, cheek=0, nose=0, browTilt=0}={}){
    const openL = clamp01(1 - 0.6*squintL);
    const openR = clamp01(1 - 0.6*squintR);
    setLids([openL, openR]);
    const neutral=$("#viseme_X");
    if(neutral){
      const cornerLift = 12*cheek;
      const mid = 860 + 6*cheek;
      const cornerY = 845 - cornerLift;
      neutral.setAttribute("d", `M455,${cornerY} Q500,${mid} 545,${cornerY}`);
      applyCheekLowerLid(cheek);
    }
    const bl=$("#brow_left"), br=$("#brow_right");
    if(bl&&br){
      const shift = 6*nose, tilt = browTilt||0;
      bl.setAttribute("d", `M440,${740-shift+tilt*0.2} C455,${730-shift+tilt*0.2} 470,${730-shift} 485,${740-shift}`);
      br.setAttribute("d", `M515,${740-shift-tilt*0.2} C530,${730-shift-tilt*0.2} 545,${730-shift} 560,${740-shift}`);
    }
  }
  function applyCheekLowerLid(cheek){
    cheek=clamp01(cheek);
    const maxRaise=6, raise=maxRaise*cheek;
    ["L","R"].forEach(side=>{
      const l=$(`#lidL_${side}`);
      if(l){
        const h=parseFloat(l.getAttribute("height")||"0");
        const nh=h + raise/2;
        l.setAttribute("height", nh);
        l.setAttribute("y", 780+22-nh);
      }
    });
  }

  // Micro-tween smile with overshoot/settle
  let smileTweenId=null;
  function smileSpring(intensity=1, {overshoot=0.18, duration=260, settle=160}={}){
    intensity=clamp01(intensity);
    const startT=now();
    const neutral=$("#viseme_X");
    if(smileTweenId) cancelAnimationFrame(smileTweenId);
    function easeOutBack(t){ const c1=1.70158, c3=c1+1; return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2); }
    function frame(){
      const t=(now()-startT)/duration;
      if(!neutral){ return; }
      if(t<1){
        const s=easeOutBack(t)*(1+overshoot)-overshoot; // overshoot > 1 then ease back
        const corner = 845 - 12*intensity*s;
        const mid = 860 + 8*intensity*(1-s*0.5);
        neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
        applyCheekLowerLid(intensity*s*0.9);
        smileTweenId=requestAnimationFrame(frame);
      } else {
        // settle
        const settleStart=now();
        function settleFrame(){
          const u=(now()-settleStart)/settle;
          const s=1 - Math.min(1,u)*0.15; // decay 15%
          const corner = 845 - 12*intensity*s;
          const mid = 860 + 8*intensity*(1-s*0.5);
          neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
          applyCheekLowerLid(intensity*s*0.9);
          if(u<1) requestAnimationFrame(settleFrame);
        }
        requestAnimationFrame(settleFrame);
      }
    }
    requestAnimationFrame(frame);
  }

  // Breath with variability
  let breatheId=null, breathPeriod=3000, breathAmp=1.5;
  function breathe(on=true, amp=1.5, period=3000, variability=0.08){
    breathAmp=amp; breathPeriod=period;
    if(breatheId) cancelAnimationFrame(breatheId), breatheId=null;
    if(!on) return;
    const torso=$("#torso"); let start=null;
    function step(ts){
      if(!start) start=ts;
      const phase=(ts-start)/breathPeriod;
      const s=1+Math.sin(phase*2*Math.PI)*breathAmp/100;
      if(torso) torso.style.transform=`scale(${s})`;
      // lightly vary period
      if(Math.floor(phase)%2===0 && Math.random()<0.005){
        breathPeriod = period*(1 + (Math.random()*2-1)*variability);
      }
      breatheId=requestAnimationFrame(step);
    }
    breatheId=requestAnimationFrame(step);
  }

  // Audio-reactive hook: call from outside with 0..1 amplitude
  function audioReact(level){
    level=clamp01(level);
    // map to pupil dilation and tiny head bob
    setPupil(6 + 3*level);
    const head=$("#head"); if(head) setRotation(head, (level-0.5)*2);
  }

  function setPose(p={}){
    [["#head","head"],["#neck","neck"],["#torso","torso"],
     ["#arm_L","armL"],["#forearm_L","forearmL"],
     ["#arm_R","armR"],["#forearm_R","forearmR"],
     ["#leg_L","legL"],["#shin_L","shinL"],
     ["#leg_R","legR"],["#shin_R","shinR"]]
    .forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); });
  }

  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=clamp01(i); }
  let microId=null;
  function microIdle(on=true){
    if(microId){ clearInterval(microId); microId=null; }
    if(!on) return;
    microId=setInterval(()=>{
      const dx=(Math.random()-.5)*4, dy=(Math.random()-.5)*3; setGaze(dx,dy);
      const head=$("#head"); if(head) setRotation(head,(Math.random()-.5)*4);
    }, 450+Math.random()*400);
  }

  // phoneme→viseme and scheduler (unchanged)
  const MAP={ A:["AA","AH","AO"], EE:["IY","IH","EH","EY","AE"], WQ:["UW","W"], O:["OW","OH","UH","UW"], FV:["F","V"], L:["L"], TH:["TH","DH"], MBP:["M","B","P"], X:["SIL","REST"] };
  function phonemeToViseme(ph){ ph=(ph||"").toUpperCase(); for(const [v,arr] of Object.entries(MAP)) if(arr.includes(ph)) return v; return "X"; }
  function scheduleVisemes(audio,timeline,lead=0){ if(!timeline||!timeline.length) return; const start=performance.now()+50; audio.currentTime=0; audio.play().catch(()=>{});
    timeline.forEach(({t,ph})=>{ const when=start+t-lead; setTimeout(()=>showViseme(phonemeToViseme(ph)), Math.max(0, when-performance.now())); }); }

  // Public API
  const API = {
    showViseme, setGaze, lookAt, blinkOnce, autoBlink, setBlinkAsymmetry,
    setAffect, setAffectPlus, smileSpring,
    setPose, breathe, setGlow, microIdle, setLids, setPupil,
    phonemeToViseme, scheduleVisemes, audioReact,
    act(json){
      try{
        const c=(typeof json==='string')?JSON.parse(json):json;
        if(c.viseme) showViseme(c.viseme);
        if(c.gaze) setGaze(c.gaze[0], c.gaze[1]);
        if(c.lookAt) lookAt(c.lookAt[0], c.lookAt[1], c.lookK?.[0]??0.18, c.lookK?.[1]??0.9);
        if(c.blink) (c.blink==='auto'? autoBlink(true): blinkOnce(c.blink));
        if(c.blinkSkew!==undefined) setBlinkAsymmetry(c.blinkSkew);
        if(c.affect) setAffect(c.affect);
        if(c.affectPlus) setAffectPlus(c.affectPlus);
        if(c.smileSpring!==undefined) smileSpring(c.smileSpring, c.springOpts||{});
        if(c.pose) setPose(c.pose);
        if(c.breathe!==undefined) breathe(!!c.breathe, c.breatheAmp||1.5, c.breathePeriod||3000, c.breatheVar||0.08);
        if(c.glow!==undefined) setGlow(c.glow);
        if(c.micro!==undefined) microIdle(!!c.micro);
        if(c.lids!==undefined) setLids(c.lids);
        if(c.pupil!==undefined) setPupil(c.pupil);
        if(c.audioLevel!==undefined) audioReact(c.audioLevel);
      } catch(e){ console.error("Neura API act error", e); }
    }
  };
  global.NeuraRig=API;
})(window);
