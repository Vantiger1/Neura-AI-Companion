
# Neura Rig v1.5 — Realism Upgrades
New: micro-tween **Smile Spring** with overshoot/settle, smooth **lookAt** target tracking, **blink asymmetry**, audio-reactive hooks, and variable breathing.

## API Additions
- `smileSpring(intensity, {overshoot=.18, duration=260, settle=160})`
- `lookAt(dx, dy, stiffness=.18, damping=.9)`
- `setBlinkAsymmetry(skew)` // -1 left-first, +1 right-first
- `audioReact(level)` // 0..1 → pupil/head
- `breathe(on, amp, period, variability)` // period drifts slightly

### Examples
```js
NeuraRig.smileSpring(.9, {overshoot:.2});
NeuraRig.lookAt(6,-2);              // smooth gaze + tiny head yaw
NeuraRig.setBlinkAsymmetry(0.5);    // right eye leads
NeuraRig.act({ audioLevel: 0.8 });  // quick pupil/head pulse
```

All previous controls (visemes, phonemes, pose, affectPlus) still work.
