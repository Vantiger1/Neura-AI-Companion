import 'package:flutter/material.dart';

class DreamShowScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: compile and play monthly dream show animation
    return Scaffold(
      appBar: AppBar(title: Text('Dream Show')),
      body: Center(child: Text('Monthly Dream Show')),
    );
  }
}
