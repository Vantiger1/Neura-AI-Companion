class TranscriptionService {
  /// Transcribes audio file at [path] and returns transcript text.
  Future<String> transcribe(String audioPath) async {
    // TODO: call speech-to-text API
    return '';
  }
}
