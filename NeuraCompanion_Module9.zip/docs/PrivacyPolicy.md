# Privacy Policy

_Last updated: YYYY-MM-DD_

**Introduction**

We (“Neura Companion”, “we”, “our”) respect your privacy and are committed to protecting it through our compliance with this policy.

**Information We Collect**

- Personal Data: email address, display name, avatar.
- Usage Data: app usage, features accessed.
- Health & Dream Data: optional voice recordings and dream transcripts.

**How We Use Your Data**

- Provide and improve the app features.
- Sync and backup data across devices.
- Analytics and aggregated insights.

**Data Sharing**

We do not share personal data with third parties except:
- With your consent.
- For legal compliance.
- To service providers under NDA.

**Your Choices**

- Access, update, or delete your data via Profile.
- Opt-out of analytics (in settings).
- Revoke consent at any time.

**Contact Us**

If you have questions, contact privacy@neura.com.
