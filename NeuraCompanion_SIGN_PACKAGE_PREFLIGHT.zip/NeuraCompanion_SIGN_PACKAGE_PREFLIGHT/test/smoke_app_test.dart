import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:neuro_companion/src/app.dart';

void main() {
  testWidgets('App boots and bottom navigation routes exist', (tester) async {
    await tester.pumpWidget(const NeuroCompanionApp());
    await tester.pumpAndSettle();

    // Bottom nav labels exist.
    expect(find.text('Home'), findsOneWidget);
    expect(find.text('Journal'), findsOneWidget);
    expect(find.text('Check-In'), findsOneWidget);
    expect(find.text('Goals'), findsOneWidget);
    expect(find.text('Meditation'), findsOneWidget);
    expect(find.text('Neura'), findsOneWidget);
    expect(find.text('Settings'), findsOneWidget);

    // Tap through each tab to ensure routing doesn't throw.
    await tester.tap(find.text('Journal'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Check-In'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Goals'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Meditation'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Neura'));
    await tester.pumpAndSettle();

    await tester.tap(find.text('Settings'));
    await tester.pumpAndSettle();

    // Return home.
    await tester.tap(find.text('Home'));
    await tester.pumpAndSettle();

    // App should still be alive.
    expect(find.byType(MaterialApp), findsOneWidget);
  });
}
