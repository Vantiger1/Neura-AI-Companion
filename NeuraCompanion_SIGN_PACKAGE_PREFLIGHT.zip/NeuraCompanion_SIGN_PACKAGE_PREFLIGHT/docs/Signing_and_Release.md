# Neura Companion — Signing + Packaging + Release

This patch adds:
- Android **signed AAB/APK** support in CI
- Windows **MSIX** packaging support
- Preflight gates: `flutter analyze` + `flutter test` (includes a smoke UI test)

## 1) Android Play Store (upload keystore)

### Create an upload keystore (local)
**Windows**
- Run: `scripts\generate_android_upload_keystore.bat`

**macOS/Linux**
- Run: `./scripts/generate_android_upload_keystore.sh`

This generates:
- `android/upload-keystore.jks`

### Create `android/key.properties` (local builds only)
Create `android/key.properties` (DO NOT COMMIT):

```
storePassword=YOUR_STORE_PASSWORD
keyPassword=YOUR_KEY_PASSWORD
keyAlias=YOUR_ALIAS
storeFile=upload-keystore.jks
```

### GitHub Actions secrets (for signed CI builds)
Add these repository secrets:

- `ANDROID_KEYSTORE_BASE64`  (base64 of `android/upload-keystore.jks`)
- `ANDROID_KEYSTORE_PASSWORD`
- `ANDROID_KEY_ALIAS`
- `ANDROID_KEY_PASSWORD`

Base64 helpers:

**macOS/Linux**
```
base64 -w 0 android/upload-keystore.jks
```

**PowerShell**
```
[Convert]::ToBase64String([IO.File]::ReadAllBytes("android\upload-keystore.jks"))
```

## 2) Windows MSIX

This patch uses the Dart `msix` tool.

Local (Windows):
- Run: `scripts\build_msix.bat`

### Optional: signed MSIX in CI
If you want a signed MSIX in GitHub Actions, add these secrets:

- `MSIX_CERT_BASE64` (base64 of a `.pfx` certificate)
- `MSIX_CERT_PASSWORD`

If you do not set them, CI will still generate an **unsigned** MSIX.

## 3) Preflight gate
Local:
- `scripts\preflight.bat`
- `./scripts/preflight.sh`

CI:
- Runs `flutter analyze` + `flutter test` before building.

## 4) Release workflow
Push a tag like `v1.0.1`:
- CI builds signed Android AAB/APK (if secrets exist)
- Builds Windows MSIX (signed if secrets exist)
- Attaches artifacts to a GitHub Release
