@echo off
setlocal

REM Creates an Android upload keystore for Play Console signing.
REM Output: android\upload-keystore.jks

cd /d "%~dp0\.."

where keytool >nul 2>&1
if errorlevel 1 (
  echo keytool not found. Install a JDK and retry.
  exit /b 1
)

if not exist android mkdir android

set KEY_ALIAS=upload
set /p KEY_ALIAS=Key alias (default: upload): 
if "%KEY_ALIAS%"=="" set KEY_ALIAS=upload

echo Generating android\upload-keystore.jks (validity 10000 days, RSA 2048)
keytool -genkeypair -v ^
  -keystore android\upload-keystore.jks ^
  -alias "%KEY_ALIAS%" ^
  -keyalg RSA -keysize 2048 -validity 10000

echo.
echo Done.
echo Next: create android\key.properties and DO NOT COMMIT it.
endlocal
