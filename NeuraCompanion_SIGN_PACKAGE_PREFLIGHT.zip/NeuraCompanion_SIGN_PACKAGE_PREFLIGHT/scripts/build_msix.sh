#!/usr/bin/env bash
set -euo pipefail

# MSIX packaging only works on Windows.
case "$(uname -s | tr '[:upper:]' '[:lower:]')" in
  mingw*|msys*|cygwin*) ;;
  *) echo "MSIX packaging requires Windows. Run scripts/build_msix.bat on Windows." >&2; exit 1 ;;
esac

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

flutter pub get

if [[ -n "${MSIX_CERT_PATH:-}" ]]; then
  if [[ -z "${MSIX_CERT_PASSWORD:-}" ]]; then
    echo "MSIX_CERT_PASSWORD is required when MSIX_CERT_PATH is set." >&2
    exit 1
  fi
  dart run msix:create --certificate-path "$MSIX_CERT_PATH" --certificate-password "$MSIX_CERT_PASSWORD"
else
  dart run msix:create
fi

echo "Done."
