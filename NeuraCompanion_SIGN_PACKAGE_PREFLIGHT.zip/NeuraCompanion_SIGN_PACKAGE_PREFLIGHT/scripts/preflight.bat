@echo off
setlocal enabledelayedexpansion

REM Preflight gate: repair scaffolds -> deps -> analyze -> tests -> (optional) builds.
REM Usage:
REM   scripts\preflight.bat
REM   scripts\preflight.bat build

cd /d "%~dp0\.."

echo == Preflight: repair platforms ==
call scripts\repair_platforms.bat || exit /b 1

echo == Preflight: pub get ==
flutter pub get || exit /b 1

echo == Preflight: analyze ==
flutter analyze || exit /b 1

echo == Preflight: test ==
flutter test || exit /b 1

if "%~1"=="build" (
  echo == Preflight: build apk (release) ==
  flutter build apk --release || exit /b 1

  echo == Preflight: build web (release) ==
  flutter build web --release || exit /b 1
)

echo == Preflight: OK ==
endlocal
