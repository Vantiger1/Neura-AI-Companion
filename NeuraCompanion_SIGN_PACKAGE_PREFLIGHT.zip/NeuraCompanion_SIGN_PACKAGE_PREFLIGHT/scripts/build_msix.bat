@echo off
setlocal

cd /d "%~dp0\.."

echo Pub get...
flutter pub get || exit /b 1

echo Building MSIX...
if not "%MSIX_CERT_PATH%"=="" (
  if "%MSIX_CERT_PASSWORD%"=="" (
    echo MSIX_CERT_PASSWORD is required when MSIX_CERT_PATH is set.
    exit /b 1
  )
  dart run msix:create --certificate-path "%MSIX_CERT_PATH%" --certificate-password "%MSIX_CERT_PASSWORD%" || exit /b 1
) else (
  dart run msix:create || exit /b 1
)

echo Done. Check build\windows\x64\runner\Release and the generated .msix in build\windows.
endlocal
