@echo off
setlocal

REM CI helper: writes android\upload-keystore.jks and android\key.properties from env vars.

if "%ANDROID_KEYSTORE_BASE64%"=="" (
  echo ANDROID_KEYSTORE_BASE64 not set. Skipping Android signing setup.
  exit /b 0
)

cd /d "%~dp0\.."
if not exist android mkdir android

REM Decode base64 keystore to file using PowerShell
powershell -NoProfile -Command ^
  "$b=[System.Convert]::FromBase64String($env:ANDROID_KEYSTORE_BASE64); [System.IO.File]::WriteAllBytes('android\upload-keystore.jks',$b)" || exit /b 1

> android\key.properties (
  echo storePassword=%ANDROID_KEYSTORE_PASSWORD%
  echo keyPassword=%ANDROID_KEY_PASSWORD%
  echo keyAlias=%ANDROID_KEY_ALIAS%
  echo storeFile=upload-keystore.jks
)

echo Android signing files created.
endlocal
