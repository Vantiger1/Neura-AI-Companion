#!/usr/bin/env bash
set -euo pipefail

# Preflight gate: repair scaffolds -> deps -> analyze -> tests -> (optional) builds.
# Usage:
#   ./scripts/preflight.sh
#   ./scripts/preflight.sh build

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

chmod +x scripts/repair_platforms.sh

echo "== Preflight: repair platforms =="
./scripts/repair_platforms.sh

echo "== Preflight: pub get =="
flutter pub get

echo "== Preflight: analyze =="
flutter analyze

echo "== Preflight: test =="
flutter test

if [[ "${1:-}" == "build" ]]; then
  echo "== Preflight: build apk (release) =="
  flutter build apk --release

  echo "== Preflight: build web (release) =="
  flutter build web --release
fi

echo "== Preflight: OK =="
