#!/usr/bin/env bash
set -euo pipefail

# Creates an Android upload keystore for Play Console signing.
# Output: android/upload-keystore.jks
# You will be prompted for passwords.

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if ! command -v keytool >/dev/null 2>&1; then
  echo "keytool not found. Install a JDK and retry." >&2
  exit 1
fi

mkdir -p android

read -rp "Key alias (default: upload): " KEY_ALIAS
KEY_ALIAS="${KEY_ALIAS:-upload}"

echo "Generating android/upload-keystore.jks (validity 10000 days, RSA 2048)"
keytool -genkeypair -v   -keystore android/upload-keystore.jks   -alias "$KEY_ALIAS"   -keyalg RSA -keysize 2048 -validity 10000

echo ""
echo "Done."
echo "Next: create android/key.properties and DO NOT COMMIT it."
