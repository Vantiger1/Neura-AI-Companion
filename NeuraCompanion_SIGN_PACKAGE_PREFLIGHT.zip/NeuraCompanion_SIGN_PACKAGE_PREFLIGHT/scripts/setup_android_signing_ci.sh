#!/usr/bin/env bash
set -euo pipefail

# CI helper: writes android/upload-keystore.jks and android/key.properties from env vars.
# Required env:
#   ANDROID_KEYSTORE_BASE64
#   ANDROID_KEYSTORE_PASSWORD
#   ANDROID_KEY_ALIAS
#   ANDROID_KEY_PASSWORD

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT_DIR"

if [[ -z "${ANDROID_KEYSTORE_BASE64:-}" ]]; then
  echo "ANDROID_KEYSTORE_BASE64 not set. Skipping Android signing setup."
  exit 0
fi

mkdir -p android

echo "$ANDROID_KEYSTORE_BASE64" | base64 --decode > android/upload-keystore.jks

cat > android/key.properties <<EOF
storePassword=${ANDROID_KEYSTORE_PASSWORD}
keyPassword=${ANDROID_KEY_PASSWORD}
keyAlias=${ANDROID_KEY_ALIAS}
storeFile=upload-keystore.jks
EOF

echo "Android signing files created (android/upload-keystore.jks, android/key.properties)"
