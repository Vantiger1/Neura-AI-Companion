# Neura Sponsor System — Testing Guide

This branch (`neura-sponsor-system`) is a safe staging area to verify the full sponsor + VR + voice system.

## 1) GitHub Pages Preview
1. Push this branch.
2. Repo → Settings → Pages → Source: `neura-sponsor-system` / `/docs/`.
3. Open the Pages URL. You should see Neura greeting, sponsor grid, and controls.

## 2) Voice & Silent Mode
- Click the “Hear Neura Thank You” button on the live site.
- Toggle **Silent Mode** on/off — voice mutes but visuals remain.

## 3) Instant Sponsor Refresh (GUI)
1. Open `neura-sponsors-gui/index.html` locally.
2. Enter PAT (scopes: `read:user`, `read:org`, `repo`).
3. Enter repo `owner/name` and your branch (default: `neura-sponsor-system`).
4. Click **Refresh Sponsors Now** — confirm sponsors appear on the live site after push.

## 4) VR Demo
- Open `/docs/vr.html` on Pages.
- Confirm:
  - Penthouse autoloads.
  - Clock shows local time; breathing + time-of-day glow.
  - Neura greets based on local time.
  - Room menu lists `penthouse`, `joy-lounge`, `reflection-bay`, `mood-den` from `assets/data/rooms.json`.
- Drop your Unity WebGL build into `docs/assets/vr/penthouse/` etc. and reload.

## 5) Analytics
- Interactions (buttons, voice play, VR visits) are logged to `localStorage` and console (privacy-friendly).

## 6) Merge
- When satisfied, open a PR into `main`. Switch Pages back to `main` after merge.
