# Neura Companion — Sponsor & VR Preview (Branch: neura-sponsor-system)

Help power a kinder, smarter AI companion for everyone. Your support funds
open-source development, real-time emotion AI, accessibility, and community builds.

**Live Preview:** After pushing this branch and enabling GitHub Pages for `/docs/`, visit your Pages URL.

## 🌟 Sponsor Neura Companion

<!-- sponsors -->
<!-- sponsors -->

### 🎤 Hear Neura Thank You
GitHub READMEs can’t run voice scripts, so click here to hear Neura read sponsor names on the live site:
- **Live site:** `https://<your-username>.github.io/<your-repo>/`

### 🎯 Why sponsor?
- Accelerate features: viseme sync, mood engine, VR/AR, offline privacy mode  
- Ensure long-term maintenance, docs, and polished releases (Android/Windows/Web)  
- Keep a generous free tier for students, researchers, and creators

### 💎 Tiers & Perks
- **Bronze** ($1–$9): Backer credit, early dev logs  
- **Silver** ($10–$49): Pre-release builds, priority issue tags  
- **Gold** ($50+): Roadmap voting, sponsor-only channel, credit in release notes  
- **Premium** (Custom): Private support window, feature planning, logo placement

---

## VR Demo
- **VR:** `docs/vr.html` (Penthouse autoload; menu switches rooms)  
- Drop Unity WebGL builds into: `docs/assets/vr/<room-name>/`

## GUI — Instant Sponsor Refresh
- Open: `neura-sponsors-gui/index.html`  
- Paste PAT, click **Refresh Sponsors Now** → updates JSON + pushes to branch

## Testing
See `TESTING_GUIDE.md` for step-by-step checks before merging to `main`.
