// scripts/fetch_sponsors.mjs
// Usage: node scripts/fetch_sponsors.mjs owner/repo
import fs from 'fs';
import path from 'path';

const repo = process.argv[2];
if (!repo) {
  console.error("Missing repo (owner/name).");
  process.exit(1);
}
const [owner] = repo.split('/');

const query = `
query($login:String!) {
  user(login:$login) {
    sponsorsListing {
      tiers(first: 50) {
        nodes {
          monthlyPriceInCents
        }
      }
    }
    sponsorshipsAsMaintainer(first: 100, includePrivate:true) {
      nodes {
        privacyLevel
        tier {
          monthlyPriceInCents
        }
        sponsorEntity {
          ... on User {
            login
            name
            avatarUrl
            url
            bio
          }
          ... on Organization {
            login
            name
            avatarUrl
            url
            description
          }
        }
      }
    }
  }
}
`;

async function fetchGraphQL(query, variables) {
  const res = await fetch('https://api.github.com/graphql', {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${process.env.GH_TOKEN}`,
      'Content-Type': 'application/json',
      'User-Agent': 'neura-sponsor-system'
    },
    body: JSON.stringify({ query, variables })
  });
  if (!res.ok) {
    const t = await res.text();
    throw new Error(`GraphQL error: ${res.status} ${t}`);
  }
  return res.json();
}

function tierNameFromCents(cents) {
  const usd = Math.round(cents)/100;
  if (usd >= 50) return 'Gold';
  if (usd >= 10) return 'Silver';
  if (usd >= 1) return 'Bronze';
  return 'Supporter';
}

function avatarSizeFromTier(tier) {
  switch (tier) {
    case 'Gold': return 100;
    case 'Silver': return 80;
    case 'Bronze': return 60;
    default: return 60;
  }
}

(async () => {
  try {
    const data = await fetchGraphQL(query, { login: owner });
    const nodes = data?.data?.user?.sponsorshipsAsMaintainer?.nodes || [];
    const sponsors = nodes.map(n => {
      const cents = n?.tier?.monthlyPriceInCents ?? 0;
      const tier = tierNameFromCents(cents);
      const ent = n?.sponsorEntity || {};
      const name = ent.name || ent.login || "Anonymous";
      const login = ent.login || "anon";
      const url = ent.url || "";
      const bio = ent.bio || ent.description || "";
      const avatarUrl = ent.avatarUrl || "";
      return {
        name, login, url, bio, avatarUrl,
        monthlyAmount: Math.round(cents)/100,
        tier,
        avatarSize: avatarSizeFromTier(tier)
      };
    });

    // Sort Gold -> Silver -> Bronze -> Supporter
    const order = { Gold: 0, Silver: 1, Bronze: 2, Supporter: 3 };
    sponsors.sort((a,b) => (order[a.tier]-order[b.tier]) || (b.monthlyAmount - a.monthlyAmount));

    const outDir = path.join(process.cwd(), 'docs', 'assets', 'data');
    fs.mkdirSync(outDir, { recursive: true });
    fs.writeFileSync(path.join(outDir, 'sponsors.json'), JSON.stringify({ updatedAt: new Date().toISOString(), sponsors }, null, 2));
    console.log(`Wrote ${sponsors.length} sponsors to docs/assets/data/sponsors.json`);
  } catch (e) {
    console.error(e);
    process.exit(1);
  }
})();
