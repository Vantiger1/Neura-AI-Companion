// docs/assets/js/analytics.js
(function () {
  const key = 'neura_analytics';
  const now = Date.now();
  const data = JSON.parse(localStorage.getItem(key) || '{"events":[]}');
  function log(event, meta={}) {
    data.events.push({ t: now, event, meta });
    localStorage.setItem(key, JSON.stringify(data));
    console.debug('[NeuraAnalytics]', event, meta);
  }
  window.NeuraAnalytics = { log };
})();
