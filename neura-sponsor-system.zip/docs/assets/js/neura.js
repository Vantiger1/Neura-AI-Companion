// docs/assets/js/neura.js
const Neura = (() => {
  let silent = false;
  let cinematic = false;
  let sponsors = [];
  const tiersOrder = { Premium: 0, Gold: 1, Silver: 2, Bronze: 3, Supporter: 4 };

  function byTimeOfDay() {
    const h = new Date().getHours();
    if (h >= 5 && h < 12) return 'morning';
    if (h >= 12 && h < 18) return 'afternoon';
    if (h >= 18 && h < 22) return 'evening';
    return 'night';
  }

  function clockColorFor(timeOfDay) {
    switch (timeOfDay) {
      case 'morning': return { color: '#FFA93A', glow: 'rgba(255,169,58,0.6)' };
      case 'afternoon': return { color: '#FFFFFF', glow: 'rgba(255,255,255,0.6)' };
      case 'evening': return { color: '#FF7B6B', glow: 'rgba(255,123,107,0.6)' };
      case 'night': return { color: '#3A66FF', glow: 'rgba(58,102,255,0.6)' };
    }
  }

  function setSilentMode(v) { silent = !!v; }
  function getSilentMode() { return silent; }
  function setCinematic(v) { cinematic = !!v; document.documentElement.dataset.cinematic = cinematic ? '1' : '0'; }
  function getCinematic() { return cinematic; }

  async function speak(text) {
    if (silent) return;
    if (!('speechSynthesis' in window)) return;
    const u = new SpeechSynthesisUtterance(text);
    u.rate = 1.02; u.pitch = 1.05; u.volume = 1;
    speechSynthesis.cancel();
    speechSynthesis.speak(u);
  }

  function tierLine(tier) {
    switch (tier) {
      case 'Gold': return 'Our Gold champions:';
      case 'Silver': return 'Shoutout to our Silver stars:';
      case 'Bronze': return 'And big thanks to our Bronze buddies:';
      case 'Premium': return 'Premium legends in the house:';
      default: return 'Supporters keeping the lights on:';
    }
  }

  async function loadSponsors() {
    try {
      const res = await fetch('assets/data/sponsors.json', { cache: 'no-store' });
      const json = await res.json();
      sponsors = (json.sponsors || []).slice().sort((a,b) => {
        const d = (tiersOrder[a.tier] ?? 99) - (tiersOrder[b.tier] ?? 99);
        if (d) return d;
        return (b.monthlyAmount||0) - (a.monthlyAmount||0);
      });
      renderSponsors();
    } catch(e) { console.warn('No sponsors yet'); }
  }

  function renderSponsors() {
    const grid = document.querySelector('#sponsor-grid');
    if (!grid) return;
    grid.innerHTML = '';
    if (!sponsors.length) {
      grid.innerHTML = `<div class="empty">No sponsors yet — be the first!</div>`;
      return;
    }
    const frag = document.createDocumentFragment();
    for (const s of sponsors) {
      const div = document.createElement('div');
      div.className = `card tier-${(s.tier||'supporter').toLowerCase()}`;
      div.innerHTML = `
        <a href="${s.url||'#'}" target="_blank" rel="noopener">
          <img src="${s.avatarUrl}" width="${s.avatarSize||60}" height="${s.avatarSize||60}" alt="${s.login}" />
          <div class="meta">
            <div class="name">${s.name || s.login}</div>
            <div class="sub">@${s.login} • $${s.monthlyAmount}/mo</div>
            <div class="tier">${s.tier||'Supporter'}</div>
          </div>
        </a>`;
      frag.appendChild(div);
    }
    grid.appendChild(frag);
  }

  async function readSponsorsAloud() {
    if (!sponsors.length) {
      await speak("No sponsors yet — your logo could be here.");
      return;
    }
    const counts = sponsors.reduce((acc,s)=>{ acc[s.tier]= (acc[s.tier]||0)+1; return acc; },{});
    const goal = 20;
    await speak(`Hi! I'm Neura. We currently have ${sponsors.length} sponsors. Our next goal is ${goal}.`);
    const tiers = ['Premium','Gold','Silver','Bronze'];
    for (const t of tiers) {
      const group = sponsors.filter(s=>s.tier===t);
      if (!group.length) continue;
      await speak(tierLine(t));
      for (const s of group) {
        await speak(`${s.name||s.login}`);
      }
    }
    await speak("Thanks for fueling humane AI. You rock.");
  }

  function initClock() {
    const el = document.getElementById('vr-clock');
    if (!el) return;
    function tick() {
      const d = new Date();
      const hh = d.getHours().toString().padStart(2,'0');
      const mm = d.getMinutes().toString().padStart(2,'0');
      el.textContent = `${hh}:${mm}`;
      requestAnimationFrame(()=>{});
    }
    setInterval(tick, 1000);
    tick();

    // breathing + color
    const tod = byTimeOfDay();
    const { color, glow } = clockColorFor(tod);
    el.style.color = color;
    el.style.textShadow = `0 0 12px ${glow}`;
    document.documentElement.dataset.timeOfDay = tod;

    el.addEventListener('click', () => {
      NeuraAnalytics?.log('clock_click', { tod });
      speak(`It's now ${el.textContent}.`);
    });
  }

  return { setSilentMode, getSilentMode, setCinematic, getCinematic, loadSponsors, readSponsorsAloud, initClock, byTimeOfDay };
})();
