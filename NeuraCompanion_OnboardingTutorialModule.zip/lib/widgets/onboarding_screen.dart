import 'package:flutter/material.dart';
import '../widgets/onboarding_tutorial_service.dart';

class OnboardingScreen extends StatefulWidget {
  const OnboardingScreen({super.key});

  @override
  State<OnboardingScreen> createState() => _OnboardingScreenState();
}

class _OnboardingScreenState extends State<OnboardingScreen> {
  final tutorial = OnboardingTutorialService();
  int _current = 0;

  void _next() {
    setState(() {
      if (_current < tutorial.steps.length - 1) {
        _current++;
      } else {
        Navigator.pop(context); // Exit tutorial
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final step = tutorial.steps[_current];
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text(step.title, style: Theme.of(context).textTheme.headline5),
            const SizedBox(height: 20),
            Text(step.description, textAlign: TextAlign.center),
            const SizedBox(height: 40),
            ElevatedButton(onPressed: _next, child: Text(_current < tutorial.steps.length - 1 ? 'Next' : 'Finish')),
          ],
        ),
      ),
    );
  }
}
