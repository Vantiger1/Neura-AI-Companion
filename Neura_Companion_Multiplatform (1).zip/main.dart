
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'mood_notifier.dart';
import 'mood_history_tracker.dart';
import 'neura_memory_core.dart';
import 'dashboard_screen.dart';
import 'neura_app_shell.dart';
import 'neura_voice_engine.dart';

void main() {
  runApp(const NeuraApp());
  final voice = NeuraVoiceEngine();
  voice.speakWelcome();
}

class NeuraApp extends StatelessWidget {
  const NeuraApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => MoodNotifier()),
        ChangeNotifierProvider(create: (_) => MoodHistoryTracker()),
        ChangeNotifierProvider(create: (_) => NeuraMemoryCore()),
      ],
      child: MaterialApp(
        title: 'Neura Companion',
        theme: ThemeData.dark(useMaterial3: true),
        home: NeuraAppShell(child: DashboardScreen()),
      ),
    );
  }
}
