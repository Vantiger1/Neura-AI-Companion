#!/bin/bash
APP_DIR="/opt/neura-companion"
ICON_DIR="$APP_DIR/assets"
sudo mkdir -p "$APP_DIR"
sudo cp NeuraCompanion "$APP_DIR/"
sudo mkdir -p "$ICON_DIR"
sudo cp assets/icon.png "$ICON_DIR/"
sudo bash -c 'cat > /usr/share/applications/neura-companion.desktop <<EOF
[Desktop Entry]
Name=Neura Companion
Comment=AI-powered mood companion
Exec=$APP_DIR/NeuraCompanion
Icon=$APP_DIR/assets/icon.png
Terminal=false
Type=Application
Categories=Utility;Health;AI;
EOF'
sudo chmod +x /usr/share/applications/neura-companion.desktop
echo "Neura Companion installed for Linux menu."
