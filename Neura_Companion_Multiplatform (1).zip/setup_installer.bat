@echo off
flutter clean
flutter pub get
flutter build windows
powershell Compress-Archive -Path build\windows\runner\Release\* -DestinationPath Neura_Windows_Installer.zip
echo Windows build complete and zipped.
pause
