@echo off
flutter clean
flutter pub get
flutter build web
powershell Compress-Archive -Path build\web\* -DestinationPath Neura_WebBuild.zip
echo Web build zipped.
pause
