# Skill Pack 22 — Unified Sources + Sources Panel

This patch merges citations from:
- Persistent offline index (DOC*)
- Encrypted session index (ENC*) when unlocked

## What you get
- `NeuraUnifiedSourcesService` (calls `offline_search_cited` + `offline_search_encrypted_session`)
- Action: `unified_sources`
- UI: `NeuraSourcesPanel` for showing sources to the user (auditable answers)

## Wiring
Register the action using your existing executor instance:
```dart
NeuraUnifiedSourcesActions(NeuraKernel.I.executor).registerAll(registry);
```

## Usage
- Call `unified_sources` with `{q: "..."}`
- Show citations in your chat UI as a “Sources” expandable section, or route to `NeuraSourcesPanel`

## Next
Step 23: “Answer Composer” — Neura writes answers that reference DOC*/ENC* inline and includes an auto-generated Sources section.
