import '../neura_action_bus/action_executor.dart';
import 'neura_sources.dart';

class NeuraUnifiedSourcesService {
  final NeuraActionExecutor executor;

  NeuraUnifiedSourcesService(this.executor);

  /// Runs both persistent and encrypted-session search (if available) and merges results.
  /// - Persistent citations get DOC* ids
  /// - Session citations get ENC* ids
  /// - Results sorted by score descending
  Future<NeuraSourcesPacket> gatherSources({
    required String query,
    int persistentLimit = 6,
    int sessionLimit = 4,
  }) async {
    final q = query.trim();
    if (q.isEmpty) return NeuraSourcesPacket(query: q, citations: []);

    final citations = <NeuraCitation>[];

    // Persistent citations
    final p = await executor.execute('offline_search_cited', args: {'q': q, 'limit': persistentLimit});
    if (p.ok && p.data is Map && (p.data['citations'] is List)) {
      final list = (p.data['citations'] as List).cast<Map<String, dynamic>>();
      for (final c in list) {
        citations.add(NeuraCitation(
          id: c['id']?.toString() ?? 'DOC?',
          path: c['path']?.toString() ?? '',
          excerpt: c['excerpt']?.toString() ?? '',
          score: (c['score'] as num?)?.toDouble() ?? 0.0,
          scope: 'persistent',
        ));
      }
    }

    // Encrypted session citations (only if unlocked; action returns error if locked)
    final s = await executor.execute('offline_search_encrypted_session', args: {'q': q, 'limit': sessionLimit});
    if (s.ok && s.data is Map && (s.data['hits'] is List)) {
      final list = (s.data['hits'] as List).cast<Map<String, dynamic>>();
      int i = 1;
      for (final h in list) {
        citations.add(NeuraCitation(
          id: 'ENC$i',
          path: h['path']?.toString() ?? '',
          excerpt: h['excerpt']?.toString() ?? '',
          score: (h['score'] as num?)?.toDouble() ?? 0.0,
          scope: 'session',
          note: 'Encrypted session',
        ));
        i++;
      }
    }

    citations.sort((a, b) => b.score.compareTo(a.score));

    // Deduplicate by path (keep highest score)
    final seen = <String, NeuraCitation>{};
    for (final c in citations) {
      if (c.path.isEmpty) continue;
      final existing = seen[c.path];
      if (existing == null || c.score > existing.score) {
        seen[c.path] = c;
      }
    }

    final merged = seen.values.toList()..sort((a, b) => b.score.compareTo(a.score));
    return NeuraSourcesPacket(query: q, citations: merged);
  }
}
