import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import '../neura_action_bus/action_executor.dart';
import 'unified_sources_service.dart';

class NeuraUnifiedSourcesActions {
  final NeuraUnifiedSourcesService svc;

  NeuraUnifiedSourcesActions(NeuraActionExecutor executor) : svc = NeuraUnifiedSourcesService(executor);

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'unified_sources',
        title: 'Gather Sources (Unified)',
        description: 'Returns citations from persistent index + encrypted session index (if unlocked).',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final q = (req.args['q'] as String?)?.trim() ?? '';
          if (q.isEmpty) return NeuraActionResult.error('Missing query');
          final pLimit = (req.args['persistentLimit'] as int?) ?? 6;
          final sLimit = (req.args['sessionLimit'] as int?) ?? 4;
          final packet = await svc.gatherSources(query: q, persistentLimit: pLimit, sessionLimit: sLimit);
          return NeuraActionResult.success('OK', data: packet.toJson());
        },
      ),
    );
  }
}
