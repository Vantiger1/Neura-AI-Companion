class NeuraCitation {
  final String id; // e.g. DOC1, ENC1
  final String path;
  final String excerpt;
  final double score;
  final String scope; // persistent|session
  final String? note;

  NeuraCitation({
    required this.id,
    required this.path,
    required this.excerpt,
    required this.score,
    required this.scope,
    this.note,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'path': path,
        'excerpt': excerpt,
        'score': score,
        'scope': scope,
        if (note != null) 'note': note,
      };

  static NeuraCitation fromJson(Map<String, dynamic> j) => NeuraCitation(
        id: j['id'] as String,
        path: j['path'] as String,
        excerpt: (j['excerpt'] as String?) ?? '',
        score: (j['score'] as num?)?.toDouble() ?? 0.0,
        scope: (j['scope'] as String?) ?? 'persistent',
        note: j['note'] as String?,
      );
}

class NeuraSourcesPacket {
  final String query;
  final List<NeuraCitation> citations;

  NeuraSourcesPacket({required this.query, required this.citations});

  Map<String, dynamic> toJson() => {
        'query': query,
        'citations': citations.map((c) => c.toJson()).toList(),
      };
}
