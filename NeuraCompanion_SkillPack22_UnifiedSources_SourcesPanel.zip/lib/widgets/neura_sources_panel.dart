import 'package:flutter/material.dart';

class NeuraSourcesPanel extends StatelessWidget {
  final String query;
  final List<Map<String, dynamic>> citations;

  const NeuraSourcesPanel({
    super.key,
    required this.query,
    required this.citations,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Sources')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('Query', style: Theme.of(context).textTheme.titleMedium),
            const SizedBox(height: 4),
            Text(query, style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 12),
            Expanded(
              child: ListView.builder(
                itemCount: citations.length,
                itemBuilder: (context, i) {
                  final c = citations[i];
                  final id = c['id']?.toString() ?? '';
                  final path = c['path']?.toString() ?? '';
                  final excerpt = c['excerpt']?.toString() ?? '';
                  final scope = c['scope']?.toString() ?? 'persistent';

                  return Card(
                    child: ListTile(
                      leading: CircleAvatar(child: Text(id.isEmpty ? '?' : id)),
                      title: Text(path),
                      subtitle: Text(excerpt),
                      trailing: Text(scope),
                    ),
                  );
                },
              ),
            )
          ],
        ),
      ),
    );
  }
}
