import 'package:flutter/material.dart';

class NeuraSuggestionCard extends StatelessWidget {
  final String mood;
  final String suggestion;

  const NeuraSuggestionCard({Key? key, required this.mood, required this.suggestion}) : super(key: key);

  IconData getMoodIcon() {
    switch (mood) {
      case 'happy': return Icons.emoji_emotions;
      case 'sad': return Icons.emoji_flags;
      case 'calm': return Icons.self_improvement;
      case 'excited': return Icons.flash_on;
      case 'angry': return Icons.warning_amber_rounded;
      default: return Icons.help_outline;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      color: Colors.white,
      elevation: 4,
      margin: EdgeInsets.all(16),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      child: Padding(
        padding: EdgeInsets.all(20),
        child: Row(
          children: [
            Icon(getMoodIcon(), size: 40),
            SizedBox(width: 16),
            Expanded(child: Text(suggestion, style: TextStyle(fontSize: 16))),
          ],
        ),
      ),
    );
  }
}