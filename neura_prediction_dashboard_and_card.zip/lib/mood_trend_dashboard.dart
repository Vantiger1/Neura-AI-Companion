import 'package:flutter/material.dart';

class MoodTrendDashboard extends StatelessWidget {
  final Map<String, String> moodLog;

  const MoodTrendDashboard({Key? key, required this.moodLog}) : super(key: key);

  Color moodColor(String mood) {
    switch (mood) {
      case 'happy': return Colors.yellow;
      case 'sad': return Colors.indigo;
      case 'calm': return Colors.blueAccent;
      case 'excited': return Colors.orange;
      case 'angry': return Colors.red;
      default: return Colors.grey;
    }
  }

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: moodLog.entries.map((entry) {
        return ListTile(
          leading: CircleAvatar(backgroundColor: moodColor(entry.value)),
          title: Text(entry.key),
          subtitle: Text(entry.value),
        );
      }).toList(),
    );
  }
}