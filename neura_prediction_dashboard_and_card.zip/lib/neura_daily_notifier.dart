import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NeuraDailyNotifier {
  static final _notifications = FlutterLocalNotificationsPlugin();

  static Future<void> init() async {
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const settings = InitializationSettings(android: android);
    await _notifications.initialize(settings);
  }

  static Future<void> scheduleDaily(String message) async {
    const androidDetails = AndroidNotificationDetails(
      'neura_daily_id', 'Neura Suggestions',
      importance: Importance.max,
      priority: Priority.high,
    );
    const platformDetails = NotificationDetails(android: androidDetails);

    await _notifications.showDailyAtTime(
      0,
      'Neura Suggests...',
      message,
      Time(8, 0, 0), // 8:00 AM daily
      platformDetails,
    );
  }
}