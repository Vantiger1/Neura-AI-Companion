// server/blockchain.js
const Web3 = require('web3');
const DataVaultABI = require('./DataVaultABI.json'); // compile to get ABI
const web3 = new Web3('http://127.0.0.1:8545'); // Ganache or local Hardhat node

let vaultContract;
let defaultAccount;

async function initVault() {
  const accounts = await web3.eth.getAccounts();
  defaultAccount = accounts[0];
  const networkId = await web3.eth.net.getId();
  // Replace with deployed contract address
  const deployedAddress = '0xYourDeployedContractAddress';
  vaultContract = new web3.eth.Contract(DataVaultABI, deployedAddress);
}

initVault();

async function storeOnChain(userId, dataHash) {
  if (!vaultContract) throw new Error("Contract not initialized");
  const receipt = await vaultContract.methods
    .storeRecord(userId, dataHash)
    .send({ from: defaultAccount, gas: 300000 });
  return receipt.events.RecordStored.returnValues.id;
}

// Example usage in your /api/neura/event handler
// if (shouldWriteOnChain(event)) {
//   const id = await storeOnChain(userId, computeHash(data));
//   console.log("Stored on chain with id", id);
// }
