# Neura Blockchain Data Vault Module

## Setup

1. **Install dependencies**
   ```
   cd blockchain
   npm install
   ```

2. **Run local node**
   - Launch Ganache CLI or `npx hardhat node`

3. **Compile & Deploy**
   ```
   npm run compile
   npm run deploy
   ```
   Copy the deployed contract address into `server/blockchain.js`

4. **Server Integration**
   - Add `require('./blockchain.js')` in your `server/server.js`
   - Call `storeOnChain(userId, dataHash)` in your AI event handler when `permissionUpdate.blockchain` is true.

5. **Compute dataHash**
   - Use a hash of the data (e.g., SHA256) or an IPFS hash to represent the stored record.

This module provides an immutable on-chain log of sensitive user data.
