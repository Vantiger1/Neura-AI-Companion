
# Neura Companion — Lightweight Fitted Rig (External Portrait)
This build references `portrait.webp` externally instead of embedding it, making the SVG tiny and fast while keeping full AI control (eyes, lids, visemes, pivots).

## Files
- `index.html` — demo page with inline SVG + JS controller
- `portrait.webp` — optimized portrait texture (use this)
- `portrait.jpg` — fallback
- (No base64 blobs inside the SVG)

## Usage
Open `index.html`. Keep `portrait.webp` next to it. In Flutter WebView, include both files in your assets.

## Drive it
```js
NeuraRig.autoBlink(true); NeuraRig.setGaze(6,-2); NeuraRig.showViseme('A');
```
