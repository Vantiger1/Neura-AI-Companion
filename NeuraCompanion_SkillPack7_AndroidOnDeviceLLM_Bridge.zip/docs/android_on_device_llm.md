# Neura Android On‑Device LLM (GGUF) – Build Notes

This patch adds an **Android on‑device LLM bridge** (Flutter ⇄ Kotlin ⇄ JNI).

Out of the box it is **safe**:
- If the native library is missing, the app does **not** crash.
- Neura falls back to the localhost server engine, if configured.

To get **true on‑device inference**, you must build and bundle `libneura_llama.so`.

## 1) Enable the stub (proves the pipeline)

### A. Turn on CMake in `android/app/build.gradle.kts`

Add this inside the `android { ... }` block:

```kotlin
externalNativeBuild {
    cmake {
        path = file("src/main/cpp/CMakeLists.txt")
    }
}

defaultConfig {
    // ... existing config
    externalNativeBuild {
        cmake {
            // Conservative flags; you can tune later.
            cppFlags += listOf("-O3", "-fexceptions", "-frtti")
        }
    }
    ndk {
        // Start with ARM64 only for sanity; expand later.
        abiFilters += setOf("arm64-v8a")
    }
}
```

### B. Build the app

`flutter clean && flutter run`

Now enable:
- **Settings → Local Models → On‑Device LLM (Android)**
- Tap **Test on‑device engine**

If the native stub built correctly, you should see:
- `version: neura_llama_stub_0.1`

## 2) Replace the stub with llama.cpp

The stub demonstrates the wiring, but it does not run a real model.

Recommended approach:
1. Add `llama.cpp` as a git submodule or vendor it into `android/app/src/main/cpp/llama.cpp`.
2. Build it as part of the same `CMakeLists.txt`.
3. Implement `LlamaNative.chat(...)` to:
   - load a GGUF model from app storage
   - tokenize + run inference
   - return generated text

### Model placement

Put GGUF models under an app-accessible directory, for example:
- `Android/data/<your.package>/files/models/` (debug)
- or the app documents directory (release)

Then pass the model path into native code. (Future patch: add `loadModel(path)` to the channel.)

## 3) Practical constraints (don’t ignore these)

- **Thermals/battery:** small models + low max tokens.
- **Memory:** keep context conservative; 2k–4k is typical for mobile.
- **Latency:** don’t block UI thread; run inference on a worker thread.

## Troubleshooting

- If **health** says library not loaded:
  - confirm CMake is wired
  - confirm ABI filters match your device
  - run `./gradlew :app:externalNativeBuildDebug` in `android/`

