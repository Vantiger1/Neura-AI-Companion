import 'package:shared_preferences/shared_preferences.dart';

/// Android-only: settings for an on-device LLM bridge.
///
/// Neura remains offline: this only enables calling native on-device inference
/// through a MethodChannel.
class NeuraOnDeviceLlmSettings {
  static const _kEnabled = 'neura.on_device_llm.enabled';
  static const _kMaxTokens = 'neura.on_device_llm.max_tokens';
  static const _kThreads = 'neura.on_device_llm.threads';
  static const _kContextTokens = 'neura.on_device_llm.context_tokens';
  static const _kUseGpu = 'neura.on_device_llm.use_gpu';

  static final NeuraOnDeviceLlmSettings I = NeuraOnDeviceLlmSettings._();
  NeuraOnDeviceLlmSettings._();

  SharedPreferences? _sp;

  Future<void> init() async {
    _sp ??= await SharedPreferences.getInstance();
  }

  bool get enabled => _sp?.getBool(_kEnabled) ?? false;
  int get maxTokens => _sp?.getInt(_kMaxTokens) ?? 256;
  int get threads => _sp?.getInt(_kThreads) ?? 4;
  int get contextTokens => _sp?.getInt(_kContextTokens) ?? 2048;
  bool get useGpu => _sp?.getBool(_kUseGpu) ?? false;

  Future<void> setEnabled(bool v) async => _sp?.setBool(_kEnabled, v);
  Future<void> setMaxTokens(int v) async => _sp?.setInt(_kMaxTokens, v);
  Future<void> setThreads(int v) async => _sp?.setInt(_kThreads, v);
  Future<void> setContextTokens(int v) async => _sp?.setInt(_kContextTokens, v);
  Future<void> setUseGpu(bool v) async => _sp?.setBool(_kUseGpu, v);
}
