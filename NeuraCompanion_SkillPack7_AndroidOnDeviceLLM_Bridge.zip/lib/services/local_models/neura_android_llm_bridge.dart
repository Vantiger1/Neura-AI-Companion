import 'dart:async';
import 'dart:io';

import 'package:flutter/services.dart';

import 'neura_on_device_llm_settings.dart';

/// Thin MethodChannel wrapper for Android on-device inference.
///
/// The native side may be stubbed (returns not_available) until you build/link
/// a real runtime. This is intentional: the Flutter app MUST keep running.
class NeuraAndroidLlmBridge {
  static final NeuraAndroidLlmBridge I = NeuraAndroidLlmBridge._();
  NeuraAndroidLlmBridge._();

  static const MethodChannel _ch = MethodChannel('neura_llm');

  bool get supported => Platform.isAndroid;

  Future<Map<String, dynamic>> health() async {
    if (!supported) {
      return {'ok': false, 'error': 'Android only.'};
    }
    await NeuraOnDeviceLlmSettings.I.init();
    if (!NeuraOnDeviceLlmSettings.I.enabled) {
      return {'ok': false, 'error': 'On-device LLM is disabled.'};
    }

    try {
      final res = await _ch.invokeMethod<Map>('health');
      return (res ?? const {}).cast<String, dynamic>();
    } catch (e) {
      return {'ok': false, 'error': e.toString()};
    }
  }

  Future<Map<String, dynamic>> chat({
    required String prompt,
    required String system,
    required double temperature,
    List<Map<String, String>>? history,
  }) async {
    if (!supported) {
      return {'ok': false, 'error': 'Android only.'};
    }

    await NeuraOnDeviceLlmSettings.I.init();
    if (!NeuraOnDeviceLlmSettings.I.enabled) {
      return {'ok': false, 'error': 'On-device LLM is disabled.'};
    }

    final settings = NeuraOnDeviceLlmSettings.I;

    final payload = <String, dynamic>{
      'prompt': prompt,
      'system': system,
      'temperature': temperature,
      'maxTokens': settings.maxTokens,
      'threads': settings.threads,
      'contextTokens': settings.contextTokens,
      'useGpu': settings.useGpu,
      'history': (history ?? const []).take(10).toList(),
    };

    try {
      final res = await _ch.invokeMethod<Map>('chat', payload);
      return (res ?? const {}).cast<String, dynamic>();
    } catch (e) {
      return {
        'ok': false,
        'error': e.toString(),
        'hint': 'Native bridge failed. Ensure the Android channel is registered and (optionally) the native runtime is built.',
      };
    }
  }
}
