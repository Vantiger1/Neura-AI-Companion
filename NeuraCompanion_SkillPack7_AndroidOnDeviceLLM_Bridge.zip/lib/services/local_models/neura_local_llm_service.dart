import 'dart:convert';
import 'dart:io';

import '../neura_automation_prefs.dart';
import '../neura_policy.dart';
import 'neura_local_model_settings.dart';
import 'neura_android_llm_bridge.dart';
import 'neura_on_device_llm_settings.dart';

/// Local LLM service.
///
/// Priority order (offline-first):
/// 1) Android on-device runtime (if enabled)
/// 2) localhost OpenAI-compatible server (llama.cpp/Ollama/etc.)
///
/// If neither is available, Neura returns a helpful error and falls back to
/// Knowledge Packs.
class NeuraLocalLlmService {
  static final NeuraLocalLlmService I = NeuraLocalLlmService._();
  NeuraLocalLlmService._();

  Future<void> init() async {
    await NeuraAutomationPrefs.I.init();
    await NeuraLocalModelSettings.I.init();
    await NeuraOnDeviceLlmSettings.I.init();
  }

  bool get enabled => NeuraAutomationPrefs.I.capLocalModels || NeuraAutomationPrefs.I.fullAccessEnabled;

  PolicyDecision policyDecision() {
    return NeuraPolicyEngine.I.decide(capability: NeuraCapability.localModels, risk: NeuraRisk.low);
  }

  bool get _androidOnDeviceEnabled => Platform.isAndroid && NeuraOnDeviceLlmSettings.I.enabled;

  Future<Map<String, dynamic>> health() async {
    await init();
    if (!enabled) {
      return {
        'ok': false,
        'error': 'Local Models capability is disabled.',
      };
    }

    // Android on-device health.
    if (_androidOnDeviceEnabled) {
      final res = await NeuraAndroidLlmBridge.I.health();
      // If the bridge is stubbed, it will return ok=false with a hint.
      return {
        ...res,
        'engine': 'android_on_device',
      };
    }

    // localhost server health.
    final base = NeuraLocalModelSettings.I.llmBaseUrl;
    final uri = Uri.parse('$base/v1/models');
    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: NeuraLocalModelSettings.I.llmTimeoutMs);
    try {
      final req = await client.getUrl(uri);
      final res = await req.close();
      final txt = await utf8.decodeStream(res);
      return {
        'ok': res.statusCode >= 200 && res.statusCode < 300,
        'statusCode': res.statusCode,
        'body': txt,
        'engine': 'localhost_server',
      };
    } catch (e) {
      return {
        'ok': false,
        'error': e.toString(),
        'engine': 'localhost_server',
      };
    } finally {
      client.close(force: true);
    }
  }

  Future<Map<String, dynamic>> chat({
    required String prompt,
    String? system,
    List<Map<String, String>>? history,
  }) async {
    await init();

    final decision = policyDecision();
    if (!decision.allowed) {
      return {
        'ok': false,
        'error': decision.reason,
      };
    }
    if (!enabled) {
      return {
        'ok': false,
        'error': 'Local Models capability is disabled. Enable it in Privacy & Safety.',
      };
    }

    final model = NeuraLocalModelSettings.I.llmModel;
    final temp = NeuraLocalModelSettings.I.llmTemperature;

    final sys = system ??
        'You are Neura, an offline-first assistant. '
            'Prefer the provided offline knowledge. '
            'Be concise, safe, and practical.';

    // 1) Android on-device inference (best offline story).
    if (_androidOnDeviceEnabled) {
      final res = await NeuraAndroidLlmBridge.I.chat(
        prompt: prompt,
        system: sys,
        temperature: temp,
        history: history,
      );

      if (res['ok'] == true) {
        return {
          'ok': true,
          'engine': 'android_on_device',
          'model': res['model'] ?? model,
          'content': res['content'] ?? '',
          'raw': res,
        };
      }

      // If native is not available yet, fall through to localhost server.
      // (This keeps Android usable today while you finish native builds.)
    }

    // 2) localhost OpenAI-compatible server.
    final base = NeuraLocalModelSettings.I.llmBaseUrl;
    final timeoutMs = NeuraLocalModelSettings.I.llmTimeoutMs;
    final uri = Uri.parse('$base/v1/chat/completions');

    final messages = <Map<String, String>>[];
    messages.add({'role': 'system', 'content': sys});

    if (history != null && history.isNotEmpty) {
      messages.addAll(history.take(10));
    }

    messages.add({'role': 'user', 'content': prompt});

    final payload = <String, dynamic>{
      'model': model,
      'temperature': temp,
      'messages': messages,
    };

    final client = HttpClient();
    client.connectionTimeout = Duration(milliseconds: timeoutMs);

    try {
      final req = await client.postUrl(uri);
      req.headers.contentType = ContentType.json;
      req.write(jsonEncode(payload));
      final res = await req.close();
      final txt = await utf8.decodeStream(res);

      if (res.statusCode < 200 || res.statusCode >= 300) {
        return {
          'ok': false,
          'engine': 'localhost_server',
          'statusCode': res.statusCode,
          'error': 'Local model server returned HTTP ${res.statusCode}.',
          'body': txt,
          'hint':
              'Start a local OpenAI-compatible server on ${NeuraLocalModelSettings.I.llmBaseUrl}. '
              'For llama.cpp, run: server --host 127.0.0.1 --port 8080 --model <path-to-gguf>.',
        };
      }

      final map = (jsonDecode(txt) as Map).cast<String, dynamic>();
      final choices = (map['choices'] as List?)?.cast<dynamic>() ?? const [];
      final first = choices.isEmpty ? null : (choices.first as Map).cast<String, dynamic>();
      final msg = (first?['message'] as Map?)?.cast<String, dynamic>();
      final content = (msg?['content'] ?? '').toString();

      return {
        'ok': true,
        'engine': 'localhost_server',
        'model': model,
        'content': content,
        'raw': map,
      };
    } catch (e) {
      return {
        'ok': false,
        'engine': 'localhost_server',
        'error': e.toString(),
        'hint':
            'If you are on Windows, make sure a local model server is running. '
            'If you are on Android, enable On-Device LLM in Settings → Local Models, '
            'or use a companion desktop host temporarily.',
      };
    } finally {
      client.close(force: true);
    }
  }
}
