import 'dart:io';

import 'package:flutter/material.dart';

import '../../../services/neura_automation_prefs.dart';
import '../../../services/local_models/neura_android_llm_bridge.dart';
import '../../../services/local_models/neura_local_llm_service.dart';
import '../../../services/local_models/neura_local_model_settings.dart';
import '../../../services/local_models/neura_on_device_llm_settings.dart';

class LocalModelsScreen extends StatefulWidget {
  const LocalModelsScreen({super.key});

  @override
  State<LocalModelsScreen> createState() => _LocalModelsScreenState();
}

class _LocalModelsScreenState extends State<LocalModelsScreen> {
  final _baseUrl = TextEditingController();
  final _model = TextEditingController();
  final _timeout = TextEditingController();

  final _maxTokens = TextEditingController();
  final _threads = TextEditingController();
  final _context = TextEditingController();

  double _temp = 0.3;
  bool _onDevice = false;
  bool _useGpu = false;

  bool _busy = false;
  String _status = '—';

  Future<void> _load() async {
    await NeuraAutomationPrefs.I.init();
    await NeuraLocalModelSettings.I.init();
    await NeuraOnDeviceLlmSettings.I.init();

    _baseUrl.text = NeuraLocalModelSettings.I.llmBaseUrl;
    _model.text = NeuraLocalModelSettings.I.llmModel;
    _timeout.text = NeuraLocalModelSettings.I.llmTimeoutMs.toString();
    _temp = NeuraLocalModelSettings.I.llmTemperature;

    _onDevice = NeuraOnDeviceLlmSettings.I.enabled;
    _maxTokens.text = NeuraOnDeviceLlmSettings.I.maxTokens.toString();
    _threads.text = NeuraOnDeviceLlmSettings.I.threads.toString();
    _context.text = NeuraOnDeviceLlmSettings.I.contextTokens.toString();
    _useGpu = NeuraOnDeviceLlmSettings.I.useGpu;

    setState(() {});
  }

  Future<void> _save() async {
    setState(() => _busy = true);
    try {
      await NeuraLocalModelSettings.I.setLlmBaseUrl(_baseUrl.text);
      await NeuraLocalModelSettings.I.setLlmModel(_model.text);
      final t = int.tryParse(_timeout.text.trim()) ?? 120000;
      await NeuraLocalModelSettings.I.setLlmTimeoutMs(t);
      await NeuraLocalModelSettings.I.setLlmTemperature(_temp);

      // Android on-device (safe no-op elsewhere)
      await NeuraOnDeviceLlmSettings.I.setEnabled(_onDevice);
      final mt = int.tryParse(_maxTokens.text.trim()) ?? 256;
      final th = int.tryParse(_threads.text.trim()) ?? 4;
      final ct = int.tryParse(_context.text.trim()) ?? 2048;
      await NeuraOnDeviceLlmSettings.I.setMaxTokens(mt);
      await NeuraOnDeviceLlmSettings.I.setThreads(th);
      await NeuraOnDeviceLlmSettings.I.setContextTokens(ct);
      await NeuraOnDeviceLlmSettings.I.setUseGpu(_useGpu);

      setState(() => _status = 'Saved.');
    } catch (e) {
      setState(() => _status = 'Save failed: $e');
    } finally {
      setState(() => _busy = false);
    }
  }

  Future<void> _test() async {
    setState(() {
      _busy = true;
      _status = 'Testing…';
    });

    final res = await NeuraLocalLlmService.I.health();
    setState(() {
      _busy = false;
      if (res['ok'] == true) {
        _status = 'OK (${res['engine'] ?? 'unknown'})';
      } else {
        _status = 'Not ready (${res['engine'] ?? 'unknown'}): ${(res['error'] ?? res['statusCode'] ?? 'unknown')}';
      }
    });
  }

  Future<void> _testOnDevice() async {
    setState(() {
      _busy = true;
      _status = 'Testing on-device engine…';
    });

    final res = await NeuraAndroidLlmBridge.I.health();
    setState(() {
      _busy = false;
      _status = res['ok'] == true ? 'On-device OK' : 'On-device not available: ${(res['error'] ?? 'unknown')}';
    });
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void dispose() {
    _baseUrl.dispose();
    _model.dispose();
    _timeout.dispose();
    _maxTokens.dispose();
    _threads.dispose();
    _context.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final prefs = NeuraAutomationPrefs.I;
    final enabled = prefs.capLocalModels || prefs.fullAccessEnabled;
    final isAndroid = Platform.isAndroid;

    return Scaffold(
      appBar: AppBar(title: const Text('Local Models (Offline AI Core)')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text(
            'Neura can run fully offline.\n\n'
            'Priority order:\n'
            '• Android: On-device runtime (if enabled)\n'
            '• Windows: Localhost OpenAI-compatible server (llama.cpp/Ollama)\n\n'
            'Everything stays on your device.',
          ),
          const SizedBox(height: 12),
          Card(
            child: ListTile(
              leading: Icon(enabled ? Icons.check_circle : Icons.block),
              title: Text(enabled ? 'Enabled' : 'Disabled'),
              subtitle: const Text('Controlled by Privacy & Safety → Local Models.'),
            ),
          ),
          const SizedBox(height: 12),

          if (isAndroid) ...[
            Card(
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        const Expanded(
                          child: Text(
                            'On-Device LLM (Android) – Experimental',
                            style: TextStyle(fontWeight: FontWeight.w600),
                          ),
                        ),
                        Switch(
                          value: _onDevice,
                          onChanged: _busy ? null : (v) => setState(() => _onDevice = v),
                        ),
                      ],
                    ),
                    const Text(
                      'Runs locally via a native bridge. If the native runtime is not built yet, '
                      'Neura will safely fall back to your localhost server.\n\n'
                      'See docs/android_on_device_llm.md to build/link llama.cpp.',
                    ),
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Expanded(
                          child: TextField(
                            controller: _maxTokens,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Max tokens',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: TextField(
                            controller: _threads,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Threads',
                              border: OutlineInputBorder(),
                            ),
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: _context,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Context tokens',
                        border: OutlineInputBorder(),
                      ),
                    ),
                    const SizedBox(height: 8),
                    Row(
                      children: [
                        Checkbox(
                          value: _useGpu,
                          onChanged: _busy ? null : (v) => setState(() => _useGpu = v ?? false),
                        ),
                        const Expanded(child: Text('Try GPU (if supported)')),
                      ],
                    ),
                    const SizedBox(height: 8),
                    OutlinedButton.icon(
                      onPressed: _busy ? null : _testOnDevice,
                      icon: const Icon(Icons.memory),
                      label: const Text('Test on-device engine'),
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 12),
          ],

          TextField(
            controller: _baseUrl,
            decoration: const InputDecoration(
              labelText: 'Base URL (localhost server)',
              helperText: 'Example: http://127.0.0.1:8080',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _model,
            decoration: const InputDecoration(
              labelText: 'Model name',
              helperText: 'Whatever your local server reports; can be any string for llama.cpp.',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _timeout,
            keyboardType: TextInputType.number,
            decoration: const InputDecoration(
              labelText: 'Timeout (ms)',
              helperText: 'Default 120000',
              border: OutlineInputBorder(),
            ),
          ),
          const SizedBox(height: 12),
          Text('Temperature: ${_temp.toStringAsFixed(2)}'),
          Slider(
            value: _temp,
            min: 0.0,
            max: 1.0,
            divisions: 20,
            onChanged: (v) => setState(() => _temp = v),
          ),
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 12,
            children: [
              ElevatedButton.icon(
                onPressed: _busy ? null : _save,
                icon: const Icon(Icons.save),
                label: const Text('Save'),
              ),
              OutlinedButton.icon(
                onPressed: _busy ? null : _test,
                icon: const Icon(Icons.health_and_safety),
                label: const Text('Test engine'),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Card(
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text('Status: $_status'),
            ),
          ),
          const SizedBox(height: 12),
          const Text(
            'Tip: If Android on-device is enabled but not built yet, Neura will fall back to the localhost server.\n'
            'Ship now, then “level up” to true on-device inference as you finish the native runtime.',
          ),
        ],
      ),
    );
  }
}
