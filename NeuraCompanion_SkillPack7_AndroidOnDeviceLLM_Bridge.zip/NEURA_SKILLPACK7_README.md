# Neura Companion – Skill Pack 7

## What this adds

**Android On‑Device LLM Bridge** (offline):
- Flutter → MethodChannel (`neura_llm`) → Kotlin → JNI
- Safe fallback: if native library isn’t built, app does not crash.
- Settings UI: toggle + threads/maxTokens/context.

## Files

- `lib/services/local_models/neura_on_device_llm_settings.dart`
- `lib/services/local_models/neura_android_llm_bridge.dart`
- `lib/services/local_models/neura_local_llm_service.dart` (updated)
- `lib/src/modules/models/local_models_screen.dart` (updated)
- `android/app/src/main/kotlin/...` (channel + engine + JNI stubs)
- `android/app/src/main/cpp/...` (stub native library)
- `docs/android_on_device_llm.md`

## How to apply

1. Copy the patch into your project root (overwrite files when prompted).
2. For Android on-device builds, follow `docs/android_on_device_llm.md`.
3. Run:
   - `flutter pub get`
   - `flutter run` (Android)

## Expected behavior

- If you enable On‑Device LLM but haven’t built native yet:
  - health/chat will report not available
  - Neura will fall back to your localhost server (if configured)

