package com.neurocompanion.app.neura

/**
 * JNI signatures for the native on-device runtime.
 *
 * You can back these with llama.cpp, ggml, or any local inference engine.
 *
 * This patch ships with a SAFE stub design: if the native library isn't built,
 * the Flutter app does not crash; it simply reports not available.
 */
object LlamaNative {
  external fun version(): String

  external fun chat(
    system: String,
    prompt: String,
    temperature: Double,
    maxTokens: Int,
    threads: Int,
    contextTokens: Int,
    useGpu: Boolean,
  ): String
}
