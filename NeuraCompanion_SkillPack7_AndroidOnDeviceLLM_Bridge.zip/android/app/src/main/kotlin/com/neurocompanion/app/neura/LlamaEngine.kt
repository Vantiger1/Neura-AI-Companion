package com.neurocompanion.app.neura

import java.util.concurrent.atomic.AtomicBoolean

object LlamaEngine {
  private val loaded = AtomicBoolean(false)
  private var loadError: String? = null

  private fun ensureLoaded() {
    if (loaded.get()) return
    try {
      System.loadLibrary("neura_llama")
      loaded.set(true)
    } catch (t: Throwable) {
      loadError = t.toString()
      loaded.set(false)
    }
  }

  fun health(): Map<String, Any?> {
    ensureLoaded()
    if (!loaded.get()) {
      return mapOf(
        "ok" to false,
        "error" to (loadError ?: "Native library not loaded."),
        "hint" to "Build and bundle the native on-device runtime (see docs/android_on_device_llm.md).",
      )
    }

    return try {
      val v = LlamaNative.version()
      mapOf(
        "ok" to true,
        "version" to v,
      )
    } catch (t: Throwable) {
      mapOf(
        "ok" to false,
        "error" to t.toString(),
      )
    }
  }

  fun chat(
    prompt: String,
    system: String,
    temperature: Double,
    maxTokens: Int,
    threads: Int,
    contextTokens: Int,
    useGpu: Boolean,
  ): Map<String, Any?> {
    ensureLoaded()
    if (!loaded.get()) {
      return mapOf(
        "ok" to false,
        "error" to (loadError ?: "Native library not loaded."),
        "hint" to "On-device LLM is enabled but not built. Follow docs/android_on_device_llm.md.",
      )
    }

    if (prompt.isBlank()) {
      return mapOf("ok" to false, "error" to "Missing prompt.")
    }

    return try {
      val out = LlamaNative.chat(
        system = system,
        prompt = prompt,
        temperature = temperature,
        maxTokens = maxTokens,
        threads = threads,
        contextTokens = contextTokens,
        useGpu = useGpu,
      )
      mapOf(
        "ok" to true,
        "model" to "android_on_device",
        "content" to out,
      )
    } catch (t: Throwable) {
      mapOf(
        "ok" to false,
        "error" to t.toString(),
      )
    }
  }
}
