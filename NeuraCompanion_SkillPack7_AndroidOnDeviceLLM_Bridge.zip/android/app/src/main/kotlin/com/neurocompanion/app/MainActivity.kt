package com.neurocompanion.app

import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import com.neurocompanion.app.neura.NeuraLlamaChannel

class MainActivity : FlutterActivity() {
  override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
    super.configureFlutterEngine(flutterEngine)
    NeuraLlamaChannel.register(flutterEngine)
  }
}
