# Android On-Device LLM Native Runtime

This folder ships with a **safe stub** native library so you can prove the JNI pipeline works.

## What you get

- `llama_stub.cpp`: returns a canned response.
- `CMakeLists.txt`: builds `libneura_llama.so`.

## What you should do next

Replace the stub with a real on-device runtime:

- integrate `llama.cpp` (GGUF) or another ggml/gguf engine
- implement `LlamaNative.chat(...)` and return generated text

Full instructions: `docs/android_on_device_llm.md`.
