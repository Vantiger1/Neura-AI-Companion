#include <jni.h>
#include <string>

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_version(JNIEnv* env, jclass) {
  std::string v = "neura_llama_stub_0.1";
  return env->NewStringUTF(v.c_str());
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_chat(JNIEnv* env, jclass,
                                                   jstring system,
                                                   jstring prompt,
                                                   jdouble temperature,
                                                   jint maxTokens,
                                                   jint threads,
                                                   jint contextTokens,
                                                   jboolean useGpu) {
  (void)system;
  (void)prompt;
  (void)temperature;
  (void)maxTokens;
  (void)threads;
  (void)contextTokens;
  (void)useGpu;

  std::string out =
      "[On-device engine STUB] You built the native library successfully. "
      "Next: replace this stub with llama.cpp inference and return tokens.";
  return env->NewStringUTF(out.c_str());
}
