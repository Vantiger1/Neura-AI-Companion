@echo off
title Neura Sponsor System Setup
echo Opening the Neura Sponsors GUI in your default browser...
start "" "%~dp0neura-sponsors-gui\index.html"
echo.
echo Next steps:
echo 1) Create a new branch: neura-sponsor-system
echo 2) Commit and push these files
echo 3) Enable GitHub Pages for this branch (docs/ folder)
