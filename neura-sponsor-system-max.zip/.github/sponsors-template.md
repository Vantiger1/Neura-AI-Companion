<table>
  <tr>
  {{#sponsors}}
    <td align="center" style="padding: 12px;">
      <a href="{{url}}" target="_blank">
        <img src="{{avatarUrl}}" width="{{avatarSize}}" style="border-radius:50%;box-shadow:0 0 10px rgba(0,0,0,0.15);"><br>
        <sub><b>{{name}}</b></sub><br>
        <sub>@{{login}}</sub><br>
        <sub>💖 ${{monthlyAmount}}/mo — {{tier}}</sub>
      </a>
    </td>
    {{#isMultipleOf4}}
  </tr><tr>
    {{/isMultipleOf4}}
  {{/sponsors}}
  </tr>
</table>
{{^sponsors}}
<p align="center"><i>No sponsors yet — be the first!</i></p>
{{/sponsors}}
