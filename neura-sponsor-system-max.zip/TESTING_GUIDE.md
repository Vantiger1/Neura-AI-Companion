# Testing Guide — neura-sponsor-system

1) Push branch and enable GitHub Pages (`/docs/` on this branch).
2) Landing page: try "Hear Neura Thank You", Silent Mode, Cinematic Mode.
3) Wall of Fame: sponsors load from `assets/data/sponsors.json`.
4) GUI: open `neura-sponsors-gui/index.html` locally; Refresh sponsors; Push JSON.
5) VR: open `vr.html`, Penthouse autoloads (iframe if build found), switch rooms, clock/voice reacts.
6) Analytics: open DevTools console to see interaction logs.
