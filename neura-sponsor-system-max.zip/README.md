# Neura Companion — Sponsor & VR Preview (Branch: neura-sponsor-system)

## 🌟 Sponsors
<!-- sponsors -->
<!-- sponsors -->

### 🎤 Hear Neura Thank You
READMEs can’t speak, so click the button on the **live site** (GitHub Pages) to hear Neura read sponsor names aloud.

### Live Preview
Enable Pages for this branch (`/docs/`) and visit your site to see VR, Wall of Fame, voice, Silent/Cinematic mode, and analytics working.

### VR builds
Drop Unity WebGL exports into `docs/assets/vr/<room>/` and open `docs/vr.html`.
