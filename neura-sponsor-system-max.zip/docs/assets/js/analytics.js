(function(){
  const key='neura_analytics';
  function log(event, meta={}){
    const now=Date.now();
    const data=JSON.parse(localStorage.getItem(key)||'{"events":[]}');
    data.events.push({t:now,event,meta});
    localStorage.setItem(key, JSON.stringify(data));
    console.debug('[NeuraAnalytics]',event,meta);
  }
  window.NeuraAnalytics={log};
})();