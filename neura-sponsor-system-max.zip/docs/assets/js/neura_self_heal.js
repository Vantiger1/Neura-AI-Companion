(function () {
  const MAX_RETRIES = 3;
  let retries = 0;
  function notify(msg) {
    console.warn("[Neura][self-heal]", msg);
    try {
      if (window.Neura && Neura.speak && !Neura.getSilentMode?.()) {
        Neura.speak("One sec—I'm fixing something under the hood.");
      }
    } catch(_) {}
  }
  async function softReload() {
    try {
      if (window.Neura && Neura.loadSponsors) await Neura.loadSponsors();
      retries = 0;
    } catch (e) {
      if (++retries <= MAX_RETRIES) setTimeout(softReload, 600 * retries);
      else console.error("[Neura] persistent error after retries:", e);
    }
  }
  window.addEventListener("error", (e) => { notify(e.message||"Unexpected error"); softReload(); });
  window.addEventListener("unhandledrejection", (e) => { notify((e.reason&&e.reason.message)||"Unhandled promise rejection"); softReload(); });
})();