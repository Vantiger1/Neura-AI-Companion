// Fetch sponsors via GraphQL and write docs/assets/data/sponsors.json
import fs from 'fs';
import path from 'path';
const repo = process.argv[2];
if (!repo) { console.error("Missing repo (owner/name)"); process.exit(1); }
const [owner] = repo.split('/');
const query = `
query($login:String!){
  user(login:$login){
    sponsorshipsAsMaintainer(first:100, includePrivate:true){
      nodes{
        tier{ monthlyPriceInCents }
        sponsorEntity{
          ... on User{ login name avatarUrl url bio }
          ... on Organization{ login name avatarUrl url description }
        }
      }
    }
  }
}`;
async function gq(query, variables){
  const r = await fetch('https://api.github.com/graphql',{
    method:'POST',
    headers:{ 'Authorization':'Bearer '+process.env.GH_TOKEN, 'Content-Type':'application/json' },
    body: JSON.stringify({query, variables})
  });
  if(!r.ok){ throw new Error(await r.text()); }
  return r.json();
}
function tierFromCents(c){
  const usd = Math.round((c||0))/100;
  if (usd >= 50) return 'Gold';
  if (usd >= 10) return 'Silver';
  if (usd >= 1) return 'Bronze';
  return 'Supporter';
}
function sizeForTier(t){
  return t==='Gold'?100:t==='Silver'?80:60;
}
const data = await gq(query,{login: owner});
const nodes = data?.data?.user?.sponsorshipsAsMaintainer?.nodes || [];
const sponsors = nodes.map(n=>{
  const cents = n?.tier?.monthlyPriceInCents || 0;
  const t = tierFromCents(cents);
  const e = n?.sponsorEntity || {};
  return {
    name: e.name || e.login || 'Anonymous',
    login: e.login || 'anon',
    url: e.url || '',
    bio: e.bio || e.description || '',
    avatarUrl: e.avatarUrl || '',
    monthlyAmount: Math.round(cents)/100,
    tier: t,
    avatarSize: sizeForTier(t)
  };
});
const order = { Gold:0, Silver:1, Bronze:2, Supporter:3 };
sponsors.sort((a,b)=> (order[a.tier]-order[b.tier]) || (b.monthlyAmount-a.monthlyAmount));
fs.mkdirSync('docs/assets/data', { recursive: true });
fs.writeFileSync('docs/assets/data/sponsors.json', JSON.stringify({ updatedAt:new Date().toISOString(), sponsors }, null, 2));
console.log('Wrote', sponsors.length, 'sponsors');
