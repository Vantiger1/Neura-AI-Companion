package services

class AuthService {
    fun authenticate(): Boolean {
        // TODO: Integrate Windows Hello via JNA or fallback
        return true
    }
}
