package services

import org.apache.pdfbox.pdmodel.PDDocument
import org.apache.pdfbox.pdmodel.common.PDRectangle
import com.opencsv.CSVWriter
import java.io.FileWriter

class ExportService {
    fun exportPdf(text: String, path: String) {
        PDDocument().use { doc ->
            val page = org.apache.pdfbox.pdmodel.PDPage(PDRectangle.LETTER)
            doc.addPage(page)
            // TODO: draw text on PDF
            doc.save(path)
        }
    }

    fun exportCsv(rows: List<Array<String>>, path: String) {
        FileWriter(path).use { fw ->
            CSVWriter(fw).use { writer -> writer.writeAll(rows) }
        }
    }
}
