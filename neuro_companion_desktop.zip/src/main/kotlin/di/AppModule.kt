package di

import org.koin.dsl.module
import services.AuthService
import services.AIService
import services.StorageService
import services.ExportService
import services.VoiceService
import viewmodel.DashboardViewModel
import ui.screens.RitualViewModel

val appModule = module {
    single { AuthService() }
    single { AIService() }
    single { StorageService() }
    single { ExportService() }
    single { VoiceService() }

    single { DashboardViewModel(get()) }
    single { RitualViewModel(get()) }
    // TODO: add other ViewModels
}
