package viewmodel

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import services.AIService

class DashboardViewModel(private val ai: AIService) {
    var suggestion by mutableStateOf("")
        private set

    var isBusy by mutableStateOf(false)
        private set

    fun loadSuggestion() {
        CoroutineScope(Dispatchers.Main).launch {
            isBusy = true
            suggestion = try {
                ai.generateText("Today’s productivity tip:")
            } catch (e: Exception) {
                "Failed to fetch tip."
            } finally {
                isBusy = false
            }
        }
    }
}
