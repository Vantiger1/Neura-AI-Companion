package ui.screens

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import kotlinx.coroutines.launch
import org.koin.java.KoinJavaComponent.get
import viewmodel.DashboardViewModel

@Composable
fun DashboardScreen(onNavigate: (String) -> Unit) {
    val vm: DashboardViewModel by get(DashboardViewModel::class.java)
    val scope = rememberCoroutineScope()
    Column(modifier = Modifier.padding(16.dp)) {
        Button(onClick = { scope.launch { vm.loadSuggestion() } }) {
            Text("Get Suggestion")
        }
        Text(vm.suggestion)
        Button(onClick = { onNavigate("ritual") }) {
            Text("Go to Ritual Mode")
        }
    }
}
