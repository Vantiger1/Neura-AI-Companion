import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../models/evolving_avatar_model.dart';

class AvatarWidget extends StatelessWidget {
  final EvolvingAvatar avatar;

  const AvatarWidget({required this.avatar});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Text('${avatar.name} - Level ${avatar.level}'),
        SizedBox(height: 8),
        Lottie.asset(avatar.animationPath, width: 120, height: 120),
      ],
    );
  }
}
