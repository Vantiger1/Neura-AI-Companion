import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as crypto;
import 'package:flutter/foundation.dart';

import 'action_registry.dart';
import 'neura_action.dart';
import 'sandbox_paths.dart';
import 'encrypted_session.dart';
import 'crypto_vault.dart';

/// Encrypted session actions:
/// - unlock_encrypted_session
/// - lock_encrypted_session
/// - encrypted_session_status
/// - sandbox_read_text_auto (uses session passphrase when file is encrypted)
class NeuraEncryptedSessionActions {
  final NeuraEncryptedSession session;
  final NeuraSandbox sandbox;
  final NeuraCryptoVault vault;

  NeuraEncryptedSessionActions({
    NeuraEncryptedSession? session,
    NeuraSandbox? sandbox,
    NeuraCryptoVault? vault,
  })  : session = session ?? NeuraEncryptedSession(),
        sandbox = sandbox ?? NeuraSandbox(),
        vault = vault ?? NeuraCryptoVault();

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'unlock_encrypted_session',
        title: 'Unlock Encrypted Sandbox Session',
        description: 'Temporarily unlocks access to encrypted sandbox content for indexing/reading.',
        risk: NeuraRisk.high,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final pass = (req.args['passphrase'] as String?)?.trim() ?? '';
          final ttlSec = (req.args['ttlSeconds'] as int?) ?? 600;
          if (pass.isEmpty) return NeuraActionResult.error('Missing passphrase');
          session.unlock(pass, ttl: Duration(seconds: ttlSec.clamp(60, 3600)));
          return NeuraActionResult.success('Unlocked', data: {'ttlSeconds': ttlSec, 'secondsRemaining': session.secondsRemaining});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'lock_encrypted_session',
        title: 'Lock Encrypted Sandbox Session',
        description: 'Immediately forgets the encrypted session passphrase and ends access.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          session.lock();
          return NeuraActionResult.success('Locked', data: {'secondsRemaining': 0});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'encrypted_session_status',
        title: 'Encrypted Session Status',
        description: 'Returns whether encrypted content is currently unlocked.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          return NeuraActionResult.success('OK', data: {'unlocked': session.isUnlocked, 'secondsRemaining': session.secondsRemaining});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_read_text_auto',
        title: 'Read Text (Auto Decrypt if Unlocked)',
        description: 'Reads sandbox text; decrypts .enc if session is unlocked.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final rel = (req.args['path'] as String?)?.trim() ?? '';
          if (rel.isEmpty) return NeuraActionResult.error('Missing path');

          final root = await sandbox.root();
          final ent = await sandbox.resolve(rel);
          final f = File(ent.path);

          if (!sandbox.isWithinSandbox(f.path, root.path)) return NeuraActionResult.error('Denied: outside sandbox');
          if (!f.existsSync()) return NeuraActionResult.error('Not found: $rel');

          final raw = await f.readAsBytes();

          // If not encrypted, return text directly
          if (!_looksEncrypted(Uint8List.fromList(raw))) {
            final text = String.fromCharCodes(raw);
            return NeuraActionResult.success('OK', data: {'text': text, 'bytes': raw.length, 'decrypted': false});
          }

          final pass = session.passphrase;
          if (pass == null || pass.isEmpty) return NeuraActionResult.error('Encrypted file. Session is locked.');

          final plain = await vault.decryptBytes(enc: Uint8List.fromList(raw), passphrase: pass);
          final text = String.fromCharCodes(plain);
          return NeuraActionResult.success('OK', data: {'text': text, 'bytes': plain.length, 'decrypted': true});
        },
      ),
    );
  }

  bool _looksEncrypted(Uint8List bytes) {
    if (bytes.length < 4) return false;
    return bytes[0] == 0x4E && bytes[1] == 0x45 && bytes[2] == 0x4E && bytes[3] == 0x43; // NENC
  }
}
