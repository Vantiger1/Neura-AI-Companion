import 'dart:async';

/// Scoped unlock session for encrypted sandbox content.
/// This avoids “always decrypted” states and enforces explicit user approval.
class NeuraEncryptedSession {
  DateTime? _expiresAt;
  String? _passphrase;
  Timer? _timer;

  bool get isUnlocked => _expiresAt != null && DateTime.now().isBefore(_expiresAt!);

  String? get passphrase => isUnlocked ? _passphrase : null;

  int get secondsRemaining {
    if (!isUnlocked) return 0;
    return _expiresAt!.difference(DateTime.now()).inSeconds.clamp(0, 1 << 30);
  }

  void unlock(String passphrase, {Duration ttl = const Duration(minutes: 10)}) {
    _passphrase = passphrase;
    _expiresAt = DateTime.now().add(ttl);
    _timer?.cancel();
    _timer = Timer(ttl, () => lock());
  }

  void lock() {
    _timer?.cancel();
    _timer = null;
    _expiresAt = null;
    _passphrase = null;
  }
}
