import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import '../neura_action_bus/encrypted_session.dart';
import 'offline_encrypted_indexing.dart';

class NeuraOfflineEncryptedActions {
  final NeuraEncryptedIndexer enc;
  final NeuraEncryptedSession session;

  NeuraOfflineEncryptedActions({NeuraEncryptedIndexer? enc, NeuraEncryptedSession? session})
      : session = session ?? NeuraEncryptedSession(),
        enc = enc ?? NeuraEncryptedIndexer(session: session);

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'offline_index_encrypted_session',
        title: 'Index Encrypted Files (Session)',
        description: 'Decrypts and indexes .enc files into a session-only FTS table (cleared on lock).',
        risk: NeuraRisk.high,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          if (!session.isUnlocked) return NeuraActionResult.error('Encrypted session locked.');
          final maxFiles = (req.args['maxFiles'] as int?) ?? 25;
          final maxBytes = (req.args['maxBytesPerFile'] as int?) ?? (2 * 1024 * 1024);
          final n = await enc.indexEncryptedNow(maxFiles: maxFiles, maxBytesPerFile: maxBytes);
          return NeuraActionResult.success('Indexed $n encrypted file(s)', data: {'indexed': n});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'offline_search_encrypted_session',
        title: 'Search Encrypted Session Index',
        description: 'Searches session-only decrypted index for encrypted files.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          if (!session.isUnlocked) return NeuraActionResult.error('Encrypted session locked.');
          final q = (req.args['q'] as String?)?.trim() ?? '';
          if (q.isEmpty) return NeuraActionResult.error('Missing query');
          await enc.open();
          final hits = enc.searchSession(q, limit: (req.args['limit'] as int?) ?? 8);
          return NeuraActionResult.success('OK', data: {'q': q, 'hits': hits});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'offline_clear_encrypted_session_index',
        title: 'Clear Encrypted Session Index',
        description: 'Clears session-only decrypted index (forget decrypted view).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          await enc.open();
          enc.clearSessionIndex();
          return NeuraActionResult.success('Cleared', data: {});
        },
      ),
    );
  }
}
