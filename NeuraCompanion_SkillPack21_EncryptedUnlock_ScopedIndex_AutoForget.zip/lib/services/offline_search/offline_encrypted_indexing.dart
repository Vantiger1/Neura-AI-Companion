import 'dart:io';
import 'dart:typed_data';

import 'package:crypto/crypto.dart' as crypto;
import 'package:sqlite3/sqlite3.dart';

import '../neura_action_bus/sandbox_paths.dart';
import '../neura_action_bus/crypto_vault.dart';
import '../neura_action_bus/encrypted_session.dart';

/// Indexed view for encrypted docs during an active session.
/// This does NOT store plaintext on disk. It inserts decrypted text into FTS only
/// for the life of the session, and must be cleared when the session ends.
///
/// Implementation detail:
/// - We keep a separate FTS table `docs_fts_session` so clearing is easy.
class NeuraEncryptedIndexer {
  final NeuraSandbox sandbox;
  final NeuraCryptoVault vault;
  final NeuraEncryptedSession session;

  Database? _db;

  NeuraEncryptedIndexer({
    NeuraSandbox? sandbox,
    NeuraCryptoVault? vault,
    NeuraEncryptedSession? session,
  })  : sandbox = sandbox ?? NeuraSandbox(),
        vault = vault ?? NeuraCryptoVault(),
        session = session ?? NeuraEncryptedSession();

  Future<void> open() async {
    if (_db != null) return;
    final root = await sandbox.root();
    final dbFile = File('${root.path}${Platform.pathSeparator}.neura_index.sqlite');
    _db = sqlite3.open(dbFile.path);

    _db!.execute('''
      CREATE VIRTUAL TABLE IF NOT EXISTS docs_fts_session USING fts5(
        rel_path,
        body,
        content='',
        tokenize='porter'
      );
    ''');
  }

  void close() {
    _db?.dispose();
    _db = null;
  }

  Future<int> indexEncryptedNow({int maxFiles = 25, int maxBytesPerFile = 2 * 1024 * 1024}) async {
    if (!session.isUnlocked || session.passphrase == null) {
      throw StateError('Encrypted session is locked.');
    }
    await open();
    final root = await sandbox.root();

    final encFiles = root
        .listSync(recursive: true)
        .whereType<File>()
        .where((f) => f.path.toLowerCase().endsWith('.enc'))
        .toList();

    int count = 0;
    for (final f in encFiles) {
      if (count >= maxFiles) break;
      final rel = f.path.replaceFirst(root.path + Platform.pathSeparator, '');

      final stat = f.statSync();
      if (stat.size <= 0 || stat.size > maxBytesPerFile) continue;

      final raw = await f.readAsBytes();
      final plain = await vault.decryptBytes(enc: Uint8List.fromList(raw), passphrase: session.passphrase!);

      // best-effort utf8 decode (allow malformed)
      final text = String.fromCharCodes(plain);
      if (text.trim().isEmpty) continue;

      // Insert into session-only index
      _db!.execute('DELETE FROM docs_fts_session WHERE rel_path=?', [rel]);
      _db!.execute('INSERT INTO docs_fts_session(rel_path, body) VALUES(?,?)', [rel, text]);

      count++;
    }

    return count;
  }

  List<Map<String, dynamic>> searchSession(String query, {int limit = 8}) {
    if (_db == null) throw StateError('Open first');
    final q = query.trim();
    if (q.isEmpty) return [];

    final rs = _db!.select('''
      SELECT rel_path,
             snippet(docs_fts_session, 1, '[', ']', '…', 12) AS snip,
             bm25(docs_fts_session) AS rank
      FROM docs_fts_session
      WHERE docs_fts_session MATCH ?
      ORDER BY rank
      LIMIT ?;
    ''', [q, limit]);

    return rs.map((r) {
      final rank = (r['rank'] as num).toDouble();
      final score = 1.0 / (1.0 + rank.abs());
      return {'path': r['rel_path'], 'excerpt': r['snip'], 'score': score, 'scope': 'session'};
    }).toList();
  }

  void clearSessionIndex() {
    _db?.execute('DELETE FROM docs_fts_session;');
  }
}
