# Skill Pack 21 — Encrypted Sandbox Unlock + Scoped Indexing + Auto-Forget

This patch adds the missing privacy control: encrypted files remain private **by default** and only become searchable
during a user-approved unlock session.

## What you get
### Session Manager
- `NeuraEncryptedSession`
  - unlock(passphrase, ttl)
  - lock() (immediate forget)
  - `secondsRemaining`

### Actions
- `unlock_encrypted_session` (HIGH risk)
- `lock_encrypted_session`
- `encrypted_session_status`
- `sandbox_read_text_auto` (auto-decrypts .enc if session unlocked)

### Session-only Encrypted Index
- `NeuraEncryptedIndexer`
  - indexes decrypted text into `docs_fts_session`
  - clears instantly on demand
- Actions:
  - `offline_index_encrypted_session`
  - `offline_search_encrypted_session`
  - `offline_clear_encrypted_session_index`

## Design guarantees
- No plaintext is written to disk by this feature.
- Decrypted text lives only inside the FTS session table and can be wiped instantly.
- `.enc` files remain excluded from the normal persistent index.

## Integration
Register actions at boot:
```dart
final encSession = NeuraEncryptedSession();
NeuraEncryptedSessionActions(session: encSession).registerAll(registry);
NeuraOfflineEncryptedActions(session: encSession).registerAll(registry);
```

When user locks session, also clear session index:
```dart
await executor.execute('offline_clear_encrypted_session_index');
await executor.execute('lock_encrypted_session');
```

## Recommended UX
- Use your existing “Full Access” checklist + disclaimer flow.
- Add a dedicated “Unlock Encrypted Files” button with TTL slider (5–30 minutes).
- Always show a visible timer badge while unlocked.

## Next
Step 22: merge search results across (persistent + session) with unified citations + “sources panel”.
