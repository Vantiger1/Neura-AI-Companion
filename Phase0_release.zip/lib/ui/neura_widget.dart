import 'package:flutter/widgets.dart';
import 'package:rive/rive.dart';

class NeuraWidget extends StatefulWidget {
  @override
  _NeuraWidgetState createState() => _NeuraWidgetState();
}

class _NeuraWidgetState extends State<NeuraWidget> {
  String _currentState = 'idle';

  @override
  Widget build(BuildContext context) {
    switch (_currentState) {
      case 'greeting':
        return Image.asset('assets/animations/neura_wave.png');
      default:
        return RiveAnimation.asset('assets/animations/your_neura_idle.riv');
    }
  }
}
