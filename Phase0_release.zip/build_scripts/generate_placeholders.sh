#!/usr/bin/env bash
BASE=assets/animations
mkdir -p $BASE
for mood in portrait wave idle; do
  touch $BASE/your_neura_${mood}.riv
done
