const express=require('express'), bodyParser=require('body-parser'),
  rateLimit=require('express-rate-limit'), sqlite3=require('sqlite3').verbose(), path=require('path');
const app=express(); app.use(bodyParser.json());
const db=new sqlite3.Database(path.resolve(__dirname,'neura.db'));
db.serialize(()=>{
  db.run(`CREATE TABLE IF NOT EXISTS permissions(feature TEXT PRIMARY KEY, enabled INTEGER)`);
  ['envAI'].forEach(f=>db.run(`INSERT OR IGNORE INTO permissions(feature, enabled) VALUES(?,0)`,f));
});
const limiter=rateLimit({windowMs:60000,max:5,message:{error:'Too many requests'}});
let nextAction=null;
app.use((req,res,next)=>{
  const key=req.header('x-api-key'); if(!key||key!==process.env.NEURA_API_KEY) return res.status(401).json({error:'Unauthorized'}); next();
});
app.post('/api/neura/event',limiter,(req,res)=>{
  const{event,data}=req.body;
  if(event==='permissionUpdate'){
    db.run(`UPDATE permissions SET enabled=? WHERE feature=?`,[data.enabled?1:0,data.feature]);
    nextAction={action:'confirmPermission',params:data};
  } else if(event==='emergencyRequest'){
    nextAction={action:'emergencyResponse',params:{message:'Contacting services...'}};
  } else if(event==='moodDetected'){
    if(data.mood==='Mad') nextAction={action:'calmMood',params:{}};
    if(data.mood==='Sad') nextAction={action:'upliftMood',params:{}};
  }
  res.sendStatus(200);
});
app.get('/api/neura/next-action',(req,res)=>{
  const a=nextAction||{action:null,params:{}};
  nextAction=null; res.json(a);
});
app.get('/api/neura/permissions',(req,res)=>{
  db.all(`SELECT feature,enabled FROM permissions`,(e,rows)=>{
    if(e) return res.status(500).json({error:'DB error'}); const p={};rows.forEach(r=>p[r.feature]=!!r.enabled);res.json(p);
  });
});
app.listen(3000,()=>console.log('Server on 3000'));