# Neura Complete Project

## Frontend
- `frontend/index.html`: 3D dashboard & AR demo integrating Neura models, modules, and AI control.
- `frontend/models/`: placeholder GLB models and background music.

## Server
- `server/server.js`: Express server with SQLite persistence, permission safeguards, and AI event handling.

## Scripts
- `scripts/generate_full_neura_scene.py`: Blender script to create advanced models and environment assets.

## Usage
1. Place real `.glb` models in `frontend/models` and `background_music.mp3`.
2. `npm install sqlite3 express body-parser express-rate-limit`
3. `export NEURA_API_KEY=your_key && node server/server.js`
4. Serve `frontend/index.html` over HTTPS for WebXR (e.g., `npx http-server frontend -c-1 -S`).
5. Open in Chrome Android or a WebXR-capable browser.

Permission toggles, AI control, mood reactions, environment modules, and AR placement are all integrated.

