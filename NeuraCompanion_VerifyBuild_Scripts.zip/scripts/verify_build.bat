\
@echo off
setlocal EnableExtensions

REM Wrapper for PowerShell verify_build.ps1
REM Usage: scripts\verify_build.bat "C:\path\to\repo"

set "TARGET=%~1"
if "%TARGET%"=="" set "TARGET=%CD%"

powershell -ExecutionPolicy Bypass -File "%~dp0verify_build.ps1" -Target "%TARGET%" -Android -Windows -Release
exit /b %ERRORLEVEL%
