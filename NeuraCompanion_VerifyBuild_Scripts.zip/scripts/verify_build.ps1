\
param(
  [Parameter(Mandatory=$false)]
  [string]$Target = "",
  [switch]$Android,
  [switch]$Windows,
  [switch]$Aab,          # Android App Bundle instead of APK
  [switch]$Release,      # Release mode build (default debug if neither specified)
  [switch]$Debug,
  [switch]$SkipTests,
  [switch]$Clean,
  [string]$Flutter = "flutter"
)

$ErrorActionPreference = "Stop"

function Test-FlutterRepo($p) {
  return (Test-Path (Join-Path $p "pubspec.yaml")) -and (Test-Path (Join-Path $p "lib"))
}

function Find-Repo([string]$start) {
  $cur = Resolve-Path $start
  for ($i=0; $i -lt 6; $i++) {
    if (Test-FlutterRepo $cur) { return $cur }
    $parent = Split-Path $cur -Parent
    if ($parent -eq $cur) { break }
    $cur = $parent
  }
  return $null
}

function New-ReportDir($repo) {
  $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
  $dir = Join-Path $repo "__neura_build_reports__\$stamp"
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  return $dir
}

function Write-File($path, $content) {
  $content | Out-File -FilePath $path -Encoding utf8 -Force
}

function Run-Step($name, $cmd, $logPath) {
  Write-Host "==> $name"
  Write-Host "    $cmd"
  $out = & powershell -NoProfile -Command "$cmd" 2>&1 | Out-String
  Write-File $logPath $out
  return $out
}

# Resolve target
$bundleRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
if ([string]::IsNullOrWhiteSpace($Target)) {
  $Target = (Find-Repo (Get-Location).Path)
  if ($null -eq $Target) { $Target = (Find-Repo $bundleRoot) }
}
if ($null -eq $Target -or [string]::IsNullOrWhiteSpace($Target)) {
  Write-Host "ERROR: Could not auto-detect repo. Provide -Target path." -ForegroundColor Red
  exit 2
}
$Target = (Resolve-Path $Target).Path
if (!(Test-FlutterRepo $Target)) {
  Write-Host "ERROR: Target does not look like a Flutter repo (missing pubspec.yaml or lib/)." -ForegroundColor Red
  exit 3
}

# Default platforms: if none specified, do both
if (-not $Android.IsPresent -and -not $Windows.IsPresent) {
  $Android = $true
  $Windows = $true
}

# Build mode
$mode = "debug"
if ($Release.IsPresent -and -not $Debug.IsPresent) { $mode = "release" }
if ($Debug.IsPresent -and -not $Release.IsPresent) { $mode = "debug" }

Push-Location $Target
$reportDir = New-ReportDir $Target

$paths = @{
  doctor = Join-Path $reportDir "env_doctor.txt"
  pubget = Join-Path $reportDir "pub_get.txt"
  analyze = Join-Path $reportDir "analyze.txt"
  tests = Join-Path $reportDir "tests.txt"
  buildAndroid = Join-Path $reportDir "build_android.txt"
  buildWindows = Join-Path $reportDir "build_windows.txt"
  report = Join-Path $reportDir "report.md"
}

$summary = New-Object System.Collections.Generic.List[string]
$summary.Add("# Neura Companion — Verify + Build Report")
$summary.Add("")
$summary.Add("- Repo: `$Target`")
$summary.Add("- Timestamp: `$(Get-Date -Format o)`")
$summary.Add("- Platforms: Android=$Android Windows=$Windows")
$summary.Add("- Mode: $mode")
$summary.Add("- AAB: $($Aab.IsPresent)")
$summary.Add("- SkipTests: $($SkipTests.IsPresent)")
$summary.Add("- Clean: $($Clean.IsPresent)")
$summary.Add("")

try {
  if ($Clean.IsPresent) {
    Run-Step "flutter clean" "$Flutter clean" (Join-Path $reportDir "clean.txt") | Out-Null
  }

  $doctor = Run-Step "flutter doctor -v" "$Flutter doctor -v" $paths.doctor
  $summary.Add("## Environment")
  $summary.Add("Logs: env_doctor.txt")
  $summary.Add("")

  $pub = Run-Step "flutter pub get" "$Flutter pub get" $paths.pubget
  $summary.Add("## Dependencies")
  $summary.Add("Logs: pub_get.txt")
  $summary.Add("")

  $an = Run-Step "flutter analyze" "$Flutter analyze" $paths.analyze
  $anOk = ($an -notmatch "error •")
  $summary.Add("## Static Analysis")
  $summary.Add("- Status: " + ($(if($anOk){"PASS"}else{"FAIL"})))
  $summary.Add("Logs: analyze.txt")
  $summary.Add("")

  $testOk = $true
  if (-not $SkipTests.IsPresent) {
    $t = Run-Step "flutter test" "$Flutter test" $paths.tests
    $testOk = ($t -notmatch "FAILED") -and ($t -notmatch "Some tests failed")
    $summary.Add("## Tests")
    $summary.Add("- Status: " + ($(if($testOk){"PASS"}else{"FAIL"})))
    $summary.Add("Logs: tests.txt")
    $summary.Add("")
  } else {
    Write-File $paths.tests "SKIPPED"
    $summary.Add("## Tests")
    $summary.Add("- Status: SKIPPED")
    $summary.Add("Logs: tests.txt")
    $summary.Add("")
  }

  $androidOk = $true
  if ($Android.IsPresent) {
    if ($Aab.IsPresent) {
      $cmd = "$Flutter build appbundle --$mode"
    } else {
      $cmd = "$Flutter build apk --$mode"
    }
    $b = Run-Step "Android build" $cmd $paths.buildAndroid
    $androidOk = ($b -notmatch "FAILURE: Build failed") -and ($b -notmatch "Exception:") -and ($b -notmatch "BUILD FAILED")
    $summary.Add("## Android Build")
    $summary.Add("- Status: " + ($(if($androidOk){"PASS"}else{"FAIL"})))
    $summary.Add("- Artifact: see `build/app/outputs/`")
    $summary.Add("Logs: build_android.txt")
    $summary.Add("")
  } else {
    Write-File $paths.buildAndroid "SKIPPED"
  }

  $windowsOk = $true
  if ($Windows.IsPresent) {
    # Ensure windows desktop enabled (safe to call; no-op if already enabled)
    Run-Step "flutter config --enable-windows-desktop" "$Flutter config --enable-windows-desktop" (Join-Path $reportDir "enable_windows.txt") | Out-Null

    $cmd = "$Flutter build windows --$mode"
    $bw = Run-Step "Windows build" $cmd $paths.buildWindows
    $windowsOk = ($bw -notmatch "FAILURE: Build failed") -and ($bw -notmatch "Exception:") -and ($bw -notmatch "BUILD FAILED")
    $summary.Add("## Windows Build")
    $summary.Add("- Status: " + ($(if($windowsOk){"PASS"}else{"FAIL"})))
    $summary.Add("- Artifact: `build/windows/x64/runner/`")
    $summary.Add("Logs: build_windows.txt")
    $summary.Add("")
  } else {
    Write-File $paths.buildWindows "SKIPPED"
  }

  $allOk = $anOk -and $testOk -and $androidOk -and $windowsOk
  $summary.Add("## Overall")
  $summary.Add("- Result: " + ($(if($allOk){"PASS"}else{"FAIL"})))
  $summary.Add("")
  $summary.Add("## Log Files")
  $summary.Add("- env_doctor.txt")
  $summary.Add("- pub_get.txt")
  $summary.Add("- analyze.txt")
  $summary.Add("- tests.txt")
  $summary.Add("- build_android.txt")
  $summary.Add("- build_windows.txt")
  $summary.Add("")

  Write-File $paths.report ($summary -join "`n")

  if (-not $allOk) {
    Write-Host "Build finished with FAIL. See report: $($paths.report)" -ForegroundColor Yellow
    exit 10
  }

  Write-Host "Build finished PASS. Report: $($paths.report)" -ForegroundColor Green
  exit 0
}
catch {
  $msg = $_.Exception.ToString()
  Write-File (Join-Path $reportDir "fatal_error.txt") $msg

  $summary.Add("## Fatal Error")
  $summary.Add("See fatal_error.txt")
  Write-File $paths.report ($summary -join "`n")

  Write-Host "FATAL: $msg" -ForegroundColor Red
  exit 99
}
finally {
  Pop-Location
}
