## Notes / Requirements

### Android build
- Android SDK + build-tools installed
- JAVA_HOME configured (JDK 17 recommended)
- Gradle can download dependencies

### Windows build
- Visual Studio Build Tools / Visual Studio with Desktop development with C++
- CMake + Ninja usually installed by Flutter tooling, but VS workload is key

### Exit codes
- 0: success
- 10: analysis/tests/build failed (see report)
- 2/3: repo detection failed
- 99: fatal exception in script
