# Neura Companion — Verify + Build Tooling (Android + Windows)

This pack adds a one-command verification and build pipeline for your Flutter repo:
- `flutter doctor -v`
- `flutter pub get`
- `flutter analyze`
- `flutter test` (optional)
- Build Android APK/AAB (optional)
- Build Windows runner (optional)
- Produces a timestamped build report + logs in `__neura_build_reports__/`

## PowerShell (recommended)
```powershell
# Run from inside your repo or pass -Target:
powershell -ExecutionPolicy Bypass -File .\scripts\verify_build.ps1 -Target "C:\path\to\repo" -Android -Windows -Release
```

## Batch
```bat
scripts\verify_build.bat "C:\path\to\repo"
```

## Outputs
A folder like:
`__neura_build_reports__/20260126_150000/`
containing:
- `report.md`
- `env_doctor.txt`
- `pub_get.txt`
- `analyze.txt`
- `tests.txt`
- `build_android.txt`
- `build_windows.txt`
