import 'dart:collection';

class NeuraUndoEntry {
  final String title;
  final String undoActionId;
  final Map<String, dynamic> undoArgs;

  const NeuraUndoEntry({
    required this.title,
    required this.undoActionId,
    required this.undoArgs,
  });
}

class NeuraUndoStack {
  final ListQueue<NeuraUndoEntry> _q = ListQueue();

  int get length => _q.length;

  void push(NeuraUndoEntry e) {
    _q.addFirst(e);
    while (_q.length > 50) {
      _q.removeLast();
    }
  }

  NeuraUndoEntry? pop() => _q.isEmpty ? null : _q.removeFirst();
  NeuraUndoEntry? peek() => _q.isEmpty ? null : _q.first;

  List<NeuraUndoEntry> snapshot() => _q.toList(growable: false);
  void clear() => _q.clear();
}
