import 'dart:io';

import 'package:path_provider/path_provider.dart';

/// NeuraSandbox: a strict file sandbox used for allowlisted file operations.
/// All operations must stay within this directory.
class NeuraSandbox {
  static const String folderName = 'neura_sandbox';
  static const String trashFolderName = '.trash';

  Future<Directory> root() async {
    final dir = await getApplicationDocumentsDirectory();
    final root = Directory('${dir.path}${Platform.pathSeparator}$folderName');
    if (!root.existsSync()) root.createSync(recursive: true);
    final trash = Directory('${root.path}${Platform.pathSeparator}$trashFolderName');
    if (!trash.existsSync()) trash.createSync(recursive: true);
    return root;
  }

  Future<Directory> trash() async {
    final r = await root();
    final t = Directory('${r.path}${Platform.pathSeparator}$trashFolderName');
    if (!t.existsSync()) t.createSync(recursive: true);
    return t;
  }

  /// Resolve a user-relative path inside the sandbox.
  /// Rejects traversal and absolute paths.
  Future<FileSystemEntity> resolve(String relativePath) async {
    final r = await root();
    final cleaned = _clean(relativePath);
    final full = '${r.path}${Platform.pathSeparator}$cleaned';
    return File(full);
  }

  String _clean(String p) {
    var s = p.trim();
    s = s.replaceAll('\\', Platform.pathSeparator).replaceAll('/', Platform.pathSeparator);
    while (s.startsWith(Platform.pathSeparator)) {
      s = s.substring(1);
    }
    if (s.contains('..')) {
      throw StateError('Path traversal is not allowed.');
    }
    return s;
  }

  bool isWithinSandbox(String fullPath, String sandboxRootPath) {
    final normFull = File(fullPath).absolute.path;
    final normRoot = Directory(sandboxRootPath).absolute.path;
    return normFull.startsWith(normRoot);
  }
}
