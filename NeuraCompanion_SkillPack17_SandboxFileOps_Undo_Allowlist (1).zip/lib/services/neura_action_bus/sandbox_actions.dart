import 'dart:io';

import 'neura_action.dart';
import 'action_registry.dart';
import 'sandbox_paths.dart';
import 'undo_stack.dart';

class NeuraSandboxActions {
  final NeuraSandbox sandbox;
  final NeuraUndoStack undo;

  NeuraSandboxActions({NeuraSandbox? sandbox, NeuraUndoStack? undo})
      : sandbox = sandbox ?? NeuraSandbox(),
        undo = undo ?? NeuraUndoStack();

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'sandbox_list',
        title: 'List Sandbox Files',
        description: 'Lists files inside Neura’s sandbox directory.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final root = await sandbox.root();
          final items = root
              .listSync(recursive: true)
              .where((e) => !e.path.contains('${Platform.pathSeparator}${NeuraSandbox.trashFolderName}${Platform.pathSeparator}'))
              .map((e) => e.path.replaceFirst(root.path + Platform.pathSeparator, ''))
              .toList()
            ..sort();
          return NeuraActionResult.success('OK', data: {'root': root.path, 'items': items});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_write_text',
        title: 'Write Text File (Sandbox)',
        description: 'Writes a text file inside Neura’s sandbox (undo supported).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final rel = (req.args['path'] as String?)?.trim() ?? '';
          final content = (req.args['content'] as String?) ?? '';
          if (rel.isEmpty) return NeuraActionResult.error('Missing path');

          final root = await sandbox.root();
          final ent = await sandbox.resolve(rel);
          final f = File(ent.path);
          if (!sandbox.isWithinSandbox(f.path, root.path)) {
            return NeuraActionResult.error('Denied: outside sandbox');
          }

          String? previous;
          if (f.existsSync()) {
            previous = f.readAsStringSync();
          } else {
            f.parent.createSync(recursive: true);
          }
          f.writeAsStringSync(content);

          undo.push(
            NeuraUndoEntry(
              title: 'Undo write: $rel',
              undoActionId: 'sandbox_write_text',
              undoArgs: {'path': rel, 'content': previous ?? ''},
            ),
          );

          return NeuraActionResult.success('Wrote file', data: {'path': rel, 'previousContent': previous});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_rename',
        title: 'Rename (Sandbox)',
        description: 'Renames a file inside the sandbox (undo supported).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final from = (req.args['from'] as String?)?.trim() ?? '';
          final to = (req.args['to'] as String?)?.trim() ?? '';
          if (from.isEmpty || to.isEmpty) return NeuraActionResult.error('Missing from/to');

          final root = await sandbox.root();
          final srcEnt = await sandbox.resolve(from);
          final dstEnt = await sandbox.resolve(to);

          final src = File(srcEnt.path);
          final dst = File(dstEnt.path);

          if (!sandbox.isWithinSandbox(src.path, root.path) || !sandbox.isWithinSandbox(dst.path, root.path)) {
            return NeuraActionResult.error('Denied: outside sandbox');
          }
          if (!src.existsSync()) return NeuraActionResult.error('Source not found: $from');

          dst.parent.createSync(recursive: true);
          src.renameSync(dst.path);

          undo.push(
            NeuraUndoEntry(
              title: 'Undo rename: $to → $from',
              undoActionId: 'sandbox_rename',
              undoArgs: {'from': to, 'to': from},
            ),
          );

          return NeuraActionResult.success('Renamed', data: {'from': from, 'to': to});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_move',
        title: 'Move (Sandbox)',
        description: 'Moves a file inside the sandbox (undo supported).',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final from = (req.args['from'] as String?)?.trim() ?? '';
          final to = (req.args['to'] as String?)?.trim() ?? '';
          if (from.isEmpty || to.isEmpty) return NeuraActionResult.error('Missing from/to');

          final root = await sandbox.root();
          final srcEnt = await sandbox.resolve(from);
          final dstEnt = await sandbox.resolve(to);

          final src = File(srcEnt.path);
          final dst = File(dstEnt.path);

          if (!sandbox.isWithinSandbox(src.path, root.path) || !sandbox.isWithinSandbox(dst.path, root.path)) {
            return NeuraActionResult.error('Denied: outside sandbox');
          }
          if (!src.existsSync()) return NeuraActionResult.error('Source not found: $from');

          dst.parent.createSync(recursive: true);
          src.renameSync(dst.path);

          undo.push(
            NeuraUndoEntry(
              title: 'Undo move: $to → $from',
              undoActionId: 'sandbox_move',
              undoArgs: {'from': to, 'to': from},
            ),
          );

          return NeuraActionResult.success('Moved', data: {'from': from, 'to': to});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_delete',
        title: 'Delete (Sandbox)',
        description: 'Deletes a file by moving it to sandbox trash (undo supported).',
        risk: NeuraRisk.high,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final path = (req.args['path'] as String?)?.trim() ?? '';
          if (path.isEmpty) return NeuraActionResult.error('Missing path');

          final root = await sandbox.root();
          final trash = await sandbox.trash();
          final ent = await sandbox.resolve(path);
          final src = File(ent.path);

          if (!sandbox.isWithinSandbox(src.path, root.path)) return NeuraActionResult.error('Denied: outside sandbox');
          if (!src.existsSync()) return NeuraActionResult.error('Not found: $path');

          final stamp = DateTime.now().millisecondsSinceEpoch;
          final trashedName = '$stamp-${path.replaceAll(Platform.pathSeparator, '_')}';
          final trashedRel = '${NeuraSandbox.trashFolderName}/$trashedName';
          final dst = File('${trash.path}${Platform.pathSeparator}$trashedName');

          dst.parent.createSync(recursive: true);
          src.renameSync(dst.path);

          undo.push(
            NeuraUndoEntry(
              title: 'Undo delete: $path',
              undoActionId: 'sandbox_restore_from_trash',
              undoArgs: {'trashPath': trashedRel, 'restoreTo': path},
            ),
          );

          return NeuraActionResult.success('Moved to trash', data: {'path': path, 'trashPath': trashedRel});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_restore_from_trash',
        title: 'Restore from Trash (Sandbox)',
        description: 'Restores a previously deleted file from sandbox trash.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final trashPath = (req.args['trashPath'] as String?)?.trim() ?? '';
          final restoreTo = (req.args['restoreTo'] as String?)?.trim() ?? '';
          if (trashPath.isEmpty || restoreTo.isEmpty) return NeuraActionResult.error('Missing trashPath/restoreTo');

          final root = await sandbox.root();
          final tFile = File('${root.path}${Platform.pathSeparator}$trashPath');
          final destEnt = await sandbox.resolve(restoreTo);
          final dest = File(destEnt.path);

          if (!sandbox.isWithinSandbox(tFile.path, root.path) || !sandbox.isWithinSandbox(dest.path, root.path)) {
            return NeuraActionResult.error('Denied: outside sandbox');
          }
          if (!tFile.existsSync()) return NeuraActionResult.error('Trash item not found: $trashPath');

          dest.parent.createSync(recursive: true);
          tFile.renameSync(dest.path);

          return NeuraActionResult.success('Restored', data: {'trashPath': trashPath, 'restoreTo': restoreTo});
        },
      ),
    );

    reg.register(
      NeuraAction(
        id: 'sandbox_undo_last',
        title: 'Undo Last Sandbox Change',
        description: 'Reverts the most recent sandbox change if possible.',
        risk: NeuraRisk.medium,
        capability: NeuraCapability.fileAccess,
        handler: (req) async {
          final entry = undo.pop();
          if (entry == null) return NeuraActionResult.error('Nothing to undo.');
          return NeuraActionResult.success('UNDO_READY', data: {
            'title': entry.title,
            'undoActionId': entry.undoActionId,
            'undoArgs': entry.undoArgs,
          });
        },
      ),
    );
  }
}
