# Skill Pack 17 — Sandbox File Ops (Allowlisted) + Real Undo

This patch expands Neura’s OS capabilities safely by introducing a strict file sandbox.

## What you get
- `NeuraSandbox`: a dedicated folder inside app documents (`neura_sandbox/`)
- Allowlisted sandbox actions:
  - `sandbox_list`
  - `sandbox_write_text` (undo supported)
  - `sandbox_rename` (undo supported)
  - `sandbox_move` (undo supported)
  - `sandbox_delete` (HIGH risk; moves to `.trash/` and supports restore undo)
  - `sandbox_restore_from_trash`
  - `sandbox_undo_last` (returns an undo payload)
- `NeuraSuggestionMapper` updated to support sandbox suggestion types.

## Integration
1) Register sandbox actions at boot (recommended in your `NeuraKernel.boot()` after builtin actions):
```dart
final undo = NeuraUndoStack();
NeuraSandboxActions(undo: undo).registerAll(registry);
```

2) Handling UNDO_READY
`sandbox_undo_last` returns message `UNDO_READY` with payload:
- `undoActionId`
- `undoArgs`

Route it through your existing executor:
```dart
final u = result.data;
await executor.execute(u['undoActionId'], args: Map<String,dynamic>.from(u['undoArgs']));
```

## Dependency
This patch uses `path_provider`. Ensure `pubspec.yaml` includes:
- path_provider: any
Then run `flutter pub get`.

## Next
Step 18: sandbox import/export (file picker) + optional encrypted sandbox.
