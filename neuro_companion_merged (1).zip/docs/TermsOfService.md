# Terms of Service

_Last updated: YYYY-MM-DD_

**Acceptance of Terms**

By using Neura Companion, you agree to these terms.

**Use of the App**

- You must be 13+ to use the app.
- You may not resell or misuse the service.

**Subscriptions & Payments**

- Billing occurs via Google Play / Stripe.
- Refunds subject to provider policies.

**Intellectual Property**

All content and code are © 2025 Neura Companion.

**Limitation of Liability**

Use at your own risk; no warranty.

**Governing Law**

These terms are governed by the laws of [Your Jurisdiction].

**Contact**

support@neura.com
