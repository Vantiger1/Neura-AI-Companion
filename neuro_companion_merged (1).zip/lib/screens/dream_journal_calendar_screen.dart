import 'package:flutter/material.dart';

class DreamJournalCalendarScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    // TODO: implement calendar UI with entries
    return Scaffold(
      appBar: AppBar(title: Text('Dream Journal')),
      body: Center(child: Text('Dream Calendar Screen')),
    );
  }
}
