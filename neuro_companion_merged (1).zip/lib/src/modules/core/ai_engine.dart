class AICompanionEngine {
  static String respondToMood(String mood) {
    return "Based on your mood '$mood', I suggest a calming meditation and light journaling.";
  }

  static String suggestGoal(String category) {
    return "Today's goal in $category: Write one page in your journal.";
  }
}