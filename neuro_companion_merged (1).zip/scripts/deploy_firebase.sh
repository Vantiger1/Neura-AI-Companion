#!/bin/bash
# CI/CD deploy script for Firebase Hosting
echo "Building Flutter Web..."
flutter build web --release
echo "Deploying to Firebase..."
firebase deploy --only hosting
