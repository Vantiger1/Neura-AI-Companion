
# Neura Unified (Readable)
Includes:
- NeuraRig v2.1a (external-authority; manual by default)
- NeuraBehavior v2.3 (priority stack + calm/warm futuristic presets)
- Demo HTML with a minimal scaffold SVG (IDs match your real rig).

## Usage
1) Include the JS:
```html
<script src="neura_unified_v2_3.js"></script>
```
2) Keep your API in charge:
```js
NeuraRig.setEngineMode('manual');
NeuraRig.setAutoLoops({ blink:false, breathe:false, attention:false });
```
3) Layer behaviors:
```js
const greet = NeuraBehavior.presets.greeting();
setTimeout(() => {
  const listen = NeuraBehavior.presets.listening();
  NeuraBehavior.stop(greet);
}, 900);
```

Swap the scaffold for your production SVG (keep the IDs).
