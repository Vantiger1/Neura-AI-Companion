/* NeuraRig v2.1a (Readable) — see previous message for details */

(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("NeuraRig: #neuraRig root not found"); return; }
  const clamp=(x,a,b)=>Math.max(a,Math.min(b,x));
  const clamp01=x=>clamp(x,0,1);
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };

  // Ensure highlights
  (function(){
    ["L","R"].forEach(side=>{
      const eye = document.querySelector(`#eye_${side}`);
      if(!eye) return;
      if(!document.querySelector(`#hl_${side}`)){
        const hl = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
        hl.setAttribute("id", `hl_${side}`); hl.setAttribute("rx","6"); hl.setAttribute("ry","4");
        hl.setAttribute("fill","#ffffff"); hl.setAttribute("opacity","0.85");
        eye.appendChild(hl);
      }
    });
  })();

  // Eyes/gaze
  function _applyGaze(dx,dy){
    [["L",460],["R",540]].forEach(([s,cx])=>{
      const i=$(`#iris_${s}`), p=$(`#pupil_${s}`), h=$(`#hl_${s}`);
      const x=cx+dx, y=780+dy;
      if(i){ i.setAttribute("cx",x); i.setAttribute("cy",y); }
      if(p){ p.setAttribute("cx",x); p.setAttribute("cy",y); }
      if(h){ h.setAttribute("cx", x-6); h.setAttribute("cy", y-6); }
    });
  }
  function setGaze(dx,dy){ _applyGaze(dx,dy); }
  let gazeTarget={x:0,y:0}, gazeState={x:0,y:0}, gvx=0, gvy=0, gazeRAF=null;
  function lookAt(x,y, stiffness=32, damping=6){
    gazeTarget={x,y};
    if(gazeRAF) return;
    const step=()=>{
      const ax = stiffness*(gazeTarget.x - gazeState.x) - damping*gvx;
      const ay = stiffness*(gazeTarget.y - gazeState.y) - damping*gvy;
      const dt=1/60;
      gvx += ax*dt; gvy += ay*dt;
      gazeState.x += gvx*dt; gazeState.y += gvy*dt;
      _applyGaze(gazeState.x, gazeState.y);
      const head=$("#head"); if(head) setRotation(head, Math.max(-6, Math.min(6, gazeState.x*0.6)));
      if(Math.hypot(gazeTarget.x-gazeState.x, gazeTarget.y-gazeState.y) > 0.01 || Math.hypot(gvx,gvy) > 0.01){
        gazeRAF=requestAnimationFrame(step);
      } else { gazeRAF=null; gvx=gvy=0; }
    };
    gazeRAF=requestAnimationFrame(step);
  }
  function saccadeBurst(intensity=1){
    const step=(dx,dy,delay)=> setTimeout(()=> setGaze(dx,dy), delay);
    const dx1=(Math.random()-.5)*4*intensity, dy1=(Math.random()-.5)*3*intensity;
    const dx2=(Math.random()-.5)*2*intensity, dy2=(Math.random()-.5)*2*intensity;
    step(dx1,dy1, 0); step(dx1+dx2, dy1+dy2, 60); step(0,0, 160);
  }

  // Lids + blink/glint
  let lidTargetL=1, lidTargetR=1, lidOpenL=1, lidOpenR=1, lvL=0, lvR=0, lidRAF=null;
  function setLids(open=1){
    if(Array.isArray(open)){ lidTargetL=clamp01(open[0]); lidTargetR=clamp01(open[1]??open[0]); }
    else { lidTargetL=lidTargetR=clamp01(open); }
    if(!lidRAF){ lidRAF=requestAnimationFrame(lidStep); }
  }
  function setEyeOpennessRaw(side, open){
    const span=22;
    const u=$(`#lidU_${side}`), l=$(`#lidL_${side}`);
    if(!u||!l) return;
    const upperH=(1-open)*span, lowerH=(1-open)*span;
    u.setAttribute("y",780-22); u.setAttribute("height",upperH);
    l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
  }
  function lidStep(){
    const kOpen=42, cOpen=6, kClose=26, cClose=5, dt=1/60;
    const kL = (lidTargetL > lidOpenL) ? kOpen : kClose;
    const cL = (lidTargetL > lidOpenL) ? cOpen : cClose;
    const aL = kL*(lidTargetL - lidOpenL) - cL*lvL;
    lvL += aL*dt; lidOpenL = clamp01(lidOpenL + lvL*dt);
    const kR = (lidTargetR > lidOpenR) ? kOpen : kClose;
    const cR = (lidTargetR > lidOpenR) ? cOpen : cClose;
    const aR = kR*(lidTargetR - lidOpenR) - cR*lvR;
    lvR += aR*dt; lidOpenR = clamp01(lidOpenR + lvR*dt);
    setEyeOpennessRaw("L", lidOpenL); setEyeOpennessRaw("R", lidOpenR);
    ["L","R"].forEach(s=>{ const h=$(`#hl_${s}`); const open=(s==="L"? lidOpenL: lidOpenR); if(h) h.setAttribute("opacity",(0.5+0.5*open).toFixed(2)); });
    if(Math.abs(lidTargetL-lidOpenL)>0.002 || Math.abs(lidTargetR-lidOpenR)>0.002 || Math.abs(lvL)>0.002 || Math.abs(lvR)>0.002){
      lidRAF=requestAnimationFrame(lidStep);
    } else { lidRAF=null; }
  }
  let blinkSkew=0; function setBlinkAsymmetry(skew=0){ blinkSkew=Math.max(-1, Math.min(1, skew)); }
  function glintFlash(){ ["L","R"].forEach(s=>{ const h=$(`#hl_${s}`); if(!h) return; h.setAttribute("opacity","1"); h.setAttribute("rx","8"); h.setAttribute("ry","5"); setTimeout(()=>{ h.setAttribute("opacity","0.85"); h.setAttribute("rx","6"); h.setAttribute("ry","4"); }, 90); }); }
  function blinkOnce(duration=120){
    const skewMs = 40 * blinkSkew;
    setTimeout(()=> setLids([0, lidOpenR]), Math.max(0, -skewMs));
    setTimeout(()=> setLids([lidOpenL, 0]), Math.max(0,  skewMs));
    setTimeout(()=> { setLids(1); glintFlash(); }, duration + Math.abs(skewMs));
  }

  // Loops (off until enabled)
  const loops = { blink:false, breathe:false, attention:false };
  function setAutoLoops(opts={}){
    if(typeof opts.blink==='boolean') loops.blink = opts.blink;
    if(typeof opts.breathe==='boolean') loops.breathe = opts.breathe;
    if(typeof opts.attention==='boolean') loops.attention = opts.attention;
  }
  function autoBlink(on=true, min=2200, max=5200){
    loops.blink = !!on;
    if(!on) return;
    const loop=()=>{ if(!loops.blink) return; blinkOnce(120); setTimeout(loop, Math.random()*(max-min)+min); };
    loop();
  }

  // Pupils & affect
  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }
  function setAmbientLuminance(l){ l=clamp01(l); setPupil(10 - 7*l); }
  function audioReact(level){ level=clamp01(level); setPupil(6 + 3*level); const head=$("#head"); if(head) setRotation(head, (level-0.5)*2); }
  function setAffect({browLift=0, smile=0}={}){
    const bl=$("#brow_left"), br=$("#brow_right"), neutral=$("#viseme_X");
    if(bl&&br){
      bl.setAttribute("d", `M440,${740-browLift} C455,${730-browLift} 470,${730-browLift} 485,${740-browLift}`);
      br.setAttribute("d", `M515,${740-browLift} C530,${730-browLift} 545,${730-browLift} 560,${740-browLift}`);
    }
    if(neutral){
      const mid = 860 + 10*smile;
      const corner = 845 - 12*Math.max(0,smile);
      neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
      applyCheekLowerLid(Math.max(0,smile));
    }
  }
  function setAffectPlus({squintL=0, squintR=0, cheek=0, nose=0, browTilt=0}={}){
    const openL = clamp01(1 - 0.6*squintL);
    const openR = clamp01(1 - 0.6*squintR);
    setLids([openL, openR]);
    const neutral=$("#viseme_X");
    if(neutral){
      const cornerLift = 12*cheek;
      const mid = 860 + 6*cheek;
      const cornerY = 845 - cornerLift;
      neutral.setAttribute("d", `M455,${cornerY} Q500,${mid} 545,${cornerY}`);
      applyCheekLowerLid(cheek);
    }
    const bl=$("#brow_left"), br=$("#brow_right");
    if(bl&&br){
      const shift = 6*nose, tilt = browTilt||0;
      bl.setAttribute("d", `M440,${740-shift+tilt*0.2} C455,${730-shift+tilt*0.2} 470,${730-shift} 485,${740-shift}`);
      br.setAttribute("d", `M515,${740-shift-tilt*0.2} C530,${730-shift-tilt*0.2} 545,${730-shift} 560,${740-shift}`);
    }
  }
  function applyCheekLowerLid(cheek){
    cheek=clamp01(cheek);
    const maxRaise=6, raise=maxRaise*cheek;
    ["L","R"].forEach(side=>{
      const l=$(`#lidL_${side}`);
      if(l){
        const h=parseFloat(l.getAttribute("height")||"0");
        const nh=h + raise/2;
        l.setAttribute("height", nh);
        l.setAttribute("y", 780+22-nh);
      }
    });
  }
  function smileSpring(intensity=1, {overshoot=0.18, duration=260, settle=160}={}){
    intensity=clamp01(intensity);
    const neutral=$("#viseme_X"); if(!neutral) return;
    const t0=performance.now();
    function easeOutBack(t){ const c1=1.70158, c3=c1+1; return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2); }
    function frame(){
      const t=(performance.now()-t0)/duration;
      if(t<1){
        const s=easeOutBack(t)*(1+overshoot)-overshoot;
        const corner = 845 - 12*intensity*s;
        const mid = 860 + 8*intensity*(1-s*0.5);
        neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
        applyCheekLowerLid(intensity*s*0.9);
        requestAnimationFrame(frame);
      } else {
        const s0=performance.now();
        (function settle(){
          const u=(performance.now()-s0)/settle;
          const s=1 - Math.min(1,u)*0.15;
          const corner = 845 - 12*intensity*s;
          const mid = 860 + 8*intensity*(1-s*0.5);
          neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
          applyCheekLowerLid(intensity*s*0.9);
          if(u<1) requestAnimationFrame(settle);
        })();
      }
    }
    requestAnimationFrame(frame);
  }
  const EASE = { calm: t=>t*t*(3-2*t), focused: t=>t<.3? (t/.3) : 1-(1-t)/(1-.3), amused: t=>1- Math.pow(1-t, 2.2), sad: t=>Math.pow(t,1.8), surprised: t=>t<.5? (2*t*t) : 1- Math.pow(-2*t+2,2)/2 };
  function transitionAffect(target, ms=220, mode='calm'){
    const ease = EASE[mode]||EASE.calm;
    const bl0=0, sm0=0;
    const t0=performance.now();
    function frame(){
      const u=Math.min(1, (performance.now()-t0)/ms);
      const e=ease(u);
      const browLift = (target.browLift||0)*e + bl0*(1-e);
      const smile    = (target.smile||0)*e + sm0*(1-e);
      setAffect({browLift, smile});
      if(u<1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  // Visemes
  function showViseme(n){
    $$(".viseme").forEach(v=>v.classList.add("hidden"));
    (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden");
    const mouth = document.querySelector('#mouth');
    if(mouth){
      let angle = 0;
      if(n==='A'||n==='O'||n==='WQ'){ angle = 4; }
      mouth.style.transformOrigin = '500px 845px';
      mouth.style.transform = `rotate(${angle}deg)`;
    }
  }
  const MAP={ A:["AA","AH","AO"], EE:["IY","IH","EH","EY","AE"], WQ:["UW","W"], O:["OW","OH","UH","UW"], FV:["F","V"], L:["L"], TH:["TH","DH"], MBP:["M","B","P"], X:["SIL","REST"] };
  function phonemeToViseme(ph){ ph=(ph||"").toUpperCase(); for(const [v,arr] of Object.entries(MAP)) if(arr.includes(ph)) return v; return "X"; }
  function scheduleVisemes(audio,timeline,lead=0){
    if(!timeline||!timeline.length) return; const start=performance.now()+50; audio.currentTime=0; audio.play().catch(()=>{});
    timeline.forEach(({t,ph})=>{ const when=start+t-lead; setTimeout(()=>showViseme(phonemeToViseme(ph)), Math.max(0, when-performance.now())); });
  }

  // Breathing + attention (loops optional)
  let breatheId=null, breathPeriod=3000, breathAmp=1.5, breatheVar=0.08;
  function breathe(on=true, amp=1.5, period=3000, variability=0.08){
    loops.breathe = !!on;
    breathAmp=amp; breathPeriod=period; breatheVar=variability;
    if(breatheId) cancelAnimationFrame(breatheId), breatheId=null;
    if(!on) return;
    const torso=$("#torso"), head=$("#head"); let start=null;
    function step(ts){
      if(!loops.breathe){ breatheId=null; return; }
      if(!start) start=ts;
      const phase=(ts-start)/breathPeriod;
      const s=1+Math.sin(phase*2*Math.PI)*breathAmp/100;
      if(torso) torso.style.transform=`scale(${s})`;
      if(head)  setRotation(head, Math.sin(phase*2*Math.PI)*0.3);
      if(Math.floor(phase)%2===0 && Math.random()<0.005){
        breathPeriod = period*(1 + (Math.random()*2-1)*breatheVar);
      }
      breatheId=requestAnimationFrame(step);
    }
    breatheId=requestAnimationFrame(step);
  }
  let attTimer=null, hotspots=[[6,-2],[-6,-2],[0,3]];
  function setHotspots(list){ if(Array.isArray(list)&&list.length) hotspots=list; }
  function idleAttention(on=true, interval=[2600, 5200]){
    loops.attention = !!on;
    if(attTimer) { clearTimeout(attTimer); attTimer=null; }
    const loop=()=>{
      if(!loops.attention) return;
      const [dx,dy] = hotspots[Math.floor(Math.random()*hotspots.length)];
      saccadeBurst(.9); setTimeout(()=> setGaze(dx,dy), 70);
      attTimer = setTimeout(loop, Math.random()*(interval[1]-interval[0])+interval[0]);
    };
    if(on) loop();
  }

  // Pose & glow
  function setPose(p={}){
    [["#head","head"],["#neck","neck"],["#torso","torso"],
     ["#arm_L","armL"],["#forearm_L","forearmL"],
     ["#arm_R","armR"],["#forearm_R","forearmR"],
     ["#leg_L","legL"],["#shin_L","shinL"],
     ["#leg_R","legR"],["#shin_R","shinR"]]
    .forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); });
  }
  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=clamp01(i); }

  // Engine authority
  let engineMode='manual';
  let mood={ arousal:0, valence:0, focus:0.5 };
  let blinkMin=2200, blinkMax=5200;
  function applyMood(arousal, valence, focus){
    const ar=(arousal+1)/2, fo=focus;
    blinkMin = 1600 - 700*ar + 400*fo;
    blinkMax = 4200 - 1000*ar + 600*fo;
    const basePupil = 5.5 + 2.0*ar + 0.5*Math.max(0,valence);
    setPupil(basePupil);
    const smile = Math.max(0, valence) * (0.2 + 0.6*ar);
    const browLift = (valence*6) + (ar*2);
    setAffect({ browLift, smile });
    setAffectPlus({ cheek: smile*1.2, squintL: ar*0.2, squintR: ar*0.2 });
    if(loops.breathe){ const period = 3600 - 1400*ar; const amp = 1.2 + 0.8*(1-fo); breathe(true, amp, period, 0.09); }
    if(loops.attention){ idleAttention(true, [ 2400 + 1200*fo, 5200 + 1600*fo ]); }
    setPose({ head: valence * 2.0 });
  }
  function setEngineMode(mode='manual'){ engineMode = (mode==='auto') ? 'auto' : 'manual'; }
  function engineTick(state={}){
    const a=clamp(state.arousal??mood.arousal,-1,1);
    const v=clamp(state.valence??mood.valence,-1,1);
    const f=clamp01(state.focus??mood.focus);
    mood={ arousal:a, valence:v, focus:f };
    applyMood(a,v,f);
  }
  let moodRAF=null;
  function neuraMood(state={}){
    const a=clamp(state.arousal??0,-1,1), v=clamp(state.valence??0,-1,1), f=clamp01(state.focus??0.5);
    mood={ arousal:a, valence:v, focus:f };
    if(engineMode!=='auto'){ engineTick(mood); return; }
    if(moodRAF) return;
    const step=()=>{ applyMood(mood.arousal, mood.valence, mood.focus); if(loops.blink) autoBlink(true, blinkMin, blinkMax); moodRAF=requestAnimationFrame(step); };
    moodRAF=requestAnimationFrame(step);
  }

  global.NeuraRig = {
    setGaze, lookAt, saccadeBurst,
    setLids, setBlinkAsymmetry, blinkOnce, autoBlink, setAutoLoops,
    setPupil, setAmbientLuminance, audioReact,
    setAffect, setAffectPlus, smileSpring, transitionAffect,
    showViseme, phonemeToViseme, scheduleVisemes,
    setPose, breathe, setGlow, idleAttention, setHotspots,
    setEngineMode, engineTick, neuraMood,
    act(json){
      try{
        const c=(typeof json==='string')?JSON.parse(json):json;
        if(c.viseme) showViseme(c.viseme);
        if(c.gaze) setGaze(c.gaze[0], c.gaze[1]);
        if(c.lookAt) lookAt(c.lookAt[0], c.lookAt[1], c.lookK?.[0]??32, c.lookK?.[1]??6);
        if(c.blink) (c.blink==='auto'? autoBlink(true): blinkOnce(c.blink));
        if(c.blinkSkew!==undefined) setBlinkAsymmetry(c.blinkSkew);
        if(c.affect) setAffect(c.affect);
        if(c.affectPlus) setAffectPlus(c.affectPlus);
        if(c.smileSpring!==undefined) smileSpring(c.smileSpring, c.springOpts||{});
        if(c.pose) setPose(c.pose);
        if(c.breathe!==undefined) breathe(!!c.breathe, c.breatheAmp||1.5, c.breathePeriod||3000, c.breatheVar||0.08);
        if(c.glow!==undefined) setGlow(c.glow);
        if(c.attention!==undefined) idleAttention(!!c.attention);
        if(c.lids!==undefined) setLids(c.lids);
        if(c.pupil!==undefined) setPupil(c.pupil);
        if(c.audioLevel!==undefined) audioReact(c.audioLevel);
        if(c.ambient!==undefined) setAmbientLuminance(c.ambient);
        if(c.engineMode) setEngineMode(c.engineMode);
        if(c.autoLoops) setAutoLoops(c.autoLoops);
        if(c.moodTick) engineTick(c.moodTick);
        if(c.mood) neuraMood(c.mood);
      }catch(e){ console.error("Neura API act error", e); }
    }
  };
})(window);


// ---- Behavior Module Below ----

/* NeuraBehavior v2.3 (Readable) — calm/warm futuristic presets */

(function(global){
  const Rig = global.NeuraRig;
  if(!Rig){ console.warn('NeuraBehavior: NeuraRig missing'); return; }
  const clamp01 = x => Math.max(0, Math.min(1, x));
  const EASE = {
    smooth: t=>t*t*(3-2*t),
    velvet: t=>1- Math.pow(1-t, 2.4),
    bloom:  t=>{ const k=.6; return t<k ? (t/k) : 1-(1-t)/(1-k); },
    drift:  t=>t<.5? (2*t*t) : 1- Math.pow(-2*t+2,2)/2
  };
  const now = ()=>performance.now(); let _id=1; const stack=[];
  function start(name, props={}, opts={}){
    const b={ id:_id++, name, priority:opts.priority??60, weight:clamp01(opts.weight??1), t0:now(),
      duration:opts.duration??360, ease:EASE[opts.ease||'velvet']||EASE.velvet, fadeOut:opts.fadeOut??300, props };
    stack.push(b); stack.sort((a,b)=> b.priority - a.priority || b.t0 - a.t0); return b.id;
  }
  function stop(id){ const i=stack.findIndex(x=>x.id===id); if(i<0) return; stack[i]._stopping=true; stack[i]._stopT=now(); }
  function clear(){ stack.length=0; }
  function mixObj(dst, src, w){
    if(!src) return dst; dst=dst||{};
    for(const k in src){
      const v=src[k];
      if(typeof v==='number'){ dst[k]=(dst[k]??0)+v*w; }
      else if(Array.isArray(v)){ dst[k]=(dst[k]||v.map(()=>0)).map((x,i)=> x + (v[i]??0)*w); }
      else if(typeof v==='object'){ dst[k]=mixObj(dst[k], v, w); }
    } return dst;
  }
  function evalWeight(b,t){
    const u=Math.min(1,(t-b.t0)/b.duration); const win=b.ease(u);
    if(b._stopping){ const uo=Math.min(1,(t-b._stopT)/b.fadeOut); return b.weight*(1 - EASE.smooth(uo)); }
    return b.weight*win;
  }
  function computeFrame(t){
    let remaining=1.0;
    const acc={ affect:null, affectPlus:null, lids:null, blink:null, lookK:null, idle:null, pose:null, glow:null, pupils:null, gaze:null };
    for(const b of stack.slice().sort((a,b)=> b.priority - a.priority || b.t0 - a.t0)){
      const w=Math.min(remaining, evalWeight(b,t)); if(w<=0) continue;
      acc.affect     = mixObj(acc.affect,     b.props.affect,     w);
      acc.affectPlus = mixObj(acc.affectPlus, b.props.affectPlus, w);
      if(b.props.lids!=null){ const lids=Array.isArray(b.props.lids)?b.props.lids:[b.props.lids,b.props.lids];
        acc.lids = acc.lids ? [acc.lids[0]+lids[0]*w, acc.lids[1]+lids[1]*w] : [lids[0]*w, lids[1]*w];
      }
      if(b.props.blink){ const bl=b.props.blink; acc.blink=acc.blink||{min:0,max:0,skew:0,has:true};
        if(bl.min) acc.blink.min += bl.min*w; if(bl.max) acc.blink.max += bl.max*w; if(bl.skew!=null) acc.blink.skew += bl.skew*w; }
      if(b.props.lookK){ const [st,dp]=b.props.lookK; acc.lookK=acc.lookK? [acc.lookK[0]+st*w, acc.lookK[1]+dp*w] : [st*w, dp*w]; }
      if(b.props.idle){ const [mn,mx]=b.props.idle; acc.idle=acc.idle? [acc.idle[0]+mn*w, acc.idle[1]+mx*w] : [mn*w, mx*w]; }
      acc.pose  = mixObj(acc.pose,  b.props.pose,  w);
      if(b.props.glow!=null)   acc.glow   = (acc.glow??0) + b.props.glow*w;
      if(b.props.pupils!=null) acc.pupils = (acc.pupils??0) + b.props.pupils*w;
      if(b.props.gaze) acc.gaze = acc.gaze? [acc.gaze[0]+b.props.gaze[0]*w, acc.gaze[1]+b.props.gaze[1]*w] : [b.props.gaze[0]*w, b.props.gaze[1]*w];
      remaining -= w*0.88; if(remaining<=0.01) break;
    } return acc;
  }
  let running=true, raf=null;
  function setRunning(on=true){ running=!!on; if(running && !raf) raf=requestAnimationFrame(loop); }
  function loop(){ raf=null; const t=now();
    for(let i=stack.length-1;i>=0;--i){ const b=stack[i]; if(b._stopping && (t-b._stopT)>(b.fadeOut+16)) stack.splice(i,1); }
    const acc=computeFrame(t); const act={};
    if(acc.affect) act.affect=acc.affect;
    if(acc.affectPlus) act.affectPlus=acc.affectPlus;
    if(acc.lids) act.lids=acc.lids.map(clamp01);
    if(acc.pose) act.pose=acc.pose;
    if(acc.glow!=null) act.glow=clamp01(acc.glow);
    if(acc.pupils!=null) act.pupil=Math.max(3,Math.min(10,acc.pupils));
    if(acc.gaze) act.gaze=acc.gaze;
    if(acc.blink && acc.blink.skew!=null) act.blinkSkew=Math.max(-1,Math.min(1,acc.blink.skew));
    if(acc.lookK) act.lookK=acc.lookK;
    if(acc.idle) act.attention=true;
    if(Object.keys(act).length) Rig.act(act);
    if(running) raf=requestAnimationFrame(loop);
  } setRunning(true);

  const VIBE={ pupils:6.2, lids:0.94, glow:0.10, headTilt:1.2, lookStiff:34, lookDamp:7 };
  const presets={
    listening(opts={}){ return start('listening', {
        affect:{ browLift:1.8, smile:.18 }, affectPlus:{ squintL:.14, squintR:.14, cheek:.10 },
        lids:[VIBE.lids,VIBE.lids], lookK:[VIBE.lookStiff,VIBE.lookDamp], idle:[3400,5600],
        pose:{ head:VIBE.headTilt }, pupils:VIBE.pupils, glow:VIBE.glow*1.0
      }, { priority:opts.priority??65, weight:opts.weight??.95, duration:320, ease:'velvet' }); },
    thinking(opts={}){ return start('thinking', {
        affect:{ browLift:.8, smile:.06 }, affectPlus:{ squintL:.20, squintR:.18, nose:.18, browTilt:.75, cheek:.08 },
        lids:[.90,.88], lookK:[32,7.5], idle:[4200,6400], gaze:[2,-1], pose:{ head:-0.8 }, pupils:5.8, glow:VIBE.glow*1.15
      }, { priority:opts.priority??72, weight:opts.weight??1.0, duration:360, ease:'drift' }); },
    speaking(opts={}){ return start('speaking', {
        affect:{ browLift:2.4, smile:.28 }, affectPlus:{ cheek:.28, squintL:.10, squintR:.10 },
        lids:[.95,.93], blink:{ skew:.18 }, lookK:[33,6.8], pose:{ head:.6 }, pupils:6.3, glow:VIBE.glow*1.2
      }, { priority:opts.priority??78, weight:opts.weight??.9, duration:260, ease:'bloom' }); },
    greeting(opts={}){ return start('greeting', {
        affect:{ browLift:3.2, smile:.62 }, affectPlus:{ cheek:.58, squintL:.12, squintR:.12 },
        lids:[.965,.955], pose:{ head:2.0 }, pupils:6.5, glow:VIBE.glow*1.35
      }, { priority:opts.priority??90, weight:opts.weight??1.0, duration:320, ease:'bloom' }); }
  };
  global.NeuraBehavior={ start, stop, clear, presets, setRunning, tick: loop };
})(window);
