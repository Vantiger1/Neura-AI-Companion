import 'package:flutter/material.dart';
import '../../core/services/analytics_service.dart';
import '../../core/services/error_logger.dart';

class DiagnosticsScreen extends StatefulWidget {
  @override
  _DiagnosticsScreenState createState() => _DiagnosticsScreenState();
}

class _DiagnosticsScreenState extends State<DiagnosticsScreen> {
  final _analytics = AnalyticsService();
  final _errorLogger = ErrorLogger();
  List<Map> _events = [];
  String _logs = '';

  @override
  void initState() {
    super.initState();
    _loadData();
  }

  Future<void> _loadData() async {
    await _analytics.init();
    setState(() { _events = _analytics.queryEvents(); });
    final file = File('${(await getTemporaryDirectory()).path}/neura_errors.log');
    if (await file.exists()) _logs = await file.readAsString();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Diagnostics')),
      body: ListView(children: [
        ListTile(title: Text('Events'), subtitle: Text(_events.map((e) => e['name']).join(', '))),
        ExpansionTile(title: Text('Error Logs'), children: [Text(_logs)]),
      ]),
    );
  }
}
