#include <jni.h>
#include <string>
#include <atomic>

static std::atomic<bool> g_cancel{false};

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_version(JNIEnv* env, jobject /*thiz*/) {
  return env->NewStringUTF("stub-0.2 (no llama.cpp)");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_loadModel(JNIEnv* env, jobject /*thiz*/, jstring /*path*/) {
  // Safe stub: signal not available
  return JNI_FALSE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_unloadModel(JNIEnv* env, jobject /*thiz*/) {
  (void)env;
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_cancel(JNIEnv* env, jobject /*thiz*/) {
  (void)env;
  g_cancel.store(true);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_chat(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring system,
    jstring prompt,
    jdouble /*temperature*/,
    jint /*maxTokens*/,
    jint /*threads*/,
    jint /*contextTokens*/,
    jboolean /*useGpu*/) {

  const char* c_prompt = env->GetStringUTFChars(prompt, nullptr);
  (void)system;

  std::string out = "[on-device LLM unavailable] The Android native runtime is stubbed. "
                    "To enable real offline inference, drop llama.cpp sources + headers into "
                    "android/app/src/main/cpp/third_party/llama and rebuild.";

  env->ReleaseStringUTFChars(prompt, c_prompt);
  return env->NewStringUTF(out.c_str());
}
