#include <jni.h>
#include <string>
#include <atomic>

#ifdef NEURA_HAS_LLAMA
// IMPORTANT:
// This file is intentionally minimal and designed to be adapted to the exact
// llama.cpp version the user vendors into third_party/llama.
//
// Many llama.cpp APIs evolve. We keep this as a compatibility shell:
// - loadModel(path)
// - unloadModel()
// - cancel()
// - chat(...)
//
// Once llama.cpp is vendored, wire these calls to the local API you prefer.

static std::atomic<bool> g_cancel{false};
static std::string g_modelPath;

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_version(JNIEnv* env, jobject /*thiz*/) {
  return env->NewStringUTF("llama-bindings-shell-0.1");
}

extern "C" JNIEXPORT jboolean JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_loadModel(JNIEnv* env, jobject /*thiz*/, jstring path) {
  const char* c_path = env->GetStringUTFChars(path, nullptr);
  g_modelPath = c_path ? c_path : "";
  env->ReleaseStringUTFChars(path, c_path);

  // TODO: replace with actual llama.cpp model load.
  // Return JNI_TRUE only when successful.
  return g_modelPath.empty() ? JNI_FALSE : JNI_TRUE;
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_unloadModel(JNIEnv* env, jobject /*thiz*/) {
  (void)env;
  // TODO: free model/context
  g_modelPath.clear();
}

extern "C" JNIEXPORT void JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_cancel(JNIEnv* env, jobject /*thiz*/) {
  (void)env;
  g_cancel.store(true);
}

extern "C" JNIEXPORT jstring JNICALL
Java_com_neurocompanion_app_neura_LlamaNative_chat(
    JNIEnv* env,
    jobject /*thiz*/,
    jstring system,
    jstring prompt,
    jdouble /*temperature*/,
    jint /*maxTokens*/,
    jint /*threads*/,
    jint /*contextTokens*/,
    jboolean /*useGpu*/) {

  const char* c_sys = env->GetStringUTFChars(system, nullptr);
  const char* c_prompt = env->GetStringUTFChars(prompt, nullptr);

  std::string out;
  if (g_modelPath.empty()) {
    out = "No model loaded. Call loadModel(path) first.";
  } else {
    // TODO: replace with actual token loop. g_cancel should interrupt.
    // For now we provide a deterministic placeholder to keep builds stable.
    out = "[llama-bindings shell] Model loaded at: " + g_modelPath + "\n";
    out += "System: " + std::string(c_sys ? c_sys : "") + "\n";
    out += "Prompt: " + std::string(c_prompt ? c_prompt : "") + "\n";
    out += "(Wire llama.cpp token generation loop here.)";
  }

  if (c_sys) env->ReleaseStringUTFChars(system, c_sys);
  if (c_prompt) env->ReleaseStringUTFChars(prompt, c_prompt);

  return env->NewStringUTF(out.c_str());
}
#endif
