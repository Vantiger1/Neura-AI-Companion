package com.neurocompanion.app.neura

/**
 * JNI signatures for the native on-device runtime.
 *
 * Skill Pack 11 adds lifecycle + cancellation.
 * The native side still compiles as a safe stub unless llama.cpp sources are present.
 */
object LlamaNative {
  external fun version(): String

  external fun loadModel(path: String): Boolean
  external fun unloadModel()
  external fun cancel()

  external fun chat(
    system: String,
    prompt: String,
    temperature: Double,
    maxTokens: Int,
    threads: Int,
    contextTokens: Int,
    useGpu: Boolean,
  ): String
}
