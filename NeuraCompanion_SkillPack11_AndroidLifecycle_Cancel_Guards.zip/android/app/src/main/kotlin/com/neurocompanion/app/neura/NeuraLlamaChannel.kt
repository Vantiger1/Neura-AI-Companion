package com.neurocompanion.app.neura

import android.content.Context
import android.app.ActivityManager
import android.os.PowerManager
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel

/**
 * Android on-device LLM bridge.
 *
 * Skill Pack 11 adds:
 * - model lifecycle (load/unload)
 * - cancellation
 * - lightweight device guardrails (power-save + low-RAM tuning)
 */
object NeuraLlamaChannel {
  private const val CHANNEL = "neura_llm"

  fun register(engine: FlutterEngine) {
    val appContext = engine.context
    val channel = MethodChannel(engine.dartExecutor.binaryMessenger, CHANNEL)

    channel.setMethodCallHandler { call: MethodCall, result: MethodChannel.Result ->
      try {
        when (call.method) {
          "health" -> result.success(LlamaEngine.health())

          "loadModel" -> {
            val args = call.arguments as? Map<*, *>
            val path = (args?.get("path") as? String)?.trim() ?: ""
            if (path.isBlank()) {
              result.success(mapOf("ok" to false, "error" to "Missing model path."))
            } else {
              result.success(LlamaEngine.loadModel(path))
            }
          }

          "unloadModel" -> {
            result.success(LlamaEngine.unloadModel())
          }

          "cancel" -> {
            result.success(LlamaEngine.cancel())
          }

          "chat" -> {
            val args = call.arguments as? Map<*, *>
            val prompt = (args?.get("prompt") as? String)?.trim() ?: ""
            val system = (args?.get("system") as? String)?.trim() ?: ""
            val temperature = (args?.get("temperature") as? Number)?.toDouble() ?: 0.3
            val maxTokensIn = (args?.get("maxTokens") as? Number)?.toInt() ?: 256
            val threadsIn = (args?.get("threads") as? Number)?.toInt() ?: 4
            val ctxIn = (args?.get("contextTokens") as? Number)?.toInt() ?: 2048
            val useGpu = (args?.get("useGpu") as? Boolean) ?: false

            val tuned = tuneForDevice(appContext, threadsIn, maxTokensIn, ctxIn)

            val r = LlamaEngine.chat(
              prompt = prompt,
              system = system,
              temperature = temperature,
              maxTokens = tuned.maxTokens,
              threads = tuned.threads,
              contextTokens = tuned.contextTokens,
              useGpu = useGpu,
            )
            result.success(r)
          }

          else -> result.notImplemented()
        }
      } catch (t: Throwable) {
        result.success(mapOf("ok" to false, "error" to t.toString()))
      }
    }
  }

  private data class Tuned(val threads: Int, val maxTokens: Int, val contextTokens: Int)

  /**
   * Guardrails:
   * - Power saver: reduce threads + tokens (keeps thermals sane)
   * - Low RAM devices: reduce context + threads
   */
  private fun tuneForDevice(ctx: Context, threads: Int, maxTokens: Int, contextTokens: Int): Tuned {
    var t = threads.coerceIn(1, 8)
    var m = maxTokens.coerceIn(16, 2048)
    var c = contextTokens.coerceIn(512, 4096)

    try {
      val pm = ctx.getSystemService(Context.POWER_SERVICE) as? PowerManager
      if (pm?.isPowerSaveMode == true) {
        t = t.coerceAtMost(2)
        m = m.coerceAtMost(256)
        c = c.coerceAtMost(2048)
      }

      val am = ctx.getSystemService(Context.ACTIVITY_SERVICE) as? ActivityManager
      if (am?.isLowRamDevice == true) {
        t = t.coerceAtMost(2)
        m = m.coerceAtMost(256)
        c = c.coerceAtMost(1536)
      }
    } catch (_: Throwable) {
      // Safe: if any of this fails, keep caller-provided values.
    }

    return Tuned(t, m, c)
  }
}
