package com.neurocompanion.app.neura

import java.util.concurrent.atomic.AtomicBoolean

object LlamaEngine {
  private val libLoaded = AtomicBoolean(false)
  private val modelLoaded = AtomicBoolean(false)
  private var loadError: String? = null

  private fun ensureLibLoaded() {
    if (libLoaded.get()) return
    try {
      System.loadLibrary("neura_llama")
      libLoaded.set(true)
    } catch (t: Throwable) {
      loadError = t.toString()
      libLoaded.set(false)
    }
  }

  fun health(): Map<String, Any?> {
    ensureLibLoaded()
    if (!libLoaded.get()) {
      return mapOf(
        "ok" to false,
        "error" to (loadError ?: "Native library not loaded."),
        "hint" to "Build and bundle the Android native runtime (see docs/android_on_device_llm_runtime.md).",
      )
    }

    return try {
      val v = LlamaNative.version()
      mapOf(
        "ok" to true,
        "version" to v,
        "modelLoaded" to modelLoaded.get(),
      )
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }

  fun loadModel(path: String): Map<String, Any?> {
    ensureLibLoaded()
    if (!libLoaded.get()) {
      return mapOf("ok" to false, "error" to (loadError ?: "Native library not loaded."))
    }

    return try {
      val ok = LlamaNative.loadModel(path)
      modelLoaded.set(ok)
      mapOf(
        "ok" to ok,
        "modelLoaded" to ok,
        "path" to path,
      )
    } catch (t: Throwable) {
      modelLoaded.set(false)
      mapOf("ok" to false, "error" to t.toString())
    }
  }

  fun unloadModel(): Map<String, Any?> {
    ensureLibLoaded()
    if (!libLoaded.get()) {
      return mapOf("ok" to false, "error" to (loadError ?: "Native library not loaded."))
    }

    return try {
      LlamaNative.unloadModel()
      modelLoaded.set(false)
      mapOf("ok" to true, "modelLoaded" to false)
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }

  fun cancel(): Map<String, Any?> {
    ensureLibLoaded()
    if (!libLoaded.get()) {
      return mapOf("ok" to false, "error" to (loadError ?: "Native library not loaded."))
    }

    return try {
      LlamaNative.cancel()
      mapOf("ok" to true)
    } catch (t: Throwable) {
      mapOf("ok" to false, "error" to t.toString())
    }
  }

  fun chat(
    prompt: String,
    system: String,
    temperature: Double,
    maxTokens: Int,
    threads: Int,
    contextTokens: Int,
    useGpu: Boolean,
  ): Map<String, Any?> {
    ensureLibLoaded()
    if (!libLoaded.get()) {
      return mapOf(
        "ok" to false,
        "error" to (loadError ?: "Native library not loaded."),
        "hint" to "On-device LLM is enabled but not built. Follow docs/android_on_device_llm_runtime.md.",
      )
    }

    if (prompt.isBlank()) return mapOf("ok" to false, "error" to "Missing prompt.")

    // If model isn't loaded, we attempt a lazy load only if a path was previously stored.
    // (In Flutter, prefer explicit loadModel.)
    if (!modelLoaded.get()) {
      // Native may support in-memory default. If not, it will throw and we surface hint.
    }

    return try {
      val out = LlamaNative.chat(
        system = system,
        prompt = prompt,
        temperature = temperature,
        maxTokens = maxTokens,
        threads = threads,
        contextTokens = contextTokens,
        useGpu = useGpu,
      )
      mapOf(
        "ok" to true,
        "model" to "android_on_device",
        "content" to out,
      )
    } catch (t: Throwable) {
      mapOf(
        "ok" to false,
        "error" to t.toString(),
        "hint" to "If you haven't loaded a GGUF model yet, call loadModel(path) first.",
      )
    }
  }
}
