# Skill Pack 11 — Android On-Device LLM: Lifecycle + Cancel + Guardrails

This patch improves the Android on-device runtime integration by adding:

- `loadModel(path)` / `unloadModel()` lifecycle
- `cancel()` for interrupting long generations
- device guardrails (power saver + low-RAM tuning)
- CMake auto-detection of `third_party/llama` headers

## What you must supply (offline)
To run a real local model, you must vendor a local inference engine, such as llama.cpp.

Expected directory:

```
android/app/src/main/cpp/third_party/llama/
  llama.h (or include/llama.h)
  ...sources...
```

This patch **will not break your build** if you do not provide llama.cpp.
It compiles a safe stub and returns "on-device unavailable".

## Flutter calls
- `NeuraAndroidLlmBridge.I.loadModel(path)`
- `NeuraAndroidLlmBridge.I.chat(prompt: ..., system: ..., temperature: ...)`
- `NeuraAndroidLlmBridge.I.cancel()`
- `NeuraAndroidLlmBridge.I.unloadModel()`

## Next (recommended)
- Add EventChannel token streaming for Android native.
- Wire the native implementation to your vendored llama.cpp API.
- Add thermal callbacks (Android 10+) for more precise throttling.
