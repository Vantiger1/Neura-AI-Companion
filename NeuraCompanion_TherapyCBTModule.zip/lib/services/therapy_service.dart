import '../models/therapy_path_model.dart';

class TherapyService {
  final List<TherapyPrompt> _cbtPrompts = [
    TherapyPrompt(
      id: 'cbt1',
      title: 'Thought Challenge',
      instruction: 'Describe a recent negative thought. What evidence supports or refutes it?',
      method: 'CBT',
    ),
    TherapyPrompt(
      id: 'cbt2',
      title: 'Cognitive Distortions',
      instruction: 'What thinking error occurred? (e.g., catastrophizing, black-and-white)',
      method: 'CBT',
    ),
  ];

  final List<TherapyPrompt> _dbtPrompts = [
    TherapyPrompt(
      id: 'dbt1',
      title: 'Emotion Regulation',
      instruction: 'How did you manage your emotions today? What skills did you use?',
      method: 'DBT',
    )
  ];

  final List<TherapyPrompt> _actPrompts = [
    TherapyPrompt(
      id: 'act1',
      title: 'Values Check',
      instruction: 'What action did you take that aligned with your values today?',
      method: 'ACT',
    )
  ];

  List<TherapyPrompt> getAll(String method) {
    switch (method) {
      case 'CBT': return _cbtPrompts;
      case 'DBT': return _dbtPrompts;
      case 'ACT': return _actPrompts;
      default: return [];
    }
  }

  List<String> getMethods() => ['CBT', 'DBT', 'ACT'];
}
