import 'package:flutter/material.dart';
import 'core/services/setup_service.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await SetupService().initialize();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: Scaffold(
        appBar: AppBar(title: Text('Neura Companion')),
        body: Center(child: Text('Welcome to Neura Companion')),
      ),
    );
  }
}
