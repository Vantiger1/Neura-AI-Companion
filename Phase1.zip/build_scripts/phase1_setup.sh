#!/usr/bin/env bash
echo "Phase 1: Verifying folder structure and dependencies..."
flutter pub get
echo "Phase 1 setup complete."
