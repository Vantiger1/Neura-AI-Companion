#!/usr/bin/env bash
set -euo pipefail

# -------------------------------------------------------------
# Script: setup_azure_storage.sh
# Purpose: Automate Azure Storage + Crashlytics integration + Debugging
# Usage: Run from project root (requires Flutter & Git)
# -------------------------------------------------------------

# Configure Firebase upload
FIREBASE_BUCKET="your-firebase-bucket.appspot.com"
FIREBASE_UPLOAD_DIR="debug_reports"
FIREBASE_TARGET="gs://${FIREBASE_BUCKET}/${FIREBASE_UPLOAD_DIR}"

# Optional: Check Flutter version
REQUIRED_FLUTTER="3.19.6"
CURRENT_FLUTTER=$(flutter --version | grep -oP 'Flutter \K[0-9.]+' || echo "")
if [ "$CURRENT_FLUTTER" != "$REQUIRED_FLUTTER" ]; then
  echo "⚠️ Required Flutter version is $REQUIRED_FLUTTER but found $CURRENT_FLUTTER"
fi

echo "Adding Azure & Crashlytics dependencies..."
flutter pub add \
  azure_identity \
  azure_storage_blobs \
  firebase_core \
  firebase_crashlytics \
  connectivity_plus \
  file_picker \
  shimmer \
  flutter_riverpod \
  integration_test

echo "Creating lib/services and lib/ui folders..."
mkdir -p "lib/services" "lib/ui"

# Ensure test directory and default test file
mkdir -p test test/widget_test integration_test test_driver

# (Test generation steps omitted for brevity – unchanged)
# ... unit, widget, integration test generation here ...

# Run tests
echo "Running unit + widget + integration tests..."
flutter test --coverage || echo "Some tests failed. Please check output above."
flutter drive --driver=test_driver/integration_test.dart --target=integration_test/app_test.dart || echo "Integration test failed."

# Test coverage threshold check
if [ -f coverage/lcov.info ]; then
  COVERAGE=$(lcov --summary coverage/lcov.info | grep -Po '\d+(?=%)' | head -1 || echo 0)
  THRESHOLD=85
  if [ "$COVERAGE" -lt "$THRESHOLD" ]; then
    echo "❌ Coverage ($COVERAGE%) is below required threshold ($THRESHOLD%)"
    exit 1
  fi
fi

# Coverage Report
if [ -f coverage/lcov.info ]; then
  genhtml coverage/lcov.info --output-directory coverage/html > /dev/null 2>&1 || true
  if [ -f coverage/html/index.html ]; then
    echo "Opening test coverage report..."
    xdg-open coverage/html/index.html 2>/dev/null || open coverage/html/index.html || echo "Coverage report saved at coverage/html/index.html"
  fi
fi

# Diagnostic logs
echo "Running flutter analyze and doctor..."
flutter analyze > diagnostics_flutter_analyze.txt || echo "flutter analyze failed"
flutter doctor -v > diagnostics_flutter_doctor.txt || echo "flutter doctor failed"

# Generate summary
echo "Summary Report - $(date)" > diagnostics_summary.txt
echo "Analyzed warnings:" >> diagnostics_summary.txt
grep -i warning diagnostics_flutter_analyze.txt >> diagnostics_summary.txt
echo "Doctor output:" >> diagnostics_summary.txt
head -n 20 diagnostics_flutter_doctor.txt >> diagnostics_summary.txt

# Bundle diagnostics
zip diagnostics_bundle.zip diagnostics_flutter_*.txt diagnostics_summary.txt > /dev/null 2>&1 || true

# Upload to Firebase Storage
TIMESTAMP=$(date +%Y%m%d_%H%M%S)
BUNDLE_NAME="diagnostics_bundle_$TIMESTAMP.zip"
UPLOAD_PATH="$FIREBASE_TARGET/$BUNDLE_NAME"
echo "Uploading $BUNDLE_NAME to Firebase Storage..."
gsutil cp diagnostics_bundle.zip "$UPLOAD_PATH" && \
  echo "✅ Upload complete: $UPLOAD_PATH" || \
  echo "❌ Upload failed: check Firebase auth and bucket permissions."

# Cleanup old bundles (optional)
echo "Checking Firebase for old bundles..."
OLD_BUNDLES=$(gsutil ls "$FIREBASE_TARGET/diagnostics_bundle_*.zip" | head -n -5)
if [ -n "$OLD_BUNDLES" ]; then
  echo "Deleting old diagnostic bundles..."
  echo "$OLD_BUNDLES" | xargs gsutil rm || echo "⚠️ Failed to delete some old bundles"
fi

# Optional Firebase Hosting deploy (if configured)
if [ -f firebase.json ]; then
  echo "Deploying to Firebase Hosting (optional)..."
  firebase deploy --only hosting || echo "❌ Firebase Hosting deploy failed"
fi

# Optional: staging config switch
if [[ "$*" == *"--staging"* ]]; then
  echo "🧪 Setting up staging config..."
  cp firebase.staging.json android/app/google-services.json
fi

# Open test files
echo "Opening test files..."
${EDITOR:-code} test/main_test.dart test/widget_test/widget_sample_test.dart integration_test/app_test.dart || echo "Opened test files in default editor."

# CI workflow (unchanged)
# ... GitHub Actions setup here ...
