import 'package:flutter/material.dart';
import 'services/analytics_service.dart';
import 'services/error_logger.dart';
import 'services/feedback_service.dart';
import 'ui/diagnostics_screen.dart';
import 'ui/feedback_form.dart';
import 'ui/community_dashboard.dart';
import 'ui/neura_animator.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await AnalyticsService().init();
  await FeedbackService().init();
  FlutterError.onError = (details) {
    ErrorLogger().logError(details.exception, details.stack!);
    FlutterError.presentError(details);
  };
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      home: AppScaffold(),
    );
  }
}

class AppScaffold extends StatefulWidget {
  @override
  _AppScaffoldState createState() => _AppScaffoldState();
}

class _AppScaffoldState extends State<AppScaffold> {
  int _currentIndex = 0;
  final _pages = [
    Center(child: NeuraAnimator(portraitAsset: 'assets/animations/neura_portrait.png')),
    FeedbackForm(),
    CommunityDashboard(),
    DiagnosticsScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Neura Companion')),
      body: _pages[_currentIndex],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _currentIndex,
        items: [
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.feedback), label: 'Feedback'),
          BottomNavigationBarItem(icon: Icon(Icons.group), label: 'Community'),
          BottomNavigationBarItem(icon: Icon(Icons.build), label: 'Diagnostics'),
        ],
        onTap: (i) => setState(() => _currentIndex = i),
      ),
    );
  }
}
