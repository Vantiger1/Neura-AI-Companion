import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../rooms/room_keys.dart';
import '../../rooms/room_memory_service.dart';
import '../../core/event_bus.dart';
import '../../core/emotion_engine.dart';
import '../../services/audio_service.dart';
import '../../avatar/outfit_engine.dart';
class RoomsScreen extends StatefulWidget{ const RoomsScreen({super.key}); @override State<RoomsScreen> createState()=>_RoomsScreenState();}
class _RoomsScreenState extends State<RoomsScreen>{ String? _current; String _outfit='...'; late final RoomMemoryService memory; late final EmotionEngine emotions; late final AudioService audio; late final OutfitEngine outfits;
@override void initState(){ super.initState(); final bus=context.read<NeuraEventBus>(); memory=RoomMemoryService(bus); emotions=context.read<EmotionEngine>(); audio=context.read<AudioService>(); outfits=OutfitEngine(); Future.microtask(() async{ _current=await memory.lastRoom()??Rooms.reflectionBay; await _applyRoom(_current!); if(mounted) setState((){});}); }
Future<void> _applyRoom(String room) async{ await memory.save(room); switch(room){ case Rooms.reflectionBay: await emotions.setMood('calm', intensity:.55); await audio.playRoomAmbient(Rooms.reflectionBay); break; case Rooms.joyLounge: await emotions.setMood('joy', intensity:.75); await audio.playRoomAmbient(Rooms.joyLounge); break; case Rooms.moodDen: await emotions.setMood('focus', intensity:.6); await audio.playRoomAmbient(Rooms.moodDen); break; } _outfit=await outfits.current(mood: emotions.current); }
@override Widget build(BuildContext c){ return Scaffold(appBar: AppBar(title: const Text('Rooms')), body: Padding(padding: const EdgeInsets.all(16), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children:[ Text('Welcome ${_current==null? "" : "back to $_current"}'), const SizedBox(height:12), Text('Today\'s Outfit: $_outfit'), const SizedBox(height:24), Wrap(spacing:10, children: Rooms.all.map((r)=> ElevatedButton(onPressed: () async{ await _applyRoom(r); if(mounted) setState(()=>_current=r);}, child: Text(r))).toList(), ) ]))); } }