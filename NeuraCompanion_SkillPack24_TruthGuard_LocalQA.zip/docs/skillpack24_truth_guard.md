# Skill Pack 24 — Local QA / Truth Guard (Offline)

This patch adds an offline “truth guard” to prevent Neura from speaking/writing:
- unsupported claims
- overconfident language
- risky domain phrasing (medical/legal/investment)

## What you get
- `NeuraTruthGuard`
- Action: `truth_guard_check`

## Inputs
- `draft` (string)
- `sources` (the same object returned by `unified_sources`)
- `minKeywordOverlap` (default 2)

## Outputs
- `okToSpeak` (bool)
- `issues` (list of info/warn/block)
- `suggestedRewrite` (string)

## Recommended pipeline
1) `unified_sources`
2) local model drafts answer
3) `truth_guard_check`
   - If `okToSpeak=false`, use `suggestedRewrite` or re-draft with more citations
4) `compose_answer_from_sources`

## Next
Step 25: “Policy Guard + Approvals” for sensitive actions (system changes, installs, deletes) using your existing checklist UI.
