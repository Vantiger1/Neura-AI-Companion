\
import 'neura_sources.dart';

class NeuraTruthIssue {
  final String severity; // info|warn|block
  final String message;
  final String? sentence;
  final List<String> relatedCitations;

  NeuraTruthIssue({
    required this.severity,
    required this.message,
    this.sentence,
    this.relatedCitations = const [],
  });

  Map<String, dynamic> toJson() => {
        'severity': severity,
        'message': message,
        if (sentence != null) 'sentence': sentence,
        if (relatedCitations.isNotEmpty) 'relatedCitations': relatedCitations,
      };
}

class NeuraTruthGuardResult {
  final bool okToSpeak;
  final List<NeuraTruthIssue> issues;
  final String suggestedRewrite;

  NeuraTruthGuardResult({
    required this.okToSpeak,
    required this.issues,
    required this.suggestedRewrite,
  });

  Map<String, dynamic> toJson() => {
        'okToSpeak': okToSpeak,
        'issues': issues.map((i) => i.toJson()).toList(),
        'suggestedRewrite': suggestedRewrite,
      };
}

/// Lightweight offline “truth guard”.
/// Heuristic goals:
/// - Detect overconfident language
/// - Ensure claims have some citation support (keyword overlap)
/// - Suggest safer phrasing when support is weak
///
/// This is not a fact-checker. It is a “tone + support” guard.
class NeuraTruthGuard {
  static final _sentenceSplit = RegExp(r'(?<=[\.\!\?])\s+');
  static final _token = RegExp(r"[A-Za-z0-9']{3,}");

  static final _overclaimWords = <String>{
    'always',
    'never',
    'guarantee',
    'guaranteed',
    'prove',
    'proven',
    'certain',
    'definitely',
    'undeniable',
    'best',
    'perfect',
    'all',
    'every',
    'none',
    'completely',
    '100%',
  };

  static final _riskPhrases = <String>[
    'medical advice',
    'diagnose',
    'cure',
    'treat',
    'legal advice',
    'investment advice',
    'financial advice',
  ];

  NeuraTruthGuardResult check({
    required String draftAnswer,
    required NeuraSourcesPacket sources,
    int minKeywordOverlap = 2,
  }) {
    final answer = draftAnswer.trim();
    if (answer.isEmpty) {
      return NeuraTruthGuardResult(okToSpeak: true, issues: [], suggestedRewrite: '');
    }

    final citations = sources.citations;
    final sentences = answer
        .split(_sentenceSplit)
        .map((s) => s.trim())
        .where((s) => s.isNotEmpty)
        .toList();

    final issues = <NeuraTruthIssue>[];
    bool block = false;

    for (final s in sentences) {
      final lower = s.toLowerCase();

      // Risk phrases
      for (final p in _riskPhrases) {
        if (lower.contains(p)) {
          issues.add(NeuraTruthIssue(
            severity: 'warn',
            message: 'High-risk domain phrasing detected (“$p”). Use disclaimers and encourage professional help.',
            sentence: s,
          ));
        }
      }

      // Overclaim detection
      final overclaims = _overclaimWords.where((w) => lower.contains(w)).toList();
      if (overclaims.isNotEmpty) {
        issues.add(NeuraTruthIssue(
          severity: 'warn',
          message: 'Overconfident wording detected: ${overclaims.join(", ")}. Consider softer language.',
          sentence: s,
        ));
      }

      // Support check
      final tokens = _tokens(s);
      if (tokens.length < 4) continue;

      final support = _supportingCitations(tokens, citations, minKeywordOverlap);
      if (support.isEmpty) {
        final assertive = overclaims.isNotEmpty || _looksNumericClaim(s) || _looksDirective(s);
        issues.add(NeuraTruthIssue(
          severity: assertive ? 'block' : 'warn',
          message: assertive
              ? 'Sentence appears like a claim/command but has no supporting citations.'
              : 'Sentence may benefit from citations to support it.',
          sentence: s,
        ));
        if (assertive) block = true;
      } else {
        issues.add(NeuraTruthIssue(
          severity: 'info',
          message: 'Citation support found.',
          sentence: s,
          relatedCitations: support,
        ));
      }
    }

    final suggested = _suggestRewrite(answer, issues);

    return NeuraTruthGuardResult(
      okToSpeak: !block,
      issues: _compressIssues(issues),
      suggestedRewrite: suggested,
    );
  }

  List<NeuraTruthIssue> _compressIssues(List<NeuraTruthIssue> issues) {
    final blocks = issues.where((i) => i.severity == 'block').toList();
    final warns = issues.where((i) => i.severity == 'warn').toList();
    final infos = issues.where((i) => i.severity == 'info').take(12).toList();
    return [...blocks, ...warns, ...infos];
  }

  List<String> _tokens(String s) {
    final matches = _token.allMatches(s);
    final out = <String>[];
    for (final m in matches) {
      out.add(m.group(0)!.toLowerCase());
    }
    return out;
  }

  bool _looksNumericClaim(String s) {
    return RegExp(r'\b\d+(\.\d+)?\s*(%|percent)\b', caseSensitive: false).hasMatch(s) ||
        RegExp(r'\b\d{4,}\b').hasMatch(s);
  }

  bool _looksDirective(String s) {
    final lower = s.trimLeft().toLowerCase();
    return lower.startsWith('do ') ||
        lower.startsWith('use ') ||
        lower.startsWith('install ') ||
        lower.startsWith('delete ') ||
        lower.startsWith('turn on ') ||
        lower.startsWith('enable ');
  }

  List<String> _supportingCitations(
    List<String> tokens,
    List<NeuraCitation> citations,
    int minOverlap,
  ) {
    if (citations.isEmpty) return const [];
    final supported = <String>[];
    for (final c in citations) {
      final hay = ('${c.path}\n${c.excerpt}').toLowerCase();
      int overlap = 0;
      for (final t in tokens.take(18)) {
        if (hay.contains(t)) overlap++;
        if (overlap >= minOverlap) break;
      }
      if (overlap >= minOverlap) supported.add(c.id);
    }
    return supported;
  }

  String _suggestRewrite(String answer, List<NeuraTruthIssue> issues) {
    if (issues.isEmpty) return '';
    final hasBlock = issues.any((i) => i.severity == 'block');

    final soften = answer
        .replaceAll(RegExp(r'\balways\b', caseSensitive: false), 'often')
        .replaceAll(RegExp(r'\bnever\b', caseSensitive: false), 'rarely')
        .replaceAll(RegExp(r'\bguarantee(d)?\b', caseSensitive: false), 'aim')
        .replaceAll(RegExp(r'\bdefinitely\b', caseSensitive: false), 'likely')
        .replaceAll(RegExp(r'\bprove(n)?\b', caseSensitive: false), 'suggest');

    if (!hasBlock) return soften;

    return '''
$soften

Notes:
- Some statements above were not clearly supported by the provided sources. For a fully auditable answer, either (1) add supporting documents to the sandbox, or (2) rewrite the answer to explicitly cite which document supports each point.
'''.trim();
  }
}
