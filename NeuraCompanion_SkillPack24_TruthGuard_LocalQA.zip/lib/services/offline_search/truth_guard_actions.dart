\
import '../neura_action_bus/action_registry.dart';
import '../neura_action_bus/neura_action.dart';
import 'neura_sources.dart';
import 'truth_guard.dart';

class NeuraTruthGuardActions {
  final NeuraTruthGuard guard;

  NeuraTruthGuardActions({NeuraTruthGuard? guard}) : guard = guard ?? NeuraTruthGuard();

  void registerAll(NeuraActionRegistry reg) {
    reg.register(
      NeuraAction(
        id: 'truth_guard_check',
        title: 'Truth Guard Check',
        description: 'Checks a draft answer against citations and flags unsupported/overconfident claims.',
        risk: NeuraRisk.low,
        capability: NeuraCapability.textProcessing,
        handler: (req) async {
          final draft = (req.args['draft'] as String?)?.trim() ?? '';
          final sourcesJson = (req.args['sources'] as Map?)?.cast<String, dynamic>() ?? {};
          final q = (sourcesJson['query'] as String?) ?? '';
          final list = (sourcesJson['citations'] as List?)?.cast<Map<String, dynamic>>() ?? const [];

          final packet = NeuraSourcesPacket(
            query: q,
            citations: list.map(NeuraCitation.fromJson).toList(),
          );

          final overlap = (req.args['minKeywordOverlap'] as int?) ?? 2;

          final result = guard.check(
            draftAnswer: draft,
            sources: packet,
            minKeywordOverlap: overlap,
          );

          return NeuraActionResult.success('OK', data: result.toJson());
        },
      ),
    );
  }
}
