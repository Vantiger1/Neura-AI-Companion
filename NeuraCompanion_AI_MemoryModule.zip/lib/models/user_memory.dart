import 'package:flutter/foundation.dart';

@immutable
class UserMemory {
  final String id;
  final DateTime timestamp;
  final String moodTag;
  final List<String> keywords;
  final String source;

  const UserMemory({
    required this.id,
    required this.timestamp,
    required this.moodTag,
    required this.keywords,
    required this.source,
  });

  Map<String, dynamic> toMap() => {
        'id': id,
        'timestamp': timestamp.toIso8601String(),
        'moodTag': moodTag,
        'keywords': keywords,
        'source': source,
      };

  factory UserMemory.fromMap(Map<String, dynamic> map) => UserMemory(
        id: map['id'],
        timestamp: DateTime.parse(map['timestamp']),
        moodTag: map['moodTag'],
        keywords: List<String>.from(map['keywords']),
        source: map['source'],
      );
}
