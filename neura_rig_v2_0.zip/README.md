
# NeuraRig v2.0 — Unified Lightweight Controller

## Features
Gaze + smooth lookAt, saccade clustering, autoBlink (asym + glint), eyelid inertia,
affect/affectPlus (cheek→corners + lower-lid assist), SmileSpring, transitionAffect
(per-emotion easing), visemes with jaw tilt, phoneme→viseme + scheduler,
breathing (head-coupled + variability), audioReact, ambient luminance→pupil,
idle attention hotspots, micro idle, glow.

## Core API
```js
// Eyes & gaze
NeuraRig.setGaze(dx, dy);
NeuraRig.lookAt(dx, dy, stiffness=32, damping=6);
NeuraRig.saccadeBurst(intensity=1);

// Blinks & lids
NeuraRig.setLids(openOr[openL,openR]);   // inertia spring
NeuraRig.setBlinkAsymmetry(skew);        // -1 L first … +1 R first
NeuraRig.blinkOnce(ms=120);
NeuraRig.autoBlink(true);

// Pupils & light/audio
NeuraRig.setPupil(rPx);
NeuraRig.setAmbientLuminance(0..1);
NeuraRig.audioReact(0..1);

// Affect
NeuraRig.setAffect({ browLift, smile });
NeuraRig.setAffectPlus({ squintL, squintR, cheek, nose, browTilt });
NeuraRig.smileSpring(intensity, { overshoot=.18, duration=260, settle=160 });
NeuraRig.transitionAffect({browLift, smile}, ms=220, mode='calm'|'focused'|'amused'|'sad'|'surprised');

// Speech
NeuraRig.showViseme('X'|'A'|'EE'|'FV'|'O'|'MBP'|'L'|'WQ'|'TH'); // jaw tilt on A/O/WQ
NeuraRig.phonemeToViseme('AH'); // -> 'A'
NeuraRig.scheduleVisemes(audioEl, [{t:ms, ph:'AH'}, ...], leadMs);

// Body & idle
NeuraRig.setPose({ head, neck, torso, armL, forearmL, armR, forearmR, legL, shinL, legR, shinR });
NeuraRig.breathe(on, amp=1.5, period=3000, variability=0.08);
NeuraRig.setGlow(opacity0..1);
NeuraRig.microIdle(true);
NeuraRig.setHotspots([[dx,dy], ...]);
NeuraRig.idleAttention(true);

// Router
NeuraRig.act({ /* combine any of the above in one JSON */ });
```

## Flutter (Dart) helper
```dart
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

class NeuraView extends StatefulWidget {
  const NeuraView({super.key});
  @override State<NeuraView> createState() => _NeuraViewState();
}

class _NeuraViewState extends State<NeuraView> {
  late final WebViewController _ctrl;
  @override void initState() {
    super.initState();
    _ctrl = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadFlutterAsset('assets/neura/index.html');
  }
  Future<void> neuraAct(Map<String,dynamic> action) async {
    final s = jsonEncode(action);
    await _ctrl.runJavaScript('NeuraRig.act($s);');
  }
  @override Widget build(BuildContext ctx) => WebViewWidget(controller: _ctrl);
}
```

## Android (Kotlin) helper
```kotlin
fun WebView.neuraAct(action: Map<String, Any>) {
    val json = JSONObject(action).toString()
    this.evaluateJavascript("NeuraRig.act($json);", null)
}
```

## iOS (Swift, WKWebView) helper
```swift
extension WKWebView {
  func neuraAct(_ action: [String: Any]) {
    let data = try! JSONSerialization.data(withJSONObject: action)
    let json = String(data: data, encoding: .utf8)!
    self.evaluateJavaScript("NeuraRig.act(\(json));", completionHandler: nil)
  }
}
```
