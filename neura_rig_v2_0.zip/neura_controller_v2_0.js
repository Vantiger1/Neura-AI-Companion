
/*! NeuraRig v2.0 — unified lightweight controller
 *  Features: gaze, smooth lookAt, saccadeBurst, autoBlink(+asym, glint), eyelid inertia,
 *  affect/affectPlus (cheek→corners+lower lids), smileSpring, transitionAffect (per-emotion easing),
 *  visemes + jaw pivot, phoneme→viseme + scheduler, breathing(+head coupling+variability),
 *  audioReact, ambient luminance→pupil, idleAttention hotspots, microIdle, glow.
 */
(function(global){
  const $=s=>document.querySelector(s), $$=s=>Array.from(document.querySelectorAll(s));
  if(!$("#neuraRig")){ console.warn("neuraRig not found"); return; }
  const clamp01=x=>Math.max(0,Math.min(1,x));

  // ---------- Highlights (catchlights) ----------
  function ensureHighlights(){
    ["L","R"].forEach(side=>{
      const eye = document.querySelector(`#eye_${side}`);
      if(!eye) return;
      if(!document.querySelector(`#hl_${side}`)){
        const hl = document.createElementNS("http://www.w3.org/2000/svg", "ellipse");
        hl.setAttribute("id", `hl_${side}`);
        hl.setAttribute("rx","6"); hl.setAttribute("ry","4");
        hl.setAttribute("fill","#ffffff"); hl.setAttribute("opacity","0.85");
        eye.appendChild(hl);
      }
    });
  } ensureHighlights();

  // ---------- Core helpers ----------
  const setRotation=(el,d)=>{ el.style.transform=`rotate(${d}deg)`; };

  // Gaze (immediate) + keep iris/pupil/highlights aligned
  function _applyGaze(dx,dy){
    [["L",460],["R",540]].forEach(([s,cx])=>{
      const i=$(`#iris_${s}`), p=$(`#pupil_${s}`), h=$(`#hl_${s}`);
      const x=cx+dx, y=780+dy;
      if(i){ i.setAttribute("cx",x); i.setAttribute("cy",y); }
      if(p){ p.setAttribute("cx",x); p.setAttribute("cy",y); }
      if(h){ h.setAttribute("cx", x-6); h.setAttribute("cy", y-6); }
    });
  }
  function setGaze(dx,dy){ _applyGaze(dx,dy); }

  // Smooth lookAt (critically-damped-ish mass-spring)
  let gazeTarget={x:0,y:0}, gazeState={x:0,y:0}, gvx=0, gvy=0, gazeRAF=null;
  function lookAt(x,y, stiffness=32, damping=6){
    gazeTarget={x,y};
    if(gazeRAF) return;
    const step=()=>{
      const ax = stiffness*(gazeTarget.x - gazeState.x) - damping*gvx;
      const ay = stiffness*(gazeTarget.y - gazeState.y) - damping*gvy;
      const dt=1/60;
      gvx += ax*dt; gvy += ay*dt;
      gazeState.x += gvx*dt; gazeState.y += gvy*dt;
      _applyGaze(gazeState.x, gazeState.y);
      const head=$("#head"); if(head) setRotation(head, Math.max(-6, Math.min(6, gazeState.x*0.6)));
      if(Math.hypot(gazeTarget.x-gazeState.x, gazeTarget.y-gazeState.y) > 0.01 || Math.hypot(gvx,gvy) > 0.01){
        gazeRAF=requestAnimationFrame(step);
      } else { gazeRAF=null; gvx=gvy=0; }
    };
    gazeRAF=requestAnimationFrame(step);
  }

  // Saccade cluster (two quick jumps then settle)
  function saccadeBurst(intensity=1){
    const step=(dx,dy,delay)=> setTimeout(()=> setGaze(dx,dy), delay);
    const dx1=(Math.random()-.5)*4*intensity, dy1=(Math.random()-.5)*3*intensity;
    const dx2=(Math.random()-.5)*2*intensity, dy2=(Math.random()-.5)*2*intensity;
    step(dx1,dy1, 0);
    step(dx1+dx2, dy1+dy2, 60);
    step(0,0, 160);
  }

  // ---------- Eyelid inertia (springy openness) ----------
  let lidTargetL=1, lidTargetR=1, lidOpenL=1, lidOpenR=1, lvL=0, lvR=0, lidRAF=null;
  function setLids(open=1){
    if(Array.isArray(open)){ lidTargetL=clamp01(open[0]); lidTargetR=clamp01(open[1]??open[0]); }
    else { lidTargetL=lidTargetR=clamp01(open); }
    if(!lidRAF){ lidRAF=requestAnimationFrame(lidStep); }
  }
  function setEyeOpennessRaw(side, open){
    const span=22;
    const u=$(`#lidU_${side}`), l=$(`#lidL_${side}`);
    if(!u||!l) return;
    const upperH=(1-open)*span, lowerH=(1-open)*span;
    u.setAttribute("y",780-22); u.setAttribute("height",upperH);
    l.setAttribute("y",780+22-lowerH); l.setAttribute("height",lowerH);
  }
  function lidStep(){
    const kOpen=42, cOpen=6, kClose=26, cClose=5, dt=1/60;
    // Left
    const kL = (lidTargetL > lidOpenL) ? kOpen : kClose;
    const cL = (lidTargetL > lidOpenL) ? cOpen : cClose;
    const aL = kL*(lidTargetL - lidOpenL) - cL*lvL;
    lvL += aL*dt; lidOpenL = clamp01(lidOpenL + lvL*dt);
    // Right
    const kR = (lidTargetR > lidOpenR) ? kOpen : kClose;
    const cR = (lidTargetR > lidOpenR) ? cOpen : cClose;
    const aR = kR*(lidTargetR - lidOpenR) - cR*lvR;
    lvR += aR*dt; lidOpenR = clamp01(lidOpenR + lvR*dt);

    setEyeOpennessRaw("L", lidOpenL);
    setEyeOpennessRaw("R", lidOpenR);

    // highlight dims with closure
    ["L","R"].forEach(s=>{
      const h=$(`#hl_${s}`);
      const open = (s==="L"? lidOpenL: lidOpenR);
      if(h){ h.setAttribute("opacity", (0.5 + 0.5*open).toFixed(2)); }
    });

    if(Math.abs(lidTargetL-lidOpenL)>0.002 || Math.abs(lidTargetR-lidOpenR)>0.002 || Math.abs(lvL)>0.002 || Math.abs(lvR)>0.002){
      lidRAF=requestAnimationFrame(lidStep);
    } else { lidRAF=null; }
  }

  // Blink with glint & optional asymmetry
  let blinking=false, blinkSkew=0;
  function setBlinkAsymmetry(skew=0){ blinkSkew=Math.max(-1, Math.min(1, skew)); }
  function glintFlash(){
    ["L","R"].forEach(s=>{ const h=$(`#hl_${s}`); if(!h) return;
      h.setAttribute("opacity","1"); h.setAttribute("rx","8"); h.setAttribute("ry","5");
      setTimeout(()=>{ h.setAttribute("opacity","0.85"); h.setAttribute("rx","6"); h.setAttribute("ry","4"); }, 90);
    });
  }
  function blinkOnce(duration=120){
    const skewMs = 40 * blinkSkew;
    setTimeout(()=> setLids([0, lidOpenR]), Math.max(0, -skewMs));
    setTimeout(()=> setLids([lidOpenL, 0]), Math.max(0,  skewMs));
    setTimeout(()=> { setLids(1); glintFlash(); }, duration + Math.abs(skewMs));
  }
  function autoBlink(on=true, min=2200, max=5200){
    blinking=on;
    const loop=()=>{ if(!blinking) return; blinkOnce(120); setTimeout(loop, Math.random()*(max-min)+min); };
    if(on) loop();
  }

  // Pupils, luminance & audio hooks
  function setPupil(r=7){ r=Math.max(3,Math.min(10,r)); ["L","R"].forEach(s=>{ const p=$(`#pupil_${s}`); if(p) p.setAttribute("r",r); }); }
  function setAmbientLuminance(l){ l=clamp01(l); setPupil(10 - 7*l); } // dark→big pupils, bright→small
  function audioReact(level){ level=clamp01(level); setPupil(6 + 3*level); const head=$("#head"); if(head) setRotation(head, (level-0.5)*2); }

  // Affect basics
  function setAffect({browLift=0, smile=0}={}){
    const bl=$("#brow_left"), br=$("#brow_right"), neutral=$("#viseme_X");
    if(bl&&br){
      bl.setAttribute("d", `M440,${740-browLift} C455,${730-browLift} 470,${730-browLift} 485,${740-browLift}`);
      br.setAttribute("d", `M515,${740-browLift} C530,${730-browLift} 545,${730-browLift} 560,${740-browLift}`);
    }
    if(neutral){
      const mid = 860 + 10*smile;
      const corner = 845 - 12*Math.max(0,smile);
      neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
      applyCheekLowerLid(Math.max(0,smile));
    }
  }
  function setAffectPlus({squintL=0, squintR=0, cheek=0, nose=0, browTilt=0}={}){
    const openL = clamp01(1 - 0.6*squintL);
    const openR = clamp01(1 - 0.6*squintR);
    setLids([openL, openR]);
    const neutral=$("#viseme_X");
    if(neutral){
      const cornerLift = 12*cheek;
      const mid = 860 + 6*cheek;
      const cornerY = 845 - cornerLift;
      neutral.setAttribute("d", `M455,${cornerY} Q500,${mid} 545,${cornerY}`);
      applyCheekLowerLid(cheek);
    }
    const bl=$("#brow_left"), br=$("#brow_right");
    if(bl&&br){
      const shift = 6*nose, tilt = browTilt||0;
      bl.setAttribute("d", `M440,${740-shift+tilt*0.2} C455,${730-shift+tilt*0.2} 470,${730-shift} 485,${740-shift}`);
      br.setAttribute("d", `M515,${740-shift-tilt*0.2} C530,${730-shift-tilt*0.2} 545,${730-shift} 560,${740-shift}`);
    }
  }
  function applyCheekLowerLid(cheek){
    cheek=clamp01(cheek);
    const maxRaise=6, raise=maxRaise*cheek;
    ["L","R"].forEach(side=>{
      const l=$(`#lidL_${side}`);
      if(l){
        const h=parseFloat(l.getAttribute("height")||"0");
        const nh=h + raise/2;
        l.setAttribute("height", nh);
        l.setAttribute("y", 780+22-nh);
      }
    });
  }

  // Smile spring tween
  function smileSpring(intensity=1, {overshoot=0.18, duration=260, settle=160}={}){
    intensity=clamp01(intensity);
    const neutral=$("#viseme_X"); if(!neutral) return;
    const t0=performance.now();
    let phase=0;
    function easeOutBack(t){ const c1=1.70158, c3=c1+1; return 1 + c3*Math.pow(t-1,3) + c1*Math.pow(t-1,2); }
    function frame(){
      const t=(performance.now()-t0)/duration;
      if(t<1){
        const s=easeOutBack(t)*(1+overshoot)-overshoot;
        const corner = 845 - 12*intensity*s;
        const mid = 860 + 8*intensity*(1-s*0.5);
        neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
        applyCheekLowerLid(intensity*s*0.9);
        requestAnimationFrame(frame);
      } else {
        const s0=performance.now();
        (function settle(){
          const u=(performance.now()-s0)/settle;
          const s=1 - Math.min(1,u)*0.15;
          const corner = 845 - 12*intensity*s;
          const mid = 860 + 8*intensity*(1-s*0.5);
          neutral.setAttribute("d", `M455,${corner} Q500,${mid} 545,${corner}`);
          applyCheekLowerLid(intensity*s*0.9);
          if(u<1) requestAnimationFrame(settle);
        })();
      }
    }
    requestAnimationFrame(frame);
  }

  // Per-emotion easing helper
  const EASE = {
    calm: t=>t*t*(3-2*t),
    focused: t=>t<.3? (t/.3) : 1-(1-t)/(1-.3),
    amused: t=>1- Math.pow(1-t, 2.2),
    sad: t=>Math.pow(t,1.8),
    surprised: t=>t<.5? (2*t*t) : 1- Math.pow(-2*t+2,2)/2
  };
  function transitionAffect(target, ms=220, mode='calm'){
    const ease = EASE[mode]||EASE.calm;
    const bl0=0, sm0=0;
    const t0=performance.now();
    function frame(){
      const u=Math.min(1, (performance.now()-t0)/ms);
      const e=ease(u);
      const browLift = (target.browLift||0)*e + bl0*(1-e);
      const smile    = (target.smile||0)*e + sm0*(1-e);
      setAffect({browLift, smile});
      if(u<1) requestAnimationFrame(frame);
    }
    requestAnimationFrame(frame);
  }

  // Pose & breathing (with head pitch coupling + variability)
  function setPose(p={}){
    [["#head","head"],["#neck","neck"],["#torso","torso"],
     ["#arm_L","armL"],["#forearm_L","forearmL"],
     ["#arm_R","armR"],["#forearm_R","forearmR"],
     ["#leg_L","legL"],["#shin_L","shinL"],
     ["#leg_R","legR"],["#shin_R","shinR"]]
    .forEach(([sel,key])=>{ const deg=p[key]??0; const el=$(sel); if(el) setRotation(el,deg); });
  }
  let breatheId=null, breathPeriod=3000, breathAmp=1.5, breatheVar=0.08;
  function breathe(on=true, amp=1.5, period=3000, variability=0.08){
    breathAmp=amp; breathPeriod=period; breatheVar=variability;
    if(breatheId) cancelAnimationFrame(breatheId), breatheId=null;
    if(!on) return;
    const torso=$("#torso"), head=$("#head"); let start=null;
    function step(ts){
      if(!start) start=ts;
      const phase=(ts-start)/breathPeriod;
      const s=1+Math.sin(phase*2*Math.PI)*breathAmp/100;
      if(torso) torso.style.transform=`scale(${s})`;
      if(head)  setRotation(head, Math.sin(phase*2*Math.PI)*0.3);
      if(Math.floor(phase)%2===0 && Math.random()<0.005){
        breathPeriod = period*(1 + (Math.random()*2-1)*breatheVar);
      }
      breatheId=requestAnimationFrame(step);
    }
    breatheId=requestAnimationFrame(step);
  }

  // Glow
  function setGlow(i=1){ const g=$("#face_glow"); if(g) g.style.opacity=clamp01(i); }

  // Idle micro + idle attention
  let microId=null;
  function microIdle(on=true){
    if(microId){ clearInterval(microId); microId=null; }
    if(!on) return;
    microId=setInterval(()=>{
      const dx=(Math.random()-.5)*4, dy=(Math.random()-.5)*3; setGaze(dx,dy);
      const head=$("#head"); if(head) setRotation(head,(Math.random()-.5)*4);
    }, 450+Math.random()*400);
  }
  let attentionOn=false, attTimer=null, hotspots=[[6,-2],[-6,-2],[0,3]];
  function setHotspots(list){ if(Array.isArray(list)&&list.length) hotspots=list; }
  function idleAttention(on=true, interval=[2600, 5200]){
    attentionOn=on;
    if(attTimer) { clearTimeout(attTimer); attTimer=null; }
    const loop=()=>{
      if(!attentionOn) return;
      const [dx,dy] = hotspots[Math.floor(Math.random()*hotspots.length)];
      saccadeBurst(.9);
      setTimeout(()=> setGaze(dx,dy), 70);
      attTimer = setTimeout(loop, Math.random()*(interval[1]-interval[0])+interval[0]);
    };
    if(on) loop();
  }

  // Visemes + jaw tilt
  function showViseme(n){
    $$(".viseme").forEach(v=>v.classList.add("hidden"));
    (document.querySelector(`#viseme_${n}`)||$("#viseme_X"))?.classList.remove("hidden");
    const mouth = document.querySelector('#mouth');
    if(mouth){
      let angle = 0;
      if(n==='A'||n==='O'||n==='WQ'){ angle = 4; }
      mouth.style.transformOrigin = '500px 845px';
      mouth.style.transform = `rotate(${angle}deg)`;
    }
  }

  // phoneme→viseme & scheduler
  const MAP={ A:["AA","AH","AO"], EE:["IY","IH","EH","EY","AE"], WQ:["UW","W"], O:["OW","OH","UH","UW"], FV:["F","V"], L:["L"], TH:["TH","DH"], MBP:["M","B","P"], X:["SIL","REST"] };
  function phonemeToViseme(ph){ ph=(ph||"").toUpperCase(); for(const [v,arr] of Object.entries(MAP)) if(arr.includes(ph)) return v; return "X"; }
  function scheduleVisemes(audio,timeline,lead=0){
    if(!timeline||!timeline.length) return; const start=performance.now()+50; audio.currentTime=0; audio.play().catch(()=>{});
    timeline.forEach(({t,ph})=>{ const when=start+t-lead; setTimeout(()=>showViseme(phonemeToViseme(ph)), Math.max(0, when-performance.now())); });
  }

  // Public API
  const API = {
    // Gaze & eyes
    setGaze, lookAt, saccadeBurst,
    setLids, setBlinkAsymmetry, blinkOnce, autoBlink,
    setPupil, setAmbientLuminance, audioReact,
    // Affect & animation
    setAffect, setAffectPlus, smileSpring, transitionAffect,
    // Visemes & speech
    showViseme, phonemeToViseme, scheduleVisemes,
    // Body & idle
    setPose, breathe, setGlow, microIdle, idleAttention, setHotspots,
    // Single-call router
    act(json){
      try{
        const c=(typeof json==='string')?JSON.parse(json):json;
        if(c.viseme) showViseme(c.viseme);
        if(c.gaze) setGaze(c.gaze[0], c.gaze[1]);
        if(c.lookAt) lookAt(c.lookAt[0], c.lookAt[1], c.lookK?.[0]??32, c.lookK?.[1]??6);
        if(c.blink) (c.blink==='auto'? autoBlink(true): blinkOnce(c.blink));
        if(c.blinkSkew!==undefined) setBlinkAsymmetry(c.blinkSkew);
        if(c.affect) setAffect(c.affect);
        if(c.affectPlus) setAffectPlus(c.affectPlus);
        if(c.smileSpring!==undefined) smileSpring(c.smileSpring, c.springOpts||{});
        if(c.pose) setPose(c.pose);
        if(c.breathe!==undefined) breathe(!!c.breathe, c.breatheAmp||1.5, c.breathePeriod||3000, c.breatheVar||0.08);
        if(c.glow!==undefined) setGlow(c.glow);
        if(c.micro!==undefined) microIdle(!!c.micro);
        if(c.lids!==undefined) setLids(c.lids);
        if(c.pupil!==undefined) setPupil(c.pupil);
        if(c.audioLevel!==undefined) audioReact(c.audioLevel);
        if(c.ambient!==undefined) setAmbientLuminance(c.ambient);
        if(c.attention!==undefined) idleAttention(!!c.attention);
        if(c.hotspots) setHotspots(c.hotspots);
      } catch(e){ console.error("Neura API act error", e); }
    }
  };
  global.NeuraRig=API;
})(window);
