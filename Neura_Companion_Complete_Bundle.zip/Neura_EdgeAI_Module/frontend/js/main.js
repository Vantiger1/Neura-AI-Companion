// frontend/js/main.js
import * as tf from '@tensorflow/tfjs';

const featurePermissions = {}; // populated elsewhere

let edgeModel, scalerMean, scalerStd;
const eventQueue = [];

export function enqueueLocalEvent(evt) {
  eventQueue.push(evt);
}

export function dequeueLocalEvent() {
  return eventQueue.shift();
}

async function initEdgeAI() {
  edgeModel = await tf.loadGraphModel('/models/health_predictor/tfjs_model/model.json');
  const scaler = await fetch('/models/health_predictor/scaler.json').then(r => r.json());
  scalerMean = scaler.mean; scalerStd = scaler.std;
}

// decision logic for offline
async function localAIDecision(event, data) {
  switch(event) {
    case 'moodDetected':
      return { action: 'confirmMood', params:{ mood: data.mood } };
    case 'predictRequest':
      const norm = data.features.map((v,i) => (v - scalerMean[i]) / scalerStd[i]);
      const input = tf.tensor2d([norm]);
      const [sT, fT] = edgeModel.predict(input);
      const stress = (await sT.data())[0];
      const fatigue = (await fT.data())[0];
      if (stress > 0.8) return { action:'suggestRelaxation', params:{} };
      else if (fatigue > 0.7) return { action:'suggestNap', params:{} };
      else return { action:null, params:{} };
    default:
      return { action:null, params:{} };
  }
}

export async function aiLoop() {
  if (featurePermissions.edgeai) await initEdgeAI();
  while(true) {
    let result;
    if (featurePermissions.edgeai && !navigator.onLine) {
      const evt = dequeueLocalEvent();
      if (!evt) { await new Promise(r=>setTimeout(r, 1000)); continue; }
      result = await localAIDecision(evt.event, evt.data);
    } else {
      const res = await fetch('/api/neura/next-action');
      result = await res.json();
    }
    if (result.action) handleAction(result.action, result.params);
    await new Promise(r=>setTimeout(r, 1000));
  }
}

// placeholder handleAction
function handleAction(action, params) {
  console.log('Edge AI action:', action, params);
}

// override callNeuraAI to queue when offline
export function callNeuraAI(event, data) {
  if (featurePermissions.edgeai && !navigator.onLine) {
    enqueueLocalEvent({event, data});
  } else {
    fetch('/api/neura/event', {method:'POST', headers:{'Content-Type':'application/json'}, body:JSON.stringify({event,data})});
  }
}
