// frontend/sw.js
const CACHE = 'neura-edge-v1';
const ASSETS = [
  '/', '/index.html',
  '/js/main.js',
  '/models/health_predictor/tfjs_model/model.json',
  '/models/health_predictor/scaler.json'
];

self.addEventListener('install', e =>
  e.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)))
);

self.addEventListener('fetch', e =>
  e.respondWith(caches.match(e.request).then(hit => hit || fetch(e.request)))
);
