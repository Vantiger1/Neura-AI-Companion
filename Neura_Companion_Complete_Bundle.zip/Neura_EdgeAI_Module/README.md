# Neura Edge AI Offline Support Module

## Frontend

- **sw.js**: Service worker caches assets for offline.
- **js/main.js**: AI loop that uses `localAIDecision` when offline & edgeai enabled.
- Implements `enqueueLocalEvent` & `dequeueLocalEvent` as in-memory queue.

## Usage

1. Include `<script>navigator.serviceWorker.register('/sw.js');</script>` in index.html.
2. Load `js/main.js` as module.
3. Ensure `featurePermissions.edgeai` toggle is wired.
4. Test by toggling offline in DevTools and firing `callNeuraAI('moodDetected', {...})` or `callNeuraAI('predictRequest', {features: [...]})`.

This scaffolds offline AI.    
