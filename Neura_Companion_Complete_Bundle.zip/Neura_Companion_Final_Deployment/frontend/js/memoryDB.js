// IndexedDB helper for memories
export const dbName = 'NeuraMemoryDB';
export const storeName = 'memories';
// ... rest of the memoryDB.js code ...
