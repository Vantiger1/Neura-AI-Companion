// server/blockchain.js
const Web3 = require('web3');
const { vaultAddress } = require('./vaultConfig');
const DataVaultABI = require('../blockchain/artifacts/contracts/DataVault.sol/DataVault.json').abi;
const web3 = new Web3('http://127.0.0.1:8545');

let vaultContract, defaultAccount;

async function initVault() {
  const accounts = await web3.eth.getAccounts();
  defaultAccount = accounts[0];
  vaultContract = new web3.eth.Contract(DataVaultABI, vaultAddress);
}

initVault();

async function storeOnChain(userId, dataHash) {
  if (!vaultContract) throw new Error("Contract not initialized");
  const receipt = await vaultContract.methods
    .storeRecord(userId, dataHash)
    .send({ from: defaultAccount, gas: 300000 });
  return receipt.events.RecordStored.returnValues.id;
}

module.exports = { storeOnChain };
