// contracts/DataVault.sol
// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract DataVault {
    struct Record {
        uint256 timestamp;
        string userId;
        string dataHash;
    }

    Record[] public records;

    event RecordStored(uint256 indexed id, uint256 timestamp, string userId, string dataHash);

    function storeRecord(string calldata userId, string calldata dataHash) external returns (uint256) {
        uint256 id = records.length;
        records.push(Record(block.timestamp, userId, dataHash));
        emit RecordStored(id, block.timestamp, userId, dataHash);
        return id;
    }

    function getRecord(uint256 id) external view returns (uint256, string memory, string memory) {
        Record storage r = records[id];
        return (r.timestamp, r.userId, r.dataHash);
    }

    function totalRecords() external view returns (uint256) {
        return records.length;
    }
}
