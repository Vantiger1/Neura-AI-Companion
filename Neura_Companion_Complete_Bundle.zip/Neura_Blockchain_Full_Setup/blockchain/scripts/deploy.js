// scripts/deploy.js
const hre = require("hardhat");

async function main() {
  const DataVault = await hre.ethers.getContractFactory("DataVault");
  const vault = await DataVault.deploy();
  await vault.deployed();
  console.log("DataVault deployed to:", vault.address);
}
main().catch(error => {
  console.error(error);
  process.exit(1);
});
