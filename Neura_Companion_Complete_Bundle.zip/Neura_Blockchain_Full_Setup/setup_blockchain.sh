#!/bin/bash
# Setup Ganache or Hardhat node, compile and deploy contract

# Start Hardhat node in background
echo "Starting Hardhat node..."
npx hardhat node > hh_node.log 2>&1 &
HH_NODE_PID=$!
sleep 5

# Compile and deploy contract
echo "Compiling and deploying contract..."
cd blockchain
npm install
npx hardhat compile
DEPLOY_OUTPUT=$(npx hardhat run scripts/deploy.js --network local)
echo "$DEPLOY_OUTPUT"

# Extract deployed address
ADDRESS=$(echo "$DEPLOY_OUTPUT" | grep -Eo "0x[a-fA-F0-9]{40}")
echo "Deployed contract address: $ADDRESS"

# Save address to server config
echo "module.exports = { vaultAddress: '$ADDRESS' };" > ../server/vaultConfig.js

# Kill Hardhat node
kill $HH_NODE_PID
echo "Setup complete. Vault address written to server/vaultConfig.js"
