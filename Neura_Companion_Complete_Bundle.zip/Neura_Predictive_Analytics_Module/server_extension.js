// server/server.js (append these lines)
const tf = require('@tensorflow/tfjs-node');
const path = require('path');
let healthModel = null;
(async () => {
  healthModel = await tf.loadLayersModel('file://' + path.resolve(__dirname,'../models/health_predictor/saved_model/model.json'));
  console.log('Health model loaded');
})();
app.post('/api/neura/predict', async (req, res) => {
  const { features } = req.body; // Array of 5 numbers
  if (!healthModel) return res.status(503).json({ error: 'Model not loaded' });
  const input = tf.tensor2d([features]);
  const [stressT, fatigueT] = healthModel.predict(input);
  const stress  = (await stressT.data())[0];
  const fatigue = (await fatigueT.data())[0];
  let action = null;
  if(stress > 0.8) action = { action:'suggestRelaxation' };
  else if(fatigue > 0.7) action = { action:'suggestNap' };
  res.json({ stress, fatigue, ...action });
});
