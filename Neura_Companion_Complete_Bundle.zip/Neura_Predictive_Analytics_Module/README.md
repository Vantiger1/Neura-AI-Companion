Neura Predictive Health Analytics Module

Scripts:
- scripts/health_analytics_pipeline.py: ingests CSVs, computes features, saves scaler.
- scripts/train_health_predictor.py: trains model and exports SavedModel.

Server:
- server_extension.js: code to append to server.js for /api/neura/predict.

Front-End:
- Load TF.js model from models/health_predictor/tfjs_model.
- Fetch scaler parameters and run runHealthPredict as provided.

Place biometric CSVs in data/biometric/. Run pipeline and training before starting server.
