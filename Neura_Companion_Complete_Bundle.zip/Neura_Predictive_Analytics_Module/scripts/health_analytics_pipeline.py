# scripts/health_analytics_pipeline.py
import pandas as pd
import numpy as np
import glob
import os
from sklearn.preprocessing import StandardScaler
from datetime import timedelta

DATA_DIR = 'data/biometric'
FEATURE_DIR = 'data/features'
os.makedirs(FEATURE_DIR, exist_ok=True)

def compute_features(df):
    df['timestamp'] = pd.to_datetime(df['timestamp'])
    df = df.sort_values('timestamp').set_index('timestamp')
    df['hrv_mean_1h'] = df['hrv'].rolling('1h').mean()
    df['hrv_std_1h']  = df['hrv'].rolling('1h').std()
    df['hrv_slope_1h']= df['hrv'].diff().rolling('1h').mean()
    df['activity_avg_1h'] = df['activity_level'].rolling('1h').mean()
    df['mood_code'] = df['mood'].astype('category').cat.codes
    df['mood_vol_2h'] = df['mood_code'].rolling('2h').apply(lambda x: np.sum(x.diff().abs()), raw=True)
    df = df.dropna()
    return df

def label_events(df):
    df['stress_risk'] = (df['hrv_mean_1h'] < df['hrv_mean_1h'].quantile(0.2)).astype(int)
    df['fatigue_risk'] = ((df['activity_avg_1h'] < df['activity_avg_1h'].quantile(0.2)) &
                          (df['heart_rate'] < df['heart_rate'].quantile(0.3))).astype(int)
    return df

def build_dataset():
    all_files = glob.glob(os.path.join(DATA_DIR, '*.csv'))
    feature_list = []
    for f in all_files:
        df = pd.read_csv(f)
        df_feat = compute_features(df)
        df_labeled = label_events(df_feat)
        feature_list.append(df_labeled)
    full = pd.concat(feature_list)
    X = full[['hrv_mean_1h','hrv_std_1h','hrv_slope_1h','activity_avg_1h','mood_vol_2h']]
    y_stress  = full['stress_risk']
    y_fatigue = full['fatigue_risk']
    scaler = StandardScaler()
    X_scaled = scaler.fit_transform(X)
    np.save(os.path.join(FEATURE_DIR,'X.npy'), X_scaled)
    np.save(os.path.join(FEATURE_DIR,'y_stress.npy'), y_stress.values)
    np.save(os.path.join(FEATURE_DIR,'y_fatigue.npy'), y_fatigue.values)
    import joblib
    joblib.dump(scaler, os.path.join(FEATURE_DIR,'scaler.joblib'))
    print('Feature dataset and scaler saved.')

if __name__ == '__main__':
    build_dataset()
