# scripts/train_health_predictor.py
import numpy as np
from tensorflow import keras
import os
import joblib

FEATURE_DIR = 'data/features'
MODEL_DIR   = 'models/health_predictor'
os.makedirs(MODEL_DIR, exist_ok=True)

X = np.load(os.path.join(FEATURE_DIR,'X.npy'))
y_stress  = np.load(os.path.join(FEATURE_DIR,'y_stress.npy'))
y_fatigue = np.load(os.path.join(FEATURE_DIR,'y_fatigue.npy'))
scaler = joblib.load(os.path.join(FEATURE_DIR,'scaler.joblib'))

def build_model():
    inp = keras.Input(shape=(X.shape[1],))
    x = keras.layers.Dense(32, activation='relu')(inp)
    x = keras.layers.Dense(16, activation='relu')(x)
    out_stress  = keras.layers.Dense(1, activation='sigmoid', name='stress')(x)
    out_fatigue = keras.layers.Dense(1, activation='sigmoid', name='fatigue')(x)
    model = keras.Model(inputs=inp, outputs=[out_stress, out_fatigue])
    model.compile(optimizer='adam',
                  loss={'stress':'binary_crossentropy','fatigue':'binary_crossentropy'},
                  metrics=['accuracy'])
    return model

model = build_model()
model.fit(X, {'stress':y_stress,'fatigue':y_fatigue},
          epochs=20, batch_size=64, validation_split=0.2)
model.save(os.path.join(MODEL_DIR,'saved_model'))
# After installing tensorflowjs, convert:
# tensorflowjs_converter --input_format=tf_saved_model --output_format=tfjs_graph_model #   models/health_predictor/saved_model models/health_predictor/tfjs_model
