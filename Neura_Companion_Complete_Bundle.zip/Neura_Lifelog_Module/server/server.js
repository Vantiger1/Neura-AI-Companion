// Lifelog memory endpoints
db.run(`CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  timestamp INTEGER,
  type TEXT,
  dataUrl TEXT,
  tags TEXT,
  transcript TEXT
)`);

app.post('/api/neura/memory', (req, res) => {
  const { type, dataUrl, tags, transcript } = req.body;
  const ts = Date.now();
  db.run(`INSERT INTO memories(timestamp,type,dataUrl,tags,transcript) VALUES(?,?,?,?,?)`,
         [ts,type,dataUrl,JSON.stringify(tags),transcript||''], function(err){
    if(err) return res.status(500).json({error:err.message});
    res.json({id:this.lastID,timestamp:ts});
  });
});

app.get('/api/neura/memory', (req, res) => {
  const q = req.query.query;
  let sql = `SELECT * FROM memories`;
  const params = [];
  if(q){
    sql += ` WHERE tags LIKE ? OR transcript LIKE ?`;
    params.push("%"+q+"%","%"+q+"%");
  }
  db.all(sql, params, (e, rows) => {
    if(e) return res.status(500).json({error:e.message});
    rows.forEach(r=>r.tags=JSON.parse(r.tags));
    res.json(rows);
  });
});

app.get('/api/neura/memory/:id', (req, res) => {
  db.get(`SELECT * FROM memories WHERE id = ?`, [req.params.id], (e,row) => {
    if(e) return res.status(500).json({error:e.message});
    if(!row) return res.status(404).json({error:'Not found'});
    row.tags=JSON.parse(row.tags);
    res.json(row);
  });
});
