export const dbName = 'NeuraMemoryDB';
export const storeName = 'memories';

export function openDB() {
  return new Promise((resolve, reject) => {
    const req = indexedDB.open(dbName, 1);
    req.onupgradeneeded = () => {
      const db = req.result;
      if (!db.objectStoreNames.contains(storeName)) {
        const store = db.createObjectStore(storeName, { keyPath: 'id', autoIncrement: true });
        store.createIndex('tags', 'tags', { multiEntry: true });
        store.createIndex('transcript', 'transcript', { multiEntry: true });
      }
    };
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function saveMemory(item) {
  const db = await openDB();
  return new Promise((resolve, reject) => {
    const tx = db.transaction(storeName, 'readwrite');
    const store = tx.objectStore(storeName);
    const req = store.add({ ...item, timestamp: Date.now() });
    req.onsuccess = () => resolve(req.result);
    req.onerror   = () => reject(req.error);
  });
}

export async function getAllMemories() {
  const db = await openDB();
  return new Promise(resolve => {
    const tx = db.transaction(storeName, 'readonly');
    const store = tx.objectStore(storeName);
    const req = store.getAll();
    req.onsuccess = () => resolve(req.result);
  });
}

export async function searchMemories(query) {
  const db = await openDB();
  return new Promise(resolve => {
    const tx = db.transaction(storeName, 'readonly');
n    const store = tx.objectStore(storeName);
    const idxTags = store.index('tags');
    const idxTrans = store.index('transcript');
    const results = new Map();
    idxTags.getAll(query).onsuccess = e => {
      e.target.result.forEach(item => results.set(item.id, item));
      idxTrans.getAll(query).onsuccess = e2 => {
        e2.target.result.forEach(item => results.set(item.id, item));
        resolve(Array.from(results.values()));
      };
    };
  });
}
