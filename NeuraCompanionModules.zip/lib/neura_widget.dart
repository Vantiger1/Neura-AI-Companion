import 'package:logger/logger.dart';

class NeuraWidget {
  final Logger logger;

  NeuraWidget({required this.logger});

  void render(dynamic container) {}
}
