import 'package:logger/logger.dart';

class HapticVisualCues {
  final Logger logger;

  HapticVisualCues({required this.logger});

  void triggerPattern(int patternId) {}
}
