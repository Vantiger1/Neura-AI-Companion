import 'package:logger/logger.dart';
import 'package:sensors/sensors.dart';

class ActivityPosture {
  final Logger logger;
  // Slouch detection dependencies

  ActivityPosture({required this.logger});

  void startMonitoring() {}
  void stopMonitoring() {}
}
