import 'package:logger/logger.dart';

class ClinicalUpgrades {
  final Logger logger;

  ClinicalUpgrades({required this.logger});

  void applyUpgrade(String id) {}
}
