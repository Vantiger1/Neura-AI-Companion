import 'package:logger/logger.dart';
import 'permissions_service.dart';
import 'healthos_client.dart';
import 'hrv_aggregator.dart';

class BiometricFeedback {
  final PermissionsService permService;
  final HealthOSClient osClient;
  final HRVAggregator aggregator;
  final Logger logger;

  BiometricFeedback({required this.permService, required this.osClient, required this.aggregator, required this.logger});

  Future<double?> fetchHRV(Duration interval) async {
    // HRV fetch logic
    return null;
  }
}
