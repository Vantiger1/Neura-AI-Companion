import 'package:logger/logger.dart';

class OnTheGoLogging {
  final Logger logger;
  // TTS and recorder dependencies

  OnTheGoLogging({required this.logger});

  void startVoiceLog() {}
  void stopVoiceLog() {}
  void playback(String text) {}
}
