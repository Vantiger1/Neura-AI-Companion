import 'package:logger/logger.dart';

class MicroWorkouts {
  final Logger logger;
  // exercise list and timer

  MicroWorkouts({required this.logger});

  void startWorkout() {}
  void pauseWorkout() {}
}
