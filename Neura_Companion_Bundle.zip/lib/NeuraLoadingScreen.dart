// Neura animated loading screen logic
