
import 'package:flutter/material.dart';
import 'widgets/emotion_memory_graph.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    final now = DateTime.now();
    final moodData = List.generate(7, (i) => MoodEntry(
      now.subtract(Duration(days: i)),
      'joy',
      (0.3 + i * 0.1).clamp(0.0, 1.0),
    ));

    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(title: Text('Emotion Memory Graph')),
        body: Padding(
          padding: const EdgeInsets.all(16.0),
          child: EmotionMemoryGraph(moodData: moodData, emotionFilter: 'joy'),
        ),
      ),
    );
  }
}
