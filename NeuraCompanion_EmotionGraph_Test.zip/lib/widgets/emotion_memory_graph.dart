
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter/material.dart';

class MoodEntry {
  final DateTime timestamp;
  final String emotion;
  final double intensity;

  MoodEntry(this.timestamp, this.emotion, this.intensity);
}

class EmotionMemoryGraph extends StatelessWidget {
  final List<MoodEntry> moodData;
  final String emotionFilter;

  EmotionMemoryGraph({required this.moodData, required this.emotionFilter});

  @override
  Widget build(BuildContext context) {
    final filtered = moodData.where((entry) => entry.emotion == emotionFilter).toList();

    final spots = filtered.map((entry) {
      final day = entry.timestamp.difference(DateTime.now()).inDays;
      return FlSpot(day.toDouble(), entry.intensity);
    }).toList();

    return LineChart(LineChartData(
      gridData: FlGridData(show: true),
      titlesData: FlTitlesData(show: true),
      lineBarsData: [
        LineChartBarData(
          spots: spots,
          isCurved: true,
          colors: [Colors.blueAccent],
          barWidth: 3,
          belowBarData: BarAreaData(show: true, colors: [Colors.blue.withOpacity(0.3)]),
        ),
      ],
    ));
  }
}
