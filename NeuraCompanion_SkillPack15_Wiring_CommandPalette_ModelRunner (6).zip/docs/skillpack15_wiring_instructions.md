# Skill Pack 15 — Wiring Layer (ActionBus + Command Palette + Model Runner Controls)

This patch wires the OS execution surface into a single kernel so Neura feels like an OS layer, not just a screen.

## What you get
- `NeuraKernel` singleton: registry + gate + executor + desktop llama.cpp runner
- `NeuraCommandPalette`: floating palette overlay to run actions
- `NeuraKernelLogScreen`: live view of kernel logs

## How to integrate (minimal)
1) Ensure Skill Pack 14 files exist:
- `lib/services/neura_action_bus/*`
- `lib/services/local_models/neura_llama_server_runner.dart`

2) Wrap your app root with the palette overlay:
In your `main.dart` (or wherever you return the root widget), wrap your `MaterialApp`:

```dart
return NeuraCommandPalette(
  child: MaterialApp(
    // ...
  ),
);
```

3) Add an optional route for logs:

```dart
routes: {
  '/neura_kernel_logs': (_) => const NeuraKernelLogScreen(),
}
```

## How to use
- Tap the floating "Neura" button.
- Search actions:
  - Local LLM Server Status
  - Start Local LLM Server (requires Full Access + approval)
  - Stop Local LLM Server

## Next recommended patch
Wire your Knowledge Pack suggestion objects to call `executor.execute(suggestedActionId, args: ...)`
and map each suggestion to a real allowlisted action.
