import 'package:flutter/material.dart';

import '../neura_kernel/neura_kernel.dart';

class NeuraKernelLogScreen extends StatefulWidget {
  const NeuraKernelLogScreen({super.key});

  @override
  State<NeuraKernelLogScreen> createState() => _NeuraKernelLogScreenState();
}

class _NeuraKernelLogScreenState extends State<NeuraKernelLogScreen> {
  final List<String> _lines = [];

  @override
  void initState() {
    super.initState();
    NeuraKernel.I.boot();
    NeuraKernel.I.logs.listen((l) {
      if (!mounted) return;
      setState(() => _lines.insert(0, l));
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Kernel Logs')),
      body: ListView.builder(
        itemCount: _lines.length,
        itemBuilder: (ctx, i) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: Text(_lines[i], style: const TextStyle(fontFamily: 'monospace', fontSize: 12)),
        ),
      ),
    );
  }
}
