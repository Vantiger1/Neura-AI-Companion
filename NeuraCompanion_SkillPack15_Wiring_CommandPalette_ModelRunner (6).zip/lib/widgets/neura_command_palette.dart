import 'package:flutter/material.dart';

import '../neura_kernel/neura_kernel.dart';
import '../services/neura_action_bus/neura_action.dart';

class NeuraCommandPalette extends StatefulWidget {
  final Widget child;

  const NeuraCommandPalette({super.key, required this.child});

  @override
  State<NeuraCommandPalette> createState() => _NeuraCommandPaletteState();
}

class _NeuraCommandPaletteState extends State<NeuraCommandPalette> {
  final _search = TextEditingController();
  bool _open = false;

  @override
  void initState() {
    super.initState();
    NeuraKernel.I.boot();
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  void open() => setState(() => _open = true);

  void close() {
    setState(() {
      _open = false;
      _search.text = '';
    });
  }

  List<NeuraAction> _filtered() {
    final q = _search.text.trim().toLowerCase();
    final all = NeuraKernel.I.registry.list();
    if (q.isEmpty) return all;
    return all.where((a) => a.title.toLowerCase().contains(q) || a.description.toLowerCase().contains(q)).toList();
  }

  Future<void> _runAction(NeuraAction action) async {
    final r = await NeuraKernel.I.executor.execute(action.id, args: {});
    if (!mounted) return;

    if (r.ok) {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${action.title}: ${r.message}')));
      close();
      return;
    }

    if (r.message == 'APPROVAL_REQUIRED') {
      final approved = await _askApproval(r.data);
      if (!approved) return;

      final r2 = await NeuraKernel.I.executor.approveAndExecute(action.id, args: {});
      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('${action.title}: ${r2.message}')));
      close();
      return;
    }

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(r.message)));
  }

  Future<bool> _askApproval(Map<String, dynamic> meta) async {
    return (await showDialog<bool>(
          context: context,
          builder: (ctx) => AlertDialog(
            title: Text('Approval required (${meta['risk']})'),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('${meta['title']}'),
                const SizedBox(height: 8),
                Text('${meta['description']}'),
                const SizedBox(height: 12),
                const Text('Only approve if you understand and consent to this action.'),
              ],
            ),
            actions: [
              TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
              ElevatedButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Approve')),
            ],
          ),
        )) ??
        false;
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        widget.child,
        Positioned(
          right: 12,
          bottom: 12,
          child: FloatingActionButton.extended(
            onPressed: open,
            label: const Text('Neura'),
            icon: const Icon(Icons.auto_awesome),
          ),
        ),
        if (_open)
          Positioned.fill(
            child: Material(
              color: Colors.black54,
              child: Center(
                child: ConstrainedBox(
                  constraints: const BoxConstraints(maxWidth: 680),
                  child: Card(
                    child: Padding(
                      padding: const EdgeInsets.all(12),
                      child: Column(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Row(
                            children: [
                              const Icon(Icons.search),
                              const SizedBox(width: 8),
                              Expanded(
                                child: TextField(
                                  controller: _search,
                                  autofocus: true,
                                  decoration: const InputDecoration(
                                    hintText: 'Search actions (e.g., Start Local LLM, Status, Stop)',
                                    border: InputBorder.none,
                                  ),
                                  onChanged: (_) => setState(() {}),
                                ),
                              ),
                              IconButton(onPressed: close, icon: const Icon(Icons.close)),
                            ],
                          ),
                          const Divider(),
                          ConstrainedBox(
                            constraints: const BoxConstraints(maxHeight: 360),
                            child: ListView(
                              shrinkWrap: true,
                              children: _filtered()
                                  .map(
                                    (a) => ListTile(
                                      title: Text(a.title),
                                      subtitle: Text(a.description),
                                      trailing: Text(a.risk.name.toUpperCase()),
                                      onTap: () => _runAction(a),
                                    ),
                                  )
                                  .toList(),
                            ),
                          ),
                          const SizedBox(height: 8),
                          Row(
                            children: const [
                              Icon(Icons.shield, size: 18),
                              SizedBox(width: 6),
                              Expanded(
                                child: Text(
                                  'High/Critical actions require Full Access + approval.',
                                  style: TextStyle(fontSize: 12),
                                ),
                              ),
                            ],
                          ),
                        ],
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
      ],
    );
  }
}
