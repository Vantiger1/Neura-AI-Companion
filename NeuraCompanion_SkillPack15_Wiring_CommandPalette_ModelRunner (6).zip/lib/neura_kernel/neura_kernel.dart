import 'dart:async';

import '../services/neura_action_bus/action_registry.dart';
import '../services/neura_action_bus/approval_gate.dart';
import '../services/neura_action_bus/builtin_actions.dart';
import '../services/neura_action_bus/neura_executor.dart';
import '../services/local_models/neura_llama_server_runner.dart';

/// NeuraKernel: single source of truth for:
/// - Action registry
/// - Approval gate
/// - Executor
/// - Desktop local model runner (llama.cpp server)
///
/// This keeps the OS-like layer consistent across screens and platforms.
class NeuraKernel {
  NeuraKernel._();

  static final NeuraKernel I = NeuraKernel._();

  final NeuraActionRegistry registry = NeuraActionRegistry();
  final NeuraApprovalGate gate = NeuraApprovalGate();
  late final NeuraActionExecutor executor = NeuraActionExecutor(registry: registry, gate: gate);

  final NeuraLlamaServerRunner llamaRunner = NeuraLlamaServerRunner();
  final StreamController<String> _log = StreamController.broadcast();

  Stream<String> get logs => _log.stream;

  bool _booted = false;

  Future<void> boot() async {
    if (_booted) return;
    _booted = true;

    // Mirror runner logs into kernel logs
    llamaRunner.logs.listen((l) => _log.add(l));

    // Register core actions (start/stop/status, run_suggestion placeholder)
    NeuraBuiltinActions(llamaRunner).registerAll(registry);

    _log.add('[kernel] boot complete');
  }

  void dispose() {
    try {
      llamaRunner.dispose();
    } catch (_) {}
    try {
      _log.close();
    } catch (_) {}
  }
}
