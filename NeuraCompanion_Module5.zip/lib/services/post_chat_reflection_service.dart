class PostChatReflectionService {
  /// Generates a reflection summary after chat session.
  Future<String> generateReflection(String sessionText) async {
    // TODO: call AI to summarize session
    return '';
  }
}
