class JournalPromptService {
  /// Fetches an AI-driven prompt based on mood and time of day.
  Future<String> fetchPrompt({String mood = '', DateTime? time}) async {
    // TODO: call AI prompt API
    return 'How are you feeling today?';
  }
}
