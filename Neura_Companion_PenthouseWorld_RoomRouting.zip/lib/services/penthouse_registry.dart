import 'package:flutter/material.dart';

import '../models/penthouse_object.dart';
import '../screens/avatar_selector_screen.dart';
import '../screens/dream_show_screen.dart';
import '../screens/dream_visualizer_screen.dart';
import '../screens/journal_prompt_screen.dart';
import '../screens/sync_status_screen.dart';
import '../screens/voice_journal_screen.dart';

/// Central registry of objects in the Penthouse.
///
/// Add new modules here and they become both tappable objects *and* voice intents.
class PenthouseRegistry {
  static List<PenthouseObject> objects() {
    return const [
      PenthouseObject(
        id: 'journal_desk',
        label: 'Journal Desk',
        roomId: 'reflection_bay',
        x: 0.18,
        y: 0.62,
        icon: Icons.edit_note,
        builder: (_) => JournalPromptScreen(),
      ),
      PenthouseObject(
        id: 'voice_booth',
        label: 'Voice Booth',
        roomId: 'voice_booth',
        x: 0.36,
        y: 0.78,
        icon: Icons.mic,
        builder: (_) => VoiceJournalScreen(),
      ),
      PenthouseObject(
        id: 'dream_bed',
        label: 'Dream Bed',
        roomId: 'dream_bay',
        x: 0.70,
        y: 0.62,
        icon: Icons.bedtime,
        builder: (_) => DreamVisualizerScreen(),
      ),
      PenthouseObject(
        id: 'dream_theater',
        label: 'Dream Theater',
        roomId: 'dream_bay',
        x: 0.84,
        y: 0.78,
        icon: Icons.movie,
        builder: (_) => DreamShowScreen(),
      ),
      PenthouseObject(
        id: 'avatar_mirror',
        label: 'Avatar Mirror',
        roomId: 'persona_lab',
        x: 0.52,
        y: 0.56,
        icon: Icons.face,
        builder: (_) => AvatarSelectorScreen(),
      ),
      PenthouseObject(
        id: 'sync_console',
        label: 'Sync Console',
        roomId: 'control_room',
        x: 0.08,
        y: 0.80,
        icon: Icons.cloud_sync,
        builder: (_) => SyncStatusScreen(),
      ),
    ];
  }

  static PenthouseObject? byId(String id) {
    for (final o in objects()) {
      if (o.id == id) return o;
    }
    return null;
  }
}
