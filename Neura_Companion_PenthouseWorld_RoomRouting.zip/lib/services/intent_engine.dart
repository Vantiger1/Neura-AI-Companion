import 'dart:math';

import 'penthouse_registry.dart';

class IntentResult {
  final String type; // 'object' or 'none'
  final String? id;
  final double score;

  const IntentResult(this.type, {this.id, required this.score});
}

/// Minimal intent detection that routes user speech/text to Penthouse objects.
///
/// Uses token overlap + fuzzy contains scoring. Keep it fast and offline.
class IntentEngine {
  static IntentResult detect(String input) {
    final q = _norm(input);
    if (q.isEmpty) return const IntentResult('none', score: 0);

    double best = 0;
    String? bestId;

    for (final obj in PenthouseRegistry.objects()) {
      final label = _norm(obj.label);
      final synonyms = _synonymsFor(obj.id).map(_norm).toList();
      final candidates = <String>[label, ...synonyms];

      for (final c in candidates) {
        final s = _score(q, c);
        if (s > best) {
          best = s;
          bestId = obj.id;
        }
      }
    }

    if (bestId != null && best >= 0.42) {
      return IntentResult('object', id: bestId, score: best);
    }
    return IntentResult('none', score: best);
  }

  static double _score(String query, String candidate) {
    if (query == candidate) return 1.0;
    if (query.contains(candidate) || candidate.contains(query)) return 0.82;

    final qt = query.split(' ').where((t) => t.isNotEmpty).toSet();
    final ct = candidate.split(' ').where((t) => t.isNotEmpty).toSet();
    final inter = qt.intersection(ct).length;
    final union = qt.union(ct).length;
    final jaccard = union == 0 ? 0.0 : inter / union;

    // Fuzzy similarity: normalized edit distance for small strings.
    final ed = _levenshtein(query, candidate);
    final maxLen = max(1, max(query.length, candidate.length));
    final fuzzy = 1.0 - (ed / maxLen);

    return (0.55 * jaccard) + (0.45 * fuzzy);
  }

  static String _norm(String s) {
    return s
        .toLowerCase()
        .replaceAll(RegExp(r'[^a-z0-9\s]'), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static List<String> _synonymsFor(String id) {
    switch (id) {
      case 'journal_desk':
        return ['journal', 'write', 'notes', 'reflection', 'diary'];
      case 'voice_booth':
        return ['voice', 'record', 'mic', 'speech journal'];
      case 'dream_bed':
        return ['dreams', 'sleep', 'dream visualizer'];
      case 'dream_theater':
        return ['dream show', 'replay', 'theater', 'movie'];
      case 'avatar_mirror':
        return ['avatar', 'persona', 'select avatar', 'mirror'];
      case 'sync_console':
        return ['sync', 'cloud', 'backup', 'status'];
      default:
        return [];
    }
  }

  static int _levenshtein(String a, String b) {
    if (a == b) return 0;
    if (a.isEmpty) return b.length;
    if (b.isEmpty) return a.length;

    final prev = List<int>.generate(b.length + 1, (i) => i);
    final curr = List<int>.filled(b.length + 1, 0);

    for (int i = 1; i <= a.length; i++) {
      curr[0] = i;
      for (int j = 1; j <= b.length; j++) {
        final cost = a.codeUnitAt(i - 1) == b.codeUnitAt(j - 1) ? 0 : 1;
        curr[j] = min(
          min(curr[j - 1] + 1, prev[j] + 1),
          prev[j - 1] + cost,
        );
      }
      for (int j = 0; j <= b.length; j++) {
        prev[j] = curr[j];
      }
    }
    return prev[b.length];
  }
}
