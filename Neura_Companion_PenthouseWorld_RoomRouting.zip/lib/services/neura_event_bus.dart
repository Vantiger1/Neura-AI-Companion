import 'package:flutter/foundation.dart';

/// Tiny in-app event bus for cross-widget navigation/animation triggers.
///
/// We keep this intentionally simple (ValueNotifiers) so it works
/// without extra dependencies or complex state management.
class NeuraEventBus {
  /// When set, the Penthouse should animate Neura to the object and open it.
  static final ValueNotifier<String?> goToObjectId = ValueNotifier<String?>(null);

  /// When set, the UI can display a brief status line.
  static final ValueNotifier<String?> statusLine = ValueNotifier<String?>(null);

  static void announce(String message) {
    statusLine.value = message;
  }

  static void requestObject(String objectId) {
    goToObjectId.value = objectId;
  }
}
