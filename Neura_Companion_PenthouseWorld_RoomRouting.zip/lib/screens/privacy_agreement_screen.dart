import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class PrivacyAgreementScreen extends StatelessWidget {
  static const _kAcceptedKey = 'privacy_accepted';

  static Future<bool> isAccepted() async {
    final prefs = await SharedPreferences.getInstance();
    return prefs.getBool(_kAcceptedKey) ?? false;
  }

  static Future<void> setAccepted(bool v) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAcceptedKey, v);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Privacy Agreement')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Before we begin, please confirm you understand:\n'
              '\n• Neura Companion is not medical advice.'
              '\n• Your data stays local-first and can be deleted anytime.'
              '\n• You are in control of memory and permissions.',
            ),
            const SizedBox(height: 16),
            const Expanded(
              child: SingleChildScrollView(
                child: Text(
                  'Privacy & Terms (Summary)\n\n'
                  'We minimize data collection. When cloud sync is enabled, it is opt-in. '
                  'This app provides coaching and reflection tools and should not be used '
                  'as a substitute for professional help.\n\n'
                  'You can export or delete your local data from settings at any time.',
                ),
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: ElevatedButton(
                    onPressed: () async {
                      await setAccepted(true);
                      if (context.mounted) {
                        Navigator.of(context).pushReplacementNamed('/');
                      }
                    },
                    child: const Text('I Agree'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
