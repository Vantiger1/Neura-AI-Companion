import 'package:flutter/material.dart';

class ChallengeListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Challenges')),
      body: const Center(
        child: Text('Challenges module (stub).'),
      ),
    );
  }
}
