import 'package:flutter/material.dart';

class FeedScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('MoodNet Feed')),
      body: const Center(
        child: Text('Public ritual feed (stub).'),
      ),
    );
  }
}
