import 'dart:async';

import 'package:flutter/material.dart';

import '../models/penthouse_object.dart';
import '../services/neura_event_bus.dart';
import '../services/neura_state_service.dart';
import '../services/penthouse_registry.dart';
import '../widgets/mascot_widget.dart';

/// The "module world" home screen.
///
/// Modules are physical objects. Neura "moves" to an object, then the module opens.
class PenthouseScreen extends StatefulWidget {
  @override
  State<PenthouseScreen> createState() => _PenthouseScreenState();
}

class _PenthouseScreenState extends State<PenthouseScreen> {
  late final List<PenthouseObject> _objects;
  StreamSubscription? _sub;

  // Normalized Neura position.
  double _nx = 0.50;
  double _ny = 0.30;

  @override
  void initState() {
    super.initState();
    _objects = PenthouseRegistry.objects();
    // Restore a sensible position.
    final last = NeuraStateService.lastObject;
    if (last != null) {
      final o = PenthouseRegistry.byId(last);
      if (o != null) {
        _nx = o.x;
        _ny = o.y;
      }
    }

    NeuraStateService.setRoom('penthouse');

    // Listen for voice-driven routing.
    NeuraEventBus.goToObjectId.addListener(_onExternalObjectRequest);
  }

  @override
  void dispose() {
    NeuraEventBus.goToObjectId.removeListener(_onExternalObjectRequest);
    _sub?.cancel();
    super.dispose();
  }

  void _onExternalObjectRequest() {
    final id = NeuraEventBus.goToObjectId.value;
    if (id == null) return;
    // Clear it to avoid re-triggering.
    NeuraEventBus.goToObjectId.value = null;
    final obj = PenthouseRegistry.byId(id);
    if (obj != null) {
      _goToObject(obj);
    }
  }

  Future<void> _goToObject(PenthouseObject obj) async {
    setState(() {
      _nx = obj.x;
      _ny = obj.y;
    });

    await NeuraStateService.setLastObject(obj.id);
    await NeuraStateService.setRoom(obj.roomId);
    NeuraEventBus.announce('Heading to ${obj.label}…');

    // Give the movement time to complete, then open.
    await Future.delayed(const Duration(milliseconds: 650));
    if (!mounted) return;
    Navigator.of(context).push(
      MaterialPageRoute(builder: obj.builder),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Theme.of(context).colorScheme.surface,
      body: LayoutBuilder(
        builder: (context, constraints) {
          final w = constraints.maxWidth;
          final h = constraints.maxHeight;

          // Neura on-screen position.
          final neuraX = (w * _nx).clamp(0.0, w - 120);
          final neuraY = (h * _ny).clamp(0.0, h - 160);

          return Stack(
            children: [
              // Minimal "penthouse" background; replace with your room art later.
              Container(
                decoration: const BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0B1020), Color(0xFF161A2B)],
                  ),
                ),
              ),

              // Objects.
              for (final obj in _objects) _buildObject(obj, w, h),

              // Neura avatar "moves" between objects.
              AnimatedPositioned(
                duration: const Duration(milliseconds: 620),
                curve: Curves.easeInOutCubic,
                left: neuraX,
                top: neuraY,
                child: Column(
                  children: [
                    MascotWidget(),
                    const SizedBox(height: 6),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                      decoration: BoxDecoration(
                        color: Colors.black.withOpacity(0.45),
                        borderRadius: BorderRadius.circular(999),
                      ),
                      child: Text(
                        'Neura • ${NeuraStateService.mood}',
                        style: const TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),

              // Title.
              SafeArea(
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Text(
                    'Penthouse',
                    style: Theme.of(context)
                        .textTheme
                        .headlineSmall
                        ?.copyWith(color: Colors.white),
                  ),
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildObject(PenthouseObject obj, double w, double h) {
    final left = (w * obj.x).clamp(0.0, w - 120);
    final top = (h * obj.y).clamp(0.0, h - 120);
    return Positioned(
      left: left,
      top: top,
      child: GestureDetector(
        onTap: () => _goToObject(obj),
        child: Container(
          width: 110,
          padding: const EdgeInsets.all(10),
          decoration: BoxDecoration(
            color: Colors.white.withOpacity(0.08),
            borderRadius: BorderRadius.circular(18),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(obj.icon, color: Colors.white, size: 28),
              const SizedBox(height: 6),
              Text(
                obj.label,
                textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white, fontSize: 12),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
