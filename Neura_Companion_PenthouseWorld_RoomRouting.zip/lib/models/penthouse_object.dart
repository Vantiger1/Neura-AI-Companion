import 'package:flutter/material.dart';

/// A tappable "object" in the Penthouse (module world).
///
/// Positions are normalized (0..1) so layouts scale across screens.
class PenthouseObject {
  final String id;
  final String label;
  final String roomId;
  final double x;
  final double y;
  final IconData icon;
  final WidgetBuilder builder;

  const PenthouseObject({
    required this.id,
    required this.label,
    required this.roomId,
    required this.x,
    required this.y,
    required this.icon,
    required this.builder,
  });
}
