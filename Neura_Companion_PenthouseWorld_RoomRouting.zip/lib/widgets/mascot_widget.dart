import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';
import '../models/ai_avatar.dart';
import '../services/avatar_service.dart';

class MascotWidget extends StatefulWidget {
  @override
  _MascotWidgetState createState() => _MascotWidgetState();
}

class _MascotWidgetState extends State<MascotWidget> {
  final _avatarService = AvatarService();
  AIAvatar? _avatar;

  @override
  void initState() {
    super.initState();
    _avatarService.getSelectedAvatar().then((a) {
      setState(() => _avatar = a);
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_avatar == null) return SizedBox.shrink();
    return Lottie.asset(
      _avatar!.assetPath,
      width: 100,
      height: 100,
      errorBuilder: (_, __, ___) {
        return Container(
          width: 100,
          height: 100,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            color: Colors.white.withOpacity(0.08),
            border: Border.all(color: Colors.white.withOpacity(0.10)),
          ),
          child: const Icon(Icons.auto_awesome, color: Colors.white),
        );
      },
    );
  }
}
