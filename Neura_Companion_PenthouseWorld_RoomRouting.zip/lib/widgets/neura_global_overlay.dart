import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

import '../services/intent_engine.dart';
import '../services/neura_event_bus.dart';
import '../services/neura_state_service.dart';
import '../services/penthouse_registry.dart';

/// Always-on overlay: mic + quick commands.
///
/// This is deliberately compact and non-intrusive: it gives Neura "agency"
/// without hijacking the app UI.
class NeuraGlobalOverlay extends StatefulWidget {
  final void Function(String route) onNavigate;

  const NeuraGlobalOverlay({super.key, required this.onNavigate});

  @override
  State<NeuraGlobalOverlay> createState() => _NeuraGlobalOverlayState();
}

class _NeuraGlobalOverlayState extends State<NeuraGlobalOverlay> {
  final stt.SpeechToText _stt = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  bool _listening = false;
  String _lastHeard = '';
  StreamSubscription? _statusSub;

  @override
  void initState() {
    super.initState();
    // Small quality-of-life: speak faster for assistant vibe.
    _tts.setSpeechRate(0.48);
  }

  @override
  void dispose() {
    _statusSub?.cancel();
    _tts.stop();
    super.dispose();
  }

  Future<void> _toggleListen() async {
    if (_listening) {
      await _stt.stop();
      setState(() => _listening = false);
      return;
    }
    final ok = await _stt.initialize();
    if (!ok) {
      NeuraEventBus.announce("Mic isn't available right now.");
      return;
    }

    setState(() => _listening = true);
    await _stt.listen(
      onResult: (res) {
        setState(() => _lastHeard = res.recognizedWords);
        if (res.finalResult) {
          _handleCommand(_lastHeard);
          setState(() => _listening = false);
        }
      },
    );
  }

  Future<void> _handleCommand(String text) async {
    final intent = IntentEngine.detect(text);
    if (intent.type == 'object' && intent.id != null) {
      final obj = PenthouseRegistry.byId(intent.id!);
      if (obj == null) return;

      await _speak('Taking you to ${obj.label}.');
      widget.onNavigate('penthouse');
      await NeuraStateService.setRoom('penthouse');
      NeuraEventBus.requestObject(obj.id);
      return;
    }

    // Tiny convenience routes.
    final q = text.toLowerCase();
    if (q.contains('home') || q.contains('penthouse')) {
      await _speak('Back to the Penthouse.');
      widget.onNavigate('penthouse');
      return;
    }
    if (q.contains('profile')) {
      await _speak('Opening your profile.');
      widget.onNavigate('profile');
      return;
    }

    await _speak("I heard you, but I don't have that wired yet. Try 'open journal' or 'dreams'.");
  }

  Future<void> _speak(String text) async {
    try {
      await _tts.stop();
      await _tts.speak(text);
    } catch (_) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    return Positioned(
      right: 14,
      bottom: 90,
      child: Material(
        color: Colors.transparent,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.end,
          children: [
            ValueListenableBuilder<String?>(
              valueListenable: NeuraEventBus.statusLine,
              builder: (_, status, __) {
                if (status == null || status.trim().isEmpty) return const SizedBox.shrink();
                return Container(
                  margin: const EdgeInsets.only(bottom: 10),
                  padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
                  decoration: BoxDecoration(
                    color: Colors.black.withOpacity(0.55),
                    borderRadius: BorderRadius.circular(18),
                    border: Border.all(color: Colors.white.withOpacity(0.08)),
                  ),
                  child: Text(
                    status,
                    style: const TextStyle(color: Colors.white, fontSize: 12),
                  ),
                );
              },
            ),
            FloatingActionButton(
              heroTag: 'neura_mic',
              onPressed: _toggleListen,
              child: Icon(_listening ? Icons.stop : Icons.mic),
            ),
          ],
        ),
      ),
    );
  }
}
