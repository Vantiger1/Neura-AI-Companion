import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'dart:convert';
import 'dart:math';

import 'screens/sign_in_screen.dart';
import 'screens/privacy_agreement_screen.dart';
import 'screens/analytics_screen.dart';
import 'screens/feed_screen.dart';
import 'screens/challenge_list_screen.dart';
import 'screens/leaderboard_screen.dart';
import 'screens/profile_screen.dart';
import 'screens/penthouse_screen.dart';
import 'services/auth_service.dart';
import 'services/neura_state_service.dart';
import 'widgets/neura_global_overlay.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await Firebase.initializeApp();
  } catch (_) {
    // Allows running without Firebase options during local/dev.
  }
  await Hive.initFlutter();

  // Hive encryption key setup
  final secureStorage = FlutterSecureStorage();
  String? key = await secureStorage.read(key: 'hive_key');
  if (key == null) {
    key = base64UrlEncode(List<int>.generate(32, (_) => Random.secure().nextInt(256)));
    await secureStorage.write(key: 'hive_key', value: key);
  }
  final encryptionKey = base64Url.decode(key);
  await Hive.openBox('usage_entries', encryptionCipher: HiveAesCipher(encryptionKey));
  await NeuraStateService.init(encryptionKey);

  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final _auth = AuthService();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura Companion',
      theme: ThemeData.light(),
      darkTheme: ThemeData.dark(),
      initialRoute: '/',
      routes: {
        '/': (_) => AuthWidget(),
      },
    );
  }
}

class AuthWidget extends StatefulWidget {
  @override
  _AuthWidgetState createState() => _AuthWidgetState();
}

class _AuthWidgetState extends State<AuthWidget> {
  @override
  void initState() {
    super.initState();
    AuthService.onAuthStateChanged.listen((user) {
      setState(() {});
    });
  }

  @override
  Widget build(BuildContext context) {
    final user = AuthService.currentUser;
    if (user == null) return SignInScreen();
    return FutureBuilder<bool>(
      future: PrivacyAgreementScreen.isAccepted(),
      builder: (_, snap) {
        if (!snap.hasData) return SizedBox.shrink();
        return snap.data! ? MainNav() : PrivacyAgreementScreen();
      },
    );
  }
}

class MainNav extends StatefulWidget {
  @override
  _MainNavState createState() => _MainNavState();
}

class _MainNavState extends State<MainNav> {
  int _idx = 0;
  final _tabs = [
    PenthouseScreen(),
    AnalyticsScreen(),
    FeedScreen(),
    ChallengeListScreen(),
    LeaderboardScreen(),
    ProfileScreen(),
  ];
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          _tabs[_idx],
          NeuraGlobalOverlay(
            onNavigate: (route) {
              // Keep it simple: map routes to tabs.
              final idx = {
                'penthouse': 0,
                'analytics': 1,
                'feed': 2,
                'challenges': 3,
                'leaderboard': 4,
                'profile': 5,
              }[route];
              if (idx != null) setState(() => _idx = idx);
            },
          ),
        ],
      ),
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _idx,
        onTap: (i) => setState(() => _idx = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.bar_chart), label: 'Analytics'),
          BottomNavigationBarItem(icon: Icon(Icons.feed), label: 'Feed'),
          BottomNavigationBarItem(icon: Icon(Icons.flag), label: 'Challenges'),
          BottomNavigationBarItem(icon: Icon(Icons.emoji_events), label: 'Leaderboard'),
          BottomNavigationBarItem(icon: Icon(Icons.person), label: 'Profile'),
        ],
      ),
    );
  }
}
