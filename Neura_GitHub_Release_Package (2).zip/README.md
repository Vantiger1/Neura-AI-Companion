
# Neura AI Companion Module

A complete Flutter implementation of a personalized, evolving AI mascot designed for emotional support, dream tracking, humor, and productivity.

## Features

- Animated glowing avatar with emotion engine
- Voice personality with quiet mode and ambient speech
- Mood and dream tracking with monthly playback
- Full joke system with ratings and favorites
- Billing logic for add-on unlocks
- Growth memory and music learning
- Nighttime dream mode and interpretation
- Calendar + journal + dream cinema

## Usage

1. Drop the `lib/neura/` folder into your Flutter project.
2. Import and initialize `NeuraManager`.
3. Add desired Neura widgets (e.g., `NeuraAvatar`, `NeuraJokePanelAnimated`, `DreamReplayLauncherWidget`) to your UI.
4. (Optional) Setup Firebase and `in_app_purchase` for full functionality.

See the `example/` folder to get started quickly.

---

This is the most advanced AI companion module for Flutter to date.
