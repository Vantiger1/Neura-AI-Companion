import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: Scaffold(
      backgroundColor: Colors.black,
      body: Center(
        child: Text('Neura is ready to be your companion!', style: TextStyle(color: Colors.white)),
      ),
    ),
  ));
}